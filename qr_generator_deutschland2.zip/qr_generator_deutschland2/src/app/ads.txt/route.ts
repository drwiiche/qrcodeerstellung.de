import { getSettings } from '@/src/lib/settings';

/**
 * GET /ads.txt — AdSense seller authorization, generated from the dashboard's
 * configured AdSense provider. Empty body until a publisher ID is stored.
 * Format: google.com, pub-XXXXXXXXXXXXXXXX, DIRECT, f08c47fec0942fa0
 */
export async function GET() {
  const settings = await getSettings();
  const adsense = settings.ads.providers.find(
    (p) => p.enabled && p.type === 'adsense' && p.clientId.trim()
  );
  const publisherId = adsense?.clientId.trim().replace(/^ca-/, '') || '';
  const body = publisherId ? `google.com, ${publisherId}, DIRECT, f08c47fec0942fa0\n` : '';
  return new Response(body, {
    status: 200,
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  });
}