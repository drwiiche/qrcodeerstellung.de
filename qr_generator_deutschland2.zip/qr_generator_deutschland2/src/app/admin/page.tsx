import type { Metadata } from 'next';
import { AdminDashboard } from '@/src/components/admin/AdminDashboard';

export const metadata: Metadata = {
  title: 'Admin-Dashboard | QR-Generator Deutschland',
  robots: { index: false, follow: false },
};

export default function AdminPage() {
  return <AdminDashboard />;
}
