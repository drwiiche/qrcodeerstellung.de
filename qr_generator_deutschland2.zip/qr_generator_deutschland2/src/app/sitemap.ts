import type { MetadataRoute } from 'next';
import { SITE_URL } from '@/src/lib/site';
import { getAllPosts } from '@/src/lib/posts';
import { ALL_HUBS } from '@/src/data/seo-pages';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const lastModified = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${SITE_URL}/`, lastModified, changeFrequency: 'daily', priority: 1 },
    { url: `${SITE_URL}/anleitungen`, lastModified, changeFrequency: 'monthly', priority: 0.8 },
    { url: `${SITE_URL}/blog`, lastModified, changeFrequency: 'weekly', priority: 0.9 },
    { url: `${SITE_URL}/ueber-uns`, lastModified, changeFrequency: 'yearly', priority: 0.5 },
    { url: `${SITE_URL}/datenschutz`, lastModified, changeFrequency: 'yearly', priority: 0.3 },
    { url: `${SITE_URL}/agb`, lastModified, changeFrequency: 'yearly', priority: 0.3 },
    { url: `${SITE_URL}/impressum`, lastModified, changeFrequency: 'yearly', priority: 0.4 },
  ];

  const hubRoutes: MetadataRoute.Sitemap = ALL_HUBS.map((hub) => ({
    url: `${SITE_URL}${hub.slug === 'auf' ? '/qr-codes-auf' : `/qr-codes-fuer/${hub.slug}`}`,
    lastModified,
    changeFrequency: 'weekly',
    priority: 0.8,
  }));

  const subRoutes: MetadataRoute.Sitemap = ALL_HUBS.flatMap((hub) =>
    hub.subs.map((sub) => ({
      url: `${SITE_URL}${hub.slug === 'auf' ? '/qr-codes-auf' : `/qr-codes-fuer/${hub.slug}`}/${sub.slug}`,
      lastModified,
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    }))
  );

  const posts = await getAllPosts();
  const postRoutes: MetadataRoute.Sitemap = posts.map((p) => ({
    url: `${SITE_URL}/blog/${p.slug}`,
    lastModified: new Date(`${p.date}T00:00:00`),
    changeFrequency: 'monthly' as const,
    priority: 0.6,
  }));

  return [...staticRoutes, ...hubRoutes, ...subRoutes, ...postRoutes];
}