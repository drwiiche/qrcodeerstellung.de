import type { Metadata, Viewport } from 'next';
import { Instrument_Sans, JetBrains_Mono } from 'next/font/google';
import { SITE_URL } from '@/src/lib/site';
import '../index.css';

const instrument = Instrument_Sans({
  subsets: ['latin'],
  display: 'swap',
  style: ['normal', 'italic'],
  variable: '--font-instrument',
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-jetbrains',
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: 'QR-Generator Deutschland – Kostenlos QR-Codes für Zuhause & Home-Office',
  description:
    'Erstellen Sie hochauflösende QR-Codes für Zuhause & Alltag in Deutschland: Fritz!Box Gäste-WLAN, SEPA GiroCode Banküberweisung, vCard Visitenkarte, Paketabstellort & mehr.',
  keywords: [
    'QR Code Generator Deutschland',
    'WLAN QR Code Fritzbox',
    'GiroCode SEPA Überweisung erstellen',
    'vCard Visitenkarte QR',
    'QR Code für Zuhause',
  ],
  applicationName: 'QR-Code Generator',
  manifest: '/manifest.json',
  icons: {
    icon: [
      { url: '/favicon.svg', type: 'image/svg+xml' },
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
    ],
    shortcut: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    type: 'website',
    locale: 'de_DE',
    siteName: 'QR-Generator Deutschland',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'QR-Generator Deutschland – Vorschau und Generator',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#000000',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de" className={`${instrument.variable} ${jetbrains.variable}`}>
      <body className="bg-white text-black antialiased selection:bg-[#FF5832] selection:text-white">
        {children}
      </body>
    </html>
  );
}
