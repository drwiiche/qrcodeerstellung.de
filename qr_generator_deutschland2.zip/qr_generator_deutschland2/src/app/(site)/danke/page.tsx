import type { Metadata } from 'next';
import { ThankYouPage } from '../../../components/ThankYouPage';

export const metadata: Metadata = {
  title: 'Vielen Dank – Ihr QR-Code ist druckfertig | QR-Generator Deutschland',
  description:
    'Ihr QR-Code wurde erfolgreich generiert! Beachten Sie unsere Druck-Tipps für deutsche Haushalte und Visitenkarten für 100% Scanbarkeit.',
  alternates: { canonical: '/danke' },
  robots: { index: false, follow: true },
};

export default function DankePage() {
  return <ThankYouPage />;
}
