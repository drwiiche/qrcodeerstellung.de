import type { Metadata } from 'next';
import { MATERIALS_HUB } from '@/src/data/seo-pages';
import { SeoLandingPage } from '../../../components/SeoLandingPage';

export const revalidate = 300;

export const metadata: Metadata = {
  title: MATERIALS_HUB.metaTitle,
  description: MATERIALS_HUB.metaDescription,
  alternates: { canonical: '/qr-codes-auf' },
};

export default function MaterialsHubPage() {
  return <SeoLandingPage hub={MATERIALS_HUB} />;
}