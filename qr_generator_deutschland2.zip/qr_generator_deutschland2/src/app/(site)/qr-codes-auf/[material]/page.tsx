import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { MATERIALS_HUB, findSub } from '@/src/data/seo-pages';
import { SeoLandingPage } from '../../../../components/SeoLandingPage';

export const revalidate = 300;

export function generateStaticParams() {
  return MATERIALS_HUB.subs.map((s) => ({ material: s.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ material: string }>;
}): Promise<Metadata> {
  const { material } = await params;
  const page = findSub(MATERIALS_HUB, material);
  if (!page) return { title: 'Nicht gefunden' };
  return {
    title: `${page.metaTitle} | QR-Generator Deutschland`,
    description: page.metaDescription,
    alternates: { canonical: `/qr-codes-auf/${page.slug}` },
  };
}

export default async function MaterialPage({
  params,
}: {
  params: Promise<{ material: string }>;
}) {
  const { material } = await params;
  const page = findSub(MATERIALS_HUB, material);
  if (!page) notFound();
  return <SeoLandingPage hub={MATERIALS_HUB} sub={page} />;
}