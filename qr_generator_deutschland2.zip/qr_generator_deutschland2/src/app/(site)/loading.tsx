/** Route-level loading state shown while the generator page hydrates (item 12). */
export default function Loading() {
  return (
    <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="max-w-3xl mb-10 sm:mb-14 animate-pulse">
        <div className="h-10 sm:h-14 w-3/4 bg-zinc-100 rounded-2xl mb-4" />
        <div className="h-4 w-1/2 bg-zinc-100 rounded-full" />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 xl:col-span-8 space-y-6">
          <div className="bg-white rounded-[16px] border border-zinc-200 p-6 min-h-[320px] animate-pulse" />
          <div className="bg-white rounded-[16px] border border-zinc-200 p-6 min-h-[240px] animate-pulse" />
        </div>
        <div className="lg:col-span-5 xl:col-span-4">
          <div className="bg-[#F4F4F5] rounded-[16px] border border-zinc-200 min-h-[380px] animate-pulse" />
        </div>
      </div>
    </main>
  );
}
