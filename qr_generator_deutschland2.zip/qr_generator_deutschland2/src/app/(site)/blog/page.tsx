import type { Metadata } from 'next';
import Link from 'next/link';
import { getAllPosts } from '@/src/lib/posts';
import { AdSlot } from '../../../components/AdSlot';
import { ArrowRight, Clock } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Blog & Anleitungen | QR-Codes im Einsatz – QR-Generator Deutschland',
  description:
    'Praxisnahe Anleitungen und Strategien rund um QR-Codes in Deutschland: Gastronomie, Marketing, Technik-Guides, Datenschutz und kreative Anwendungsideen – Schritt für Schritt erklärt.',
  alternates: { canonical: '/blog' },
};

export const revalidate = 300;

export default async function BlogIndexPage() {
  const posts = await getAllPosts();

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <nav aria-label="Brotkrumen" className="text-xs text-zinc-400 mb-6">
        <Link href="/" className="hover:text-black transition">
          Startseite
        </Link>
        <span className="mx-1.5">/</span>
        <span className="text-zinc-600">Blog</span>
      </nav>

      {/* CTA above the fold */}
      <div className="max-w-3xl mb-10 sm:mb-12">
        <h1 className="text-3xl sm:text-5xl font-semibold tracking-tight text-black mb-3 leading-[1.05]">
          QR-Codes verstehen, richtig einsetzen
        </h1>
        <p className="text-sm sm:text-lg text-zinc-500 leading-relaxed max-w-2xl">
          Anleitungen, Vergleiche und Strategien aus der Praxis: So erstellen Sie QR-Codes, die
          funktionieren – und wie Sie sie in Gastronomie, Marketing und Alltag sinnvoll nutzen.
        </p>
        <div className="mt-7 flex flex-wrap items-center gap-3">
          <Link
            href="/"
            className="px-6 py-3 rounded-full bg-black text-white font-semibold text-sm hover:bg-zinc-800 flex items-center gap-2 transition"
          >
            Zum QR-Code Generator
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            href="/anleitungen"
            className="px-5 py-3 rounded-full bg-white hover:bg-[#F4F4F5] text-black font-semibold text-sm border border-zinc-200 flex items-center gap-2 transition"
          >
            Ausführliche Anleitung
          </Link>
        </div>
      </div>

      <AdSlot position="below-hero" />

      {posts.length === 0 ? (
        <div className="rounded-[16px] border border-zinc-200 bg-white p-10 text-center text-sm text-zinc-500">
          Noch keine Beiträge veröffentlicht.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {posts.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="group flex flex-col bg-white rounded-[16px] border border-zinc-200 p-6 hover:border-zinc-300 transition"
            >
              <div className="flex items-center gap-2 text-[11px] text-zinc-400 mb-3">
                <span className="font-semibold text-[#FF5832]">{post.categoryLabel}</span>
                <span>·</span>
                <time dateTime={post.date}>
                  {new Date(`${post.date}T00:00:00`).toLocaleDateString('de-DE', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}
                </time>
              </div>
              <h2 className="text-base font-semibold text-black leading-snug tracking-tight mb-2 group-hover:text-[#FF5832] transition">
                {post.title}
              </h2>
              <p className="text-sm text-zinc-500 leading-relaxed flex-1">{post.excerpt}</p>
              <div className="mt-4 pt-4 border-t border-zinc-100 flex items-center justify-between text-xs text-zinc-400">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  {post.readingMinutes} Min. Lesezeit
                </span>
                <span className="text-black font-semibold flex items-center gap-1">
                  Weiterlesen
                  <ArrowRight className="w-3.5 h-3.5 transition group-hover:translate-x-0.5" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}