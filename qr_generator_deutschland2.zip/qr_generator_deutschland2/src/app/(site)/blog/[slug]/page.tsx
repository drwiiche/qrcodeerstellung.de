import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getAllPosts, getPost, getRelatedPosts, categoryLabel } from '@/src/lib/posts';
import { AdSlot } from '../../../../components/AdSlot';
import { JsonLd } from '../../../../components/JsonLd';
import { SITE_URL } from '@/src/lib/site';
import { ArrowRight, Clock } from 'lucide-react';

export const revalidate = 300;

type Params = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  const posts = await getAllPosts();
  return posts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) return { title: 'Beitrag nicht gefunden' };
  return {
    title: `${post.title} | QR-Generator Deutschland`,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      type: 'article',
      title: post.title,
      description: post.excerpt,
      publishedTime: post.date,
      tags: [post.categoryLabel],
      url: `/blog/${post.slug}`,
      siteName: 'QR-Generator Deutschland',
      locale: 'de_DE',
      images: [{ url: '/og-image.png', width: 1200, height: 630 }],
    },
  };
}

export default async function BlogPostPage({ params }: Params) {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) notFound();

  const related = await getRelatedPosts(post.slug, post.category, 3);
  const published = new Date(`${post.date}T00:00:00`).toLocaleDateString('de-DE', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  const articleSchema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: post.title,
    description: post.excerpt,
    datePublished: post.date,
    inLanguage: 'de-DE',
    image: `${SITE_URL}/og-image.png`,
    mainEntityOfPage: `${SITE_URL}/blog/${post.slug}`,
    author: { '@type': 'Organization', name: 'QR-Generator Deutschland', url: SITE_URL },
    publisher: {
      '@type': 'Organization',
      name: 'QR-Generator Deutschland',
      logo: { '@type': 'ImageObject', url: `${SITE_URL}/favicon.svg` },
    },
  };

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <JsonLd data={articleSchema} />
      <div className="max-w-3xl mx-auto">
        <nav aria-label="Brotkrumen" className="text-xs text-zinc-400 mb-6">
          <Link href="/" className="hover:text-black transition">
            Startseite
          </Link>
          <span className="mx-1.5">/</span>
          <Link href="/blog" className="hover:text-black transition">
            Blog
          </Link>
          <span className="mx-1.5">/</span>
          <span className="text-zinc-600 line-clamp-1">{post.title}</span>
        </nav>

        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-black mb-4 leading-[1.08]">
          {post.title}
        </h1>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-400 mb-8 pb-6 border-b border-zinc-200">
          <time dateTime={post.date}>{published}</time>
          <Link href="/blog" className="text-[#FF5832] font-semibold hover:text-[#B31D00] transition">
            {post.categoryLabel}
          </Link>
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            {post.readingMinutes} Min. Lesezeit
          </span>
        </div>

        {post.excerpt && (
          <p className="text-base sm:text-lg text-zinc-500 leading-relaxed mb-8">
            {post.excerpt}
          </p>
        )}

        <AdSlot position="below-hero" />

        <article
          className="article-body"
          dangerouslySetInnerHTML={{ __html: post.html }}
        />

        {/* CTA after the article */}
        <div className="mt-10 rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-6 sm:p-8">
          <h2 className="text-lg font-semibold text-black tracking-tight mb-1.5">
            Selber machen: QR-Code in 30 Sekunden erstellen
          </h2>
          <p className="text-sm text-zinc-500 mb-4">
            Kostenlos, ohne Anmeldung und vollständig in Ihrem Browser – direkt loslegen.
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-black text-white text-sm font-semibold hover:bg-zinc-800 transition"
          >
            Zum QR-Code Generator
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <AdSlot position="mid-content" />

        {related.length > 0 && (
          <section className="mt-12" aria-labelledby="related-heading">
            <h2 id="related-heading" className="text-base font-semibold text-black tracking-tight mb-4">
              Weitere Beiträge
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {related.map((p) => (
                <Link
                  key={p.slug}
                  href={`/blog/${p.slug}`}
                  className="group flex flex-col bg-white rounded-[16px] border border-zinc-200 p-5 hover:border-zinc-300 transition"
                >
                  <span className="text-[11px] font-semibold text-[#FF5832] mb-2">
                    {categoryLabel(p.category)}
                  </span>
                  <span className="text-sm font-semibold text-black leading-snug group-hover:text-[#FF5832] transition">
                    {p.title}
                  </span>
                  <span className="mt-2 text-xs text-zinc-400">{p.readingMinutes} Min. Lesezeit</span>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}