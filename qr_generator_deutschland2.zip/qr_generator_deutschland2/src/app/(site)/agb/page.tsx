import type { Metadata } from 'next';
import { TermsPage } from '../../../components/TermsPage';

export const metadata: Metadata = {
  title: 'Allgemeine Nutzungsbedingungen (AGB) | QR-Generator Deutschland',
  description:
    'Nutzungsbedingungen und Gewährleistungshinweise für die kostenlose Erstellung von QR-Codes für private und gewerbliche Zwecke.',
  alternates: { canonical: '/agb' },
};

export default function AgbPage() {
  return <TermsPage />;
}
