import type { Metadata } from 'next';
import { PrivacyPolicyPage } from '../../../components/PrivacyPolicyPage';

export const metadata: Metadata = {
  title: 'Datenschutzerklärung (DSGVO-konform) | QR-Generator Deutschland',
  description:
    'Transparenter Datenschutz nach DSGVO: Alle QR-Codes werden 100% clientseitig im Browser erzeugt. Keine Speicherung von Passwörtern oder Kontodaten.',
  alternates: { canonical: '/datenschutz' },
};

export default function DatenschutzPage() {
  return <PrivacyPolicyPage />;
}
