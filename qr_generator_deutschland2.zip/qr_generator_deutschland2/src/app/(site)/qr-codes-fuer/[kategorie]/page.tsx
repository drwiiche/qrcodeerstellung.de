import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { HUBS, findHub } from '@/src/data/seo-pages';
import { SeoLandingPage } from '../../../../components/SeoLandingPage';

export const revalidate = 300;

export function generateStaticParams() {
  return HUBS.filter((h) => h.slug !== 'auf').map((h) => ({ kategorie: h.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ kategorie: string }>;
}): Promise<Metadata> {
  const { kategorie } = await params;
  const hub = findHub(kategorie);
  if (!hub || hub.slug === 'auf') return { title: 'Nicht gefunden' };
  return {
    title: `${hub.metaTitle} | QR-Generator Deutschland`,
    description: hub.metaDescription,
    alternates: { canonical: `/qr-codes-fuer/${hub.slug}` },
  };
}

export default async function SeoHubPage({
  params,
}: {
  params: Promise<{ kategorie: string }>;
}) {
  const { kategorie } = await params;
  const hub = findHub(kategorie);
  if (!hub || hub.slug === 'auf') notFound();
  return <SeoLandingPage hub={hub} />;
}