import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { HUBS, findHub, findSub } from '@/src/data/seo-pages';
import { SeoLandingPage } from '../../../../../components/SeoLandingPage';

export const revalidate = 300;

export function generateStaticParams() {
  return HUBS.filter((h) => h.slug !== 'auf').flatMap((h) =>
    h.subs.map((s) => ({ kategorie: h.slug, sub: s.slug }))
  );
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ kategorie: string; sub: string }>;
}): Promise<Metadata> {
  const { kategorie, sub } = await params;
  const hub = findHub(kategorie);
  const page = hub ? findSub(hub, sub) : undefined;
  if (!hub || !page || hub.slug === 'auf') return { title: 'Nicht gefunden' };
  return {
    title: `${page.metaTitle} | QR-Generator Deutschland`,
    description: page.metaDescription,
    alternates: { canonical: `/qr-codes-fuer/${hub.slug}/${page.slug}` },
  };
}

export default async function SeoSubPage({
  params,
}: {
  params: Promise<{ kategorie: string; sub: string }>;
}) {
  const { kategorie, sub } = await params;
  const hub = findHub(kategorie);
  const page = hub ? findSub(hub, sub) : undefined;
  if (!hub || !page || hub.slug === 'auf') notFound();
  return <SeoLandingPage hub={hub} sub={page} />;
}