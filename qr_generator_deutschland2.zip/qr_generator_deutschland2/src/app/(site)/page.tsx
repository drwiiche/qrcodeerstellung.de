import type { Metadata } from 'next';
import { SITE_URL } from '@/src/lib/site';
import { HomeView } from '@/src/components/HomeView';

export const metadata: Metadata = {
  title: 'QR-Generator Deutschland – Kostenlos QR-Codes für Zuhause & Home-Office',
  description:
    'Erstellen Sie hochauflösende QR-Codes für Zuhause & Alltag in Deutschland: Fritz!Box Gäste-WLAN, SEPA GiroCode Banküberweisung, vCard Visitenkarte, Paketabstellort & mehr.',
  alternates: {
    canonical: '/',
  },
  openGraph: {
    url: '/',
    title: 'QR-Generator Deutschland – Schnelle QR-Codes für Zuhause & Office',
    description:
      'Kostenloser QR-Code Generator für Deutschland: WLAN-Passwort teilen, SEPA GiroCode Überweisung, vCard, Haustür-Paketbox. Sofort als PNG, SVG oder druckfertig herunterladen.',
  },
};

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'WebApplication',
  name: 'QR-Generator Deutschland',
  applicationCategory: 'UtilitiesApplication',
  operatingSystem: 'All',
  inLanguage: ['de-DE'],
  url: SITE_URL,
  description:
    'Erstellen Sie hochauflösende QR-Codes für Zuhause und Alltag in Deutschland: WLAN-Gästezugang, SEPA GiroCode Überweisungen, vCards und Abstellgenehmigungen.',
  offers: {
    '@type': 'Offer',
    price: '0',
    priceCurrency: 'EUR',
  },
  featureList: [
    'Fritz!Box & Speedport kompatible WLAN QR-Codes',
    'Offizieller EPC / SEPA GiroCode für deutsche Banking-Apps',
    'vCard 3.0 & 4.0 digitale Visitenkarten',
    'Haustür Abstell-Hinweise für DHL, Hermes, Amazon',
    'Vektor SVG, Ultra-HD PNG und A4 Druckvorlage',
  ],
};

export default function HomePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, '\\u003c') }}
      />
      <HomeView />
    </>
  );
}
