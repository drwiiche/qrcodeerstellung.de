import type { Metadata } from 'next';
import Link from 'next/link';
import { getSettings } from '@/src/lib/settings';
import { ShieldCheck, Heart, MapPin, Mail, Phone } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Über uns | QR-Generator Deutschland',
  description:
    'Wer hinter dem QR-Code Generator Deutschland steckt: unsere Motivation, die Prinzipien (kostenlos, datensparsam, ohne Anmeldung) und wie Sie uns erreichen.',
  alternates: { canonical: '/ueber-uns' },
};

export const revalidate = 300;

export default async function UeberUnsPage() {
  const settings = await getSettings();
  const c = settings.contact;

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="max-w-3xl mx-auto">
        <nav aria-label="Brotkrumen" className="text-xs text-zinc-400 mb-6">
          <Link href="/" className="hover:text-black transition">
            Startseite
          </Link>
          <span className="mx-1.5">/</span>
          <span className="text-zinc-600">Über uns</span>
        </nav>

        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-black mb-5 leading-[1.08]">
          Über QR-Generator Deutschland
        </h1>

        <div className="article-body">
          <p className="text-base sm:text-lg text-zinc-500 leading-relaxed">
            Wir bauen den QR-Code Generator, den wir selbst gern benutzt hätten: schnell,
            kostenlos, ohne Anmeldung – und ohne, dass sensible Daten unser Gerät verlassen.
          </p>

          <h2>Warum dieser Generator existiert</h2>
          <p>
            QR-Codes gehören in Deutschland inzwischen zum Alltag – vom Gäste-WLAN der Ferienwohnung
            über den SEPA-GiroCode der Hausverwaltung bis zur digitalen Speisekarte. Was fehlte, war
            ein Werkzeug, das genau diese Anwendungsfälle kennt und dabei auf die Dinge achtet, die
            hierzulande zählen: Datenschutz nach TTDSG und DSGVO, verständliche deutsche Sprache
            und Dateien, die auch für den professionellen Druck taugen.
          </p>

          <h2>Unsere Prinzipien</h2>
          <ul>
            <li>
              <strong>Alles bleibt lokal:</strong> Jeder QR-Code wird direkt im Browser Ihres
              Geräts berechnet. WLAN-Passwörter, IBANen und Kontaktdaten werden nie an unsere
              Server übertragen – es gibt technisch gar keinen Upload.
            </li>
            <li>
              <strong>Kostenlos und dauerhaft:</strong> Keine Konten, keine Testphasen, keine
              Abo-Fallen. Codes verfallen nicht, weil kein Server dahintersteht.
            </li>
            <li>
              <strong>Offene Formate:</strong> Wir nutzen die etablierten Standards (WIFI-Typ,
              vCard, EPC-GiroCode, Kalender-Format) – Ihre Codes funktionieren mit jeder
              Smartphone-Kamera und jeder Banking-App.
            </li>
            <li>
              <strong>Datensparsame Statistik:</strong> Wir messen nur, was wir brauchen, und
              erstens nach Ihrer Zustimmung im Cookie-Banner. Details in der{' '}
              <Link href="/datenschutz">Datenschutzerklärung</Link>.
            </li>
          </ul>

          <h2>Für wen wir bauen</h2>
          <p>
            Für Haushalte mit Ferienwohnung und Gäste-WLAN, für Vereine, die ihre Einladungen digital
            ergänzen, für Handwerksbetriebe und Cafés, für Schulen und für alle, die einen QR-Code
            brauchen, der einfach funktioniert. Die Anwendungsfälle haben wir in unseren{' '}
            <Link href="/blog">Blogbeiträgen</Link> und auf den Seiten zu{' '}
            <Link href="/qr-codes-fuer/unternehmen">QR-Codes für Unternehmen</Link>,{' '}
            <Link href="/qr-codes-fuer/schulen">für Schulen</Link> und{' '}
            <Link href="/qr-codes-fuer/veranstaltungen">für Veranstaltungen</Link> dokumentiert.
          </p>

          <h2>Kontakt &amp; rechtliche Angaben</h2>
          <p>
            Sie erreichen uns zu Fragen, Feedback und Kooperationen über folgende Kanäle. Die
            gesetzlichen Angaben gemäß § 5 DDG finden Sie im{' '}
            <Link href="/impressum">Impressum</Link>.
          </p>
        </div>

        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-5 flex items-start gap-3">
            <MapPin className="w-4 h-4 text-[#FF5832] mt-0.5 shrink-0" />
            <div className="text-sm text-zinc-700">
              <p className="font-semibold text-black">{c.company}</p>
              <p>
                {c.street}
                <br />
                {c.zip} {c.city}
              </p>
            </div>
          </div>
          <div className="rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-5 flex flex-col gap-3 text-sm">
            <a href={`mailto:${c.email}`} className="flex items-center gap-2.5 text-zinc-700 hover:text-black transition">
              <Mail className="w-4 h-4 text-[#FF5832] shrink-0" />
              {c.email}
            </a>
            <a href={`tel:${c.phone.replace(/[^0-9+]/g, '')}`} className="flex items-center gap-2.5 text-zinc-700 hover:text-black transition">
              <Phone className="w-4 h-4 text-[#FF5832] shrink-0" />
              {c.phone}
            </a>
          </div>
        </div>

        <div className="mt-6 flex items-start gap-3 rounded-[16px] border border-zinc-200 p-5">
          <ShieldCheck className="w-4 h-4 text-[#FF5832] mt-0.5 shrink-0" />
          <p className="text-sm text-zinc-600 leading-relaxed">
            <span className="font-semibold text-black">Verantwortlich:</span> {c.responsiblePerson}{' '}
            · Alle Angaben gemäß § 5 DDG und § 18 Abs. 2 MStV. Fragen zum Datenschutz beantworten
            wir über die oben genannten Kontakte.
          </p>
        </div>

        <p className="mt-6 flex items-center gap-2 text-sm text-zinc-500">
          <Heart className="w-4 h-4 text-[#FF5832]" />
          Gebaut in Deutschland – für alle, die QR-Codes ohne Umwege einsetzen möchten.
        </p>
      </div>
    </div>
  );
}