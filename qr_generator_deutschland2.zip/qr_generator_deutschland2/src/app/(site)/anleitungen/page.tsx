import type { Metadata } from 'next';
import Link from 'next/link';
import { AdSlot } from '../../../components/AdSlot';

export const metadata: Metadata = {
  title: 'Anleitung: So funktioniert der QR-Code Generator | QR-Generator Deutschland',
  description:
    'Ausführliche Handbuch-Anleitung: alle QR-Typen (WLAN, vCard, SEPA GiroCode, SMS, Standort), Gestaltung, Druck-Regeln und häufige Fehler – Schritt für Schritt erklärt.',
  alternates: { canonical: '/anleitungen' },
};

const TYPES: { name: string; payload: string; use: string; href: string }[] = [
  {
    name: 'Webseite / URL',
    payload: 'https://…',
    use: 'Der Allrounder: führt zu jeder Adresse – Speisekarte, Formular, Produktseite. Ideal für Flyer, Plakate und Verpackungen.',
    href: '/?type=url',
  },
  {
    name: 'WLAN-Gastzugang',
    payload: 'WIFI:T:WPA;S:…;P:…;;',
    use: 'Speichert Netzname und Passwort im Standardformat: Gäste verbinden sich mit einem Scan statt Passwort zu tippen. Funktioniert mit Fritz!Box, Speedport und jedem Router.',
    href: '/?type=wifi',
  },
  {
    name: 'Visitenkarte (vCard)',
    payload: 'BEGIN:VCARD…',
    use: 'Überträgt den kompletten Kontakt in die Adressbuch-App des Smartphones – der Klassiker für Visitenkarten und Messeauftritte.',
    href: '/?type=vcard',
  },
  {
    name: 'SEPA GiroCode',
    payload: 'BCD… (EPC069-12)',
    use: 'Der offizielle Überweisungs-QR-Code nach EPC-Standard: Empfänger, IBAN und Betrag werden von jeder Banking-App in Deutschland übernommen.',
    href: '/?type=sepa',
  },
  {
    name: 'Termin / Kalender',
    payload: 'BEGIN:VEVENT…',
    use: 'Legt Veranstaltungen direkt im Smartphone-Kalender ab – inklusive Erinnerung. Perfekt für Vereinsfeste, Elternabende und Messen.',
    href: '/?type=event',
  },
  {
    name: 'Paket-Abstellort',
    payload: 'Text-Hinweis für Boten',
    use: 'Spezialisierter Textcode mit Empfänger, Ablageort und Dienstleistern (DHL, Hermes, Amazon, DPD) – der Bote liest ihn ohne App.',
    href: '/?type=delivery',
  },
  {
    name: 'SMS',
    payload: 'sms:+49…?body=…',
    use: 'Öffnet den SMS-Editor mit Empfänger und vorbereiteter Nachricht – Bestellanfragen am Tisch, auf Preisschildern oder Flyern.',
    href: '/?type=sms',
  },
  {
    name: 'WhatsApp',
    payload: 'https://wa.me/…',
    use: 'Startet direkt einen Chat über die wa.me-Adresse – für Beratung und Support ohne eigenen Nachrichtendienst.',
    href: '/?type=whatsapp',
  },
  {
    name: 'Standort auf Karte',
    payload: 'https://google.com/maps/…',
    use: 'Öffnet die Koordinaten in Google Maps – der zuverlässigste Wegweiser für Hauspartys, Hofeinfahrten und Veranstaltungsorte.',
    href: '/?type=standort',
  },
  {
    name: 'Telefonnummer',
    payload: 'tel:+49…',
    use: 'Ein Tap genügt: Der Code löst den Anruf aus – sinnvoll für Notdienste, Lieferdienste und Türschilder.',
    href: '/?type=phone',
  },
  {
    name: 'E-Mail',
    payload: 'mailto:…?subject=…',
    use: 'Bereitet eine vollständige E-Mail vor (Empfänger, Betreff, Text) – ideal für Support- und Anfrageadressen.',
    href: '/?type=email',
  },
  {
    name: 'Freitext',
    payload: 'Beliebiger Text',
    use: 'Speichert reinen Text: Zutatenlisten, Hinweise, WiFi-Pässe für Keller oder Ferienwohnung – offline lesbar.',
    href: '/?type=text',
  },
];

export default function AnleitungenPage() {
  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="max-w-3xl mx-auto">
        <nav aria-label="Brotkrumen" className="text-xs text-zinc-400 mb-6">
          <Link href="/" className="hover:text-black transition">
            Startseite
          </Link>
          <span className="mx-1.5">/</span>
          <span className="text-zinc-600">Anleitungen</span>
        </nav>

        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-black mb-5 leading-[1.08]">
          Anleitung: So erstellen Sie mit diesem Generator professionelle QR-Codes
        </h1>
        <p className="text-base sm:text-lg text-zinc-500 leading-relaxed">
          Dieses Handbuch erklärt den kompletten Weg – von der Wahl des richtigen QR-Typen über
          Gestaltung und Druck bis zu den häufigsten Fehlern. Es richtet sich an Einsteiger
          genauso wie an Teams, die QR-Codes im Betrieb einsetzen.
        </p>

        <AdSlot position="below-hero" />

        <div className="article-body">
          <h2>In sechs Schritten zum fertigen QR-Code</h2>
          <ol>
            <li>
              <strong>Ziel festlegen:</strong> Was soll nach dem Scan passieren – Webseite öffnen,
              Kontakt speichern, WLAN verbinden, überweisen? Daraus folgt der QR-Typ.
            </li>
            <li>
              <strong>QR-Typ wählen:</strong> Oben in der Typ-Auswahl oder direkt über die Links
              in dieser Anleitung den passenden Generator öffnen.
            </li>
            <li>
              <strong>Daten eingeben:</strong> Die Vorschau aktualisiert sich bei jedem Tastendruck
              live. Bei Formularen mit Prüfungen (z. B. SEPA-IBAN) weist der Generator direkt auf
              Fehler hin.
            </li>
            <li>
              <strong>Gestalten:</strong> Farben, Punkte-Form, Ecken, Logo und Rahmen anpassen.
              Achten Sie auf Kontrast –Details siehe unten.
            </li>
            <li>
              <strong>Herunterladen:</strong> PNG für Bildschirme und einfache Drucke, SVG als
              Vektorformat für professionelle Druckereien und große Formate.
            </li>
            <li>
              <strong>Testen:</strong> Vor jeder Auflage mit mindestens zwei verschiedenen
              Smartphones scannen – die Kamera-App reicht völlig.
            </li>
          </ol>

          <h2>Alle QR-Typen im Überblick</h2>
          <p>
            Jeder Typ erzeugt einen standardisierten Inhalt, den Smartphones ohne App verstehen:
          </p>
          <table>
            <thead>
              <tr>
                <th>Typ</th>
                <th>Format</th>
                <th>Wofür er geeignet ist</th>
              </tr>
            </thead>
            <tbody>
              {TYPES.map((t) => (
                <tr key={t.name}>
                  <td>
                    <Link href={t.href}>{t.name}</Link>
                  </td>
                  <td>
                    <code>{t.payload}</code>
                  </td>
                  <td>{t.use}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <h2>Statische vs. dynamic QR-Codes</h2>
          <p>
            Der Generator erzeugt <strong>statische Codes</strong>: Der Inhalt steckt vollständig
            im Code selbst oder in der hinterlegten URL. Sie sind dauerhaft gültig, ohne
            Registrierung nutzbar und werden niemals abgeschaltet. Der Nachteil: Der Inhalt lässt
            sich nach dem Druck nicht mehr ändern.
          </p>
          <p>
            Dynamische Codes speichern stattdessen eine Kurz-Adresse, auf der Sie das Ziel jederzeit
            ändern können – nötig für Tracking oder häufig wechselnde Ziele. Wenn Sie eine stabile
            Adresse (z.&nbsp;B. <code>ihre-website.de/speisekarte</code>) von Anfang an festlegen,
            brauchen Sie für die meisten Anwendungsfälle keinen dynamischen Code. Details dazu im
            Blog: <Link href="/blog/dynamische-vs-statische-qr-codes">Statische vs. dynamische QR-Codes</Link>.
          </p>

          <h2>Gestaltung: Farben, Logo und Rahmen</h2>
          <ul>
            <li>
              <strong>Kontrast ist Pflicht:</strong> Dunkle Module auf hellem Grund. Grau auf Creme
              scheitert bei vielen Kameras.
            </li>
            <li>
              <strong>Markenfarben mit Bedacht:</strong> Starke Farben funktionieren, solange der
              Hintergrund deutlich heller bleibt. Der Generator warnt bei zu geringem Kontrast.
            </li>
            <li>
              <strong>Logo bis 25 %:</strong> Logos im Zentrum sind möglich – bis etwa einem
              Viertel der Fläche und mit hoher Fehlerkorrektur (Stufe H), sonst wird der Code
              unlesbar.
            </li>
            <li>
              <strong>Rahmen mit Aufforderung:</strong> Ein Rahmentext wie „Hier scannen“ erhöht
              die Scan-Rate deutlich, weil Gäste sofort wissen, wofür der Code gut ist.
            </li>
          </ul>

          <h2>Drucken &amp; Platzieren: die Regeln</h2>
          <table>
            <thead>
              <tr>
                <th>Einsatzort</th>
                <th>Mindestgröße</th>
                <th>Betrachtungsabstand</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Visitenkarte, Tischkarte</td>
                <td>2,5 cm</td>
                <td>Armeslänge</td>
              </tr>
              <tr>
                <td>Flyer, Aushang</td>
                <td>4 cm</td>
                <td>30–50 cm</td>
              </tr>
              <tr>
                <td>Plakat, Fensterbeschriftung</td>
                <td>ab 12 cm</td>
                <td>1–3 m</td>
              </tr>
              <tr>
                <td>Fahrzeug, Außenschild</td>
                <td>ab 15 cm</td>
                <td>3–5 m</td>
              </tr>
            </tbody>
          </table>
          <ul>
            <li>
              <strong>Ruhezone:</strong> Der helle Rand um den Code darf nicht beschnitten oder mit
              Text gefüllt werden.
            </li>
            <li>
              <strong>Matte Oberfläche:</strong> Glänzendes Laminat und Glasscheiben erzeugen
              Spiegelungen – der häufigste Grund für Fehlscans.
            </li>
            <li>
              <strong>Handlungsaufforderung:</strong> Ohne Hinweistext sinkt die Nutzung
              erfahrungsgemäß drastisch. Formulieren Sie konkret: „Speisekarte öffnen“ statt
              „Mehr Infos“.
            </li>
          </ul>

          <h2>Häufige Fehler und wie Sie sie vermeiden</h2>
          <ul>
            <li>
              <strong>Zu kleine Codes:</strong> Unter 2,5 cm scheitern viele Geräte. Im Zweifel
              größer drucken.
            </li>
            <li>
              <strong>Beschädigte Module:</strong> Falzstellen, Stempel oder Klebeband auf der
              Codefläche machen Codes unlesbar.
            </li>
            <li>
              <strong>Zu lange Ziele-URLs:</strong> Sehr lange Adressen erzeugen dichte Codes, die
              schlechter scannen. Kurze URLs sind robuster.
            </li>
            <li>
              <strong>Kein Test:</strong> Scannen Sie jeden gedruckten Code – mit der Kamera-App
              und einer zweiten App.
            </li>
          </ul>
          <p>
            Die vollständige Diagnose-Liste finden Sie im Blog:{' '}
            <Link href="/blog/qr-code-fehler-haeufige-probleme">
              8 häufige Gründe, warum ein QR-Code nicht funktioniert
            </Link>
            .
          </p>

          <h2>Häufige Fragen zum Generator</h2>
          <p>
            <strong>Kostet die Nutzung etwas?</strong> Nein. Alle QR-Typen sind kostenlos, ohne
            Anmeldung und ohne Laufzeitbegrenzung.
          </p>
          <p>
            <strong>Werden meine Daten hochgeladen?</strong> Nein. Die Codes werden vollständig in
            Ihrem Browser berechnet – sensible Angaben wie WLAN-Passwörter oder IBANs verlassen
            Ihr Gerät nie.
          </p>
          <p>
            <strong>Kann ich Codes kommerziell verwenden?</strong> Ja. QR-Codes sind eine offene
            Norm; es gibt keine Lizenzgebühren für die Nutzung der Codes selbst.
          </p>
          <p>
            <strong>Funktionieren die Codes dauerhaft?</strong> Statische Codes verfallen nicht und
            benötigen keinen Server – vorausgesetzt, die hinterlegte Adresse bleibt erreichbar.
          </p>
        </div>

        <div className="mt-10 rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-6 sm:p-8">
          <h2 className="text-lg font-semibold text-black tracking-tight mb-1.5">
            Bereit? Ersten QR-Code erstellen
          </h2>
          <p className="text-sm text-zinc-500 mb-4">
            Kostenlos, direkt im Browser, in unter einer Minute – auch für WLAN, SEPA und vCard.
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-black text-white text-sm font-semibold hover:bg-zinc-800 transition"
          >
            Zum Generator
          </Link>
        </div>

        <AdSlot position="above-footer" />
      </div>
    </div>
  );
}