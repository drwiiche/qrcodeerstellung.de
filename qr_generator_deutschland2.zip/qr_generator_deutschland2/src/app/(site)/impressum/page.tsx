import type { Metadata } from 'next';
import { ImpressumPage } from '../../../components/ImpressumPage';

export const metadata: Metadata = {
  title: 'Impressum & Kontakt (§ 5 TMG) | QR-Generator Deutschland',
  description:
    'Gesetzliche Anbieterkennzeichnung nach § 5 TMG und § 18 Abs. 2 MStV für QR-Generator Deutschland mit Anschrift und Kontaktinformationen.',
  alternates: { canonical: '/impressum' },
};

export default function ImpressumRoute() {
  return <ImpressumPage />;
}
