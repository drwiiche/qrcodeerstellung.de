import type { Metadata } from 'next';
import { NotFoundPage } from '@/src/components/NotFoundPage';

export const metadata: Metadata = {
  title: '404 – Seite nicht gefunden | QR-Generator Deutschland',
  description:
    'Die angeforderte Seite existiert leider nicht. Kehren Sie zur Startseite des QR-Generators zurück.',
  robots: { index: false, follow: true },
};

export default function NotFound() {
  return (
    <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <NotFoundPage />
    </main>
  );
}
