import { NextResponse } from 'next/server';
import { isAdmin } from '@/src/lib/auth';
import { updatePost, deletePost, validatePostInput, SLUG_PATTERN } from '@/src/lib/posts';

type Params = { params: Promise<{ slug: string }> };

/** PUT /api/admin/posts/[slug] — update (and possibly rename) a post. */
export async function PUT(req: Request, { params }: Params) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  const { slug } = await params;
  if (!SLUG_PATTERN.test(slug)) {
    return NextResponse.json({ error: 'Ungültiger Slug.' }, { status: 400 });
  }
  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ungültiges JSON.' }, { status: 400 });
  }
  const parsed = validatePostInput(payload);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }
  try {
    await updatePost(slug, parsed.value);
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Speichern fehlgeschlagen.' }, { status: 404 });
  }
  return NextResponse.json({ ok: true, slug: parsed.value.slug });
}

/** DELETE /api/admin/posts/[slug] */
export async function DELETE(_req: Request, { params }: Params) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  const { slug } = await params;
  if (!SLUG_PATTERN.test(slug)) {
    return NextResponse.json({ error: 'Ungültiger Slug.' }, { status: 400 });
  }
  try {
    await deletePost(slug);
  } catch {
    return NextResponse.json({ error: 'Beitrag nicht gefunden.' }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}