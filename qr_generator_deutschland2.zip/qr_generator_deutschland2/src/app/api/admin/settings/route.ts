import { NextResponse } from 'next/server';
import { isAdmin } from '@/src/lib/auth';
import { getStoredSettings, updateSettings } from '@/src/lib/settings';

/** GET /api/admin/settings — full current settings (admin only). */
export async function GET() {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  const stored = await getStoredSettings();
  const { adminPasswordHash: _hash, sessionSecret: _secret, ...settings } = stored;
  return NextResponse.json({ settings, hasPassword: Boolean(stored.adminPasswordHash) });
}

/** PUT /api/admin/settings — partial update (admin only). */
export async function PUT(req: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  let patch: unknown;
  try {
    patch = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ungültiges JSON.' }, { status: 400 });
  }
  if (typeof patch !== 'object' || patch === null) {
    return NextResponse.json({ error: 'Ungültige Daten.' }, { status: 400 });
  }
  const allowed = (['siteName', 'domain', 'contact', 'ads', 'analytics'] as const).reduce(
    (acc, key) => {
      if (key in (patch as Record<string, unknown>)) {
        acc[key] = (patch as Record<string, unknown>)[key];
      }
      return acc;
    },
    {} as Record<string, unknown>
  );
  const updated = await updateSettings(allowed as never);
  return NextResponse.json({ ok: true, settings: updated });
}
