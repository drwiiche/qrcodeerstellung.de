import { NextRequest, NextResponse } from 'next/server';
import { isAdmin } from '@/src/lib/auth';
import { markMessage, deleteMessage } from '@/src/lib/messages';

type Ctx = { params: Promise<{ id: string }> };

/** PATCH /api/admin/messages/[id] — mark read/unread. Body: { read: boolean } */
export async function PATCH(req: NextRequest, { params }: Ctx) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  const { id } = await params;
  let read = false;
  try {
    const body = await req.json();
    read = Boolean(body.read);
  } catch {
    return NextResponse.json({ error: 'Ungültige Anfrage.' }, { status: 400 });
  }
  const found = await markMessage(id, read);
  if (!found) {
    return NextResponse.json({ error: 'Nachricht nicht gefunden.' }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}

/** DELETE /api/admin/messages/[id] — remove a message. */
export async function DELETE(_req: NextRequest, { params }: Ctx) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  const { id } = await params;
  const found = await deleteMessage(id);
  if (!found) {
    return NextResponse.json({ error: 'Nachricht nicht gefunden.' }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}
