import { NextResponse } from 'next/server';
import { isAdmin } from '@/src/lib/auth';
import { listMessages, countUnread } from '@/src/lib/messages';

/** GET /api/admin/messages — all contact messages, newest first (admin only). */
export async function GET() {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  const messages = await listMessages();
  return NextResponse.json(
    { messages, unread: countUnread(messages) },
    { headers: { 'Cache-Control': 'no-store' } }
  );
}
