import { NextResponse } from 'next/server';
import { clearSessionCookie } from '@/src/lib/auth';

/** POST /api/admin/logout — clears the admin session cookie. */
export async function POST() {
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
