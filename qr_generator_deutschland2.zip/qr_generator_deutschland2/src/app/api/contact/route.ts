import { NextRequest, NextResponse } from 'next/server';
import { addMessage, validateMessage, rateLimitOk } from '@/src/lib/messages';

/**
 * POST /api/contact — public contact form endpoint (Impressum page).
 * Body: { subject?, message, email?, company? }
 * `company` is a honeypot: bots that fill it get a fake success.
 */
export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ungültige Anfrage.' }, { status: 400 });
  }

  // Honeypot — pretend success, store nothing.
  if (typeof body.company === 'string' && body.company.trim() !== '') {
    return NextResponse.json({ ok: true });
  }

  const error = validateMessage({
    subject: body.subject,
    message: body.message,
    email: body.email,
  });
  if (error) {
    return NextResponse.json({ error }, { status: 400 });
  }

  const ip =
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  if (!rateLimitOk(ip)) {
    return NextResponse.json(
      { error: 'Zu viele Nachrichten in kurzer Zeit. Bitte versuchen Sie es später erneut.' },
      { status: 429 }
    );
  }

  await addMessage({
    subject: typeof body.subject === 'string' ? body.subject : '',
    message: body.message as string,
    email: typeof body.email === 'string' ? body.email : undefined,
  });

  return NextResponse.json({ ok: true });
}
