import { NextResponse } from 'next/server';
import { getSettings } from '@/src/lib/settings';

/** GET /api/settings — public site settings (ads, analytics, contact). */
export async function GET() {
  const settings = await getSettings();
  return NextResponse.json(settings, {
    headers: { 'Cache-Control': 'no-store' },
  });
}
