/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { formatWifiPayload } from './wifi';

test('formatWifiPayload formats standard WPA network', () => {
  const result = formatWifiPayload({
    ssid: 'FRITZ!Box 7590 Gast',
    password: 'secret-password-123',
    encryption: 'WPA',
    hidden: false,
  });

  assert.equal(result, 'WIFI:T:WPA;S:FRITZ!Box 7590 Gast;P:secret-password-123;H:false;;');
});

test('formatWifiPayload formats open network with no password', () => {
  const result = formatWifiPayload({
    ssid: 'Free-Cafe-WLAN',
    password: '',
    encryption: 'nopass',
    hidden: false,
  });

  assert.equal(result, 'WIFI:T:nopass;S:Free-Cafe-WLAN;P:;H:false;;');
});

test('formatWifiPayload handles special characters and escaping', () => {
  const result = formatWifiPayload({
    ssid: 'My;Network:Home',
    password: 'p;a"ss,word',
    encryption: 'WPA',
    hidden: true,
  });

  assert.ok(result.includes('H:true;;'));
  assert.ok(result.includes('S:My\\;Network\\:Home;'));
});
