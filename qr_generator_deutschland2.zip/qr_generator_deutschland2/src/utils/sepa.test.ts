/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { formatSepaPayload, formatIbanDisplay } from './sepa';

test('formatSepaPayload formats official EPC 002 SCT GiroCode', () => {
  const result = formatSepaPayload({
    name: 'Max Mustermann',
    iban: 'DE89 3705 0198 0000 0123 45',
    bic: 'BELADEBE100',
    amount: '45.00',
    purpose: 'WG Miete Oktober',
    reference: '',
  });

  const lines = result.split('\n');
  assert.equal(lines[0], 'BCD');
  assert.equal(lines[1], '002');
  assert.equal(lines[2], '1');
  assert.equal(lines[3], 'SCT');
  assert.equal(lines[4], 'BELADEBE100');
  assert.equal(lines[5], 'Max Mustermann');
  assert.equal(lines[6], 'DE89370501980000012345');
  assert.equal(lines[7], 'EUR45.00');
  assert.equal(lines[10], 'WG Miete Oktober');
});

test('formatIbanDisplay inserts spaces every 4 characters', () => {
  const formatted = formatIbanDisplay('DE89370501980000012345');
  assert.equal(formatted, 'DE89 3705 0198 0000 0123 45');
});
