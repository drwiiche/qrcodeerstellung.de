/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Validates a German or international IBAN using ISO 7064 Modulo 97-10 checksum algorithm.
 * German IBANs (DE + 2 check digits + 8 digit BLZ + 10 digit account number) are exactly 22 chars.
 */
export function validateIbanChecksum(rawIban: string): { isValid: boolean; message?: string } {
  const iban = rawIban.replace(/\s+/g, '').toUpperCase();
  if (!iban) {
    return { isValid: false, message: 'IBAN darf nicht leer sein' };
  }

  // Specifically for Germany: exactly 22 characters
  if (iban.startsWith('DE')) {
    if (iban.length !== 22) {
      return {
        isValid: false,
        message: `Deutsche IBAN muss genau 22 Zeichen haben (aktuell: ${iban.length})`,
      };
    }
  } else if (!/^[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}$/.test(iban)) {
    return { isValid: false, message: 'Ungültiges IBAN-Format (z.B. DE89...)' };
  }

  // ISO 7064 Modulo 97 check: Move first 4 characters to the end
  const rearranged = iban.slice(4) + iban.slice(0, 4);

  // Convert letters to numbers: A = 10, B = 11, ..., Z = 35
  let numericString = '';
  for (let i = 0; i < rearranged.length; i++) {
    const code = rearranged.charCodeAt(i);
    if (code >= 65 && code <= 90) {
      numericString += (code - 55).toString();
    } else {
      numericString += rearranged[i];
    }
  }

  // Compute modulo 97 in chunks to avoid JavaScript 64-bit integer overflow
  let remainder = 0;
  for (let i = 0; i < numericString.length; i += 7) {
    const chunk = remainder.toString() + numericString.slice(i, i + 7);
    remainder = parseInt(chunk, 10) % 97;
  }

  if (remainder !== 1) {
    return { isValid: false, message: 'Ungültige IBAN-Prüfziffer' };
  }

  return { isValid: true };
}

/**
 * Sanitizes URLs to prevent malicious protocols like `javascript:` or `vbscript:`
 */
export function sanitizeUrl(url: string): string {
  const trimmed = url.trim();
  if (/^(javascript|vbscript|data):/i.test(trimmed)) {
    return 'https://the-qrcode-generator.com';
  }
  return trimmed;
}

/**
 * Validates uploaded image file against size limits (max 2MB) and allowed image MIME types.
 */
export function validateImageFile(file: File): { isValid: boolean; error?: string } {
  const MAX_SIZE_BYTES = 2 * 1024 * 1024; // 2MB
  const ALLOWED_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'];

  if (!ALLOWED_TYPES.includes(file.type)) {
    return {
      isValid: false,
      error: 'Nur PNG, JPG, WebP oder SVG Dateien sind als Logo erlaubt.',
    };
  }

  if (file.size > MAX_SIZE_BYTES) {
    return {
      isValid: false,
      error: 'Die Bilddatei ist zu groß (maximal 2 MB erlaubt).',
    };
  }

  return { isValid: true };
}
