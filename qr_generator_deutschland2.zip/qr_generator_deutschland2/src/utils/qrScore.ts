/**
 * QR readability score — grades how reliably a customized code will scan
 * (contrast, gradients, logo coverage, background images, module styles).
 */

import type { QRCustomization } from '../types/qr';

export interface QrScoreResult {
  /** 0–100 */
  score: number;
  grade: 'sehr-gut' | 'gut' | 'ausreichend' | 'kritisch';
  label: string;
  /** Human-readable problems (German), worst first */
  issues: string[];
}

function hexToRgb(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.exec(hex.trim());
  if (!m) return null;
  let h = m[1];
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

/** WCAG relative luminance (0 = black, 1 = white). */
function luminance(hex: string): number {
  const rgb = hexToRgb(hex);
  if (!rgb) return 1;
  const [r, g, b] = rgb.map((v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** WCAG contrast ratio between two hex colors (1–21). */
export function contrastRatio(a: string, b: string): number {
  const la = luminance(a);
  const lb = luminance(b);
  const [hi, lo] = la >= lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

export function computeQrScore(c: QRCustomization): QrScoreResult {
  const issues: string[] = [];
  let score = 100;

  const bg = c.backgroundColor === 'transparent' ? '#ffffff' : c.backgroundColor;
  const bgLum = luminance(bg);

  // --- 1. Contrast between module color(s) and background (max 40 pts) ----
  let worstRatio = contrastRatio(c.foregroundColor, bg);
  if (c.useGradient) {
    worstRatio = Math.min(worstRatio, contrastRatio(c.gradientColor, bg));
  }

  if (worstRatio >= 7) {
    score = 60 + 40; // excellent contrast — full marks in this dimension
  } else if (worstRatio >= 4.5) {
    score = 60 + 32;
  } else if (worstRatio >= 3) {
    score = 60 + 18;
    issues.push(`Niedriger Farbkontrast (${worstRatio.toFixed(1)}:1) – dunklere Module oder helleren Hintergrund wählen.`);
  } else {
    score = 60 + 4;
    issues.push(`Kritisch geringer Kontrast (${worstRatio.toFixed(1)}:1) – so scannen viele Kameras nicht mehr.`);
  }

  // --- 2. Inverted (light modules on dark background) ----------------------
  if (luminance(c.foregroundColor) > bgLum + 0.15) {
    score -= 8;
    issues.push('Invertierte Darstellung (helle Module auf dunklem Grund) wird von älteren Scannern oft abgelehnt.');
  }

  // --- 3. Gradient ---------------------------------------------------------
  if (c.useGradient) {
    score -= 4;
    if (luminance(c.gradientColor) > bgLum + 0.1) {
      score -= 6;
      issues.push('Der Verlaufs-Ausgang liegt zu hell auf dem Hintergrund.');
    }
  }

  // --- 4. Logo coverage ----------------------------------------------------
  if (c.logoType !== 'none') {
    const ratio = c.logoSize || 0.22;
    if (ratio > 0.3) {
      score -= 22;
      issues.push('Logo-Fläche über 30 % – deutlich verkleinern (max. ~25 % empfohlen).');
    } else if (ratio > 0.25) {
      score -= 12;
      issues.push('Logo-Fläche über 25 % – Fehlerkorrektur H verwenden oder Logo verkleinern.');
    } else if (ratio > 0.18) {
      score -= 4;
    }
    if (c.errorCorrectionLevel === 'L') {
      score -= 6;
      issues.push('Fehlerkorrektur „L“ mit Logo – auf „H“ stellen.');
    }
  }

  // --- 5. Background image -------------------------------------------------
  if (c.backgroundImageUrl) {
    const opacity = c.backgroundImageOpacity ?? 0.35;
    score -= 8 + Math.round(opacity * 24);
    const imgLum = c.bgImageLuminance ?? 0.6;
    if (imgLum < 0.45) {
      score -= 10;
      issues.push('Das Hintergrundbild ist relativ dunkel – Deckkraft reduzieren oder helles Motiv wählen.');
    }
    if (opacity > 0.55) {
      issues.push('Hintergrundbild-Deckkraft hoch – Scanbarkeit kann leiden, unter 50 % empfohlen.');
    }
  }

  // --- 6. Decorative modules ----------------------------------------------
  if (c.dotStyle === 'classy') score -= 3;
  if (c.dotStyle === 'dots') score -= 2;
  if (c.cornerStyle === 'leaf') score -= 2;

  // --- 7. Solid background is good for print ------------------------------
  if (c.backgroundColor === 'transparent') {
    score -= 6;
    issues.push('Transparenter Hintergrund: beim Druck immer einen hellen Untergrund wählen.');
  }

  score = Math.max(0, Math.min(100, Math.round(score)));

  const grade: QrScoreResult['grade'] =
    score >= 85 ? 'sehr-gut' : score >= 70 ? 'gut' : score >= 50 ? 'ausreichend' : 'kritisch';
  const label =
    grade === 'sehr-gut'
      ? 'Sehr gut scannbar'
      : grade === 'gut'
        ? 'Gut scannbar'
        : grade === 'ausreichend'
          ? 'Ausreichend – optimierbar'
          : 'Kritisch – nur eingeschränkt scannbar';

  return { score, grade, label, issues };
}