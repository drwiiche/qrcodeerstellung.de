/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DeliveryData } from '../types/qr';

/**
 * Format instructions for delivery couriers (DHL, Hermes, Amazon, DPD, GLS)
 */
export function formatDeliveryPayload(data: DeliveryData): string {
  const parts: string[] = [
    `📦 PAKET-ABSTELLHINWEIS`,
    `Empfänger: ${data.recipientName || 'Bewohner'}`,
    `Abstellort: ${data.deliveryLocation || 'Vor der Wohnungstür'}`,
  ];

  if (data.parcelServices && data.parcelServices.length > 0) {
    parts.push(`Gültig für: ${data.parcelServices.join(', ')}`);
  }

  if (data.phone) {
    parts.push(`Rückfragen / Telefon: ${data.phone}`);
  }

  if (data.specialInstructions) {
    parts.push(`Zusatzhinweis: ${data.specialInstructions}`);
  }

  return parts.join('\n');
}
