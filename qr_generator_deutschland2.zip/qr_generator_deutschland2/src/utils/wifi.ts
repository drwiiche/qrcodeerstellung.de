/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WifiData } from '../types/qr';

/**
 * Format Wi-Fi credentials into standard Wi-Fi barcode format:
 * WIFI:T:WPA;S:MyNetwork;P:MyPassword;H:false;;
 */
export function formatWifiPayload(data: WifiData): string {
  const escape = (str: string) => str.replace(/([\\;,:"])/g, '\\$1');
  const enc = data.encryption || 'WPA';
  const ssid = escape(data.ssid || '');
  const pass = enc === 'nopass' ? '' : escape(data.password || '');
  const hidden = data.hidden ? 'true' : 'false';

  return `WIFI:T:${enc};S:${ssid};P:${pass};H:${hidden};;`;
}
