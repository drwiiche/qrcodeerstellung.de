/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VCardData } from '../types/qr';

/**
 * Generates standard vCard 3.0 string compatible with iOS and Android contacts
 */
export function formatVCardPayload(data: VCardData): string {
  const lines: string[] = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `N:${data.lastName || ''};${data.firstName || ''};;;`,
    `FN:${[data.firstName, data.lastName].filter(Boolean).join(' ')}`
  ];

  if (data.organization) lines.push(`ORG:${data.organization}`);
  if (data.title) lines.push(`TITLE:${data.title}`);
  if (data.phone) lines.push(`TEL;TYPE=WORK,VOICE:${data.phone}`);
  if (data.mobile) lines.push(`TEL;TYPE=CELL,VOICE:${data.mobile}`);
  if (data.email) lines.push(`EMAIL;TYPE=INTERNET:${data.email}`);
  
  if (data.street || data.city || data.zip || data.country) {
    lines.push(`ADR;TYPE=HOME:;;${data.street || ''};${data.city || ''};;${data.zip || ''};${data.country || 'Deutschland'}`);
  }

  if (data.website) lines.push(`URL:${data.website.startsWith('http') ? data.website : 'https://' + data.website}`);
  if (data.note) lines.push(`NOTE:${data.note.replace(/\n/g, '\\n')}`);

  lines.push('END:VCARD');
  return lines.join('\n');
}
