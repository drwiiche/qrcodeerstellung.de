/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { validateIbanChecksum, sanitizeUrl, validateImageFile } from './security';

test('validateIbanChecksum validates authentic German Bundesbank sample IBAN', () => {
  // Deutsche Bundesbank test IBAN: DE89 3704 0044 0532 0130 00
  const result = validateIbanChecksum('DE89 3704 0044 0532 0130 00');
  assert.equal(result.isValid, true);
});

test('validateIbanChecksum rejects invalid checksum or corrupt digits', () => {
  const result = validateIbanChecksum('DE89 3704 0044 0532 0130 01'); // Changed last digit
  assert.equal(result.isValid, false);
  assert.ok(result.message?.includes('Prüfziffer'));
});

test('validateIbanChecksum rejects incorrect length for German IBAN', () => {
  const result = validateIbanChecksum('DE89 3704 0044');
  assert.equal(result.isValid, false);
  assert.ok(result.message?.includes('22 Zeichen'));
});

test('sanitizeUrl neutralizes javascript: protocol injection', () => {
  assert.equal(sanitizeUrl('javascript:alert(1)'), 'https://the-qrcode-generator.com');
  assert.equal(sanitizeUrl('https://mein-homeoffice.de'), 'https://mein-homeoffice.de');
});
