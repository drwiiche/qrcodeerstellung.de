/**
 * Privacy-friendly, consent-aware analytics tracker.
 * Only dispatches events if user has given consent via the Cookie Banner.
 */

export const CONSENT_STORAGE_KEY = 'qr_deutschland_cookie_consent_v1';

export interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
  timestamp: number;
}

export function getCookieConsent(): CookiePreferences | null {
  try {
    const raw = localStorage.getItem(CONSENT_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCookieConsent(prefs: Partial<CookiePreferences>) {
  try {
    const current: CookiePreferences = {
      essential: true,
      analytics: false,
      marketing: false,
      timestamp: Date.now(),
      ...prefs,
    };
    localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(current));
    // Trigger custom event so reactive components update immediately
    window.dispatchEvent(new CustomEvent('cookie_consent_changed', { detail: current }));
  } catch (e) {
    console.warn('Could not store cookie consent', e);
  }
}

export function hasAnalyticsConsent(): boolean {
  const consent = getCookieConsent();
  return Boolean(consent?.analytics);
}

export type AnalyticsEvent = 
  | 'page_view'
  | 'qr_type_change'
  | 'qr_generated'
  | 'qr_download_png'
  | 'qr_download_svg'
  | 'qr_print'
  | 'qr_copy_payload'
  | 'scan_simulation_open'
  | 'template_applied'
  | 'feedback_submitted';

export function trackEvent(eventName: AnalyticsEvent, payload: Record<string, any> = {}) {
  if (!hasAnalyticsConsent()) {
    return;
  }

  const eventPayload = {
    event: eventName,
    ...payload,
    time: new Date().toISOString(),
    lang: navigator.language,
  };

  // Safe developer logging & extensible beacon dispatch
  if (process.env.NODE_ENV !== 'production') {
    console.log('[Analytics Event]', eventPayload);
  }

  // If a dataLayer or Plausible is configured:
  if (typeof (window as any).dataLayer !== 'undefined') {
    (window as any).dataLayer.push(eventPayload);
  }
  if (typeof (window as any).plausible === 'function') {
    (window as any).plausible(eventName, { props: payload });
  }
}
