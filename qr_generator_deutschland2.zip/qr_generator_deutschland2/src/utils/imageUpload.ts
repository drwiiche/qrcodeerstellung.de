/**
 * Client-side image upload helper for QR background/border designs.
 * Resizes to a small JPEG data URL (keeps localStorage history manageable)
 * and measures average luminance so the readability score can react.
 */

export interface ProcessedImage {
  dataUrl: string;
  /** Average relative lightness, 0 (black) – 1 (white) */
  luminance: number;
}

const MAX_SIZE = 480;

export async function processDesignImage(file: File): Promise<ProcessedImage> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Bitte eine Bilddatei auswählen (JPG, PNG oder WebP).');
  }
  if (file.size > 8 * 1024 * 1024) {
    throw new Error('Die Datei ist zu groß (max. 8 MB).');
  }

  const dataUrl = await readFile(file);
  const img = await loadImage(dataUrl);

  const scale = Math.min(1, MAX_SIZE / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas nicht verfügbar.');
  ctx.drawImage(img, 0, 0, w, h);

  // Average luminance from a coarse sample.
  const sample = ctx.getImageData(0, 0, w, h).data;
  let sum = 0;
  let count = 0;
  for (let i = 0; i < sample.length; i += 4 * 37) {
    const r = sample[i] / 255;
    const g = sample[i + 1] / 255;
    const b = sample[i + 2] / 255;
    sum += 0.2126 * r + 0.7152 * g + 0.0722 * b;
    count++;
  }
  const luminance = count ? Math.min(1, Math.max(0, sum / count)) : 0.6;

  const outType = file.type === 'image/png' && luminance > 0.97 ? 'image/png' : 'image/jpeg';
  const out = canvas.toDataURL(outType, 0.82);
  return { dataUrl: out, luminance };
}

function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Datei konnte nicht gelesen werden.'));
    reader.readAsDataURL(file);
  });
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Bild konnte nicht geladen werden.'));
    img.src = src;
  });
}