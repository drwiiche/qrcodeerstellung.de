/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SepaData } from '../types/qr';

/**
 * Generates official EPC (European Payments Council) QR-Code standard for SEPA Credit Transfers (GiroCode).
 * Supported by Sparkassen-App, VR Banking, Deutsche Bank, Commerzbank, DKB, ING, Postbank, N26, etc.
 */
export function formatSepaPayload(data: SepaData): string {
  const serviceTag = 'BCD';
  const version = '002';
  const characterSet = '1'; // UTF-8
  const identification = 'SCT'; // SEPA Credit Transfer
  const bic = (data.bic || '').trim().toUpperCase();
  const name = (data.name || '').trim().substring(0, 70);
  const iban = (data.iban || '').replace(/\s+/g, '').toUpperCase();
  
  let formattedAmount = '';
  if (data.amount && parseFloat(data.amount) > 0) {
    const num = parseFloat(data.amount.replace(',', '.'));
    if (!isNaN(num)) {
      formattedAmount = `EUR${num.toFixed(2)}`;
    }
  }

  const purpose = ''; // Optional 4 char code
  const reference = (data.reference || '').trim().substring(0, 35);
  const remittanceText = (data.purpose || '').trim().substring(0, 140);
  const beneficiaryInfo = '';

  const lines = [
    serviceTag,
    version,
    characterSet,
    identification,
    bic,
    name,
    iban,
    formattedAmount,
    purpose,
    reference,
    remittanceText,
    beneficiaryInfo
  ];

  return lines.join('\n');
}

/**
 * Format IBAN with spaces for German readability (DE89 3705 0198 ...)
 */
export function formatIbanDisplay(val: string): string {
  const cleaned = val.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const parts = [];
  for (let i = 0; i < cleaned.length; i += 4) {
    parts.push(cleaned.substring(i, i + 4));
  }
  return parts.join(' ').substring(0, 27); // Max 22 chars + 5 spaces for DE IBAN
}
