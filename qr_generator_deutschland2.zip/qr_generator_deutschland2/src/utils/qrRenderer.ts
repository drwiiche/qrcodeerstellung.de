/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import QRCode from 'qrcode';
import { QRCustomization } from '../types/qr';

// Icons as SVG path strings for center logos
export const BUILTIN_ICONS: Record<string, string> = {
  wifi: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h.01"/><path d="M2 8.82a15 15 0 0 1 20 0"/><path d="M5 12.859a10 10 0 0 1 14 0"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/></svg>`,
  router: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="14" rx="2"/><path d="M6 18h.01"/><path d="M10 18h.01"/><path d="M15 10v4"/><path d="M17.8 7.2a6 6 0 0 0-8.6 0"/><path d="M20.6 4.4a10 10 0 0 0-14.2 0"/></svg>`,
  lock: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
  key: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/></svg>`,
  shield: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>`,
  sepa: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/><text x="12" y="16" font-size="6" font-family="sans-serif" font-weight="bold" text-anchor="middle" fill="currentColor">€</text></svg>`,
  card: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>`,
  bank: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 9 10-6 10 6v2H2z"/><path d="M6 11v7"/><path d="M10 11v7"/><path d="M14 11v7"/><path d="M18 11v7"/><path d="M2 20h20v2H2z"/></svg>`,
  receipt: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 7h8"/><path d="M8 11h8"/><path d="M8 15h5"/></svg>`,
  house: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>`,
  box: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>`,
  truck: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18.5" r="2.5"/><circle cx="7" cy="18.5" r="2.5"/></svg>`,
  bell: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>`,
  pin: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>`,
  user: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
  whatsapp: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><path d="M9.5 8.5c0 .5.3 1.2.6 1.7.5.8 1.4 1.7 2.2 2.2.5.3 1.2.6 1.7.6.5 0 1-.3 1.2-.7l.7-.9c.2-.3.2-.6 0-.8l-1.3-1.3c-.3-.3-.6-.3-.8 0l-.5.5c-.2.2-.4.2-.6 0-.6-.4-1.2-1-1.6-1.6-.2-.2-.2-.4 0-.6l.5-.5c.3-.2.3-.5 0-.8L11 5.1c-.2-.2-.5-.2-.8 0l-.9.7c-.4.2-.7.7-.7 1.2z"/></svg>`,
  phone: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
  mail: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>`,
  calendar: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/></svg>`,
  globe: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>`,
  coffee: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" x2="6" y1="2" y2="4"/><line x1="10" x2="10" y1="2" y2="4"/><line x1="14" x2="14" y1="2" y2="4"/></svg>`,
  restaurant: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2v6a3 3 0 0 1-3 3 3 3 0 0 1-3-3V2"/><path d="M15 11v11"/><path d="M5 2v10a3 3 0 0 0 3 3v7"/><path d="M8 2v8"/></svg>`,
  heart: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
  star: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  tag: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2H2v10l9.29 9.29c.94.94 2.48.94 3.42 0l6.58-6.58c.94-.94.94-2.48 0-3.42L12 2Z"/><circle cx="7" cy="7" r=".5" fill="currentColor"/></svg>`,
};

/**
 * Checks if a coordinate (r, c) falls into one of the three finder pattern corner zones (7x7)
 */
function isFinderPattern(r: number, c: number, moduleCount: number): boolean {
  // Top-left
  if (r < 7 && c < 7) return true;
  // Top-right
  if (r < 7 && c >= moduleCount - 7) return true;
  // Bottom-left
  if (r >= moduleCount - 7 && c < 7) return true;
  return false;
}

/**
 * Checks if a coordinate is in the central logo safe-zone
 */
function isCenterLogoZone(r: number, c: number, moduleCount: number, logoSizeRatio: number): boolean {
  if (logoSizeRatio <= 0) return false;
  const center = moduleCount / 2;
  const radius = (moduleCount * logoSizeRatio) / 2 + 1; // +1 module safety padding
  return Math.abs(r - center) < radius && Math.abs(c - center) < radius;
}

/**
 * Renders the custom styled QR code directly onto a canvas element
 */
export async function renderQRCodeToCanvas(
  canvas: HTMLCanvasElement,
  payload: string,
  options: QRCustomization,
  renderWidth = 800
): Promise<void> {
  if (!payload) payload = 'https://the-qrcode-generator.com';

  // 1. Generate QR matrix data
  const qrData = QRCode.create(payload, {
    errorCorrectionLevel: options.logoType !== 'none' ? 'H' : options.errorCorrectionLevel,
  });

  const moduleCount = qrData.modules.size;
  const rawModules = qrData.modules.data; // Uint8Array

  // 2. Setup canvas dimensions with frame consideration
  const hasTopFrame = options.frameType === 'top-bar';
  const hasBottomFrame = options.frameType === 'bottom-bar' || options.frameType === 'speech-bubble' || options.frameType === 'badge-card';
  
  const frameHeight = (hasTopFrame || hasBottomFrame) ? Math.round(renderWidth * 0.16) : 0;
  const canvasWidth = renderWidth;
  const canvasHeight = renderWidth + frameHeight;

  canvas.width = canvasWidth;
  canvas.height = canvasHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Padding & cell sizing (computed first — the background layers need it)
  const qrPadding = Math.round(renderWidth * 0.08);
  const qrAreaSize = renderWidth - qrPadding * 2;
  const cellSize = qrAreaSize / moduleCount;
  const qrOffsetY = (hasTopFrame ? frameHeight : 0) + qrPadding;
  const qrOffsetX = qrPadding;

  // Background layers (scannability first):
  //  1. optional decorative border image around the card (outside the quiet zone)
  //  2. solid card background
  //  3. optional background image behind the modules, at capped opacity
  const band = options.borderImageUrl ? Math.round(renderWidth * 0.06) : 0;

  if (options.borderImageUrl) {
    await drawImageCover(ctx, options.borderImageUrl, 0, 0, canvasWidth, canvasHeight);
    ctx.fillStyle = options.backgroundColor === 'transparent' ? '#ffffff' : options.backgroundColor;
    drawRoundedRect(
      ctx,
      band,
      band,
      canvasWidth - band * 2,
      canvasHeight - band * 2,
      Math.round(band * 0.7)
    );
    ctx.fill();
  } else if (options.backgroundColor !== 'transparent') {
    ctx.fillStyle = options.backgroundColor;
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
  } else {
    ctx.clearRect(0, 0, canvasWidth, canvasHeight);
  }

  if (options.backgroundImageUrl) {
    // Hard cap: never let the image dominate — quiet zone stays solid.
    const opacity = Math.min(0.6, Math.max(0.1, options.backgroundImageOpacity ?? 0.35));
    ctx.save();
    ctx.globalAlpha = opacity;
    await drawImageCover(ctx, options.backgroundImageUrl, qrOffsetX, qrOffsetY, qrAreaSize, qrAreaSize);
    ctx.restore();
  }

  // Setup gradient or solid fill
  let fillStyle: string | CanvasGradient = options.foregroundColor;
  if (options.useGradient) {
    const angleRad = (options.gradientAngle * Math.PI) / 180;
    const x2 = qrOffsetX + Math.cos(angleRad) * qrAreaSize;
    const y2 = qrOffsetY + Math.sin(angleRad) * qrAreaSize;
    const grad = ctx.createLinearGradient(qrOffsetX, qrOffsetY, x2, y2);
    grad.addColorStop(0, options.foregroundColor);
    grad.addColorStop(1, options.gradientColor);
    fillStyle = grad;
  }

  const logoRatio = options.logoType !== 'none' ? options.logoSize : 0;

  // 3. Draw standard modules (excluding finder patterns and logo zone)
  ctx.fillStyle = fillStyle;

  for (let r = 0; r < moduleCount; r++) {
    for (let c = 0; c < moduleCount; c++) {
      const isDark = rawModules[r * moduleCount + c] === 1;
      if (!isDark) continue;

      if (isFinderPattern(r, c, moduleCount)) continue;
      if (isCenterLogoZone(r, c, moduleCount, logoRatio)) continue;

      const x = qrOffsetX + c * cellSize;
      const y = qrOffsetY + r * cellSize;

      if (options.dotStyle === 'dots') {
        const radius = cellSize * 0.44;
        ctx.beginPath();
        ctx.arc(x + cellSize / 2, y + cellSize / 2, radius, 0, Math.PI * 2);
        ctx.fill();
      } else if (options.dotStyle === 'rounded') {
        const rad = cellSize * 0.35;
        drawRoundedRect(ctx, x + 0.5, y + 0.5, cellSize - 1, cellSize - 1, rad);
        ctx.fill();
      } else if (options.dotStyle === 'classy') {
        // Diamond / smooth star shape
        ctx.beginPath();
        ctx.moveTo(x + cellSize / 2, y);
        ctx.lineTo(x + cellSize, y + cellSize / 2);
        ctx.lineTo(x + cellSize / 2, y + cellSize);
        ctx.lineTo(x, y + cellSize / 2);
        ctx.closePath();
        ctx.fill();
      } else {
        // Standard squares
        ctx.fillRect(x, y, cellSize + 0.4, cellSize + 0.4);
      }
    }
  }

  // 4. Draw Custom Finder Corners (Eyes) at (0,0), (0, max-7), (max-7, 0)
  const finderPositions = [
    { r: 0, c: 0 },
    { r: 0, c: moduleCount - 7 },
    { r: moduleCount - 7, c: 0 },
  ];

  for (const pos of finderPositions) {
    const eyeX = qrOffsetX + pos.c * cellSize;
    const eyeY = qrOffsetY + pos.r * cellSize;
    const eyeTotalSize = 7 * cellSize;

    drawFinderEye(
      ctx,
      eyeX,
      eyeY,
      eyeTotalSize,
      cellSize,
      options.cornerStyle,
      options.eyeBorderColor || options.foregroundColor,
      options.eyeCenterColor || options.foregroundColor,
      options.backgroundColor === 'transparent' ? '#ffffff' : options.backgroundColor
    );
  }

  // 5. Draw Center Logo if selected
  if (options.logoType !== 'none') {
    const centerSize = qrAreaSize * options.logoSize;
    const centerX = qrOffsetX + (qrAreaSize - centerSize) / 2;
    const centerY = qrOffsetY + (qrAreaSize - centerSize) / 2;

    // Draw clean background pill/badge for logo
    ctx.save();
    ctx.fillStyle = options.backgroundColor === 'transparent' ? '#ffffff' : options.backgroundColor;
    ctx.shadowColor = 'rgba(0,0,0,0.12)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetY = 3;
    drawRoundedRect(ctx, centerX, centerY, centerSize, centerSize, centerSize * 0.28);
    ctx.fill();
    ctx.restore();

    // Subtle border
    ctx.strokeStyle = options.foregroundColor;
    ctx.lineWidth = Math.max(2, centerSize * 0.04);
    ctx.stroke();

    // Render Icon image
    const iconPadding = centerSize * 0.20;
    const iconInnerSize = centerSize - iconPadding * 2;
    const iconX = centerX + iconPadding;
    const iconY = centerY + iconPadding;

    if (options.logoType === 'custom' && options.customLogoUrl) {
      await drawImageOnCanvas(ctx, options.customLogoUrl, iconX, iconY, iconInnerSize, iconInnerSize);
    } else {
      const svgString = BUILTIN_ICONS[options.logoType] || BUILTIN_ICONS.wifi;
      const svgColor = options.foregroundColor;
      const coloredSvg = svgString.replace('stroke="currentColor"', `stroke="${svgColor}"`).replace('fill="currentColor"', `fill="${svgColor}"`);
      await drawSvgOnCanvas(ctx, coloredSvg, iconX, iconY, iconInnerSize, iconInnerSize);
    }
  }

  // 6. Draw Call to Action Frame / Ribbon
  if (options.frameType !== 'none' && options.frameText) {
    drawFrameBanner(
      ctx,
      options.frameType,
      options.frameText,
      options.frameColor,
      options.frameTextColor,
      canvasWidth,
      canvasHeight,
      frameHeight,
      hasTopFrame
    );
  }
}

/**
 * Draws custom finder eyes (outer 7x7 box, 5x5 clear, 3x3 center dot)
 */
function drawFinderEye(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  cellSize: number,
  style: string,
  borderColor: string,
  centerColor: string,
  bgColor: string
) {
  const outerBorderWidth = cellSize;
  const radius =
    style === 'rounded'
      ? size * 0.22
      : style === 'extra-rounded' || style === 'leaf'
      ? size * 0.38
      : 0;

  // Outer border
  ctx.fillStyle = borderColor;
  drawRoundedRect(ctx, x, y, size, size, radius);
  ctx.fill();

  // White inner space
  ctx.fillStyle = bgColor;
  const innerOffset = outerBorderWidth;
  const innerSize = size - outerBorderWidth * 2;
  const innerRadius = Math.max(0, radius - outerBorderWidth);
  drawRoundedRect(ctx, x + innerOffset, y + innerOffset, innerSize, innerSize, innerRadius);
  ctx.fill();

  // Center pupil (3x3 modules)
  ctx.fillStyle = centerColor;
  const pupilOffset = 2 * cellSize;
  const pupilSize = 3 * cellSize;
  const pupilRadius =
    style === 'rounded'
      ? pupilSize * 0.28
      : style === 'extra-rounded'
      ? pupilSize * 0.5
      : 0;
  drawRoundedRect(ctx, x + pupilOffset, y + pupilOffset, pupilSize, pupilSize, pupilRadius);
  ctx.fill();
}

/**
 * Draws rounded rectangle helper
 */
function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  if (radius <= 0) {
    ctx.beginPath();
    ctx.rect(x, y, width, height);
    return;
  }
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/**
 * Draws Call-to-action banner at top or bottom
 */
function drawFrameBanner(
  ctx: CanvasRenderingContext2D,
  type: string,
  text: string,
  bgColor: string,
  textColor: string,
  canvasWidth: number,
  canvasHeight: number,
  frameHeight: number,
  isTop: boolean
) {
  ctx.save();
  const bannerY = isTop ? 0 : canvasHeight - frameHeight;
  const bannerHeight = frameHeight;
  const paddingX = Math.round(canvasWidth * 0.08);

  ctx.fillStyle = bgColor;

  if (type === 'badge-card' || type === 'bottom-bar' || type === 'top-bar') {
    const pillHeight = bannerHeight * 0.72;
    const pillY = bannerY + (bannerHeight - pillHeight) / 2;
    drawRoundedRect(ctx, paddingX, pillY, canvasWidth - paddingX * 2, pillHeight, pillHeight / 2);
    ctx.fill();

    // Text inside banner
    ctx.fillStyle = textColor;
    ctx.font = `bold ${Math.round(pillHeight * 0.42)}px 'Plus Jakarta Sans', sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text.toUpperCase(), canvasWidth / 2, pillY + pillHeight / 2 + 1);
  }
  ctx.restore();
}

/**
 * Draws image onto canvas asynchronously
 */
function drawImageOnCanvas(
  ctx: CanvasRenderingContext2D,
  src: string,
  x: number,
  y: number,
  w: number,
  h: number
): Promise<void> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      ctx.drawImage(img, x, y, w, h);
      resolve();
    };
    img.onerror = () => {
      resolve();
    };
    img.src = src;
  });
}

/**
 * Draws an image stretched to fill the given rect (aspect ratio preserved,
 * CSS-style “cover” — center-cropped, never distorted).
 */
function drawImageCover(
  ctx: CanvasRenderingContext2D,
  src: string,
  x: number,
  y: number,
  w: number,
  h: number
): Promise<void> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const scale = Math.max(w / img.width, h / img.height);
      const dw = img.width * scale;
      const dh = img.height * scale;
      ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
      resolve();
    };
    img.onerror = () => resolve();
    img.src = src;
  });
}

/**
 * Draws inline SVG onto canvas
 */
function drawSvgOnCanvas(
  ctx: CanvasRenderingContext2D,
  svgContent: string,
  x: number,
  y: number,
  w: number,
  h: number
): Promise<void> {
  return new Promise((resolve) => {
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, x, y, w, h);
      URL.revokeObjectURL(url);
      resolve();
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve();
    };
    img.src = url;
  });
}

/**
 * Generates standalone SVG file string for vector download
 */
export async function generateQRSvg(
  payload: string,
  options: QRCustomization
): Promise<string> {
  return await QRCode.toString(payload, {
    type: 'svg',
    errorCorrectionLevel: options.logoType !== 'none' ? 'H' : options.errorCorrectionLevel,
    margin: 3,
    color: {
      dark: options.foregroundColor,
      light: options.backgroundColor === 'transparent' ? '#00000000' : options.backgroundColor,
    },
  });
}
