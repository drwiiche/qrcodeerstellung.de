/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'de';

// German display names for built-in QR center icons (keys are internal identifiers)
export const ICON_LABELS: Record<string, string> = {
  wifi: 'WLAN',
  router: 'Router',
  lock: 'Schloss',
  key: 'Schlüssel',
  shield: 'Schutzschild',
  sepa: 'SEPA',
  card: 'Karte',
  bank: 'Bank',
  receipt: 'Beleg',
  box: 'Paket',
  house: 'Haus',
  truck: 'Lieferwagen',
  bell: 'Klingel',
  pin: 'Standort',
  user: 'Kontakt',
  whatsapp: 'WhatsApp',
  sms: 'SMS',
  phone: 'Telefon',
  mail: 'E-Mail',
  calendar: 'Kalender',
  globe: 'Weltkugel',
  coffee: 'Kaffee',
  restaurant: 'Restaurant',
  heart: 'Herz',
  star: 'Stern',
  tag: 'Etikett',
};

// German display names for QR types
export const QR_TYPE_LABELS: Record<string, string> = {
  url: 'Webseite',
  wifi: 'WLAN',
  sepa: 'SEPA',
  vcard: 'Visitenkarte',
  delivery: 'Paket',
  text: 'Text',
  email: 'E-Mail',
  whatsapp: 'WhatsApp',
  sms: 'SMS',
  standort: 'Standort',
  phone: 'Telefon',
  event: 'Termin',
};

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  de: {
    appTitle: 'QR-Code Generator',
    tagline: 'Kostenlose, statische und dauerhaft gültige QR-Codes für Zuhause, Finanzen, Visitenkarten und Logistik in Deutschland.',
    typeUrl: 'Webseite / URL',
    typeWifi: 'WLAN-Zugang',
    typeSepa: 'SEPA GiroCode',
    typeVCard: 'vCard Kontakt',
    typeDelivery: 'Haustür & Pakete',
    typeText: 'Freier Text',
    typeEmail: 'E-Mail',
    typeWhatsapp: 'WhatsApp',
    typePhone: 'Telefonanruf',
    typeEvent: 'Termin / Event',
    customizationTitle: 'QR-Code gestalten',
    styleTab: 'Muster & Ecken',
    colorTab: 'Farben',
    logoTab: 'Icons & Sammlungen',
    frameTab: 'Rahmen & Text',
    previewTitle: 'Live-Vorschau',
    scanSafetyScore: 'Scan-Sicherheit',
    highResPng: 'PNG herunterladen',
    vectorSvg: 'Vektor (SVG)',
    copyClipboard: 'Kopieren',
    printA4: 'A4 Vorlage drucken',
    scanSimulator: 'Smartphone-Scan testen',
    cityHubsTitle: 'Vorlagen für deutsche Haushalte & Alltag',
    cityHubsDesc: 'Praktische QR-Code Vorlagen für Router, Banküberweisungen, Paketboten und digitale Kontakte.',
    useCasesTitle: 'Häufige Anwendungsfälle',
    copiedSuccess: 'In die Zwischenablage kopiert!',
    loadTemplate: 'Vorlage laden',
    popularTemplate: 'Beliebte Vorlage',
    privacyNote: '100% Datenschutz: Alle QR-Codes werden direkt und lokal in Ihrem Webbrowser berechnet.',
  },
};
