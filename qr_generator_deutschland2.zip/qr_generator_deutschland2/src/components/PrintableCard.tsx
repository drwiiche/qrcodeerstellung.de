/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { QRType, WifiData, SepaData, DeliveryData, VCardData } from '../types/qr';
import { Scissors, ShieldCheck, Wifi, CreditCard, Package } from 'lucide-react';

interface PrintableCardProps {
  qrImageUrl: string;
  type: QRType;
  wifiData: WifiData;
  sepaData: SepaData;
  deliveryData: DeliveryData;
  vcardData: VCardData;
}

export const PrintableCard: React.FC<PrintableCardProps> = ({
  qrImageUrl,
  type,
  wifiData,
  sepaData,
  deliveryData,
  vcardData,
}) => {
  return (
    <div id="printable-qr-card" className="hidden print:block text-slate-900 bg-white">
      {/* Cut guide header */}
      <div className="flex items-center justify-between pb-4 border-b border-dashed border-slate-400 text-xs text-slate-500">
        <span className="flex items-center gap-1.5 font-mono">
          <Scissors className="w-3.5 h-3.5" /> Hier ausschneiden oder aufhängen
        </span>
        <span className="font-semibold">QR-Generator Deutschland</span>
      </div>

      <div className="text-center py-6">
        {/* Dynamic Badge Title */}
        {type === 'wifi' && (
          <div>
            <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-blue-50 text-blue-700 mb-3">
              <Wifi className="w-8 h-8" />
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
              Gäste-WLAN
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Scannen Sie den QR-Code mit Ihrem Smartphone, um sich sofort mit dem Internet zu verbinden.
            </p>
          </div>
        )}

        {type === 'sepa' && (
          <div>
            <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-emerald-50 text-emerald-700 mb-3">
              <CreditCard className="w-8 h-8" />
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
              SEPA GiroCode
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Öffnen Sie Ihre Banking-App (Sparkasse, Deutsche Bank, ING etc.) und scannen Sie diesen Code für eine fehlerfreie Überweisung.
            </p>
          </div>
        )}

        {type === 'delivery' && (
          <div>
            <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-amber-50 text-amber-700 mb-3">
              <Package className="w-8 h-8" />
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
              Paket-Abstellhinweis
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Hinweis für DHL, Hermes, Amazon, DPD und GLS Zusteller.
            </p>
          </div>
        )}

        {type !== 'wifi' && type !== 'sepa' && type !== 'delivery' && (
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
              Hier scannen
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Halten Sie Ihre Smartphone-Kamera auf den QR-Code.
            </p>
          </div>
        )}

        {/* Center QR image */}
        <div className="my-6 inline-block p-4 rounded-2xl border-2 border-slate-900 bg-white">
          {qrImageUrl && (
            <img
              src={qrImageUrl}
              alt="Druckfertiger hochauflösender QR-Code für A4 Aushang"
              className="w-64 h-64 mx-auto object-contain"
            />
          )}
        </div>

        {/* Context details block */}
        {type === 'wifi' && (
          <div className="max-w-md mx-auto p-4 rounded-xl bg-slate-50 border border-slate-200 text-left text-xs space-y-1.5 font-mono">
            <div>
              <span className="text-slate-500 font-sans font-semibold">Netzwerk (SSID):</span>{' '}
              <strong className="text-slate-900 font-bold">{wifiData.ssid || 'Gastzugang'}</strong>
            </div>
            {wifiData.password && (
              <div>
                <span className="text-slate-500 font-sans font-semibold">Passwort:</span>{' '}
                <strong className="text-slate-900">{wifiData.password}</strong>
              </div>
            )}
            <div>
              <span className="text-slate-500 font-sans font-semibold">Sicherheit:</span>{' '}
              <span className="text-slate-700">{wifiData.encryption}</span>
            </div>
          </div>
        )}

        {type === 'sepa' && (
          <div className="max-w-md mx-auto p-4 rounded-xl bg-slate-50 border border-slate-200 text-left text-xs space-y-1.5 font-mono">
            <div>
              <span className="text-slate-500 font-sans font-semibold">Empfänger:</span>{' '}
              <strong className="text-slate-900">{sepaData.name || '-'}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-sans font-semibold">IBAN:</span>{' '}
              <strong className="text-slate-900">{sepaData.iban || '-'}</strong>
            </div>
            {sepaData.amount && (
              <div>
                <span className="text-slate-500 font-sans font-semibold">Betrag:</span>{' '}
                <strong className="text-emerald-700">{sepaData.amount} EUR</strong>
              </div>
            )}
            {sepaData.purpose && (
              <div>
                <span className="text-slate-500 font-sans font-semibold">Verwendungszweck:</span>{' '}
                <span className="text-slate-700">{sepaData.purpose}</span>
              </div>
            )}
          </div>
        )}

        {type === 'delivery' && (
          <div className="max-w-md mx-auto p-4 rounded-xl bg-amber-50 border border-amber-200 text-left text-xs space-y-1.5">
            <div>
              <span className="text-amber-800 font-bold">Empfänger:</span>{' '}
              <span className="text-slate-900 font-semibold">{deliveryData.recipientName}</span>
            </div>
            <div>
              <span className="text-amber-800 font-bold">Abstellort:</span>{' '}
              <span className="text-slate-900 font-semibold">{deliveryData.deliveryLocation}</span>
            </div>
            {deliveryData.specialInstructions && (
              <div>
                <span className="text-amber-800 font-bold">Zusatzhinweis:</span>{' '}
                <span className="text-slate-800">{deliveryData.specialInstructions}</span>
              </div>
            )}
          </div>
        )}

        {/* Footer info */}
        <div className="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1 font-sans">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> DSGVO-konform ohne Tracking erstellt
          </span>
          <span>Dauerhaft gültig ohne Ablaufdatum</span>
        </div>
      </div>
    </div>
  );
};
