/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ChevronDown,
  MousePointerClick,
  PenLine,
  Palette,
  Download,
  Store,
  GraduationCap,
  CalendarDays,
  Home,
  HeartPulse,
  FileText,
  ArrowRight,
} from 'lucide-react';
import Link from 'next/link';
import { HeroQrVisual } from './HeroQrVisual';

/** The 4-step workflow of the generator — each step gets an orange-accented card. */
const STEPS = [
  {
    icon: MousePointerClick,
    title: 'QR-Typ wählen',
    text: 'WLAN, SEPA GiroCode, vCard, Paket, Standort, SMS & mehr – 12 Typen für den deutschen Alltag.',
  },
  {
    icon: PenLine,
    title: 'Daten eingeben',
    text: 'Das Formular füllt sich, die Live-Vorschau aktualisiert sich bei jedem Tastendruck.',
  },
  {
    icon: Palette,
    title: 'Gestalten',
    text: 'Farben, Ecken, Icons und Rahmen anpassen – der Scan-Score warnt sofort bei zu wenig Kontrast.',
  },
  {
    icon: Download,
    title: 'Herunterladen & teilen',
    text: 'PNG in HD, Vektor-SVG für Druckereien oder DIN-A4-Vorlage mit Schnittlinien.',
  },
];

/** Solution hubs — links to the programmatic SEO landing pages. */
const SOLUTIONS = [
  {
    href: '/qr-codes-fuer/unternehmen',
    icon: Store,
    title: 'Für Unternehmen',
    text: 'Speisekarten, Google-Bewertungen, Angebote und Terminbuchung für Gastronomie, Handwerk & Handel.',
  },
  {
    href: '/qr-codes-fuer/schulen',
    icon: GraduationCap,
    title: 'Für Schulen & Bildung',
    text: 'Lehrmittel, Elternkommunikation und Campus-Orientierung für Schulen, Kitas und Bildungsträger.',
  },
  {
    href: '/qr-codes-fuer/veranstaltungen',
    icon: CalendarDays,
    title: 'Für Veranstaltungen',
    text: 'Programme, Anmeldungen und Hochzeiten – Besucher scannen direkt mit der Handykamera.',
  },
  {
    href: '/qr-codes-fuer/immobilien',
    icon: Home,
    title: 'Für Immobilien',
    text: 'Besichtigungen, Makler-Exposés und Mieterkommunikation ohne App und ohne Account.',
  },
  {
    href: '/qr-codes-fuer/gesundheit',
    icon: HeartPulse,
    title: 'Für Gesundheit & Fitness',
    text: 'Termininfos, Übungspläne und Check-in für Praxen, Therapeuten und Sportvereine.',
  },
  {
    href: '/qr-codes-auf',
    icon: FileText,
    title: 'Auf Marketing-Materialien',
    text: 'Flyer, Plakate, Visitenkarten & Verpackungen – Größen, Kontrast und Platzierung richtig machen.',
  },
];

const FAQS = [
  {
    question: 'Werden meine eingegebenen Daten (z.B. WLAN-Passwort oder IBAN) auf einem Server gespeichert?',
    answer:
      'Nein, keinesfalls! Unser Generator arbeitet zu 100% lokal in Ihrem Browser (Client-Side Rendering). Es findet keine Übertragung vertraulicher Zugangsdaten statt – vollständig konform mit der Datenschutz-Grundverordnung (DSGVO).',
  },
  {
    question: 'Haben die erstellten QR-Codes ein Ablaufdatum oder Scan-Limits?',
    answer:
      'Nein. Es handelt sich um echte statische QR-Codes. Sie sind unbegrenzt oft scanbar und verfallen niemals. Es ist kein Abonnement oder Account erforderlich.',
  },
  {
    question: 'Wie drucke ich den QR-Code am besten für den Flur oder die Haustür aus?',
    answer:
      'Klicken Sie einfach auf den Button "Drucken". Es öffnet sich eine saubere DIN A4 Vorlage mit gestrichelten Schnittlinien und Hinweistext für Gäste bzw. Paketboten. Ideal zum Einrahmen oder Laminieren.',
  },
  {
    question: 'Was kostet der QR-Code Generator?',
    answer:
      'Die Nutzung ist kostenlos und ohne Konto. Es gibt keine versteckten Kosten, keine Wasserzeichen und keine begrenzte Anzahl an Codes.',
  },
  {
    question: 'Welche QR-Code-Typen werden angeboten?',
    answer:
      'Zurzeit 12 Typen: Webseite, WLAN, SEPA GiroCode, Visitenkarte (vCard), Paket-Abstellort, Standort, Termin, Telefon, SMS, WhatsApp, E-Mail und Freitext.',
  },
];

export const ProgrammaticSeoSection: React.FC = () => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  return (
    <section id="anleitung" className="py-14 border-t border-zinc-200 mt-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* So funktioniert's — 4 steps + adapted animated visual */}
        <div className="grid lg:grid-cols-2 gap-8 xl:gap-12 items-center mb-14">
          <div className="max-w-xl">
            <h2 className="text-2xl sm:text-4xl font-semibold text-black tracking-tight leading-[1.1]">
              So funktioniert&apos;s
            </h2>
            <p className="mt-3 text-sm sm:text-base text-zinc-500">
              In vier Schritten vom ersten Klick bis zum druckfertigen QR-Code – ohne
              Registrierung, ohne Wasserzeichen, ohne Ablaufdatum.
            </p>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {STEPS.map((step, i) => {
                const Icon = step.icon;
                return (
                  <div
                    key={step.title}
                    className="bg-white rounded-[16px] border border-zinc-200 p-5"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <span className="flex w-10 h-10 shrink-0 items-center justify-center rounded-full bg-[#FF5832]/10 text-[#FF5832]">
                        <Icon className="w-4.5 h-4.5 stroke-[2]" />
                      </span>
                      <span className="text-[11px] font-bold text-zinc-400 tracking-widest">
                        {String(i + 1).padStart(2, '0')}
                      </span>
                    </div>
                    <h3 className="font-semibold text-sm text-black mb-1.5">{step.title}</h3>
                    <p className="text-xs text-zinc-500 leading-relaxed">{step.text}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Adapted animated visual for this section */}
          <div className="flex lg:justify-end">
            <HeroQrVisual variant="steps" />
          </div>
        </div>

        {/* Lösungen nach Branche — white cards, orange icons & links */}
        <div className="mb-14">
          <div className="max-w-2xl mb-8">
            <h2 className="text-2xl sm:text-4xl font-semibold text-black tracking-tight leading-[1.1]">
              Lösungen für jede Branche
            </h2>
            <p className="mt-3 text-sm sm:text-base text-zinc-500">
              Kuratierte Anwendungsfälle mit fertigen Vorlagen – von der Speisekarte bis zum
              Mieterkommunikations-Board.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {SOLUTIONS.map((sol) => {
              const Icon = sol.icon;
              return (
                <div
                  key={sol.href}
                  className="bg-white rounded-[16px] border border-zinc-200 p-5 flex flex-col"
                >
                  <span className="w-10 h-10 rounded-full bg-[#FF5832]/10 text-[#FF5832] flex items-center justify-center mb-4">
                    <Icon className="w-4.5 h-4.5 stroke-[2]" />
                  </span>
                  <h3 className="font-semibold text-sm text-black mb-2">{sol.title}</h3>
                  <p className="text-xs text-zinc-500 leading-relaxed mb-5 flex-1">
                    {sol.text}
                  </p>
                  <Link
                    href={sol.href}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FF5832] hover:text-[#B31D00] transition cursor-pointer"
                  >
                    <span>Lösung ansehen</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              );
            })}
          </div>
        </div>

        {/* FAQ Accordion with Schema.org optimization */}
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl sm:text-4xl font-semibold text-black tracking-tight leading-[1.1]">
              Häufig gestellte Fragen (FAQ)
            </h2>
            <p className="mt-3 text-sm sm:text-base text-zinc-500">
              Alles Wichtige zu Sicherheit, Gültigkeit und Kompatibilität in Deutschland
            </p>
          </div>

          <div className="space-y-3">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="rounded-[16px] border border-zinc-200 overflow-hidden bg-white"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="w-full p-4 text-left flex items-center justify-between text-xs sm:text-sm font-semibold text-black hover:bg-[#F4F4F5] transition cursor-pointer"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-zinc-400 transition-transform flex-shrink-0 ml-3 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="p-4 pt-1 text-xs sm:text-sm text-zinc-600 border-t border-zinc-100 leading-relaxed">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
