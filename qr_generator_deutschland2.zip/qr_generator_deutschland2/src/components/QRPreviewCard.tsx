/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Download,
  Copy,
  Printer,
  Smartphone,
  Check,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  FileCode,
  BookmarkPlus,
  XCircle,
  Image as ImageIcon,
  Loader2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { QRCustomization } from '../types/qr';
import { generateQRSvg } from '../utils/qrRenderer';
import { computeQrScore } from '../utils/qrScore';
import { useMemo } from 'react';
import { trackEvent } from '../utils/analytics';
import { ICON_LABELS } from '../utils/translations';

interface QRPreviewCardProps {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  qrImageUrl: string;
  payload: string;
  customization: QRCustomization;
  setCustomization: React.Dispatch<React.SetStateAction<QRCustomization>>;
  onOpenScanTest: () => void;
  onSaveToHistory?: () => void;
  onNotify?: (text: string) => void;
  onNavigateThankYou?: () => void;
  isRendering?: boolean;
}

export const QRPreviewCard: React.FC<QRPreviewCardProps> = ({
  canvasRef,
  qrImageUrl,
  payload,
  customization,
  setCustomization,
  onOpenScanTest,
  onSaveToHistory,
  onNotify,
  onNavigateThankYou,
  isRendering = false,
}) => {
  const [copied, setCopied] = useState(false);
  const [downloadingPng, setDownloadingPng] = useState(false);
  const [downloadingSvg, setDownloadingSvg] = useState(false);

  // Readability score (contrast, logo, background images, module styles)
  const score = useMemo(() => computeQrScore(customization), [customization]);
  const hasDesignImage = Boolean(
    customization.backgroundImageUrl || customization.borderImageUrl
  );
  const scoreChip =
    score.grade === 'sehr-gut'
      ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
      : score.grade === 'gut'
        ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
        : score.grade === 'ausreichend'
          ? 'text-amber-700 bg-amber-50 border-amber-200'
          : 'text-[#B31D00] bg-red-50 border-red-200';

  // Calculate scan contrast score
  const isContrastWarning =
    customization.backgroundColor !== 'transparent' &&
    customization.foregroundColor.toLowerCase() ===
      customization.backgroundColor.toLowerCase();

  const handleDownloadPng = () => {
    if (!canvasRef.current || downloadingPng) return;
    setDownloadingPng(true);

    try {
      const link = document.createElement('a');
      link.download = `qrcode-deutschland-${Date.now()}.png`;
      link.href = canvasRef.current.toDataURL('image/png', 1.0);
      link.click();

      trackEvent('qr_download_png', { size: customization.size });
      onNotify?.('✓ PNG erfolgreich heruntergeladen!');

      // Subtle celebration
      confetti({
        particleCount: 35,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#FF5832', '#FF8E40', '#000000'],
      });

      if (onNavigateThankYou) {
        setTimeout(() => {
          onNavigateThankYou();
        }, 1200);
      }
    } finally {
      setTimeout(() => setDownloadingPng(false), 500);
    }
  };

  const handleDownloadSvg = async () => {
    if (downloadingSvg) return;
    if (hasDesignImage) {
      onNotify?.('Hinweis: Bild-Designs sind nur im PNG-Export enthalten – SVG ohne Bilder? Entfernen Sie das Bild.');
      return;
    }
    setDownloadingSvg(true);
    try {
      const svgData = await generateQRSvg(payload, customization);
      const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.download = `qrcode-deutschland-${Date.now()}.svg`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);

      trackEvent('qr_download_svg');
      onNotify?.('✓ Vektor SVG heruntergeladen!');
    } catch (e) {
      console.error(e);
      onNotify?.('Fehler beim SVG-Export');
    } finally {
      setDownloadingSvg(false);
    }
  };

  const handleCopyToClipboard = async () => {
    if (!canvasRef.current) return;
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) return;
        await navigator.clipboard.write([
          new ClipboardItem({
            'image/png': blob,
          }),
        ]);
        setCopied(true);
        trackEvent('qr_copy_payload');
        onNotify?.('✓ In Zwischenablage kopiert!');
        setTimeout(() => setCopied(false), 2500);

        confetti({
          particleCount: 25,
          spread: 40,
          origin: { y: 0.85 },
        });
      });
    } catch (err) {
      console.error('Clipboard copy error', err);
      navigator.clipboard.writeText(payload);
      setCopied(true);
      onNotify?.('✓ Text in Zwischenablage kopiert!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handlePrint = () => {
    trackEvent('qr_print');
    window.print();
  };

  return (
    <div className="bg-white rounded-[16px] border border-zinc-200 p-5 sm:p-6 flex flex-col items-center">
      {/* Title & Quality Indicator without slop badges */}
      <div className="w-full flex items-center justify-between mb-4">
        <h2 className="text-sm font-bold text-black tracking-tight">
          Live-Vorschau
        </h2>

        <span
          className={`text-[11px] font-bold px-2.5 py-1 rounded-full border flex items-center gap-1 ${scoreChip}`}
          title="Lesbarkeits-Prüfung: Kontrast, Logo, Hintergrund, Modul-Stil"
        >
          {score.grade === 'ausreichend' || score.grade === 'kritisch' ? (
            <AlertTriangle className="w-3.5 h-3.5" />
          ) : (
            <CheckCircle2 className="w-3.5 h-3.5" />
          )}
          Scan-Score {score.score}/100
        </span>
      </div>

      {/* Hidden Canvas for Generation */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Flat Visual Preview Container with 16px radius, no shadows */}
      <div className="relative w-full max-w-[280px] aspect-square rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-5 flex items-center justify-center overflow-hidden">
        {isRendering && (
          <div className="absolute inset-0 bg-white/80 z-10 flex flex-col items-center justify-center gap-2">
            <Loader2 className="w-6 h-6 text-[#FF5832] animate-spin" />
            <span className="text-xs font-bold text-black">Wird gerendert...</span>
          </div>
        )}

        {qrImageUrl ? (
          <img
            src={qrImageUrl}
            alt="Vorschau des generierten QR-Codes in hoher Auflösung"
            className="w-full h-full object-contain"
          />
        ) : (
          <div className="w-10 h-10 border-2 border-[#FF5832] border-t-transparent rounded-full animate-spin" />
        )}
      </div>

      {/* Center Icon Indicator / Reset */}
      {customization.logoType !== 'none' || customization.customLogoUrl ? (
        <div className="mt-3 w-full flex items-center justify-between px-3.5 py-1.5 rounded-full bg-[#F4F4F5] border border-zinc-200 text-xs">
          <span className="font-semibold text-black flex items-center gap-1.5 text-[11px]">
            <ImageIcon className="w-3.5 h-3.5 text-[#FF5832]" />
            Icon aktiv: <strong className="uppercase">{customization.customLogoUrl ? 'Eigenes Bild' : ICON_LABELS[customization.logoType] || customization.logoType}</strong>
          </span>
          <button
            type="button"
            onClick={() => {
              setCustomization({ ...customization, logoType: 'none', customLogoUrl: undefined });
              onNotify?.('✓ Icon entfernt');
            }}
            className="text-[11px] font-bold text-zinc-500 hover:text-black flex items-center gap-1 cursor-pointer"
          >
            <XCircle className="w-3.5 h-3.5" />
            Entfernen
          </button>
        </div>
      ) : null}

      {/* Readability check score */}
      <div className="mt-3 w-full rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-3.5 space-y-2.5" aria-live="polite">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">
            Scan-Prüfung (Lesbarkeit)
          </span>
          <span
            className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${scoreChip}`}
          >
            {score.score}/100 · {score.label}
          </span>
        </div>

        {/* Score bar */}
        <div className="h-2 w-full rounded-full bg-zinc-200 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              score.grade === 'sehr-gut' || score.grade === 'gut'
                ? 'bg-emerald-500'
                : score.grade === 'ausreichend'
                  ? 'bg-amber-500'
                  : 'bg-[#FF5832]'
            }`}
            style={{ width: `${score.score}%` }}
          />
        </div>

        {score.issues.length > 0 ? (
          <ul className="space-y-1.5">
            {score.issues.slice(0, 4).map((issue, i) => (
              <li key={i} className="flex items-start gap-1.5 text-[11px] leading-snug text-zinc-600">
                <AlertTriangle className="w-3 h-3 text-amber-500 mt-0.5 shrink-0" />
                {issue}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-[11px] text-emerald-700 font-semibold">
            ✓ Keine Auffälligkeiten – Kontrast, Logo und Hintergrund sind optimal.
          </p>
        )}
      </div>

      {/* Scan Test Button - Rounded Full */}
      <button
        type="button"
        onClick={() => {
          trackEvent('scan_simulation_open');
          onOpenScanTest();
        }}
        className="mt-3 w-full py-2.5 px-4 rounded-full bg-[#F4F4F5] hover:bg-[#EAEAEA] text-black border border-zinc-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
      >
        <Smartphone className="w-4 h-4 text-black" />
        <span>Smartphone-Scan simulieren</span>
      </button>

      {/* Export Action Buttons */}
      <div className="w-full space-y-2 mt-4 pt-4 border-t border-zinc-100">
        {/* Main High-Conversion Download Button with warm vibrant gradient */}
        <button
          type="button"
          onClick={handleDownloadPng}
          disabled={downloadingPng}
          className="w-full py-3 px-5 rounded-full bg-gradient-to-r from-[#FF5832] via-[#FF8E40] to-[#FFB867] hover:opacity-95 text-white font-bold text-sm flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-75"
        >
          {downloadingPng ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>PNG wird vorbereitet...</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>PNG herunterladen (HD)</span>
            </>
          )}
        </button>

        {/* Secondary Buttons Row with rounded-full pills */}
        <div className="grid grid-cols-3 gap-2">
          {/* Vector SVG */}
          <button
            type="button"
            onClick={handleDownloadSvg}
            disabled={downloadingSvg}
            className="py-2 px-3 rounded-full border border-zinc-200 bg-[#F4F4F5] hover:bg-[#EAEAEA] text-black text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-75"
            title="Vektor SVG für Druckereien & Skalierung"
          >
            {downloadingSvg ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-black" />
            ) : (
              <FileCode className="w-3.5 h-3.5 text-black" />
            )}
            <span className="text-[11px]">
              {downloadingSvg ? 'Export...' : hasDesignImage ? 'SVG*' : 'SVG'}
            </span>
          </button>

          {/* Copy to Clipboard */}
          <button
            type="button"
            onClick={handleCopyToClipboard}
            className={`py-2 px-3 rounded-full border text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              copied
                ? 'bg-black text-white border-black'
                : 'border-zinc-200 bg-[#F4F4F5] hover:bg-[#EAEAEA] text-black'
            }`}
            title="Bild direkt in Zwischenablage kopieren"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-white" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-black" />
            )}
            <span className="text-[11px]">{copied ? 'Kopiert' : 'Kopieren'}</span>
          </button>

          {/* Print A4 Card */}
          <button
            type="button"
            onClick={handlePrint}
            className="py-2 px-3 rounded-full border border-zinc-200 bg-[#F4F4F5] hover:bg-[#EAEAEA] text-black text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
            title="Druckfertige DIN A4 Vorlage mit Schnittlinien"
          >
            <Printer className="w-3.5 h-3.5 text-black" />
            <span className="text-[11px]">Drucken</span>
          </button>
        </div>

        {onSaveToHistory && (
          <button
            type="button"
            onClick={onSaveToHistory}
            className="w-full py-2 px-4 rounded-full border border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-800 text-xs font-semibold transition flex items-center justify-center gap-1.5 cursor-pointer mt-1"
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-zinc-600" />
            <span>Im Browser-Verlauf speichern</span>
          </button>
        )}
      </div>

      {/* Size Selector with rounded-full pills */}
      <div className="w-full mt-3 pt-3 border-t border-zinc-100 flex items-center justify-between text-xs text-zinc-500">
        <span className="font-medium">Auflösung:</span>
        <div className="flex gap-1">
          {[512, 1024, 2048].map((sz) => (
            <button
              key={sz}
              type="button"
              onClick={() => setCustomization({ ...customization, size: sz })}
              className={`px-3 py-0.5 rounded-full text-[11px] font-semibold transition cursor-pointer ${
                customization.size === sz
                  ? 'bg-black text-white'
                  : 'bg-[#F4F4F5] text-zinc-700 hover:bg-zinc-200'
              }`}
            >
              {sz}px
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
