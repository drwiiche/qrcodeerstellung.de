'use client';

/**
 * Navbar — minimal brand + grouped dropdown navigation:
 *   QR-Typen (Generator), Lösungen (SEO-Landingpages), Ratgeber (Blog & Guides).
 * Mobile: hamburger with expandable sections. No shadows, full-rounded pills.
 */
import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  QrCode,
  History,
  ChevronDown,
  Menu,
  X,
  Link as LinkIcon,
  Wifi,
  CreditCard,
  User,
  Package,
  FileText,
  Mail,
  MessageCircle,
  MessageSquare,
  MapPin,
  Phone,
  Calendar,
  Store,
  GraduationCap,
  CalendarDays,
  Home,
  HeartPulse,
  Newspaper,
  BookOpen,
  Info,
} from 'lucide-react';
import { QRType } from '../types/qr';

interface NavbarProps {
  onScrollToSeo: () => void;
  onOpenHistory: () => void;
  historyCount: number;
  onNavigateHome?: () => void;
  onSelectQRType?: (type: QRType) => void;
}

const QR_TYPE_ITEMS: { id: QRType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'url', label: 'Webseite / URL', icon: LinkIcon },
  { id: 'wifi', label: 'WLAN-Gastzugang', icon: Wifi },
  { id: 'vcard', label: 'Visitenkarte (vCard)', icon: User },
  { id: 'sepa', label: 'SEPA GiroCode', icon: CreditCard },
  { id: 'event', label: 'Termin / Kalender', icon: Calendar },
  { id: 'delivery', label: 'Paket-Abstellort', icon: Package },
  { id: 'sms', label: 'SMS', icon: MessageSquare },
  { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle },
  { id: 'standort', label: 'Standort auf Karte', icon: MapPin },
  { id: 'phone', label: 'Telefonnummer', icon: Phone },
  { id: 'email', label: 'E-Mail', icon: Mail },
  { id: 'text', label: 'Freitext', icon: FileText },
];

const SOLUTION_ITEMS = [
  { href: '/qr-codes-fuer/unternehmen', label: 'Für Unternehmen', icon: Store },
  { href: '/qr-codes-fuer/schulen', label: 'Für Schulen & Bildung', icon: GraduationCap },
  { href: '/qr-codes-fuer/veranstaltungen', label: 'Für Veranstaltungen', icon: CalendarDays },
  { href: '/qr-codes-fuer/immobilien', label: 'Für Immobilien', icon: Home },
  { href: '/qr-codes-fuer/gesundheit', label: 'Gesundheit & Fitness', icon: HeartPulse },
  { href: '/qr-codes-auf', label: 'Auf Marketing-Materialien', icon: FileText },
];

const GUIDE_ITEMS = [
  { href: '/blog', label: 'Blog & Anleitungen', icon: Newspaper },
  { href: '/anleitungen', label: 'Generator-Anleitung', icon: BookOpen },
  { href: '/ueber-uns', label: 'Über uns', icon: Info },
];

export const Navbar: React.FC<NavbarProps> = ({
  onScrollToSeo,
  onOpenHistory,
  historyCount,
  onNavigateHome,
  onSelectQRType,
}) => {
  const [openMenu, setOpenMenu] = useState<'types' | 'solutions' | 'guides' | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileSection, setMobileSection] = useState<string | null>('types');
  const headerRef = useRef<HTMLElement | null>(null);
  const pathname = usePathname();

  // Close menus on route change or Escape.
  useEffect(() => {
    setOpenMenu(null);
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpenMenu(null);
        setMobileOpen(false);
      }
    };
    const onClick = (e: MouseEvent) => {
      if (headerRef.current && !headerRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
      }
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onClick);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onClick);
    };
  }, []);

  const pickType = (id: QRType) => {
    onSelectQRType?.(id);
    setOpenMenu(null);
    setMobileOpen(false);
  };

  const menuBtn = (
    id: 'types' | 'solutions' | 'guides',
    label: string
  ) => (
    <button
      type="button"
      aria-haspopup="true"
      aria-expanded={openMenu === id}
      onClick={() => setOpenMenu(openMenu === id ? null : id)}
      className={`inline-flex items-center gap-1 px-4 py-1.5 text-xs font-semibold rounded-full border transition cursor-pointer ${
        openMenu === id
          ? 'bg-black text-white border-black'
          : 'text-zinc-700 hover:text-black hover:bg-zinc-100 border-zinc-200'
      }`}
    >
      {label}
      <ChevronDown className={`w-3 h-3 transition-transform ${openMenu === id ? 'rotate-180' : ''}`} />
    </button>
  );

  return (
    <header ref={headerRef} className="sticky top-0 z-40 bg-white border-b border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo: icon + name only */}
          <button
            type="button"
            onClick={onNavigateHome}
            className="flex items-center gap-2.5 text-left cursor-pointer group shrink-0"
          >
            <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center transition-transform group-hover:scale-105">
              <QrCode className="w-4 h-4 stroke-[2.2]" />
            </div>
            <span className="font-bold text-base text-black tracking-tight">QR-Code Generator</span>
          </button>

          {/* Desktop dropdown groups */}
          <nav aria-label="Hauptnavigation" className="hidden lg:flex items-center gap-2 relative">
            {menuBtn('types', 'QR-Typen')}
            {menuBtn('solutions', 'Lösungen')}
            {menuBtn('guides', 'Ratgeber')}

            {openMenu === 'types' && (
              <div className="absolute top-full left-0 mt-2 w-[560px] max-w-[90vw] bg-white rounded-[16px] border border-zinc-200 p-3 grid grid-cols-2 gap-1 z-50">
                {QR_TYPE_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => pickType(item.id)}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-full text-sm text-zinc-700 hover:bg-[#F4F4F5] hover:text-black transition text-left cursor-pointer"
                  >
                    <item.icon className="w-4 h-4 text-[#FF5832] shrink-0" />
                    {item.label}
                  </button>
                ))}
              </div>
            )}

            {openMenu === 'solutions' && (
              <div className="absolute top-full left-0 mt-2 w-80 bg-white rounded-[16px] border border-zinc-200 p-3 space-y-1 z-50">
                {SOLUTION_ITEMS.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-full text-sm text-zinc-700 hover:bg-[#F4F4F5] hover:text-black transition"
                  >
                    <item.icon className="w-4 h-4 text-[#FF5832] shrink-0" />
                    {item.label}
                  </Link>
                ))}
              </div>
            )}

            {openMenu === 'guides' && (
              <div className="absolute top-full left-0 mt-2 w-80 bg-white rounded-[16px] border border-zinc-200 p-3 space-y-1 z-50">
                {GUIDE_ITEMS.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-full text-sm text-zinc-700 hover:bg-[#F4F4F5] hover:text-black transition"
                  >
                    <item.icon className="w-4 h-4 text-[#FF5832] shrink-0" />
                    {item.label}
                  </Link>
                ))}
              </div>
            )}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenHistory}
              aria-label="Verlauf der erstellten QR-Codes anzeigen"
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-black bg-[#F4F4F5] hover:bg-[#E4E4E7] rounded-full border border-zinc-200 transition cursor-pointer"
            >
              <History className="w-3.5 h-3.5 text-zinc-700" />
              <span className="hidden sm:inline">Verlauf</span>
              {historyCount > 0 && (
                <span className="bg-[#FF5832] text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {historyCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={onScrollToSeo}
              className="hidden sm:inline-flex px-4 py-1.5 text-xs font-semibold text-white bg-black hover:bg-zinc-800 rounded-full transition cursor-pointer"
            >
              QR-Code erstellen
            </button>

            {/* Mobile hamburger */}
            <button
              type="button"
              aria-label={mobileOpen ? 'Menü schließen' : 'Menü öffnen'}
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden flex items-center justify-center w-9 h-9 rounded-full border border-zinc-200 text-black hover:bg-zinc-100 transition cursor-pointer"
            >
              {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile panel */}
      {mobileOpen && (
        <nav aria-label="Mobile Navigation" className="lg:hidden border-t border-zinc-200 bg-white max-h-[75vh] overflow-y-auto">
          <div className="px-4 py-3 space-y-1">
            <button
              type="button"
              onClick={() => setMobileSection(mobileSection === 'types' ? null : 'types')}
              className="w-full flex items-center justify-between px-2 py-2.5 text-sm font-semibold text-black"
            >
              QR-Typen
              <ChevronDown className={`w-4 h-4 transition-transform ${mobileSection === 'types' ? 'rotate-180' : ''}`} />
            </button>
            {mobileSection === 'types' && (
              <div className="grid grid-cols-2 gap-1 pb-2">
                {QR_TYPE_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => pickType(item.id)}
                    className="flex items-center gap-2 px-3 py-2 rounded-full text-xs text-zinc-700 hover:bg-[#F4F4F5] transition text-left"
                  >
                    <item.icon className="w-3.5 h-3.5 text-[#FF5832] shrink-0" />
                    {item.label}
                  </button>
                ))}
              </div>
            )}

            <p className="pt-2 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Lösungen</p>
            {SOLUTION_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-2.5 px-2 py-2 rounded-full text-sm text-zinc-700 hover:bg-[#F4F4F5] transition"
              >
                <item.icon className="w-4 h-4 text-[#FF5832] shrink-0" />
                {item.label}
              </Link>
            ))}

            <p className="pt-2 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Ratgeber</p>
            {GUIDE_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-2.5 px-2 py-2 rounded-full text-sm text-zinc-700 hover:bg-[#F4F4F5] transition"
              >
                <item.icon className="w-4 h-4 text-[#FF5832] shrink-0" />
                {item.label}
              </Link>
            ))}
          </div>
        </nav>
      )}
    </header>
  );
};