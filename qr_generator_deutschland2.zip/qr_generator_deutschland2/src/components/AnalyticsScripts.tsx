'use client';

/**
 * AnalyticsScripts — injects GA4 / GTM / custom analytics snippets
 * configured in the admin dashboard, strictly gated on the visitor's
 * analytics cookie consent. Also forwards SPA page views to dataLayer.
 */
import { useEffect } from 'react';
import { getCookieConsent } from '../utils/analytics';
import type { SiteSettings } from '../lib/settings';

declare global {
  interface Window {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}

const GA4_SRC = 'https://www.googletagmanager.com/gtag/js?id=';
const GTM_SRC = 'https://www.googletagmanager.com/gtm.js?id=';

let settingsPromise: Promise<SiteSettings> | null = null;

function fetchSettings(): Promise<SiteSettings> {
  if (!settingsPromise) {
    settingsPromise = fetch('/api/settings', { cache: 'no-store' })
      .then((r) => r.json())
      .catch(() => null);
  }
  return settingsPromise;
}

function injectScript(src: string, attrs: Record<string, string> = {}): HTMLScriptElement {
  const existing = document.querySelector(`script[src="${src}"]`) as HTMLScriptElement | null;
  if (existing) return existing;
  const script = document.createElement('script');
  script.async = true;
  script.src = src;
  Object.entries(attrs).forEach(([k, v]) => script.setAttribute(k, v));
  document.head.appendChild(script);
  return script;
}

async function applyAnalytics(consent: boolean): Promise<void> {
  if (!consent) return;
  const settings = await fetchSettings();
  if (!settings?.analytics?.enabled) return;

  const { ga4Id, gtmId, customSnippet } = settings.analytics;

  if (ga4Id) {
    window.dataLayer = window.dataLayer || [];
    window.gtag = function gtag() {
      // eslint-disable-next-line prefer-rest-params
      window.dataLayer!.push(arguments);
    };
    window.gtag('js', new Date());
    window.gtag('config', ga4Id, { anonymize_ip: true });
    injectScript(GA4_SRC + ga4Id);
  }

  if (gtmId) {
    window.dataLayer = window.dataLayer || [];
    (window as any).dataLayer.unshift({
      'gtm.start': Date.now(),
      event: 'gtm.js',
    });
    injectScript(GTM_SRC + gtmId, { 'gtm-id': gtmId });
  }

  if (customSnippet) {
    const host = document.createElement('div');
    host.innerHTML = customSnippet;
    host.querySelectorAll('script').forEach((old) => {
      const s = document.createElement('script');
      for (const attr of Array.from(old.attributes)) {
        s.setAttribute(attr.name, attr.value);
      }
      s.textContent = old.textContent;
      old.replaceWith(s);
      document.head.appendChild(s);
    });
  }
}

export function AnalyticsScripts() {
  useEffect(() => {
    const sync = (consent: ReturnType<typeof getCookieConsent>) => {
      if (consent?.analytics) {
        applyAnalytics(true);
      }
    };

    sync(getCookieConsent());
    const onChange = (e: Event) => sync((e as CustomEvent).detail ?? getCookieConsent());
    window.addEventListener('cookie_consent_changed', onChange);

    return () => {
      window.removeEventListener('cookie_consent_changed', onChange);
    };
  }, []);

  return null;
}
