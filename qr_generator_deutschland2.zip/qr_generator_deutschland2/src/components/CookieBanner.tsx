/**
 * DSGVO & TTDSG compliant Cookie Consent Banner.
 */

import React, { useState, useEffect } from 'react';
import { ShieldCheck, ChevronDown, ChevronUp, Check, Info } from 'lucide-react';
import { getCookieConsent, setCookieConsent, CookiePreferences } from '../utils/analytics';

interface CookieBannerProps {
  onNavigate: (route: string) => void;
}

export const CookieBanner: React.FC<CookieBannerProps> = ({ onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [analyticsAllowed, setAnalyticsAllowed] = useState(false);
  const [marketingAllowed, setMarketingAllowed] = useState(false);

  useEffect(() => {
    const consent = getCookieConsent();
    if (!consent) {
      setIsOpen(true);
    }

    const handleReopen = () => {
      const current = getCookieConsent();
      if (current) {
        setAnalyticsAllowed(current.analytics);
        setMarketingAllowed(current.marketing);
      }
      setShowDetails(true);
      setIsOpen(true);
    };

    window.addEventListener('open_cookie_settings', handleReopen);
    return () => window.removeEventListener('open_cookie_settings', handleReopen);
  }, []);

  const handleAcceptAll = () => {
    setCookieConsent({ essential: true, analytics: true, marketing: true });
    setIsOpen(false);
  };

  const handleAcceptEssentialOnly = () => {
    setCookieConsent({ essential: true, analytics: false, marketing: false });
    setIsOpen(false);
  };

  const handleSaveCustom = () => {
    setCookieConsent({ essential: true, analytics: analyticsAllowed, marketing: marketingAllowed });
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <aside aria-label="Cookie-Einstellungen" className="fixed bottom-0 inset-x-0 z-50 p-3 sm:p-4 bg-white border-t border-zinc-200">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Text & Notice */}
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center">
                <ShieldCheck className="w-4 h-4" />
              </span>
              <h3 className="font-semibold text-sm sm:text-base tracking-tight text-black">
                Ihre Privatsphäre ist uns wichtig (DSGVO & TTDSG)
              </h3>
            </div>
            <p className="text-xs text-zinc-500 leading-relaxed">
              Wir verwenden ausschließlich technisch notwendige Speicherungen für Ihre QR-Code-Einstellungen.
              Mit Ihrer Erlaubnis möchten wir anonyme statistische Nutzungsdaten erfassen, um den Generator stetig zu verbessern.
              Alle erstellten QR-Codes werden <strong className="text-black">100% lokal in Ihrem Browser generiert</strong> – es werden keine sensiblen Eingaben an Server übermittelt.
            </p>
            <div className="flex items-center gap-3 text-[11px] text-zinc-500">
              <button
                type="button"
                onClick={() => onNavigate('datenschutz')}
                className="underline hover:text-black cursor-pointer"
              >
                Datenschutzerklärung
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => onNavigate('impressum')}
                className="underline hover:text-black cursor-pointer"
              >
                Impressum
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => setShowDetails(!showDetails)}
                className="inline-flex items-center gap-1 hover:text-black cursor-pointer font-semibold"
              >
                {showDetails ? (
                  <>
                    <span>Weniger Details</span>
                    <ChevronUp className="w-3 h-3" />
                  </>
                ) : (
                  <>
                    <span>Einstellungen anpassen</span>
                    <ChevronDown className="w-3 h-3" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 flex-shrink-0">
            <button
              type="button"
              onClick={handleAcceptEssentialOnly}
              className="px-4 py-2 rounded-full bg-white hover:bg-[#F4F4F5] text-black text-xs font-semibold border border-zinc-200 transition cursor-pointer"
            >
              Nur notwendige
            </button>
            {showDetails ? (
              <button
                type="button"
                onClick={handleSaveCustom}
                className="px-4 py-2 rounded-full bg-[#F4F4F5] hover:bg-[#E4E4E7] text-black text-xs font-semibold border border-zinc-200 transition cursor-pointer"
              >
                Auswahl speichern
              </button>
            ) : null}
            <button
              type="button"
              onClick={handleAcceptAll}
              className="px-5 py-2 rounded-full bg-black hover:bg-zinc-800 text-white text-xs font-semibold transition cursor-pointer"
            >
              Alle akzeptieren
            </button>
          </div>
        </div>

        {/* Expandable details panel */}
        {showDetails && (
          <div className="mt-4 pt-3 border-t border-zinc-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-4 rounded-[16px] bg-[#F4F4F5] border border-zinc-200">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-black flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-[#FF5832]" />
                  Technisch essenziell
                </span>
                <span className="text-[10px] uppercase font-semibold text-zinc-500 bg-white px-1.5 py-0.5 rounded-full border border-zinc-200">
                  Immer aktiv
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 leading-normal">
                Speichert Ihre QR-Eingaben, Vorlagen und den lokalen Verlauf sicher in Ihrem Browser (HTML5 LocalStorage). Keine Server-Cookies.
              </p>
            </div>

            <div className="p-4 rounded-[16px] bg-[#F4F4F5] border border-zinc-200">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-black flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5" />
                  Anonyme Nutzungsstatistik
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={analyticsAllowed}
                    onChange={(e) => setAnalyticsAllowed(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-zinc-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-200 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
              <p className="text-[11px] text-zinc-500 leading-normal">
                Hilft uns zu verstehen, welche QR-Typen am beliebtesten sind (z. B. WLAN vs. SEPA), ohne IP-Adressen oder persönliche Daten zu speichern.
              </p>
            </div>

            <div className="p-4 rounded-[16px] bg-[#F4F4F5] border border-zinc-200">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-black flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5" />
                  Werbung &amp; Marketing
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={marketingAllowed}
                    onChange={(e) => setMarketingAllowed(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-zinc-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-200 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
              <p className="text-[11px] text-zinc-500 leading-normal">
                Ermöglicht die Einblendung von Anzeigen unserer Werbepartner (z. B. Google AdSense). Ohne Zustimmung werden keine Werbungskookies gesetzt.
              </p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
