'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Mail, Phone, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { useSite } from './SiteShell';

export const ImpressumPage: React.FC = () => {
  const router = useRouter();
  const { addToast: onNotify } = useSite();
  const onNavigateHome = () => router.push('/');
  const [contactSubject, setContactSubject] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [honeypot, setHoneypot] = useState('');
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [formError, setFormError] = useState('');

  const handleSubmitContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (sending) return;
    setFormError('');
    if (!contactMessage.trim()) {
      setFormError('Bitte geben Sie eine Nachricht ein (mindestens 5 Zeichen).');
      return;
    }
    setSending(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: contactSubject,
          message: contactMessage,
          email: contactEmail,
          company: honeypot,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setFormError(data.error || 'Senden fehlgeschlagen. Bitte versuchen Sie es erneut.');
        return;
      }
      setSent(true);
      onNotify?.('✓ Nachricht gesendet! Wir melden uns in der Regel innerhalb von 24 Stunden.');
    } catch {
      setFormError('Netzwerkfehler – bitte prüfen Sie Ihre Verbindung und versuchen Sie es erneut.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12">
      <button
        type="button"
        onClick={onNavigateHome}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#FF5832] hover:text-[#B31D00] mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Zurück zum Generator</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Legal Impressum (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-[16px] border border-zinc-200 p-6 sm:p-8 space-y-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-semibold text-black tracking-tight mb-1">
              Impressum (§ 5 TMG)
            </h1>
            <p className="text-xs text-zinc-400">
              Angaben gemäß § 5 Telemediengesetz (TMG) und § 18 Abs. 2 MStV
            </p>
          </div>

          <div className="space-y-4 text-xs sm:text-sm text-zinc-700 leading-relaxed">
            <div>
              <h2 className="font-semibold text-black text-sm mb-1">Diensteanbieter</h2>
              <p>
                <strong>QR-Generator Deutschland</strong><br />
                Ein Projekt für datenschutzfreundliche Web-Werkzeuge im Alltag
              </p>
            </div>

            <div>
              <h2 className="font-semibold text-black text-sm mb-1">Anschrift</h2>
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-zinc-400 flex-shrink-0 mt-0.5" />
                <span>
                  Friedrichstraße 123<br />
                  10117 Berlin<br />
                  Deutschland
                </span>
              </p>
            </div>

            <div>
              <h2 className="font-semibold text-black text-sm mb-1">Kontakt</h2>
              <p className="space-y-1">
                <span className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-zinc-400 flex-shrink-0" />
                  <a href="mailto:info@qr-generator-deutschland.de" className="text-[#FF5832] hover:underline">
                    info@qr-generator-deutschland.de
                  </a>
                </span>
                <span className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-zinc-400 flex-shrink-0" />
                  <span>+49 (0) 30 12345678</span>
                </span>
              </p>
            </div>

            <div>
              <h2 className="font-semibold text-black text-sm mb-1">Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV</h2>
              <p>
                Redaktion & technische Betreuung:<br />
                Friedrichstraße 123, 10117 Berlin, Deutschland
              </p>
            </div>

            <div className="pt-2 border-t border-zinc-100">
              <h2 className="font-semibold text-black text-xs mb-1">EU-Streitschlichtung</h2>
              <p className="text-[11px] text-zinc-500">
                Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit: 
                <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener noreferrer" className="text-[#FF5832] underline ml-1">
                  https://ec.europa.eu/consumers/odr
                </a>.
                Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Direct Contact Form (5 Cols) */}
        <div className="lg:col-span-5 bg-[#F4F4F5] rounded-[16px] p-6 sm:p-7 border border-zinc-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-black font-semibold text-xs uppercase tracking-wider mb-2">
              <Mail className="w-4 h-4 text-[#FF5832]" />
              Direkter Kontakt
            </div>
            <h2 className="text-lg font-semibold text-black mb-2">
              Haben Sie Fragen oder Feedback?
            </h2>
            <p className="text-xs text-zinc-500 leading-relaxed mb-6">
              Wir antworten in der Regel innerhalb von 24 Stunden an Werktagen.
            </p>

            {sent ? (
              <div className="p-4 rounded-[16px] bg-white border border-zinc-200 text-black space-y-2 text-xs" role="status">
                <div className="flex items-center gap-2 font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-[#FF5832]" />
                  Nachricht gesendet
                </div>
                <p className="text-zinc-500">
                  Vielen Dank! Wir haben Ihre Nachricht erhalten und antworten in der Regel innerhalb von 24 Stunden an Werktagen. Bei dringenden Anliegen erreichen Sie uns auch direkt unter <a href="mailto:info@qr-generator-deutschland.de" className="underline font-semibold text-black">info@qr-generator-deutschland.de</a>.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitContact} className="space-y-4" noValidate>
                <div>
                  <label htmlFor="contact-subject" className="block text-[11px] font-semibold text-zinc-500 uppercase tracking-wider mb-1">
                    Betreff
                  </label>
                  <input
                    id="contact-subject"
                    type="text"
                    placeholder="z. B. Frage zu SEPA GiroCode oder Druckvorlage"
                    value={contactSubject}
                    onChange={(e) => setContactSubject(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-full bg-white border border-zinc-200 text-black text-xs placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>

                <div>
                  <label htmlFor="contact-email" className="block text-[11px] font-semibold text-zinc-500 uppercase tracking-wider mb-1">
                    Ihre E-Mail (optional)
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    placeholder="name@beispiel.de"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-full bg-white border border-zinc-200 text-black text-xs placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>

                {/* Honeypot: hidden from humans, catches bots */}
                <div className="hidden" aria-hidden="true">
                  <label htmlFor="contact-company">Firma</label>
                  <input id="contact-company" name="company" type="text" tabIndex={-1} autoComplete="off"
                    value={honeypot} onChange={(e) => setHoneypot(e.target.value)} />
                </div>

                <div>
                  <label htmlFor="contact-message" className="block text-[11px] font-semibold text-zinc-500 uppercase tracking-wider mb-1">
                    Ihre Nachricht
                  </label>
                  <textarea
                    id="contact-message"
                    rows={4}
                    required
                    placeholder="Beschreiben Sie kurz Ihr Anliegen..."
                    value={contactMessage}
                    onChange={(e) => setContactMessage(e.target.value)}
                    aria-invalid={Boolean(formError)}
                    aria-describedby={formError ? 'contact-error' : undefined}
                    className={`w-full px-4 py-3 rounded-[16px] bg-white border text-black text-xs placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-black ${
                      formError ? 'border-red-400 ring-2 ring-red-500/15' : 'border-zinc-200'
                    }`}
                  />
                </div>

                {formError && (
                  <p id="contact-error" role="alert" className="text-xs text-red-600 font-medium">
                    {formError}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={sending}
                  className="w-full py-2.5 rounded-full bg-black hover:bg-zinc-800 text-white text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-60 disabled:cursor-wait"
                >
                  <Send className={`w-3.5 h-3.5 ${sending ? 'animate-pulse' : ''}`} />
                  <span>{sending ? 'Wird gesendet...' : 'Nachricht absenden'}</span>
                </button>
              </form>
            )}
          </div>

          <div className="pt-6 mt-6 border-t border-zinc-200 text-[11px] text-zinc-400">
            <span>Antwortzeit: Mo – Fr von 09:00 bis 18:00 Uhr</span>
          </div>
        </div>
      </div>
    </div>
  );
};
