'use client';

/**
 * SiteShell — the client boundary for all public pages.
 * Owns every piece of application state (QR data, customization, history,
 * toasts, modals) and exposes it through SiteContext so individual pages
 * (home, danke, impressum, ...) can consume it without prop drilling.
 */
import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useMemo,
} from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { Navbar } from './Navbar';
import { CookieBanner } from './CookieBanner';
import { ErrorBoundary } from './ErrorBoundary';
import { ToastContainer, ToastMessage } from './Toast';
import { HistoryDrawer, HistoryItem } from './HistoryDrawer';
import { ScanTestModal } from './ScanTestModal';
import { PrintableCard } from './PrintableCard';
import { AdSlot } from './AdSlot';
import { AnalyticsScripts } from './AnalyticsScripts';
import { QrCode, Sparkles, Download, History } from 'lucide-react';
import { trackEvent } from '../utils/analytics';
import { QRType, QRCustomization, URLData, WifiData, SepaData, VCardData, DeliveryData, TextData, EmailData, WhatsappData, SmsData, StandortData, PhoneData, EventData } from '../types/qr';
import { formatWifiPayload } from '../utils/wifi';
import { formatSepaPayload } from '../utils/sepa';
import { formatVCardPayload } from '../utils/vcard';
import { formatDeliveryPayload } from '../utils/delivery';
import { renderQRCodeToCanvas } from '../utils/qrRenderer';
import { Language, TRANSLATIONS } from '../utils/translations';

const STORAGE_KEY = 'qr_deutschland_history_v1';

export interface SiteContextValue {
  lang: Language;
  navigate: (route: string) => void;
  scrollToSeo: () => void;
  scrollToForm: () => void;
  // QR type + payload
  type: QRType;
  handleSelectType: (t: QRType) => void;
  payload: string;
  qrImageUrl: string;
  isRendering: boolean;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  // form data
  urlData: URLData; setUrlData: React.Dispatch<React.SetStateAction<URLData>>;
  wifiData: WifiData; setWifiData: React.Dispatch<React.SetStateAction<WifiData>>;
  sepaData: SepaData; setSepaData: React.Dispatch<React.SetStateAction<SepaData>>;
  vcardData: VCardData; setVcardData: React.Dispatch<React.SetStateAction<VCardData>>;
  deliveryData: DeliveryData; setDeliveryData: React.Dispatch<React.SetStateAction<DeliveryData>>;
  textData: TextData; setTextData: React.Dispatch<React.SetStateAction<TextData>>;
  emailData: EmailData; setEmailData: React.Dispatch<React.SetStateAction<EmailData>>;
  whatsappData: WhatsappData; setWhatsappData: React.Dispatch<React.SetStateAction<WhatsappData>>;
  smsData: SmsData; setSmsData: React.Dispatch<React.SetStateAction<SmsData>>;
  standortData: StandortData; setStandortData: React.Dispatch<React.SetStateAction<StandortData>>;
  phoneData: PhoneData; setPhoneData: React.Dispatch<React.SetStateAction<PhoneData>>;
  eventData: EventData; setEventData: React.Dispatch<React.SetStateAction<EventData>>;
  // customization
  customization: QRCustomization;
  setCustomization: React.Dispatch<React.SetStateAction<QRCustomization>>;
  // history
  history: HistoryItem[];
  handleSaveToHistory: () => void;
  handleRestoreHistory: (item: HistoryItem) => void;
  handleClearHistory: () => void;
  handleDeleteOneHistory: (id: string) => void;
  // overlays
  isScanTestOpen: boolean; openScanTest: () => void; closeScanTest: () => void;
  isHistoryOpen: boolean; openHistory: () => void; closeHistory: () => void;
  // toasts
  addToast: (text: string, type?: 'success' | 'error' | 'info') => void;
  // templates
  handleApplyTemplate: (
    t: QRType,
    data: Record<string, any>,
    custom?: Partial<QRCustomization>
  ) => void;
}

const SiteContext = createContext<SiteContextValue | null>(null);

export function useSite(): SiteContextValue {
  const ctx = useContext(SiteContext);
  if (!ctx) throw new Error('useSite must be used within SiteShell');
  return ctx;
}

export function SiteShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [lang] = useState<Language>('de');
  const [type, setType] = useState<QRType>('wifi');
  const [isScanTestOpen, setIsScanTestOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isRendering, setIsRendering] = useState(false);
  const [qrImageUrl, setQrImageUrl] = useState<string>('');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // ---- navigation ----------------------------------------------------------
  const navigate = (route: string) => {
    const targetPath = route === 'home' ? '/' : `/${route}`;
    if (pathname !== targetPath) {
      router.push(targetPath);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSeo = () => {
    const scroll = () =>
      document.getElementById('anleitung')?.scrollIntoView({ behavior: 'smooth' });
    if (pathname !== '/') {
      router.push('/');
      setTimeout(scroll, 300);
    } else {
      scroll();
    }
  };

  const scrollToForm = () => {
    const el = document.getElementById('qr-form-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else if (pathname !== '/') {
      router.push('/');
    }
  };

  // ---- page view tracking (client-side) ------------------------------------
  useEffect(() => {
    trackEvent('page_view', { route: pathname });
  }, [pathname]);

  // ---- history (loaded after mount to avoid SSR/hydration mismatch) --------
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyHydrated, setHistoryHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setHistory(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    setHistoryHydrated(true);
  }, []);

  useEffect(() => {
    if (!historyHydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch (e) {
      console.warn('Could not persist history to localStorage', e);
    }
  }, [history, historyHydrated]);

  const addToast = (text: string, toastType: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, text, type: toastType }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // ---- form states ---------------------------------------------------------
  const [urlData, setUrlData] = useState<URLData>({ url: 'https://the-qrcode-generator.com' });
  const [wifiData, setWifiData] = useState<WifiData>({
    ssid: 'FRITZ!Box Gastzugang',
    password: 'wlan-passwort-zuhause-2026',
    encryption: 'WPA',
    hidden: false,
  });
  const [sepaData, setSepaData] = useState<SepaData>({
    name: 'Hausverwaltung Berlin GmbH',
    iban: 'DE89 3705 0198 0000 0123 45',
    bic: '',
    amount: '450.00',
    purpose: 'Miete & Nebenkosten Oktober',
    reference: '',
  });
  const [vcardData, setVcardData] = useState<VCardData>({
    firstName: 'Maximilian',
    lastName: 'Mustermann',
    organization: 'Handwerk & Beratung',
    title: 'Geschäftsführer',
    phone: '+49 30 12345678',
    mobile: '+49 170 1234567',
    email: 'max@mustermann-service.de',
    street: 'Friedrichstraße 123',
    zip: '10117',
    city: 'Berlin',
    country: 'Deutschland',
    website: 'https://mustermann-service.de',
    note: 'Kundenberatung vor Ort',
  });
  const [deliveryData, setDeliveryData] = useState<DeliveryData>({
    recipientName: 'Familie Weber (3. OG rechts)',
    deliveryLocation: 'Hinter den Blumenkübeln auf der Terrasse abstellen',
    parcelServices: ['DHL', 'Hermes', 'Amazon', 'DPD'],
    phone: '+49 170 1234567',
    specialInstructions: 'Bitte 1x kurz klingeln und abstellen',
  });
  const [textData, setTextData] = useState<TextData>({
    text: 'Herzlich willkommen in unserer Ferienwohnung in Deutschland!',
  });
  const [emailData, setEmailData] = useState<EmailData>({
    email: 'kontakt@ferienwohnung-schwarzwald.de',
    subject: 'Buchungsanfrage',
    body: 'Guten Tag, wir möchten eine Buchung für den Sommer anfragen...',
  });
  const [whatsappData, setWhatsappData] = useState<WhatsappData>({
    phoneNumber: '+491701234567',
    message: 'Hallo! Wir haben eine Frage zur Ferienwohnung.',
  });
  const [smsData, setSmsData] = useState<SmsData>({
    phoneNumber: '+49 170 1234567',
    message: 'Hallo, ich interessiere mich für Ihr Angebot.',
  });
  const [standortData, setStandortData] = useState<StandortData>({
    latitude: '52.520008',
    longitude: '13.404954',
    label: 'Treffpunkt am Haupteingang',
  });
  const [phoneData, setPhoneData] = useState<PhoneData>({ phoneNumber: '+493012345678' });
  const [eventData, setEventData] = useState<EventData>({
    title: 'Eigentümerversammlung & Sommerfest',
    location: 'Gemeinschaftsraum, EG links',
    startDate: '2026-07-15',
    startTime: '18:00',
    endDate: '2026-07-15',
    endTime: '21:00',
    description: 'Jährliche Versammlung der Hausgemeinschaft.',
  });

  // ---- customization -------------------------------------------------------
  const [customization, setCustomization] = useState<QRCustomization>({
    foregroundColor: '#0f172a',
    backgroundColor: '#ffffff',
    useGradient: false,
    gradientColor: '#2563eb',
    gradientType: 'linear',
    gradientAngle: 45,
    dotStyle: 'rounded',
    cornerStyle: 'extra-rounded',
    eyeBorderColor: '#0f172a',
    eyeCenterColor: '#0f172a',
    errorCorrectionLevel: 'M',
    logoType: 'none',
    logoSize: 0.22,
    frameType: 'none',
    frameColor: '#2563eb',
    frameText: 'HIER SCANNEN',
    frameTextColor: '#ffffff',
    size: 1024,
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // ---- payload -------------------------------------------------------------
  const payload = useMemo(() => {
    switch (type) {
      case 'url':
        return urlData.url || 'https://qr-generator-deutschland.de';
      case 'wifi':
        return formatWifiPayload(wifiData);
      case 'sepa':
        return formatSepaPayload(sepaData);
      case 'vcard':
        return formatVCardPayload(vcardData);
      case 'delivery':
        return formatDeliveryPayload(deliveryData);
      case 'text':
        return textData.text || 'QR-Code Text';
      case 'email':
        return `mailto:${emailData.email}?subject=${encodeURIComponent(emailData.subject)}&body=${encodeURIComponent(emailData.body)}`;
      case 'whatsapp': {
        const cleanPhone = whatsappData.phoneNumber.replace(/[^0-9]/g, '');
        return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(whatsappData.message)}`;
      }
      case 'sms': {
        const smsPhone = smsData.phoneNumber.replace(/[^0-9+]/g, '');
        const body = smsData.message ? `?body=${encodeURIComponent(smsData.message)}` : '';
        return `sms:${smsPhone}${body}`;
      }
      case 'standort': {
        const lat = parseFloat(standortData.latitude.replace(',', '.'));
        const lng = parseFloat(standortData.longitude.replace(',', '.'));
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return 'https://www.google.com/maps';
        return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
      }
      case 'phone':
        return `tel:${phoneData.phoneNumber}`;
      case 'event':
        return `BEGIN:VEVENT\nSUMMARY:${eventData.title}\nLOCATION:${eventData.location}\nDESCRIPTION:${eventData.description}\nDTSTART:${eventData.startDate.replace(/[-:]/g, '')}T${eventData.startTime.replace(/[-:]/g, '')}00Z\nDTEND:${eventData.endDate.replace(/[-:]/g, '')}T${eventData.endTime.replace(/[-:]/g, '')}00Z\nEND:VEVENT`;
      default:
        return 'https://qr-generator-deutschland.de';
    }
  }, [type, urlData, wifiData, sepaData, vcardData, deliveryData, textData, emailData, whatsappData, smsData, standortData, phoneData, eventData]);

  const handleSelectType = (newType: QRType) => {
    setType(newType);
    trackEvent('qr_type_change', { type: newType });
  };

  // ---- QR rendering --------------------------------------------------------
  useEffect(() => {
    let isCancelled = false;
    const canvas = canvasRef.current;
    if (!canvas) return;

    setIsRendering(true);
    renderQRCodeToCanvas(canvas, payload, customization, 800)
      .then(() => {
        if (!isCancelled && canvas) {
          setQrImageUrl(canvas.toDataURL('image/png'));
          trackEvent('qr_generated', { type });
        }
      })
      .finally(() => {
        if (!isCancelled) setIsRendering(false);
      });

    return () => {
      isCancelled = true;
    };
  }, [payload, customization, type]);

  // ---- history actions -----------------------------------------------------
  const handleSaveToHistory = () => {
    let title = 'QR-Code';
    let dataToSave: Record<string, any> = {};

    if (type === 'wifi') {
      title = `WLAN: ${wifiData.ssid || 'Gastzugang'}`;
      dataToSave = wifiData;
    } else if (type === 'sepa') {
      title = `SEPA: ${sepaData.name || 'Überweisung'}${sepaData.amount ? ` (${sepaData.amount} €)` : ''}`;
      dataToSave = sepaData;
    } else if (type === 'delivery') {
      title = `Paket: ${deliveryData.recipientName || 'Haustür'}`;
      dataToSave = deliveryData;
    } else if (type === 'vcard') {
      title = `Kontakt: ${vcardData.firstName} ${vcardData.lastName}`;
      dataToSave = vcardData;
    } else if (type === 'url') {
      title = `Link: ${urlData.url.substring(0, 32)}`;
      dataToSave = urlData;
    } else {
      title = `${type.toUpperCase()} QR-Code`;
      dataToSave = textData;
    }

    const newItem: HistoryItem = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      title,
      type,
      previewUrl: qrImageUrl,
      data: dataToSave,
      customization: { ...customization },
    };

    setHistory((prev) => [newItem, ...prev.filter((i) => i.title !== title)].slice(0, 12));
    addToast('✓ QR-Code im Verlauf gespeichert!');
  };

  const handleRestoreHistory = (item: HistoryItem) => {
    setType(item.type);
    if (item.type === 'wifi') setWifiData(item.data as WifiData);
    else if (item.type === 'sepa') setSepaData(item.data as SepaData);
    else if (item.type === 'delivery') setDeliveryData(item.data as DeliveryData);
    else if (item.type === 'vcard') setVcardData(item.data as VCardData);
    else if (item.type === 'url') setUrlData(item.data as URLData);
    else if (item.type === 'text') setTextData(item.data as TextData);
    else if (item.type === 'sms') setSmsData(item.data as SmsData);
    else if (item.type === 'standort') setStandortData(item.data as StandortData);

    if (item.customization) setCustomization(item.customization);
    addToast(`✓ "${item.title}" geladen`);
  };

  const handleClearHistory = () => {
    setHistory([]);
    addToast('Verlauf geleert', 'info');
  };

  const handleDeleteOneHistory = (id: string) => {
    setHistory((prev) => prev.filter((i) => i.id !== id));
  };

  // ---- template application ------------------------------------------------
  const handleApplyTemplate = (
    tmplType: QRType,
    data: Record<string, any>,
    custom?: Partial<QRCustomization>
  ) => {
    setType(tmplType);
    if (tmplType === 'wifi') setWifiData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'sepa') setSepaData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'delivery') setDeliveryData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'vcard') setVcardData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'url') setUrlData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'text') setTextData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'whatsapp') setWhatsappData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'sms') setSmsData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'standort') setStandortData((prev) => ({ ...prev, ...data }));

    if (custom) setCustomization((prev) => ({ ...prev, ...custom }));
    trackEvent('template_applied', { type: tmplType });
    addToast('✓ Vorlage geladen!');
    scrollToForm();
  };

  const value: SiteContextValue = {
    lang,
    navigate,
    scrollToSeo,
    scrollToForm,
    type,
    handleSelectType,
    payload,
    qrImageUrl,
    isRendering,
    canvasRef,
    urlData, setUrlData,
    wifiData, setWifiData,
    sepaData, setSepaData,
    vcardData, setVcardData,
    deliveryData, setDeliveryData,
    textData, setTextData,
    emailData, setEmailData,
    whatsappData, setWhatsappData,
    smsData, setSmsData,
    standortData, setStandortData,
    phoneData, setPhoneData,
    eventData, setEventData,
    customization,
    setCustomization,
    history,
    handleSaveToHistory,
    handleRestoreHistory,
    handleClearHistory,
    handleDeleteOneHistory,
    isScanTestOpen,
    openScanTest: () => setIsScanTestOpen(true),
    closeScanTest: () => setIsScanTestOpen(false),
    isHistoryOpen,
    openHistory: () => setIsHistoryOpen(true),
    closeHistory: () => setIsHistoryOpen(false),
    addToast,
    handleApplyTemplate,
  };

  const t = TRANSLATIONS[lang];

  return (
    <SiteContext.Provider value={value}>
      <ErrorBoundary>
        <div className="min-h-screen bg-white flex flex-col font-sans">
          <Navbar
            onScrollToSeo={scrollToSeo}
            onOpenHistory={() => setIsHistoryOpen(true)}
            historyCount={history.length}
            onNavigateHome={() => navigate('home')}
            onSelectQRType={(t) => {
              handleSelectType(t);
              navigate('home');
              setTimeout(() => scrollToForm(), 120);
            }}
          />

          <main className="flex-1 w-full">{children}</main>

          <AdSlot position="above-footer" />

          {/* Footer with German Legal Links, Privacy, Terms, Cookie Settings */}
          <footer className="bg-white text-zinc-500 py-12 border-t border-zinc-200 text-xs">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-8 mb-8">
                <div className="md:col-span-4 lg:col-span-2">
                  <div className="flex items-center gap-2.5 text-black font-semibold text-base mb-2">
                    <span className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center">
                      <QrCode className="w-4 h-4 stroke-[2.2]" />
                    </span>
                    <span>QR-Code Generator</span>
                  </div>
                  <p className="text-zinc-500 max-w-sm text-xs leading-relaxed mb-4">
                    Der schnelle, kostenlose &amp; DSGVO-konforme QR-Code Generator für
                    Haushalte, Home-Office, Mieter und Vermieter in Deutschland. Erstellt mit
                    Respekt für Privatsphäre und Zuverlässigkeit.
                  </p>
                </div>

                <div>
                  <h4 className="text-black font-semibold mb-3">Beliebte QR-Typen</h4>
                  <ul className="space-y-2 text-xs">
                    <li>
                      <button
                        onClick={() => {
                          handleSelectType('wifi');
                          navigate('home');
                        }}
                        className="hover:text-black transition cursor-pointer"
                      >
                        WLAN Gastzugang (Fritz!Box)
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => {
                          handleSelectType('sepa');
                          navigate('home');
                        }}
                        className="hover:text-black transition cursor-pointer"
                      >
                        SEPA GiroCode (Sparkasse/Banken)
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => {
                          handleSelectType('delivery');
                          navigate('home');
                        }}
                        className="hover:text-black transition cursor-pointer"
                      >
                        Paket-Abstellort an Haustür
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => {
                          handleSelectType('vcard');
                          navigate('home');
                        }}
                        className="hover:text-black transition cursor-pointer"
                      >
                        Digitale Visitenkarte vCard
                      </button>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-black font-semibold mb-3">Lösungen</h4>
                  <ul className="space-y-2 text-xs">
                    <li>
                      <Link href="/qr-codes-fuer/unternehmen" className={`hover:text-black transition ${pathname.startsWith('/qr-codes-fuer/unternehmen') ? 'text-black font-semibold' : ''}`}>
                        Für Unternehmen
                      </Link>
                    </li>
                    <li>
                      <Link href="/qr-codes-fuer/schulen" className={`hover:text-black transition ${pathname.startsWith('/qr-codes-fuer/schulen') ? 'text-black font-semibold' : ''}`}>
                        Für Schulen &amp; Bildung
                      </Link>
                    </li>
                    <li>
                      <Link href="/qr-codes-fuer/veranstaltungen" className={`hover:text-black transition ${pathname.startsWith('/qr-codes-fuer/veranstaltungen') ? 'text-black font-semibold' : ''}`}>
                        Für Veranstaltungen
                      </Link>
                    </li>
                    <li>
                      <Link href="/qr-codes-fuer/immobilien" className={`hover:text-black transition ${pathname.startsWith('/qr-codes-fuer/immobilien') ? 'text-black font-semibold' : ''}`}>
                        Für Immobilien
                      </Link>
                    </li>
                    <li>
                      <Link href="/qr-codes-fuer/gesundheit" className={`hover:text-black transition ${pathname.startsWith('/qr-codes-fuer/gesundheit') ? 'text-black font-semibold' : ''}`}>
                        Für Gesundheit &amp; Fitness
                      </Link>
                    </li>
                    <li>
                      <Link href="/qr-codes-auf" className={`hover:text-black transition ${pathname.startsWith('/qr-codes-auf') ? 'text-black font-semibold' : ''}`}>
                        Auf Marketing-Materialien
                      </Link>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-black font-semibold mb-3">Ratgeber</h4>
                  <ul className="space-y-2 text-xs">
                    <li>
                      <Link href="/blog" className={`hover:text-black transition ${pathname.startsWith('/blog') ? 'text-black font-semibold' : ''}`}>
                        Blog &amp; Anleitungen
                      </Link>
                    </li>
                    <li>
                      <Link href="/anleitungen" className={`hover:text-black transition ${pathname === '/anleitungen' ? 'text-black font-semibold' : ''}`}>
                        Generator-Anleitung
                      </Link>
                    </li>
                    <li>
                      <Link href="/ueber-uns" className={`hover:text-black transition ${pathname === '/ueber-uns' ? 'text-black font-semibold' : ''}`}>
                        Über uns &amp; Kontakt
                      </Link>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-black font-semibold mb-3">Rechtliches &amp; Service</h4>
                  <ul className="space-y-2 text-xs">
                    <li>
                      <button
                        onClick={() => navigate('datenschutz')}
                        className={`hover:text-black transition cursor-pointer ${pathname === '/datenschutz' ? 'text-black font-semibold' : ''}`}
                      >
                        Datenschutzerklärung (DSGVO)
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => navigate('impressum')}
                        className={`hover:text-black transition cursor-pointer ${pathname === '/impressum' ? 'text-black font-semibold' : ''}`}
                      >
                        Impressum &amp; Kontakt (§ 5 TMG)
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => navigate('agb')}
                        className={`hover:text-black transition cursor-pointer ${pathname === '/agb' ? 'text-black font-semibold' : ''}`}
                      >
                        Allgemeine Geschäftsbedingungen (AGB)
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => navigate('danke')}
                        className={`hover:text-black transition cursor-pointer ${pathname === '/danke' ? 'text-black font-semibold' : ''}`}
                      >
                        Drucktipps &amp; Danke-Seite
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => window.dispatchEvent(new CustomEvent('open_cookie_settings'))}
                        className="text-[#FF5832] hover:text-[#B31D00] transition cursor-pointer"
                      >
                        Cookie-Einstellungen anpassen
                      </button>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="pt-6 border-t border-zinc-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-zinc-400 text-[11px]">
                <span>© 2026 QR-Code Generator Deutschland · Alle Rechte vorbehalten.</span>
                <div className="flex items-center gap-4">
                  <button onClick={() => navigate('datenschutz')} className="hover:text-black transition">Datenschutz</button>
                  <span>·</span>
                  <button onClick={() => navigate('impressum')} className="hover:text-black transition">Impressum</button>
                  <span>·</span>
                  <button onClick={() => navigate('agb')} className="hover:text-black transition">AGB</button>
                </div>
              </div>
            </div>
          </footer>

          {/* Smartphone Scan Simulator Modal */}
          <ScanTestModal
            isOpen={isScanTestOpen}
            onClose={() => setIsScanTestOpen(false)}
            payload={payload}
            qrType={type}
            qrImageUrl={qrImageUrl}
          />

          {/* History Drawer Modal */}
          <HistoryDrawer
            isOpen={isHistoryOpen}
            onClose={() => setIsHistoryOpen(false)}
            history={history}
            onRestore={handleRestoreHistory}
            onClear={handleClearHistory}
            onDeleteOne={handleDeleteOneHistory}
          />

          {/* Cookie Consent Banner */}
          <CookieBanner onNavigate={navigate} />

          {/* Toast Notification Container */}
          <ToastContainer toasts={toasts} onDismiss={removeToast} />

          {/* Hidden Printable A4 Card Component (Activated during window.print()) */}
          <PrintableCard
            qrImageUrl={qrImageUrl}
            type={type}
            wifiData={wifiData}
            sepaData={sepaData}
            deliveryData={deliveryData}
            vcardData={vcardData}
          />

          {/* Consent-gated analytics (GA4/GTM/custom) */}
          <AnalyticsScripts />
        </div>
      </ErrorBoundary>
    </SiteContext.Provider>
  );
}
