/**
 * SeoLandingPage — server-compatible renderer for the programmatic
 * use-case pages (/qr-codes-fuer/… and /qr-codes-auf/…).
 */
import Link from 'next/link';
import { ArrowRight, Sparkles } from 'lucide-react';
import type { SeoHub, SeoSubPage } from '../data/seo-pages';
import { AdSlot } from './AdSlot';
import { JsonLd } from './JsonLd';

interface Props {
  hub: SeoHub;
  sub?: SeoSubPage;
}

export function SeoLandingPage({ hub, sub }: Props) {
  const isHub = !sub;
  const crumbs = (
    <nav aria-label="Brotkrumen" className="text-xs text-zinc-400 mb-6">
      <Link href="/" className="hover:text-black transition">
        Startseite
      </Link>
      <span className="mx-1.5">/</span>
      {isHub ? (
        <span className="text-zinc-600">{hub.label}</span>
      ) : (
        <>
          <Link
            href={hub.slug === 'auf' ? '/qr-codes-auf' : `/qr-codes-fuer/${hub.slug}`}
            className="hover:text-black transition"
          >
            {hub.label}
          </Link>
          <span className="mx-1.5">/</span>
          <span className="text-zinc-600">{sub.title.split(':')[0]}</span>
        </>
      )}
    </nav>
  );

  if (isHub) {
    return (
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="max-w-3xl">
          {crumbs}
          <h1 className="text-3xl sm:text-5xl font-semibold tracking-tight text-black mb-4 leading-[1.05]">
            {hub.title}
          </h1>
          {hub.intro.map((p, i) => (
            <p key={i} className="text-sm sm:text-lg text-zinc-500 leading-relaxed mb-4">
              {p}
            </p>
          ))}
          <div className="mt-6">
            <Link
              href="/"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-black text-white font-semibold text-sm hover:bg-zinc-800 transition"
            >
              Zum QR-Code Generator
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        <AdSlot position="below-hero" />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-2">
          {hub.subs.map((s) => (
            <Link
              key={s.slug}
              href={`${hub.slug === 'auf' ? '/qr-codes-auf' : `/qr-codes-fuer/${hub.slug}`}/${s.slug}`}
              className="group flex flex-col bg-white rounded-[16px] border border-zinc-200 p-6 hover:border-zinc-300 transition"
            >
              <h2 className="text-base font-semibold text-black leading-snug tracking-tight mb-2 group-hover:text-[#FF5832] transition">
                {s.metaTitle}
              </h2>
              <p className="text-sm text-zinc-500 leading-relaxed flex-1">{s.metaDescription}</p>
              <span className="mt-4 pt-4 border-t border-zinc-100 text-xs font-semibold text-black flex items-center gap-1">
                Anwendungsfall ansehen
                <ArrowRight className="w-3.5 h-3.5 transition group-hover:translate-x-0.5" />
              </span>
            </Link>
          ))}
        </div>
      </div>
    );
  }

  const basePath = hub.slug === 'auf' ? '/qr-codes-auf' : `/qr-codes-fuer/${hub.slug}`;
  const others = hub.subs.filter((s) => s.slug !== sub.slug);
  const canonical = `${basePath}/${sub.slug}`;

  const breadcrumb = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Startseite', item: '/' },
      { '@type': 'ListItem', position: 2, name: hub.label, item: basePath },
      { '@type': 'ListItem', position: 3, name: sub.title.split(':')[0], item: canonical },
    ],
  };

  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: sub.faq.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <JsonLd data={breadcrumb} />
      <JsonLd data={faqSchema} />
      <div className="max-w-3xl">
        {crumbs}

        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-black mb-5 leading-[1.08]">
          {sub.title}
        </h1>

        {sub.intro.map((p, i) => (
          <p key={i} className="text-base sm:text-lg text-zinc-500 leading-relaxed mb-4">
            {p}
          </p>
        ))}

        <div className="mt-6 mb-2">
          <Link
            href={sub.toolLinks[0]?.href || '/'}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-black text-white font-semibold text-sm hover:bg-zinc-800 transition"
          >
            <Sparkles className="w-4 h-4" />
            {sub.toolLinks[0]?.label || 'QR-Code erstellen'}
          </Link>
        </div>

        <AdSlot position="below-hero" />

        <section aria-labelledby="usecases" className="mt-10">
          <h2 id="usecases" className="text-xl font-semibold text-black tracking-tight mb-4">
            Praxis-Typische Anwendungsfälle
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {sub.useCases.map((u) => (
              <div key={u.title} className="rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-5">
                <h3 className="text-sm font-semibold text-black mb-1.5">{u.title}</h3>
                <p className="text-sm text-zinc-600 leading-relaxed">{u.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section aria-labelledby="steps" className="mt-10">
          <h2 id="steps" className="text-xl font-semibold text-black tracking-tight mb-4">
            In vier Schritten zum eigenen Code
          </h2>
          <ol className="space-y-3">
            {sub.steps.map((s, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-zinc-600 leading-relaxed">
                <span className="shrink-0 w-6 h-6 rounded-full bg-black text-white text-[11px] font-semibold flex items-center justify-center">
                  {i + 1}
                </span>
                {s}
              </li>
            ))}
          </ol>
        </section>

        <section aria-labelledby="tools" className="mt-10 rounded-[16px] border border-zinc-200 bg-[#F4F4F5] p-6">
          <h2 id="tools" className="text-base font-semibold text-black tracking-tight mb-3">
            Passende Generatoren
          </h2>
          <div className="flex flex-wrap gap-2">
            {sub.toolLinks.map((l) => (
              <Link
                key={l.href + l.label}
                href={l.href}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-white hover:bg-white text-black text-xs font-semibold border border-zinc-200 hover:border-zinc-300 transition"
              >
                {l.label}
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            ))}
          </div>

          {sub.blogLinks.length > 0 && (
            <>
              <h3 className="mt-5 mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">
                Vertiefung im Blog
              </h3>
              <ul className="space-y-1.5 text-sm">
                {sub.blogLinks.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-black underline decoration-[#FF5832] decoration-2 underline-offset-4 hover:text-[#FF5832] transition">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </>
          )}
        </section>

        <AdSlot position="mid-content" />

        <section aria-labelledby="faq" className="mt-10">
          <h2 id="faq" className="text-xl font-semibold text-black tracking-tight mb-4">
            Häufige Fragen
          </h2>
          <div className="space-y-4">
            {sub.faq.map((f) => (
              <div key={f.q} className="rounded-[16px] border border-zinc-200 p-5">
                <h3 className="text-sm font-semibold text-black mb-1.5">{f.q}</h3>
                <p className="text-sm text-zinc-600 leading-relaxed">{f.a}</p>
              </div>
            ))}
          </div>
        </section>

        {others.length > 0 && (
          <section aria-labelledby="more" className="mt-10">
            <h2 id="more" className="text-base font-semibold text-black tracking-tight mb-3">
              Weitere Anwendungsfälle: {hub.label}
            </h2>
            <div className="flex flex-wrap gap-2">
              {others.map((s) => (
                <Link
                  key={s.slug}
                  href={`${basePath}/${s.slug}`}
                  className="px-4 py-2 rounded-full bg-white hover:bg-[#F4F4F5] text-zinc-700 text-xs font-semibold border border-zinc-200 transition"
                >
                  {s.title.split(':')[0]}
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}