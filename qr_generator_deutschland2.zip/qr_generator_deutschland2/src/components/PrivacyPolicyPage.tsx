'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { ShieldCheck, ArrowLeft, Lock, HardDrive, CheckCircle2 } from 'lucide-react';

export const PrivacyPolicyPage: React.FC = () => {
  const router = useRouter();
  const onNavigateHome = () => router.push('/');

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12">
      <button
        type="button"
        onClick={onNavigateHome}
        className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FF5832] hover:text-[#B31D00] mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Zurück zum Generator</span>
      </button>

      <div className="bg-white rounded-[16px] border border-zinc-200 p-6 sm:p-10 space-y-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-black tracking-tight mb-2">
            Datenschutzerklärung
          </h1>
          <p className="text-xs text-zinc-400">
            Stand: 2026 · Gültig für https://qr-generator-deutschland.de
          </p>
        </div>

        {/* Highlight Box: 100% Client-Side Privacy */}
        <div className="rounded-[16px] bg-[#F4F4F5] border border-zinc-200 p-5 text-black space-y-2">
          <div className="flex items-center gap-2 font-semibold text-sm text-black">
            <Lock className="w-4 h-4" />
            Besonderer Schutz: 100% Client-Side Generierung im Browser
          </div>
          <p className="text-xs text-zinc-600 leading-relaxed">
            Ihre Privatsphäre ist das Fundament dieses Dienstes. Wenn Sie sensible Daten wie Ihr WLAN-Passwort, Ihre Bankverbindung (SEPA IBAN) oder persönliche Visitenkarten eingeben, werden diese <strong>ausschließlich lokal in Ihrem eigenen Webbrowser</strong> verarbeitet. Es findet zu keinem Zeitpunkt eine Übertragung oder Speicherung Ihrer Eingaben auf unseren Webservern statt.
          </p>
        </div>

        {/* Section 1 */}
        <section className="space-y-3 text-xs sm:text-sm text-zinc-700 leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-black border-b border-zinc-100 pb-2">
            1. Datenschutz auf einen Blick
          </h2>
          <h3 className="font-bold text-zinc-800">Allgemeine Hinweise</h3>
          <p>
            Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.
          </p>
          <h3 className="font-bold text-zinc-800">Wer ist verantwortlich für die Datenerfassung auf dieser Website?</h3>
          <p>
            Die Datenverarbeitung auf dieser Website erfolgt durch den Websitebetreiber:
            <br />
            <strong>QR-Generator Deutschland</strong>
            <br />
            Friedrichstraße 123, 10117 Berlin, Deutschland
            <br />
            E-Mail: info@qr-generator-deutschland.de
          </p>
        </section>

        {/* Section 2 */}
        <section className="space-y-3 text-xs sm:text-sm text-zinc-700 leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-black border-b border-zinc-100 pb-2">
            2. Datenerfassung auf dieser Website
          </h2>
          <h3 className="font-bold text-zinc-800">HTML5 LocalStorage (Lokaler Browser-Speicher)</h3>
          <p>
            Diese Website nutzt die lokale Speicherfunktion Ihres Browsers (LocalStorage), um Ihren optionalen Verlauf kürzlich generierter QR-Codes sowie Ihre Spracheinstellungen und Cookie-Präferenzen zu speichern. Diese Daten verbleiben auf Ihrem Endgerät und werden zu keinem Zeitpunkt an unsere Server übermittelt. Sie können den Verlauf jederzeit über den Button „Verlauf leeren“ im Menü oder über die Einstellungen Ihres Browsers vollständig löschen.
          </p>

          <h3 className="font-bold text-zinc-800">Server-Log-Dateien</h3>
          <p>
            Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log-Dateien, die Ihr Browser automatisch an uns übermittelt:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-zinc-600">
            <li>Browsertyp und Browserversion</li>
            <li>Verwendetes Betriebssystem</li>
            <li>Referrer URL</li>
            <li>Hostname des zugreifenden Rechners</li>
            <li>Uhrzeit der Serveranfrage</li>
            <li>IP-Adresse (anonymisiert)</li>
          </ul>
          <p>
            Eine Zusammenführung dieser Daten mit anderen Datenquellen wird nicht vorgenommen. Grundlage für die Datenverarbeitung ist Art. 6 Abs. 1 lit. f DSGVO.
          </p>
        </section>

        {/* Section 3 */}
        <section className="space-y-3 text-xs sm:text-sm text-zinc-700 leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-black border-b border-zinc-100 pb-2">
            3. Analyse-Tools und Cookies
          </h2>
          <p>
            Wir setzen Cookies und Web-Analyse nur ein, wenn Sie dem im Cookie-Consent-Banner ausdrücklich zugestimmt haben (Art. 6 Abs. 1 lit. a DSGVO). Wenn Sie dem widersprechen oder nur essenzielle Cookies auswählen, werden keinerlei Tracking-Mechanismen aktiviert.
          </p>
        </section>

        {/* Section 4 */}
        <section className="space-y-3 text-xs sm:text-sm text-zinc-700 leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-black border-b border-zinc-100 pb-2">
            4. Ihre Rechte als betroffene Person
          </h2>
          <p>
            Sie haben jederzeit das Recht auf unentgeltliche Auskunft über Ihre gespeicherten personenbezogenen Daten, deren Herkunft und Empfänger und den Zweck der Datenverarbeitung (Art. 15 DSGVO) sowie ein Recht auf Berichtigung (Art. 16 DSGVO), Sperrung oder Löschung dieser Daten (Art. 17 DSGVO). Hierzu sowie zu weiteren Fragen zum Thema Datenschutz können Sie sich jederzeit unter der im Impressum angegebenen Adresse an uns wenden.
          </p>
        </section>
      </div>
    </div>
  );
};
