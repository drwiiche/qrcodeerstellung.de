/**
 * JsonLd — renders schema.org structured data as an injected JSON-LD script.
 * The `<` escape prevents premature script termination.
 */
export function JsonLd({ data }: { data: Record<string, unknown> }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, '\\u003c') }}
    />
  );
}