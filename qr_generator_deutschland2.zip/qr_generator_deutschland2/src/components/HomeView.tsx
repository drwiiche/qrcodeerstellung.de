'use client';

/**
 * HomeView — the generator page content (compact hero, type tabs, form,
 * customizer, preview, about, SEO sections, sticky mobile CTA).
 *
 * The generator itself sits directly under the headline — above the fold —
 * because it is the first thing visitors should see.
 */
import React, { useEffect } from 'react';
import { QRTypeSelector } from './QRTypeSelector';
import { QRForm } from './QRForm';
import { QRCustomizer } from './QRCustomizer';
import { QRPreviewCard } from './QRPreviewCard';
import { ProgrammaticSeoSection } from './ProgrammaticSeoSection';
import { AdSlot } from './AdSlot';
import { useSite } from './SiteShell';
import { Download, History } from 'lucide-react';
import { trackEvent } from '../utils/analytics';
import { QRType } from '../types/qr';
import { QR_TYPE_LABELS } from '../utils/translations';

export function HomeView() {
  const site = useSite();

  // Preselect a QR type via /?type=wifi (used by the 404 quick links).
  // Read window.location directly to avoid the useSearchParams Suspense requirement.
  useEffect(() => {
    const requested = new URLSearchParams(window.location.search).get('type');
    if (requested && requested in QR_TYPE_LABELS) {
      site.handleSelectType(requested as QRType);
    }
    // Only on mount — later param changes are irrelevant.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
      {/* Compact hero — headline only, the generator is what follows immediately */}
      <header className="max-w-3xl mb-5">
        <h1 className="text-2xl sm:text-4xl font-semibold tracking-tight text-black mb-2 leading-[1.08]">
          Kostenlose QR-Codes für Zuhause &amp; Home-Office
        </h1>
        <p className="text-sm sm:text-base text-zinc-500 leading-relaxed max-w-2xl">
          Gäste-WLAN für Fritz!Box &amp; Speedport, SEPA GiroCode, Paket-Abstellhinweise und
          digitale Visitenkarten – sofort, lokal und dauerhaft gültig.
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1 text-xs text-zinc-400">
          <span>Sofortige Vorschau</span>
          <span>Hochauflösendes SVG &amp; PNG</span>
          <span>Dauerhaft gültig</span>
        </div>
      </header>

      {/* QR-Code type tabs — compact single line with overflow "Mehr" menu */}
      <div className="mb-5">
        <QRTypeSelector currentType={site.type} onSelectType={site.handleSelectType} />
      </div>

      {/* Generator grid — form & customizer left, sticky preview right (above the fold) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Form & Customizer */}
        <div id="qr-form-section" className="lg:col-span-7 xl:col-span-8 space-y-6">
          {/* Input Form Box */}
          <div className="bg-white rounded-[16px] border border-zinc-200 p-5 sm:p-6">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-zinc-100">
              <h2 className="text-sm sm:text-base font-semibold text-black tracking-tight">
                Daten für QR-Code eingeben
              </h2>
              <span className="text-[11px] text-zinc-400 font-medium">Automatische Vorschau</span>
            </div>

            <QRForm
              type={site.type}
              urlData={site.urlData}
              setUrlData={site.setUrlData}
              wifiData={site.wifiData}
              setWifiData={site.setWifiData}
              sepaData={site.sepaData}
              setSepaData={site.setSepaData}
              vcardData={site.vcardData}
              setVcardData={site.setVcardData}
              deliveryData={site.deliveryData}
              setDeliveryData={site.setDeliveryData}
              textData={site.textData}
              setTextData={site.setTextData}
              emailData={site.emailData}
              setEmailData={site.setEmailData}
              whatsappData={site.whatsappData}
              setWhatsappData={site.setWhatsappData}
              smsData={site.smsData}
              setSmsData={site.setSmsData}
              standortData={site.standortData}
              setStandortData={site.setStandortData}
              phoneData={site.phoneData}
              setPhoneData={site.setPhoneData}
              eventData={site.eventData}
              setEventData={site.setEventData}
              lang={site.lang}
            />
          </div>

          {/* Customizer Panel */}
          <QRCustomizer customization={site.customization} setCustomization={site.setCustomization} />
        </div>

        {/* Right Column: Sticky Preview Card on Desktop */}
        <div className="lg:col-span-5 xl:col-span-4 lg:sticky lg:top-20 space-y-4">
          <QRPreviewCard
            canvasRef={site.canvasRef}
            qrImageUrl={site.qrImageUrl}
            payload={site.payload}
            customization={site.customization}
            setCustomization={site.setCustomization}
            onOpenScanTest={site.openScanTest}
            onSaveToHistory={site.handleSaveToHistory}
            onNotify={site.addToast}
            onNavigateThankYou={() => site.navigate('danke')}
            isRendering={site.isRendering}
          />

          {/* Trust & German Compliance Card */}
          <div className="bg-[#F4F4F5] rounded-[16px] border border-zinc-200 p-4 text-xs text-zinc-600 space-y-2.5">
            <div className="flex items-center gap-2 font-semibold text-black">
              <span className="w-2 h-2 rounded-full bg-[#FF5832]" />
              Sicher für deutsche Anwender
            </div>
            <ul className="space-y-1.5 text-[11px] text-zinc-500">
              <li className="flex items-center gap-1.5">
                <span className="text-[#FF5832] font-bold">✓</span>
                Keine Datenübertragung an Server (Client-Side)
              </li>
              <li className="flex items-center gap-1.5">
                <span className="text-[#FF5832] font-bold">✓</span>
                Statische Codes ohne Weiterleitung (Lebenslang gültig)
              </li>
              <li className="flex items-center gap-1.5">
                <span className="text-[#FF5832] font-bold">✓</span>
                Geprüft nach deutschem SEPA GiroCode Standard
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Ad: below hero / generator */}
      <div className="mt-8">
        <AdSlot position="below-hero" />
      </div>

      {/* Ad: mid content */}
      <AdSlot position="mid-content" />

      {/* How it works, solutions & FAQ */}
      <ProgrammaticSeoSection />

      {/* Mobile Sticky CTA Bar */}
      <aside
        aria-label="Schnellaktionen"
        className="lg:hidden sticky bottom-0 z-40 -mx-4 sm:-mx-6 lg:-mx-8 mt-8 bg-white/95 backdrop-blur-md border-t border-zinc-200 p-3"
      >
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={site.openScanTest}
            className="flex items-center gap-2 cursor-pointer bg-[#F4F4F5] p-1.5 rounded-full border border-zinc-200"
          >
            <div className="w-9 h-9 rounded-full bg-white p-0.5 border border-zinc-200 flex-shrink-0">
              {site.qrImageUrl && (
                <img
                  src={site.qrImageUrl}
                  alt="QR-Code Miniaturansicht"
                  className="w-full h-full object-contain"
                />
              )}
            </div>
            <div className="text-left pr-1">
              <span className="text-[10px] font-semibold text-black block leading-tight">
                ✓ 100% Scanbar
              </span>
              <span className="text-[10px] text-[#FF5832] font-semibold">Testen</span>
            </div>
          </button>

          <div className="flex items-center gap-2 flex-1 justify-end">
            <button
              type="button"
              onClick={site.handleSaveToHistory}
              aria-label="Im Verlauf speichern"
              className="p-2.5 rounded-full bg-[#F4F4F5] hover:bg-[#E4E4E7] text-black text-xs font-semibold transition cursor-pointer"
              title="Speichern"
            >
              <History className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={site.scrollToSeo}
              className="py-2.5 px-4 rounded-full bg-[#F4F4F5] hover:bg-[#E4E4E7] text-black text-xs font-semibold transition cursor-pointer"
            >
              Anleitung
            </button>

            <button
              type="button"
              onClick={() => {
                if (!site.canvasRef.current) return;
                const link = document.createElement('a');
                link.download = `qrcode-deutschland-${Date.now()}.png`;
                link.href = site.canvasRef.current.toDataURL('image/png', 1.0);
                link.click();
                site.addToast('✓ PNG heruntergeladen!');
                trackEvent('qr_download_png');
                setTimeout(() => site.navigate('danke'), 1000);
              }}
              className="py-2.5 px-5 rounded-full bg-black text-white font-semibold text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>PNG</span>
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
}
