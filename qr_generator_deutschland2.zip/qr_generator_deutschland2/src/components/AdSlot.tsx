'use client';

/**
 * AdSlot — renders configured ad providers (AdSense, AppLovin, custom
 * snippets) at a given position, gated by:
 *   1. the dashboard "ads enabled" master switch,
 *   2. the provider's own enabled flag + position match,
 *   3. the visitor's cookie consent (marketing category).
 *
 * Settings are cached briefly (15s) and re-fetched when the tab regains
 * focus, so enabling ads in the dashboard shows up without a hard reload.
 */
import React, { useEffect, useRef, useState } from 'react';
import { getCookieConsent } from '../utils/analytics';
import type { AdProvider, AdSlotPosition, SiteSettings } from '../lib/settings';

interface AdSlotProps {
  position: AdSlotPosition;
}

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

const SETTINGS_TTL_MS = 15_000;
let settingsCache: { data: Promise<SiteSettings | null>; at: number } | null = null;

function fetchSettings(force = false): Promise<SiteSettings | null> {
  if (!force && settingsCache && Date.now() - settingsCache.at < SETTINGS_TTL_MS) {
    return settingsCache.data;
  }
  const data = fetch('/api/settings', { cache: 'no-store' })
    .then((r) => r.json())
    .catch(() => null);
  settingsCache = { data, at: Date.now() };
  return data;
}

export function AdSlot({ position }: AdSlotProps) {
  const [providers, setProviders] = useState<AdProvider[]>([]);
  const [consentGiven, setConsentGiven] = useState(false);

  useEffect(() => {
    let alive = true;

    const sync = (consent: ReturnType<typeof getCookieConsent>, force = false) => {
      if (!alive) return;
      const marketing = Boolean(consent?.marketing);
      setConsentGiven(marketing);
      if (!marketing) {
        setProviders([]);
        return;
      }
      fetchSettings(force).then((settings) => {
        if (!alive || !settings?.ads?.enabled) {
          setProviders([]);
          return;
        }
        setProviders(
          settings.ads.providers.filter((p) => p.enabled && p.positions.includes(position))
        );
      });
    };

    sync(getCookieConsent());
    const onChange = (e: Event) => sync((e as CustomEvent).detail ?? getCookieConsent());
    const onFocus = () => sync(getCookieConsent(), true);
    window.addEventListener('cookie_consent_changed', onChange);
    // Re-check when the visitor comes back from the admin dashboard tab.
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', onFocus);
    return () => {
      alive = false;
      window.removeEventListener('cookie_consent_changed', onChange);
      window.removeEventListener('focus', onFocus);
      document.removeEventListener('visibilitychange', onFocus);
    };
  }, [position]);

  if (providers.length === 0) return null;

  return (
    <aside aria-label="Werbung" className="my-6">
      <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-zinc-400">
        Werbung
      </p>
      <div className="overflow-hidden rounded-[16px] border border-zinc-200 bg-[#F4F4F5]">
        {providers.map((provider) =>
          provider.type === 'adsense' && provider.clientId ? (
            <AdSenseUnit
              key={provider.id}
              provider={provider}
              position={position}
              consentGiven={consentGiven}
            />
          ) : (
            <CustomSnippet key={provider.id} html={provider.snippet} />
          )
        )}
      </div>
    </aside>
  );
}

function AdSenseUnit({
  provider,
  position,
  consentGiven,
}: {
  provider: AdProvider;
  position: AdSlotPosition;
  consentGiven: boolean;
}) {
  const slotId = (provider.slots[position] || '').replace(/[^0-9]/g, '');
  const insRef = useRef<HTMLModElement | null>(null);
  const pushedRef = useRef(false);
  const [scriptReady, setScriptReady] = useState(false);
  const [scriptFailed, setScriptFailed] = useState(false);

  // Load the AdSense script once per publisher ID.
  useEffect(() => {
    if (!consentGiven) return;
    const src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${provider.clientId}`;
    const existing = document.querySelector(`script[src="${src}"]`) as HTMLScriptElement | null;
    if (existing) {
      setScriptReady(true);
      return;
    }
    const script = document.createElement('script');
    script.async = true;
    script.crossOrigin = 'anonymous';
    script.src = src;
    script.onload = () => setScriptReady(true);
    script.onerror = () => {
      setScriptFailed(true);
      if (process.env.NODE_ENV !== 'production') {
        console.warn('[AdSlot] AdSense-Skript konnte nicht geladen werden:', src);
      }
    };
    document.head.appendChild(script);
  }, [consentGiven, provider.clientId]);

  // Push the slot exactly once per mounted <ins> element.
  useEffect(() => {
    if (!scriptReady || !insRef.current || pushedRef.current) return;
    pushedRef.current = true;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      /* AdSense not yet initialized — ignore */
      console.warn('[AdSlot] adsbygoogle.push fehlgeschlagen', e);
    }
  }, [scriptReady, consentGiven, position]);

  if (!consentGiven || !slotId) return null;

  return (
    <div className="min-h-[90px] w-full p-2">
      {scriptFailed && process.env.NODE_ENV !== 'production' && (
        <p className="p-3 text-center text-xs text-zinc-500">
          AdSense-Skript nicht erreichbar (lokale Entwicklung) – Platzhalter für Position „
          {position}“.
        </p>
      )}
      <ins
        ref={insRef}
        className="adsbygoogle"
        style={{ display: 'block', minHeight: 90 }}
        data-ad-client={provider.clientId}
        data-ad-slot={slotId}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}

function CustomSnippet({ html }: { html: string }) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const [mountedHtml, setMountedHtml] = useState('');

  useEffect(() => {
    setMountedHtml(html);
    // Scripts inserted via innerHTML don't execute — re-create them.
    const host = hostRef.current;
    if (!host) return;
    host.querySelectorAll('script').forEach((old) => {
      const s = document.createElement('script');
      for (const attr of Array.from(old.attributes)) {
        s.setAttribute(attr.name, attr.value);
      }
      s.textContent = old.textContent;
      old.replaceWith(s);
    });
  }, [html]);

  if (!html) return null;
  return <div ref={hostRef} dangerouslySetInnerHTML={{ __html: mountedHtml }} />;
}