/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      aria-atomic="true"
      className="fixed bottom-16 sm:bottom-6 right-4 sm:right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none"
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`pointer-events-auto p-3.5 rounded-full border flex items-center justify-between gap-3 text-xs font-semibold transition animate-in slide-in-from-bottom-3 duration-200 ${
            toast.type === 'success'
              ? 'bg-black text-white border-zinc-200'
              : toast.type === 'error'
              ? 'bg-[#B31D00] text-white border-[#B31D00]'
              : 'bg-white text-black border-zinc-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-[#FF5832] flex-shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-[#B31D00] flex-shrink-0" />}
            {toast.type === 'info' && <Info className="w-4 h-4 text-zinc-400 flex-shrink-0" />}
            <span>{toast.text}</span>
          </div>
          <button
            type="button"
            onClick={() => onDismiss(toast.id)}
            className="text-zinc-500 hover:text-white transition p-0.5"
            aria-label="Schließen"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
