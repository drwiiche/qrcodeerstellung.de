/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { History, X, Trash2, ArrowRight, Clock, QrCode } from 'lucide-react';
import { QRType, QRCustomization } from '../types/qr';
import { QR_TYPE_LABELS } from '../utils/translations';

export interface HistoryItem {
  id: string;
  timestamp: number;
  title: string;
  type: QRType;
  previewUrl: string;
  data: Record<string, any>;
  customization: QRCustomization;
}

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
  onRestore: (item: HistoryItem) => void;
  onClear: () => void;
  onDeleteOne: (id: string) => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  history,
  onRestore,
  onClear,
  onDeleteOne,
}) => {
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="history-drawer-title"
      className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-150"
    >
      <div className="w-full max-w-md bg-white h-full flex flex-col border-l border-zinc-200 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-zinc-200 flex items-center justify-between bg-[#F4F4F5]">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-[#FF5832]" />
            <h2 id="history-drawer-title" className="text-sm font-bold text-black">
              Zuletzt erstellte QR-Codes ({history.length})
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Verlauf schließen"
            className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 hover:bg-[#E4E4E7] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {history.length === 0 ? (
            <div className="text-center py-12 text-zinc-400 space-y-2">
              <QrCode className="w-10 h-10 mx-auto text-zinc-300 stroke-1" />
              <p className="text-xs font-semibold">Noch keine QR-Codes im Verlauf.</p>
              <p className="text-[11px] text-zinc-400 max-w-xs mx-auto">
                Wenn Sie einen QR-Code herunterladen oder kopieren, wird er automatisch hier lokal auf Ihrem Gerät gespeichert.
              </p>
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl border border-zinc-200 hover:border-zinc-300 bg-[#F4F4F5]/70 hover:bg-white transition flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-lg bg-white p-1 border border-zinc-200 flex-shrink-0">
                    <img
                      src={item.previewUrl}
                      alt={`Vorschau des QR-Codes: ${item.title || 'Gespeicherter Code'}`}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-[10px] text-zinc-400 mb-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      <span>•</span>
                      <span className="uppercase font-semibold text-[#FF5832]">{QR_TYPE_LABELS[item.type] || item.type}</span>
                    </div>
                    <h3 className="text-xs font-bold text-black truncate">
                      {item.title}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      onRestore(item);
                      onClose();
                    }}
                    className="p-2 rounded-lg bg-[#F4F4F5] hover:bg-black hover:text-white text-black transition text-xs font-bold flex items-center gap-1 cursor-pointer"
                    title="Wiederherstellen"
                  >
                    <span>Laden</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteOne(item.id)}
                    className="p-2 rounded-lg text-zinc-400 hover:text-rose-600 transition cursor-pointer"
                    title="Löschen"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {history.length > 0 && (
          <div className="p-3 border-t border-zinc-200 bg-[#F4F4F5] flex items-center justify-between">
            <span className="text-[11px] text-zinc-400">
              Lokal in Ihrem Browser gespeichert (DSGVO)
            </span>
            <button
              type="button"
              onClick={onClear}
              className="text-xs text-rose-600 hover:text-rose-800 font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Verlauf leeren
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
