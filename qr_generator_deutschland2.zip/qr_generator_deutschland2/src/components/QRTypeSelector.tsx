/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  Link as LinkIcon,
  Wifi,
  CreditCard,
  User,
  Package,
  FileText,
  Mail,
  MessageCircle,
  MessageSquare,
  Phone,
  Calendar,
  MapPin,
  ChevronDown,
} from 'lucide-react';
import { QRType } from '../types/qr';

interface QRTypeSelectorProps {
  currentType: QRType;
  onSelectType: (type: QRType) => void;
}

interface TypeTab {
  id: QRType;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
}

/** All QR types the form supports — rendered as a single compact tab row. */
const TYPES: TypeTab[] = [
  { id: 'url', title: 'Webseite', icon: LinkIcon },
  { id: 'wifi', title: 'WLAN', icon: Wifi },
  { id: 'sepa', title: 'SEPA', icon: CreditCard },
  { id: 'vcard', title: 'Visitenkarte', icon: User },
  { id: 'delivery', title: 'Paket', icon: Package },
  { id: 'standort', title: 'Standort', icon: MapPin },
  { id: 'event', title: 'Termin', icon: Calendar },
  { id: 'phone', title: 'Telefon', icon: Phone },
  { id: 'sms', title: 'SMS', icon: MessageSquare },
  { id: 'whatsapp', title: 'WhatsApp', icon: MessageCircle },
  { id: 'email', title: 'E-Mail', icon: Mail },
  { id: 'text', title: 'Text', icon: FileText },
];

const TAB_CLASSES =
  'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-3.5 py-2 text-xs font-semibold transition cursor-pointer';

function TabButton({
  item,
  isActive,
  onClick,
  tabIndex,
}: {
  item: TypeTab;
  isActive: boolean;
  onClick: () => void;
  tabIndex?: number;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={onClick}
      tabIndex={tabIndex}
      aria-current={isActive ? 'true' : undefined}
      className={`${TAB_CLASSES} ${
        isActive
          ? 'bg-black text-white border-black'
          : 'bg-white text-black border-zinc-200 hover:bg-[#F4F4F5]'
      }`}
    >
      <Icon className="w-3.5 h-3.5 stroke-[2]" />
      <span>{item.title}</span>
    </button>
  );
}

export const QRTypeSelector: React.FC<QRTypeSelectorProps> = ({
  currentType,
  onSelectType,
}) => {
  const rowRef = useRef<HTMLDivElement | null>(null);
  const stripRef = useRef<HTMLDivElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [maxVisible, setMaxVisible] = useState(TYPES.length);
  const [moreOpen, setMoreOpen] = useState(false);

  // Fit as many tabs as possible on one line; the rest go into "Mehr".
  // Widths are read from a hidden strip that renders every tab icon + label
  // with the exact same markup/classes as the real buttons.
  const measure = React.useCallback(() => {
    const row = rowRef.current;
    const strip = stripRef.current;
    if (!row || !strip) return;
    const avail = row.clientWidth;
    const gap = 8;
    const moreReserve = 128; // room for the "Mehr (n)" pill incl. chevron
    const widths = Array.from(strip.children).map((c) =>
      Math.ceil(c.getBoundingClientRect().width)
    );
    const fits = (count: number): boolean => {
      let sum = 0;
      for (let i = 0; i < count; i++) sum += widths[i];
      sum += (count - 1) * gap;
      if (count < TYPES.length) sum += gap + moreReserve; // "Mehr" pill needed
      return sum <= avail;
    };
    let count = TYPES.length;
    while (count > 1 && !fits(count)) count -= 1;
    setMaxVisible(count);
  }, []);

  useLayoutEffect(() => {
    measure();
    const ro = new ResizeObserver(measure);
    if (rowRef.current) ro.observe(rowRef.current);
    // Re-measure once the webfont has loaded (widths shift).
    if (typeof document !== 'undefined' && 'fonts' in document) {
      document.fonts.ready.then(measure).catch(() => undefined);
    }
    return () => ro.disconnect();
  }, [measure]);

  // Safety net: if anything still overflows after render (font swap, rounding),
  // drop one more tab — the "Mehr" pill must never be clipped by overflow-hidden.
  useLayoutEffect(() => {
    const row = rowRef.current;
    if (!row) return;
    if (row.scrollWidth > row.clientWidth + 1 && maxVisible > 1) {
      setMaxVisible((m) => Math.max(1, m - 1));
    }
  }, [maxVisible]);

  // Close the overflow menu on outside click / Escape.
  useEffect(() => {
    if (!moreOpen) return;
    const onDown = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setMoreOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMoreOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [moreOpen]);

  const shown = TYPES.slice(0, maxVisible);
  const hidden = TYPES.slice(maxVisible);

  const select = (id: QRType) => {
    onSelectType(id);
    setMoreOpen(false);
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-500">
          QR-Code Typ wählen
        </h2>
        <span className="text-xs text-zinc-400">{TYPES.length} Typen verfügbar</span>
      </div>

      <div ref={wrapRef} className="relative">
        {/* Hidden measurement strip — always contains every tab */}
        <div
          ref={stripRef}
          aria-hidden="true"
          className="absolute left-0 top-0 -z-10 flex gap-2 opacity-0 pointer-events-none select-none"
          style={{ visibility: 'hidden' }}
        >
          {TYPES.map((item) => (
            <span key={item.id} className={TAB_CLASSES}>
              <TabIconOnly item={item} />
            </span>
          ))}
        </div>

        {/* Visible single-line tab row */}
        <div ref={rowRef} className="flex items-center gap-2 overflow-hidden">
          {shown.map((item) => (
            <TabButton
              key={item.id}
              item={item}
              isActive={currentType === item.id}
              onClick={() => select(item.id)}
            />
          ))}

          {hidden.length > 0 && (
            <div className="relative shrink-0">
              <button
                type="button"
                aria-expanded={moreOpen}
                aria-haspopup="menu"
                onClick={() => setMoreOpen((o) => !o)}
                className={`${TAB_CLASSES} bg-white text-black border-zinc-200 hover:bg-[#F4F4F5]`}
              >
                <span>Mehr</span>
                <span className="text-zinc-400 font-normal">{hidden.length}</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform ${moreOpen ? 'rotate-180' : ''}`}
                />
              </button>

              {moreOpen && (
                <div
                  role="menu"
                  className="absolute right-0 top-full mt-2 z-30 w-56 max-w-[calc(100vw-2rem)] max-h-72 overflow-auto rounded-[16px] border border-zinc-200 bg-white p-2"
                >
                  {hidden.map((item) => (
                    <div key={item.id} className="w-full">
                      <button
                        type="button"
                        role="menuitem"
                        onClick={() => select(item.id)}
                        className={`${TAB_CLASSES} w-full justify-start mb-1 ${
                          currentType === item.id
                            ? 'bg-black text-white border-black'
                            : 'bg-white text-black border-transparent hover:border-zinc-200 hover:bg-[#F4F4F5]'
                        }`}
                      >
                        <TabIconOnly item={item} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/** Icon + label for dropdown menu items (keeps markup of TabButton without nesting buttons). */
function TabIconOnly({ item }: { item: TypeTab }) {
  const Icon = item.icon;
  return (
    <>
      <Icon className="w-3.5 h-3.5 stroke-[2]" />
      <span>{item.title}</span>
    </>
  );
}
