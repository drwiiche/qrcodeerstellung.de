/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Wifi,
  Eye,
  EyeOff,
  Sparkles,
  CreditCard,
  Building,
  Info,
  Euro,
  HelpCircle,
  Truck,
  Plus,
  MapPin,
} from 'lucide-react';
import {
  QRType,
  URLData,
  WifiData,
  SepaData,
  VCardData,
  DeliveryData,
  TextData,
  EmailData,
  WhatsappData,
  SmsData,
  StandortData,
  PhoneData,
  EventData,
} from '../types/qr';
import { formatIbanDisplay } from '../utils/sepa';
import { validateIbanChecksum } from '../utils/security';
import { Language, TRANSLATIONS } from '../utils/translations';

interface QRFormProps {
  type: QRType;
  urlData: URLData;
  setUrlData: React.Dispatch<React.SetStateAction<URLData>>;
  wifiData: WifiData;
  setWifiData: React.Dispatch<React.SetStateAction<WifiData>>;
  sepaData: SepaData;
  setSepaData: React.Dispatch<React.SetStateAction<SepaData>>;
  vcardData: VCardData;
  setVcardData: React.Dispatch<React.SetStateAction<VCardData>>;
  deliveryData: DeliveryData;
  setDeliveryData: React.Dispatch<React.SetStateAction<DeliveryData>>;
  textData: TextData;
  setTextData: React.Dispatch<React.SetStateAction<TextData>>;
  emailData: EmailData;
  setEmailData: React.Dispatch<React.SetStateAction<EmailData>>;
  whatsappData: WhatsappData;
  setWhatsappData: React.Dispatch<React.SetStateAction<WhatsappData>>;
  smsData: SmsData;
  setSmsData: React.Dispatch<React.SetStateAction<SmsData>>;
  standortData: StandortData;
  setStandortData: React.Dispatch<React.SetStateAction<StandortData>>;
  phoneData: PhoneData;
  setPhoneData: React.Dispatch<React.SetStateAction<PhoneData>>;
  eventData: EventData;
  setEventData: React.Dispatch<React.SetStateAction<EventData>>;
  lang: Language;
}

export const QRForm: React.FC<QRFormProps> = ({
  type,
  urlData,
  setUrlData,
  wifiData,
  setWifiData,
  sepaData,
  setSepaData,
  vcardData,
  setVcardData,
  deliveryData,
  setDeliveryData,
  textData,
  setTextData,
  emailData,
  setEmailData,
  whatsappData,
  setWhatsappData,
  smsData,
  setSmsData,
  standortData,
  setStandortData,
  phoneData,
  setPhoneData,
  eventData,
  setEventData,
  lang,
}) => {
  const [showWifiPass, setShowWifiPass] = useState(false);
  const t = TRANSLATIONS[lang];

  // ==================== URL FORM ====================
  if (type === 'url') {
    const isInvalidUrl = urlData.url.trim().length > 0 && !/^https?:\/\//i.test(urlData.url.trim());
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Webseiten-URL oder Link *
          </label>
          <div className="relative">
            <input
              type="url"
              placeholder="https://ihre-website.de oder Notizen"
              value={urlData.url}
              onChange={(e) => setUrlData({ ...urlData, url: e.target.value })}
              className={`w-full px-4 py-2.5 rounded-full border bg-white text-zinc-900 text-base sm:text-sm focus:outline-none transition ${
                isInvalidUrl
                  ? 'border-amber-400 ring-2 ring-amber-500/20 bg-amber-50/20'
                  : 'border-zinc-300 focus:ring-2 focus:ring-black focus:border-transparent'
              }`}
            />
          </div>
          {isInvalidUrl ? (
            <p className="mt-1.5 text-xs text-amber-700 font-medium flex items-center gap-1">
              <span>⚠️ Hinweis: Für direktes Öffnen im Handy-Browser sollte die URL mit <strong>https://</strong> beginnen.</span>
            </p>
          ) : (
            <p className="mt-1.5 text-xs text-zinc-500">
              Geben Sie eine vollständige Web-Adresse mit https:// ein.
            </p>
          )}
        </div>

        {/* Quick German URL Presets */}
        <div className="pt-2">
          <span className="text-[11px] font-semibold text-zinc-500 block mb-1.5">
            Beliebte Schnell-Vorlagen für Zuhause:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {[
              { label: 'Fritz!Box Router Menü', url: 'http://fritz.box' },
              { label: 'Telekom Router Menü', url: 'http://speedport.ip' },
              { label: 'Hausordnung & Kehrwoche', url: 'https://beispiel.de/hausordnung' },
              { label: 'Speisekarte / Café', url: 'https://beispiel-cafe.de/menu' },
            ].map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setUrlData({ url: p.url })}
                className="text-xs px-2.5 py-1 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-medium transition cursor-pointer"
              >
                + {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ==================== WI-FI FORM ====================
  if (type === 'wifi') {
    const isSsidEmpty = !wifiData.ssid.trim();
    const isWpaPassTooShort =
      wifiData.encryption !== 'nopass' &&
      wifiData.password.length > 0 &&
      wifiData.password.length < 8;

    return (
      <div className="space-y-4">
        <div className="bg-[#F4F4F5] border border-zinc-200 rounded-[16px] p-3.5 flex items-start gap-2.5">
          <Wifi className="w-5 h-5 text-[#FF5832] flex-shrink-0 mt-0.5" />
          <div className="text-xs text-black">
            <p className="font-semibold">Fritz!Box & Speedport kompatibel</p>
            <p className="text-zinc-500 mt-0.5">
              Gäste scannen den Code mit der Handykamera und sind sofort online. Es wird keine App benötigt.
            </p>
          </div>
        </div>

        {/* Router Quick Presets */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-zinc-600">Router Vorlage:</span>
          <button
            type="button"
            onClick={() =>
              setWifiData({
                ...wifiData,
                ssid: 'FRITZ!Box Gastzugang',
                encryption: 'WPA',
                hidden: false,
              })
            }
            className="text-xs px-2.5 py-1 rounded-full bg-[#F4F4F5] text-black border border-zinc-200 hover:bg-[#E4E4E7] font-medium transition cursor-pointer"
          >
            AVM Fritz!Box
          </button>
          <button
            type="button"
            onClick={() =>
              setWifiData({
                ...wifiData,
                ssid: 'Speedport-Gäste-WLAN',
                encryption: 'WPA',
                hidden: false,
              })
            }
            className="text-xs px-2.5 py-1 rounded-full bg-pink-50 text-pink-800 border border-pink-200 hover:bg-pink-100 font-medium transition cursor-pointer"
          >
            Telekom Speedport
          </button>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            WLAN-Name (SSID) *
          </label>
          <input
            type="text"
            placeholder="z.B. Mein-WLAN oder FRITZ!Box Gastzugang"
            value={wifiData.ssid}
            onChange={(e) => setWifiData({ ...wifiData, ssid: e.target.value })}
            className={`w-full px-4 py-2.5 rounded-full border bg-white text-zinc-900 text-base sm:text-sm focus:outline-none transition ${
              isSsidEmpty
                ? 'border-rose-400 ring-2 ring-rose-500/20 bg-rose-50/20'
                : 'border-zinc-300 focus:ring-2 focus:ring-black'
            }`}
          />
          {isSsidEmpty && (
            <p className="mt-1 text-xs text-rose-600 font-medium">
              ⚠️ Der WLAN-Name (SSID) ist erforderlich, damit Smartphones das Netzwerk finden können.
            </p>
          )}
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            WLAN-Passwort (WPA-Schlüssel)
          </label>
          <div className="relative">
            <input
              type={showWifiPass ? 'text' : 'password'}
              placeholder="Passwort Ihres Heimnetzwerks"
              value={wifiData.password}
              onChange={(e) => setWifiData({ ...wifiData, password: e.target.value })}
              className={`w-full px-4 py-2.5 pr-10 rounded-full border bg-white text-zinc-900 text-base sm:text-sm focus:outline-none transition ${
                isWpaPassTooShort
                  ? 'border-amber-400 ring-2 ring-amber-500/20 bg-amber-50/20'
                  : 'border-zinc-300 focus:ring-2 focus:ring-black'
              }`}
            />
            <button
              type="button"
              onClick={() => setShowWifiPass(!showWifiPass)}
              className="absolute right-3 top-1/2 -tranzinc-y-1/2 text-zinc-400 hover:text-zinc-600 cursor-pointer"
            >
              {showWifiPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {isWpaPassTooShort && (
            <p className="mt-1 text-xs text-amber-700 font-medium">
              ⚠️ WPA/WPA2-Verschlüsselung verlangt mindestens 8 Zeichen (Fritz!Box Standard: 16-20 Ziffern).
            </p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Verschlüsselung
            </label>
            <select
              value={wifiData.encryption}
              onChange={(e) =>
                setWifiData({
                  ...wifiData,
                  encryption: e.target.value as 'WPA' | 'WEP' | 'nopass',
                })
              }
              className="w-full px-3.5 py-2 rounded-full border border-zinc-300 bg-white text-zinc-900 text-sm focus:outline-none focus:ring-2 focus:ring-black"
            >
              <option value="WPA">WPA / WPA2 / WPA3 (Standard)</option>
              <option value="WEP">WEP (Veraltet)</option>
              <option value="nopass">Offenes WLAN (Ohne Passwort)</option>
            </select>
          </div>

          <div className="flex items-center pt-6">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-zinc-700">
              <input
                type="checkbox"
                checked={wifiData.hidden}
                onChange={(e) => setWifiData({ ...wifiData, hidden: e.target.checked })}
                className="w-4 h-4 rounded text-black focus:ring-black border-zinc-300"
              />
              Versteckte SSID (Hidden Network)
            </label>
          </div>
        </div>
      </div>
    );
  }

  // ==================== SEPA GIROCODE FORM ====================
  if (type === 'sepa') {
    return (
      <div className="space-y-4">
        <div className="bg-[#F4F4F5] border border-zinc-200 rounded-[16px] p-3.5 flex items-start gap-2.5">
          <CreditCard className="w-5 h-5 text-[#FF5832] flex-shrink-0 mt-0.5" />
          <div className="text-xs text-black">
            <p className="font-semibold">Offizieller EPC SEPA GiroCode Standard</p>
            <p className="text-zinc-500 mt-0.5">
              Kompatibel mit Sparkasse, Volksbank, Deutsche Bank, Commerzbank, DKB, ING, Postbank & allen deutschen Banking Apps.
            </p>
          </div>
        </div>

        {/* Quick German SEPA Templates */}
        <div>
          <span className="text-[11px] font-semibold text-zinc-500 block mb-1.5">
            Deutsche Überweisungsvorlagen:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {[
              {
                label: 'WG Miete & Nebenkosten',
                purpose: 'WG Miete Anteil Oktober',
                amount: '450.00',
              },
              {
                label: 'Rundfunkbeitrag (GEZ)',
                purpose: 'Beitragsnummer 123456789',
                amount: '55.08',
              },
              {
                label: 'Kaution / Stellplatz',
                purpose: 'Mietkaution Wohnung 3.OG',
                amount: '1200.00',
              },
              {
                label: 'Handwerkerrechnung',
                purpose: 'Rechnung Reparatur Heizung',
                amount: '185.50',
              },
            ].map((tmpl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() =>
                  setSepaData({
                    ...sepaData,
                    purpose: tmpl.purpose,
                    amount: tmpl.amount,
                  })
                }
                className="text-xs px-2.5 py-1 rounded-full bg-[#F4F4F5] text-black border border-zinc-200 hover:bg-[#E4E4E7] font-medium transition cursor-pointer"
              >
                + {tmpl.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Empfängername (Name / Firma) *
            </label>
            <input
              type="text"
              placeholder="z.B. Max Mustermann oder Hausverwaltung"
              value={sepaData.name}
              onChange={(e) => setSepaData({ ...sepaData, name: e.target.value })}
              className={`w-full px-4 py-2.5 rounded-full border bg-white text-zinc-900 text-base sm:text-sm focus:outline-none transition ${
                !sepaData.name.trim()
                  ? 'border-rose-300 ring-2 ring-rose-500/10'
                  : 'border-zinc-300 focus:ring-2 focus:ring-black'
              }`}
            />
            {!sepaData.name.trim() && (
              <p className="mt-1 text-xs text-rose-600 font-medium">
                ⚠️ Empfängername ist für Banküberweisungen erforderlich.
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Betrag in EUR (€) (Optional)
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="z.B. 45.00"
                value={sepaData.amount}
                onChange={(e) => setSepaData({ ...sepaData, amount: e.target.value })}
                className="w-full px-4 py-2.5 pl-8 rounded-full border border-zinc-300 bg-white text-zinc-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-black "
              />
              <span className="absolute left-3 top-1/2 -tranzinc-y-1/2 text-zinc-400 font-bold text-sm">
                €
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="sepa-iban-input" className="block text-xs font-bold uppercase tracking-wider text-zinc-500">
                IBAN (Deutsche IBAN) *
              </label>
              {(() => {
                const cleaned = sepaData.iban.replace(/\s+/g, '');
                if (cleaned.length >= 15) {
                  const check = validateIbanChecksum(sepaData.iban);
                  if (check.isValid) {
                    return (
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        ✓ Gültige Prüfziffer
                      </span>
                    );
                  } else {
                    return (
                      <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                        {check.message || 'Ungültige IBAN'}
                      </span>
                    );
                  }
                }
                return null;
              })()}
            </div>
            {(() => {
              const cleaned = sepaData.iban.replace(/\s+/g, '');
              const isInvalidIban = cleaned.length >= 15 && !validateIbanChecksum(sepaData.iban).isValid;
              return (
                <input
                  id="sepa-iban-input"
                  type="text"
                  placeholder="DE89 3705 0198 0000 0123 45"
                  value={sepaData.iban}
                  onChange={(e) =>
                    setSepaData({ ...sepaData, iban: formatIbanDisplay(e.target.value) })
                  }
                  className={`w-full px-4 py-2.5 font-mono text-base sm:text-sm uppercase rounded-full border bg-white text-zinc-900 focus:outline-none transition ${
                    isInvalidIban
                      ? 'border-rose-400 ring-2 ring-rose-500/20 bg-rose-50/20'
                      : 'border-zinc-300 focus:ring-2 focus:ring-black'
                  }`}
                />
              );
            })()}
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              BIC (Optional in DE)
            </label>
            <input
              type="text"
              placeholder="z.B. DRESDEFF500"
              value={sepaData.bic}
              onChange={(e) =>
                setSepaData({ ...sepaData, bic: e.target.value.toUpperCase() })
              }
              className="w-full px-4 py-2.5 font-mono text-sm uppercase rounded-full border border-zinc-300 bg-white text-zinc-900 focus:outline-none focus:ring-2 focus:ring-black "
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Verwendungszweck (Max. 140 Zeichen)
          </label>
          <input
            type="text"
            placeholder="z.B. Miete Oktober, Kundennummer 8829, Rechnung 104"
            maxLength={140}
            value={sepaData.purpose}
            onChange={(e) => setSepaData({ ...sepaData, purpose: e.target.value })}
            className="w-full px-4 py-2.5 rounded-full border border-zinc-300 bg-white text-zinc-900 text-sm focus:outline-none focus:ring-2 focus:ring-black "
          />
        </div>
      </div>
    );
  }

  // ==================== VCARD FORM ====================
  if (type === 'vcard') {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Vorname *
            </label>
            <input
              type="text"
              placeholder="Max"
              value={vcardData.firstName}
              onChange={(e) => setVcardData({ ...vcardData, firstName: e.target.value })}
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Nachname *
            </label>
            <input
              type="text"
              placeholder="Mustermann"
              value={vcardData.lastName}
              onChange={(e) => setVcardData({ ...vcardData, lastName: e.target.value })}
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Mobilnummer *
            </label>
            <input
              type="tel"
              placeholder="+49 170 1234567"
              value={vcardData.mobile}
              onChange={(e) => setVcardData({ ...vcardData, mobile: e.target.value })}
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              E-Mail Adresse *
            </label>
            <input
              type="email"
              placeholder="max.mustermann@mail.de"
              value={vcardData.email}
              onChange={(e) => setVcardData({ ...vcardData, email: e.target.value })}
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Unternehmen / Organisation
            </label>
            <input
              type="text"
              placeholder="Firma oder Freelance"
              value={vcardData.organization}
              onChange={(e) =>
                setVcardData({ ...vcardData, organization: e.target.value })
              }
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Position / Beruf
            </label>
            <input
              type="text"
              placeholder="z.B. Software Entwickler / Architekt"
              value={vcardData.title}
              onChange={(e) => setVcardData({ ...vcardData, title: e.target.value })}
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Straße & Hausnummer
            </label>
            <input
              type="text"
              placeholder="Hauptstraße 12"
              value={vcardData.street}
              onChange={(e) => setVcardData({ ...vcardData, street: e.target.value })}
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              PLZ & Ort
            </label>
            <input
              type="text"
              placeholder="10115 Berlin"
              value={vcardData.city ? `${vcardData.zip} ${vcardData.city}`.trim() : vcardData.zip}
              onChange={(e) => {
                const parts = e.target.value.split(' ');
                setVcardData({
                  ...vcardData,
                  zip: parts[0] || '',
                  city: parts.slice(1).join(' ') || '',
                });
              }}
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>
      </div>
    );
  }

  // ==================== DELIVERY / PAKETBOTE FORM ====================
  if (type === 'delivery') {
    return (
      <div className="space-y-4">
        <div className="bg-[#F4F4F5] border border-zinc-200 rounded-[16px] p-3.5 flex items-start gap-2.5">
          <Truck className="w-5 h-5 text-[#FF5832] flex-shrink-0 mt-0.5" />
          <div className="text-xs text-black">
            <p className="font-semibold">Haustür-Abstellhinweis für Paketboten</p>
            <p className="text-zinc-500 mt-0.5">
              Ideal für die Klingel oder den Briefkasten: DHL, Hermes, Amazon und DPD Boten sehen sofort, wo das Paket sicher abgelegt werden darf, wenn Sie im Home-Office sind.
            </p>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Name des Empfängers (an der Klingel)
          </label>
          <input
            type="text"
            placeholder="z.B. Familie Schmidt (2. OG rechts)"
            value={deliveryData.recipientName}
            onChange={(e) =>
              setDeliveryData({ ...deliveryData, recipientName: e.target.value })
            }
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Gewünschter Abstellort
          </label>
          <input
            type="text"
            placeholder="z.B. Hinter der blauen Papiertonne im Carport"
            value={deliveryData.deliveryLocation}
            onChange={(e) =>
              setDeliveryData({ ...deliveryData, deliveryLocation: e.target.value })
            }
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />

          {/* Quick location chips */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {[
              'Vor der Wohnungstür im Flur',
              'Im Carport hinter der Mülltonne',
              'In der Paketbox am Eingang',
              'Beim Nachbarn im Erdgeschoss',
              'Auf der überdachten Terrasse',
            ].map((loc, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setDeliveryData({ ...deliveryData, deliveryLocation: loc })}
                className="text-xs px-2.5 py-1 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-medium transition cursor-pointer"
              >
                + {loc}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Telefon für Rückfragen (Optional)
            </label>
            <input
              type="tel"
              placeholder="+49 176 12345678"
              value={deliveryData.phone}
              onChange={(e) =>
                setDeliveryData({ ...deliveryData, phone: e.target.value })
              }
              className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Gilt für Paketdienste
            </label>
            <div className="flex flex-wrap gap-2 pt-1">
              {['DHL', 'Hermes', 'Amazon', 'DPD', 'GLS'].map((srv) => {
                const checked = deliveryData.parcelServices.includes(srv);
                return (
                  <button
                    key={srv}
                    type="button"
                    onClick={() => {
                      if (checked) {
                        setDeliveryData({
                          ...deliveryData,
                          parcelServices: deliveryData.parcelServices.filter((s) => s !== srv),
                        });
                      } else {
                        setDeliveryData({
                          ...deliveryData,
                          parcelServices: [...deliveryData.parcelServices, srv],
                        });
                      }
                    }}
                    className={`text-xs px-2.5 py-1 rounded-md font-semibold border transition ${
                      checked
                        ? 'bg-black text-white border-black'
                        : 'bg-white text-zinc-600 border-zinc-300 hover:border-zinc-400'
                    }`}
                  >
                    {srv}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Zusätzliche Anweisung für den Boten
          </label>
          <input
            type="text"
            placeholder="z.B. Bitte kurz klingeln nach dem Abstellen. Herzlichen Dank!"
            value={deliveryData.specialInstructions}
            onChange={(e) =>
              setDeliveryData({ ...deliveryData, specialInstructions: e.target.value })
            }
            className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  // ==================== WHATSAPP FORM ====================
  if (type === 'whatsapp') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            WhatsApp Telefonnummer (Mit Ländervorwahl)
          </label>
          <input
            type="tel"
            placeholder="491701234567 (z.B. für Deutschland 49...)"
            value={whatsappData.phoneNumber}
            onChange={(e) =>
              setWhatsappData({
                ...whatsappData,
                phoneNumber: e.target.value.replace(/[^0-9]/g, ''),
              })
            }
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1 text-xs text-zinc-500">
            Bitte ohne führende Nullen oder Plus eingeben (z.B. 49 für Deutschland).
          </p>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Vorausgefüllte Chat-Nachricht (Optional)
          </label>
          <textarea
            rows={3}
            placeholder="Hallo! Ich scanne den QR-Code von deiner Visitenkarte..."
            value={whatsappData.message}
            onChange={(e) =>
              setWhatsappData({ ...whatsappData, message: e.target.value })
            }
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  // ==================== SMS FORM ====================
  if (type === 'sms') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Empfänger (Mit Ländervorwahl)
          </label>
          <input
            type="tel"
            placeholder="+49 170 1234567"
            value={smsData.phoneNumber}
            onChange={(e) => setSmsData({ ...smsData, phoneNumber: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1 text-xs text-zinc-500">
            Deutschland: +49 statt 0 am Anfang – z. B. +491701234567.
          </p>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Vorausgefüllte Nachricht (Optional)
          </label>
          <textarea
            rows={3}
            placeholder="Hallo, ich interessiere mich für Ihr Angebot."
            value={smsData.message}
            onChange={(e) => setSmsData({ ...smsData, message: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1 text-xs text-zinc-500">
            Der Gast tippt nach dem Scannen nur noch auf Senden – ideal für Bestell-SMS am Tisch oder auf Flyern.
          </p>
        </div>
      </div>
    );
  }

  // ==================== STANDORT FORM ====================
  if (type === 'standort') {
    const lat = parseFloat(standortData.latitude.replace(',', '.'));
    const lng = parseFloat(standortData.longitude.replace(',', '.'));
    const coordsValid =
      Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
    const mapsHref = coordsValid
      ? `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`
      : null;

    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Beschriftung (Optional)
          </label>
          <input
            type="text"
            placeholder="Treffpunkt am Haupteingang, Ladenlokal, Ferienhaus …"
            value={standortData.label}
            onChange={(e) => setStandortData({ ...standortData, label: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Breitengrad
            </label>
            <input
              type="text"
              inputMode="decimal"
              placeholder="52.520008"
              value={standortData.latitude}
              onChange={(e) =>
                setStandortData({ ...standortData, latitude: e.target.value.replace(/[^0-9.,-]/g, '') })
              }
              className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
              Längengrad
            </label>
            <input
              type="text"
              inputMode="decimal"
              placeholder="13.404954"
              value={standortData.longitude}
              onChange={(e) =>
                setStandortData({ ...standortData, longitude: e.target.value.replace(/[^0-9.,-]/g, '') })
              }
              className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        {standortData.latitude && standortData.longitude && !coordsValid && (
          <p className="text-xs text-[#B31D00] font-semibold" role="alert">
            Bitte gültige Koordinaten eingeben (z. B. 52.520008 / 13.404954).
          </p>
        )}

        <div className="flex items-start gap-2.5 rounded-[16px] bg-[#F4F4F5] border border-zinc-200 p-3.5">
          <MapPin className="w-4 h-4 text-[#FF5832] mt-0.5 shrink-0" />
          <p className="text-xs text-zinc-600 leading-relaxed">
            Der Code öffnet nach dem Scannen die Koordinaten direkt in Google Maps (iOS &
            Android) – der ideale Wegweiser für Hauspartys, Hofeinfahrten, Ferienwohnungen
            oder Veranstaltungsorte. Koordinaten z. B. aus Google Maps per Rechtsklick auf die
            Karte ablesen.
          </p>
        </div>

        {mapsHref && (
          <p className="text-[11px] text-zinc-400 font-mono break-all">
            Ziel: {mapsHref}
          </p>
        )}
      </div>
    );
  }

  // ==================== TEXT FORM ====================
  if (type === 'text') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Freier Text / Notiz
          </label>
          <textarea
            rows={4}
            placeholder="Geben Sie beliebigen Text ein (z.B. Kartoninhalt für den Keller, Willkommenstext für die Gästewohnung...)"
            value={textData.text}
            onChange={(e) => setTextData({ text: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <div className="flex justify-between items-center mt-1 text-xs text-zinc-400">
            <span>Scanbar mit jedem QR-Code Scanner</span>
            <span>{textData.text.length} Zeichen</span>
          </div>
        </div>

        {/* Quick German Home Storage Chips */}
        <div>
          <span className="text-[11px] font-semibold text-zinc-500 block mb-1.5">
            Haushalt & Vorratsspeicher Vorlagen:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {[
              {
                label: 'Umzugskarton Winterkleidung',
                text: 'Karton #12: Winterjacken, Schals, Skiausrüstung, Thermowäsche.',
              },
              {
                label: 'Kellerbox Werkzeug',
                text: 'Box A-3: Akkuschrauber, Dübel, Schrauben, Bohrmaschine.',
              },
              {
                label: 'Ferienwohnung Willkommen',
                text: 'Herzlich Willkommen in unserer Wohnung! Ruhezeiten: 22:00 - 07:00 Uhr. Müllentsorgung im Innenhof.',
              },
            ].map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setTextData({ text: p.text })}
                className="text-xs px-2.5 py-1 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-medium transition cursor-pointer"
              >
                + {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ==================== EMAIL FORM ====================
  if (type === 'email') {
    const isInvalidEmail =
      emailData.email.trim().length > 0 &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailData.email.trim());

    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            E-Mail Empfänger *
          </label>
          <input
            type="email"
            placeholder="kontakt@beispiel.de"
            value={emailData.email}
            onChange={(e) => setEmailData({ ...emailData, email: e.target.value })}
            className={`w-full px-4 py-2.5 rounded-full border text-base sm:text-sm focus:outline-none transition ${
              isInvalidEmail
                ? 'border-rose-400 ring-2 ring-rose-500/20 bg-rose-50/20'
                : 'border-zinc-300 focus:ring-2 focus:ring-black'
            }`}
          />
          {isInvalidEmail && (
            <p className="mt-1 text-xs text-rose-600 font-medium">
              ⚠️ Bitte geben Sie eine gültige E-Mail-Adresse ein (z. B. name@beispiel.de).
            </p>
          )}
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Betreffzeile
          </label>
          <input
            type="text"
            placeholder="Anfrage über QR-Code"
            value={emailData.subject}
            onChange={(e) => setEmailData({ ...emailData, subject: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Nachrichtentext
          </label>
          <textarea
            rows={3}
            placeholder="Sehr geehrte Damen und Herren,..."
            value={emailData.body}
            onChange={(e) => setEmailData({ ...emailData, body: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  // ==================== PHONE FORM ====================
  if (type === 'phone') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Telefonnummer zum Anrufen
          </label>
          <input
            type="tel"
            placeholder="+49 30 12345678"
            value={phoneData.phoneNumber}
            onChange={(e) => setPhoneData({ phoneNumber: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1.5 text-xs text-zinc-500">
            Beim Scannen öffnet sich die Telefon-App des Smartphones direkt mit dieser Rufnummer.
          </p>
        </div>
      </div>
    );
  }

  // ==================== EVENT FORM ====================
  if (type === 'event') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Titel des Events / Termins *
          </label>
          <input
            type="text"
            placeholder="z.B. Eigentümerversammlung, Sommerfest, Grillen"
            value={eventData.title}
            onChange={(e) => setEventData({ ...eventData, title: e.target.value })}
            className="w-full px-4 py-3 rounded-[16px] border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Startdatum
            </label>
            <input
              type="date"
              value={eventData.startDate}
              onChange={(e) => setEventData({ ...eventData, startDate: e.target.value })}
              className="w-full px-3.5 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
              Startzeit
            </label>
            <input
              type="time"
              value={eventData.startTime}
              onChange={(e) => setEventData({ ...eventData, startTime: e.target.value })}
              className="w-full px-3.5 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1.5">
            Ort / Adresse
          </label>
          <input
            type="text"
            placeholder="Gemeinschaftsraum, Innenhof oder Adresse"
            value={eventData.location}
            onChange={(e) => setEventData({ ...eventData, location: e.target.value })}
            className="w-full px-4 py-2 rounded-full border border-zinc-300 text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  return null;
};
