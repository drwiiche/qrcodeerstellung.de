/**
 * Programmatic SEO landing pages — German use-case pages grouped by
 *   /qr-codes-fuer/[branche]/[anwendungsfall]  (Unternehmen, Schulen, Veranstaltungen)
 *   /qr-codes-auf/[material]                  (Marketing-Materialien)
 * Every page carries unique, substantive content (no thin doorway pages).
 */

export interface SeoSubPage {
  slug: string;
  /** H1 */
  title: string;
  metaTitle: string;
  metaDescription: string;
  intro: string[];
  useCases: { title: string; text: string }[];
  steps: string[];
  faq: { q: string; a: string }[];
  /** Links into the generator, preselecting a QR type via /?type=… */
  toolLinks: { label: string; href: string }[];
  blogLinks: { label: string; href: string }[];
}

export interface SeoHub {
  slug: string;
  label: string;
  title: string;
  metaTitle: string;
  metaDescription: string;
  intro: string[];
  subs: SeoSubPage[];
}

export const HUBS: SeoHub[] = [
  {
    slug: 'unternehmen',
    label: 'Für Unternehmen',
    title: 'QR-Codes für Unternehmen',
    metaTitle: 'QR-Codes für Unternehmen – Gastronomie, Handwerk & Handel | QR-Generator Deutschland',
    metaDescription:
      'Praxisnahe QR-Code-Lösungen für deutsche Unternehmen: Speisekarten, Angebote, Google-Bewertungen, Terminbuchung und mehr – kostenlos erstellen.',
    intro: [
      'Ob Restaurant, Handwerksbetrieb oder Ladengeschäft: QR-Codes verbinden Ihre analogen Berührungspunkte mit Ihrem digitalen Angebot – ohne App, ohne laufende Kosten und ohne technisches Vorwissen.',
      'Auf dieser Seite finden Sie die wichtigsten Anwendungsfälle für Unternehmen in Deutschland, mit konkreten Schritten zum eigenen QR-Code.',
    ],
    subs: [
      {
        slug: 'gastronomie',
        title: 'QR-Codes für die Gastronomie: Speisekarten, Bewertungen & Bestellungen',
        metaTitle: 'QR-Codes für Restaurants & Cafés: digitale Speisekarte erstellen',
        metaDescription:
          'So nutzen Restaurants, Cafés und Foodtrucks QR-Codes für digitale Speisekarten, Google-Bewertungen und Vorbestellungen – Schritt für Schritt erklärt.',
        intro: [
          'Die digitale Speisekarte ist in deutschen Restaurants, Cafés und Foodtrucks angekommen. Ein QR-Code auf Tischkarte, Theke oder im Fenster öffnet die Karte direkt am Smartphone des Gastes – ohne App und ohne Wartezeit.',
          'Entscheidend sind drei Dinge: ein zuverlässiger Code, eine schnelle Seite dahinter und eine gute Platzierung. Alles drei lässt sich in wenigen Minuten umsetzen.',
        ],
        useCases: [
          {
            title: 'Digitale Speisekarte am Tisch',
            text: 'Ein QR-Code auf jeder Tischkarte führt zur aktuellen Karte. Preise und Gerichte ändern Sie zentral – die gedruckten Karten bleiben gültig.',
          },
          {
            title: 'Google-Bewertungen einholen',
            text: 'Ein Bewertungs-Code auf der Rechnung oder am Ausgang führt Gäste direkt zur Bewertungsseite Ihres Betriebs – die einfachste Methode, mehr Sterne zu sammeln.',
          },
          {
            title: 'Vorbestellen & Abholen',
            text: 'Foodtrucks und Imbisshäuser setzen den Code auf Aushang oder Lieferwagen: Gäste bestellen vorab und holen ohne Wartezeit ab.',
          },
          {
            title: 'Allergene & Zutaten transparent',
            text: 'Hinter dem Code finden Gäste ausführliche Allergen- und Zutatenlisten, die auf der Papierkarte keinen Platz hätten.',
          },
        ],
        steps: [
          'QR-Typ „Webseite“ wählen und die Adresse Ihrer digitalen Speisekarte einfügen.',
          'In der Vorschau prüfen und bei Bedarf Farben an Ihr Erscheinungsbild anpassen.',
          'Als PNG (hohe Auflösung) oder Vektorgrafik SVG herunterladen.',
          'Mit der Aufforderung „Hier scannen“ auf Tischkarten, Theke und Fenster platzieren und mit zwei Smartphones testen.',
        ],
        faq: [
          {
            q: 'Brauchen meine Gäste eine App?',
            a: 'Nein. Die Kamera-App jedes Smartphones öffnet den Code direkt. Es gibt nichts zu installieren.',
          },
          {
            q: 'Funktioniert der Code auch bei schlechtem Empfang?',
            a: 'Der Code selbst braucht kein Internet. Die hinterlegte Seite sollte allerdings schlank sein, damit sie auch im Keller-Café noch lädt.',
          },
          {
            q: 'Kann ich dieselbe Karte für mehrere Standorte verwenden?',
            a: 'Ja, mit einem Code pro Adresse lässt sich auch die Nutzung je Standort nachvollziehen.',
          },
        ],
        toolLinks: [
          { label: 'Webseite-QR-Code erstellen', href: '/?type=url' },
          { label: 'SEPA-GiroCode für Rechnungen', href: '/?type=sepa' },
        ],
        blogLinks: [
          { label: 'QR-Codes für Speisekarten im Detail', href: '/blog/qr-codes-speisekarten-gastronomie' },
          { label: 'Bewertungen holen: die Strategie', href: '/blog/google-bewertungen-qr-code' },
        ],
      },
      {
        slug: 'handwerk',
        title: 'QR-Codes für Handwerk & lokale Dienstleister',
        metaTitle: 'QR-Codes für Handwerker: Angebote, Termine & Schilder',
        metaDescription:
          'Wie Handwerksbetriebe QR-Codes für Angebote, Terminanfragen, Fuhrpark und Werkstattbeschilderung sinnvoll einsetzen – mit Anleitungen.',
        intro: [
          'Handwerksbetriebe leben von Anfragen und Wiedererkennung. QR-Codes auf Visitenkarten, Fahrzeugen, Baustellenschildern und Rechnungen bringen Interessenten in Sekunden zum richtigen Ziel – vom Angebot bis zur Terminbuchung.',
          'Besonders praktisch: Der Code auf dem Firmenwagen funktioniert auch, wenn das Auto längst weggefahren ist.',
        ],
        useCases: [
          {
            title: 'Angebot per Code anfordern',
            text: 'Auf Rechnung, Baustellenschild oder Fahrzeug steht der Code zum Angebotsformular – Interessenten sparen den Anruf, Sie sparen Rückfragen.',
          },
          {
            title: 'Terminbuchung vereinfachen',
            text: 'Der Code führt zum Kalender oder Buchungstool. Kunden buchen Wartung oder Reparatur, während die Daten noch frisch im Kopf sind.',
          },
          {
            title: 'Fuhrpark als Werbefläche',
            text: 'Ein Code auf der Fahrzeugseite mit klarer Aufforderung („Angebot in 10 Sekunden anfordern“) macht jeden Kilometer zur Werbemitteldistribution.',
          },
          {
            title: 'Rechnung & Kundenakquise',
            text: 'Ein „Bewerten Sie uns“-Code auf der Schlussrechnung stärkt die lokale Sichtbarkeit bei Google.',
          },
        ],
        steps: [
          'Ziel festlegen: Formular, Terminbuchung oder Google-Bewertungsseite.',
          'QR-Typ „Webseite“ wählen, Adresse einfügen und herunterladen.',
          'Auf Visitenkarte, Fahrzeugbeschriftung und Rechnungsvorlage platzieren.',
          'Aufforderungstext daneben setzen – ohne Handlungs-aufforderung sinkt die Scan-Rate deutlich.',
        ],
        faq: [
          {
            q: 'Welche Größe braucht ein Code auf dem Fahrzeug?',
            a: 'Ab etwa 15 cm Kantenlänge ist der Code auch aus einiger Entfernung zuverlässig scannbar.',
          },
          {
            q: 'Kann ich den Code später ändern?',
            a: 'Statische Codes sind an ihre URL gebunden. Planen Sie eine dauerhafte Adresse ein – dann bleibt der Code gültig.',
          },
          {
            q: 'Ist das wirklich kostenlos?',
            a: 'Ja. Der Generator auf dieser Seite ist kostenlos, ohne Anmeldung und ohne Laufzeitbegrenzung.',
          },
        ],
        toolLinks: [
          { label: 'Angebots-QR-Code erstellen', href: '/?type=url' },
          { label: 'Visitenkarten-QR-Code (vCard)', href: '/?type=vcard' },
        ],
        blogLinks: [
          { label: 'QR-Codes für Handwerk & Nachbarschaft', href: '/blog/qr-codes-handwerk-lokal' },
        ],
      },
      {
        slug: 'einzelhandel',
        title: 'QR-Codes für Einzelhandel & Büros',
        metaTitle: 'QR-Codes für Laden & Büro: Preisschilder, Regale, Innenhof',
        metaDescription:
          'QR-Codes im Ladenlokal und Büro: Preisschilder mit Produktvideos, Lagerbestand, Wegweiser und Kontakt-QR für die Tür – so geht\'s.',
        intro: [
          'Läden und Büros haben viele kleine Flächen, die mehr erzählen könnten: Preisschilder, Regalboden, Eingangstür, Fensterfront. QR-Codes machen aus diesen Flächen digitale Infoscreens.',
          'Und im Büro sorgt ein Kontakt-QR-Code an der Tür dafür, dass Lieferanten und Besucher ohne Klingelschild-Fehler genau die richtige Person erreichen.',
        ],
        useCases: [
          {
            title: 'Produktinformationen am Regal',
            text: 'Herkunft, Pflegehinweise, Zutaten oder ein Kurzvideo: Der Code am Preisschild liefert Informationen, die im Etikett nicht Platz finden.',
          },
          {
            title: 'Kontakt-QR an der Tür',
            text: 'Ein vCard-Code am Eingang oder auf dem Klingelschild: scannen, Kontakt gespeichert – ideal für Bürogemeinschaften und Praxen.',
          },
          {
            title: 'WLAN für Kunden & Besucher',
            text: 'Statt Passwortzettel: WLAN-QR-Code an der Kasse oder im Empfang, Gäste verbinden sich mit einem Scan.',
          },
          {
            title: 'Bestellung & Reservierung',
            text: 'Saisonware oder Reservierungen: Ein Code führt zum Bestellformular oder in das Buchungssystem.',
          },
        ],
        steps: [
          'Passenden QR-Typ wählen: Webseite, vCard oder WLAN.',
          'Daten eingeben, Vorschau prüfen, als PNG oder SVG herunterladen.',
          'Auf tragfähigem Untergrund platzieren – mattes Papier statt glänzendem Laminat.',
          'Regelmäßig testen: Mind. einmal pro Quartal mit zwei Geräten scannen.',
        ],
        faq: [
          {
            q: 'Bleiben die Codes im Winter lesbar?',
            a: 'Gut laminierte oder hinter Glas platzierte Codes überstehen Witterung. Wichtig ist die Reflexion – matt kaschieren.',
          },
          {
            q: 'Wie viele Codes sollte ein Laden haben?',
            a: 'Wenige, dafür mit klarem Zweck: WLAN, Produktinfo, Bewertung. Zu viele Codes verwirren eher.',
          },
          {
            q: 'Kann ich ein Logo in den Code einbauen?',
            a: 'Ja, bis zu etwa 25 % Fläche und mit hoher Fehlerkorrektur – der Generator unterstützt Logos direkt.',
          },
        ],
        toolLinks: [
          { label: 'WLAN-QR-Code für Kunden', href: '/?type=wifi' },
          { label: 'Kontakt-QR (vCard)', href: '/?type=vcard' },
        ],
        blogLinks: [
          { label: 'Drucken & Gestaltung: die Regeln', href: '/blog/qr-code-drucken-kontrast-groesse' },
        ],
      },
      {
        slug: 'hotellerie',
        title: 'QR-Codes für Hotels, Pensionen & Ferienwohnungen',
        metaTitle: 'QR-Codes für Hotellerie: Zimmer-Info, WLAN & Bewertungen',
        metaDescription:
          'Wie Hotels und Ferienwohnungen QR-Codes für Zimmerausstattung, Gäste-WLAN, Frühstückskarte und Bewertungen einsetzen – rechtssicher und datensparsam.',
        intro: [
          'Gäste wollen keine Papiere im Zimmer – aber sie wollen Antworten: Wie lautet das WLAN-Passwort, wann gibt es Frühstück, was ist im Umfeld los? Ein QR-Code auf Zimmerkarte, Spiegel oder Informationstafel beantwortet das mit einem Scan.',
          'Entscheidend in der Beherbergung: datensparsame Ziele ohne Tracking-Falle – Gäste bewerten die Unterkunft ohnehin freiwillig, wenn der Weg kurz ist.',
        ],
        useCases: [
          {
            title: 'Gäste-WLAN auf einen Scan',
            text: 'Karte oder Zimmertafel mit WLAN-Code: Gäste verbinden sich ohne Passwort-Eintippen – das häufigste Anliegen am Empfang entfällt.',
          },
          {
            title: 'Haus- & Umgebungsinformationen',
            text: 'Frühstückszeiten, Check-out, Wandertipps und ÖPNV auf einer Info-Seite – änderbar, ohne Karten neu zu drucken.',
          },
          {
            title: 'Bewertung nach dem Aufenthalt',
            text: 'Code auf der Rechnung oder im Abschieds-Mail führt direkt zur Bewertungsseite – der klassische Hebel für die Sichtbarkeit.',
          },
          {
            title: 'Termin & Anreise',
            text: 'Standort-Code für den Hauseingang (wichtig bei Höfen und Gewerbearealen) und Termin-Codes für Frühstück oder Saunabuchung.',
          },
        ],
        steps: [
          'Ziel festlegen: Info-Seite der Unterkunft, WLAN oder Bewertungslink.',
          'Passenden Typ wählen (Webseite, WLAN oder Standort) und Code erstellen.',
          'Auf Zimmerkarte, Informationstafel und Rechnung platzieren – mit Aufforderungstext.',
          'Vor Saisonbeginn mit zwei Geräten testen und QR-Größe prüfen (mind. 3 cm).',
        ],
        faq: [
          {
            q: 'Ist ein Gäste-WLAN-Code DSGVO-konform?',
            a: 'Ja – der Code enthält nur Zugangsdaten Ihres Netzes. Isolieren Sie Gäste-Geräte per Gastzugang, dann ist die Nutzung unbedenklich.',
          },
          {
            q: 'Wo finde ich den besten Platz im Zimmer?',
            a: 'Am Kopfende der Info-Tafel oder auf der Zimmerrückseite – dort, wo Gäste ohnehin verweilen.',
          },
          {
            q: 'Kann ich Codes zwischen Zimmer wechseln?',
            a: 'Nur mit Neudruck. Planen Sie daher stabile Info-Seiten, statt pro Zimmer individuelle Codes zu verteilen.',
          },
        ],
        toolLinks: [
          { label: 'WLAN-QR-Code für Gäste', href: '/?type=wifi' },
          { label: 'Info-Seite verlinken', href: '/?type=url' },
        ],
        blogLinks: [
          { label: 'WLAN-QR-Code für die Fritz!Box', href: '/blog/wlan-qr-code-fritzbox-gastzugang' },
          { label: 'Bewertungen holen', href: '/blog/google-bewertungen-qr-code' },
        ],
      },
      {
        slug: 'friseure-wellness',
        title: 'QR-Codes für Friseure, Salons & Wellness',
        metaTitle: 'QR-Codes für Salons: Termin, Pflegeprodukte & Bewertungen',
        metaDescription:
          'Friseure und Wellness-Anbieter: QR-Codes für Terminbuchung, Produktpflege, Gutschein und Google-Bewertungen einfach umsetzen.',
        intro: [
          'Im Salon entscheidet der Moment nach der Leistung: Die Kundin ist zufrieden, das Handy ist zur Hand. Ein gut platzierter QR-Code nutzt diesen Moment – für die Bewertung, den nächsten Termin oder das empfohlene Pflegeprodukt.',
          'Und im Schaufenster führt derselbe Code zur Terminbuchung, noch bevor jemand anruft.',
        ],
        useCases: [
          {
            title: 'Termin buchten statt anrufen',
            text: 'Code auf Türschild, Spiegel oder Terminkarte führt zum Buchungstool – auch außerhalb der Öffnungszeiten.',
          },
          {
            title: 'Bewertung direkt nach dem Termin',
            text: 'Kleine Tafel an der Kasse mit der Aufforderung „Zufrieden? Hier bewerten“ erhöht die Google-Bewertungen spürbar.',
          },
          {
            title: 'Pflegeprodukte nachbestellen',
            text: 'Am Produktregal: Code zur Pflegeanleitung oder Bestellseite – Beratung, die über den Salon hinaus wirkt.',
          },
          {
            title: 'Gutscheine verkaufen',
            text: 'Schaufenster und Social-Post auf dieselbe Gutscheinseite leiten – der Code macht analoge Werbung messbar.',
          },
        ],
        steps: [
          'Zielseite wählen (Buchung, Bewertung, Gutschein oder Produkt).',
          'QR-Typ „Webseite“ wählen und Code erstellen.',
          'Mit klarer Aufforderung an Kasse, Eingang und Produktregal platzieren.',
          'Monatlich prüfen: Seite erreichbar? Bewertungen steigen?',
        ],
        faq: [
          {
            q: 'Welche Größe ist im Salon sinnvoll?',
            a: 'An Tafeln 5–8 cm, an der Kasse 4–5 cm – lesbar aus Armeslänge bei gedämpftem Licht.',
          },
          {
            q: 'Wie oft darf ich um Bewertungen bitten?',
            a: 'Pro Kundin und Termin einmal, freundlich und ohne Gegenleistung – das hält sich im Rahmen der Google-Regeln.',
          },
          {
            q: 'Funktioniert ein Code auf der Spiegelfolie?',
            a: 'Ja, sofern die Folie matt ist und die Ruhezone erhalten bleibt. Glänzende Folien verursachen Reflexionen.',
          },
        ],
        toolLinks: [
          { label: 'Termin-Code erstellen', href: '/?type=event' },
          { label: 'Bewertungs-Link hinterlegen', href: '/?type=url' },
        ],
        blogLinks: [
          { label: 'Google-Bewertungen mit QR-Code', href: '/blog/google-bewertungen-qr-code' },
        ],
      },
    ],
  },
  {
    slug: 'schulen',
    label: 'Für Schulen & Bildung',
    title: 'QR-Codes für Schulen, Kitas & Bildungseinrichtungen',
    metaTitle: 'QR-Codes für Schulen & Bildung: Lehrmittel, Eltern, Campus',
    metaDescription:
      'QR-Codes im Bildungsbereich: Lehrmaterial verlinken, Elternkommunikation vereinfachen und Orientierung auf dem Campus verbessern – so gelingt es.',
    intro: [
      'Schulen, Kitas und Hochschulen setzen QR-Codes mittlerweile in vielen Bereichen ein: vom Arbeitsblatt bis zum Elternabend, vom Campusplan bis zur Ausstellung.',
      'Die Codes sind kostenlos, datensparsam und funktionieren mit jedem Smartphone – auch mit den Geräten, die Familien bereits besitzen.',
    ],
    subs: [
      {
        slug: 'lehrmittel',
        title: 'QR-Codes für Lehrmittel & Unterrichtsmaterial',
        metaTitle: 'QR-Codes im Unterricht: Arbeitsblätter & Materialien verlinken',
        metaDescription:
          'So verlinken Lehrkräfte Videos, Hörbeispiele und Zusatzmaterial direkt am Arbeitsblatt – mit QR-Codes, die auch für jüngere Schüler funktionieren.',
        intro: [
          'Ein QR-Code am Arbeitsblatt spart der Klasse das Abtippen langer Adressen und bringt Videos, Hörbeispiele oder interaktive Übungen in Sekunden auf das Display.',
          'Für den Unterricht besonders praktisch: die Codes funktionieren offline auf dem Papier und müssen nicht erst geteilt oder verteilt werden.',
        ],
        useCases: [
          {
            title: 'Videos & Hörbeispiele am Blatt',
            text: 'Musik-, Sprach- oder Naturwissenschaftsunterricht: Ein Code verlinkt direkt zum passenden Material, ohne lange Adressen.',
          },
          {
            title: 'Selbstlernstationen',
            text: 'In der Lernlandschaft führen Codes an Stationen zu Erklärtexten, Lösungswegen oder weiteren Aufgaben.',
          },
          {
            title: 'Exkursionen & Museen',
            text: 'Auf dem Klassenausflug ergänzen Codes am Exponat die Führungen – auch ohne Schuleigene Geräte, dank privater Smartphones.',
          },
          {
            title: 'Elternmaterial & Anmeldeformulare',
            text: 'Flyer für den Elternabend oder die Klassenfahrt: Ein Scan führt direkt zum Anmeldeformular.',
          },
        ],
        steps: [
          'Ziel-URL festlegen (Video, Formular, Erklärseite).',
          'QR-Typ „Webseite“ wählen, Adresse einfügen und herunterladen.',
          'In den Unterrichtsmaterialien platzieren – mit kurzem Hinweis, was hinter dem Code steckt.',
          'Mit einer Testklasse prüfen: Funktioniert der Code auf allen Geräten?',
        ],
        faq: [
          {
            q: 'Dürfen Schüler die privaten Smartphones nutzen?',
            a: 'Das regelt die Schule. Der Code selbst setzt keine Daten voraus – er speichert nichts und überträgt nichts ohne Scan.',
          },
          {
            q: 'Welche Größe ist im Arbeitsblatt sinnvoll?',
            a: 'Ab 2,5 cm Kantenlänge ist der Code zuverlässig scanbar, auch mit günstigen Geräten.',
          },
          {
            q: 'Kann ich Codes wiederverwenden?',
            a: 'Ja – solange die Ziel-URL stabil bleibt, dienen dieselben Codes jahrelang.',
          },
        ],
        toolLinks: [{ label: 'Webseite-QR-Code erstellen', href: '/?type=url' }],
        blogLinks: [
          { label: 'QR-Codes in der Bildung: Praxisbeispiele', href: '/blog/qr-codes-schulen-bildung' },
        ],
      },
      {
        slug: 'elternkommunikation',
        title: 'QR-Codes für die Elternkommunikation',
        metaTitle: 'QR-Codes für Schulen: Eltern-Informationen & Anmeldung',
        metaDescription:
          'Vom Aushang zum Formular: wie Schulen und Kitas mit QR-Codes Termine, Anmeldungen und Notfallkontakte für Eltern vereinfachen.',
        intro: [
          'Die meisten Elterninformationen landen heute in digitalen Formularen – der Umweg über lange Adressen oderSuchaktionen kostet jedoch Nerven und Abbrüche.',
          'Ein QR-Code direkt am Aushang, auf dem Brief oder am Eingang führt Eltern in einem Schritt zum Ziel: Anmeldung, Klassenplan, Krankmeldung oder Notfallkontakte.',
        ],
        useCases: [
          {
            title: 'Anmeldung zum Schulanfang / Kita-Platz',
            text: 'Der Code auf dem Infobrief führt direkt zum Anmeldeformular – deutlich weniger Fehler als ausgefüllte Papierzettel.',
          },
          {
            title: 'Krankmeldung digital',
            text: 'Ein Code am Elternhandbuch führt zum kurzen Meldeformular – die Sekretariats-Telefonleitung bleibt frei.',
          },
          {
            title: 'Termine & ICS-Kalender',
            text: 'Der Termin-QR-Code für Elternabende und Ferienplan: Scannen legt den Termin direkt im Smartphone-Kalender ab.',
          },
          {
            title: 'WLAN für den Hausaufgabenraum',
            text: 'Gäste-WLAN per QR-Code – ohne Passwortzettel und ohne Tippen im Unterricht.',
          },
        ],
        steps: [
          'Zielseite oder Formular vorbereiten.',
          'Passenden QR-Typ wählen (Webseite oder Termin) und Code erstellen.',
          'Auf Brief, Aushang oder Elternseite platzieren – mit eindeutiger Beschriftung.',
          'Vor der Verteilung mit verschiedenen Geräten testen.',
        ],
        faq: [
          {
            q: 'Funktioniert das auch ohne schuleigenes WLAN?',
            a: 'Ja. Die Codes öffnen die Seite über Mobilfunk – vorausgesetzt, die Zielseite lädt schnell.',
          },
          {
            q: 'Wie plane ich einen Termin-QR-Code?',
            a: 'Typ „Termin“ wählen, Datum und Zeit eingeben – der Code erzeugt einen Kalendereintrag für iOS und Android.',
          },
          {
            q: 'Was ist beim Datenschutz zu beachten?',
            a: 'Die Codes selbst speichern nichts. Wählen Sie datensparsame Formulardienste und informieren Sie die Eltern transparent.',
          },
        ],
        toolLinks: [
          { label: 'Termin-QR-Code erstellen', href: '/?type=event' },
          { label: 'WLAN-QR-Code für Gäste', href: '/?type=wifi' },
        ],
        blogLinks: [
          { label: 'DSGVO bei QR-Codes im Überblick', href: '/blog/qr-code-dsgvo-datenschutz' },
        ],
      },
      {
        slug: 'campus',
        title: 'QR-Codes für Campus & Orientierung',
        metaTitle: 'QR-Codes für Hochschulen: Orientierung & Ausstattung',
        metaDescription:
          'Orientierung auf dem Campus mit QR-Codes: Wegweiser, Raumausstattung, Bibliothek und Ausstellungen – Praxisbeispiele für Hochschulen.',
        intro: [
          'Große Areale, wechselnde Räume, viele Einrichtungen: Auf dem Campus beantworten QR-Codes die Fragen, die sonst am Infopunkt landen – wo ist der Hörsaal, wie funktioniert der Drucker, wo finde ich die Prüfungsordnung.',
          'Die Pflege ist einfach: bestehende Schilder werden ergänzt, nicht ersetzt.',
        ],
        useCases: [
          {
            title: 'Raum- & Gebäudeweiser',
            text: 'An Eingängen und Aufzügen führen Codes zu interaktiven Plänen, die auch Umbauten überleben.',
          },
          {
            title: 'Geräte- & Laboranleitung',
            text: 'An Maschinen und Laborplätzen erklärt der Code die sichere Bedienung – immer in aktueller Fassung.',
          },
          {
            title: 'Bibliothek & Literaturlisten',
            text: 'Aus Leihverträgen und Literaturlisten führt ein Code direkt zum digitalen Exemplar oder Suchkatalog.',
          },
          {
            title: 'Studieninfo & Bewerbung',
            text: 'Auf Plakaten und Messeständen: Ein Scan führt zum Studiengangsprofil oder Bewerbungsformular.',
          },
        ],
        steps: [
          'Inventur: wiederkehrende Fragen am Standort notieren.',
          'Für jede Frage eine stabile Ziel-URL festlegen.',
          'Codes mit einheitlichem Design (Logo, Rahmen) erstellen.',
          'Auf bestehende Beschilderung aufbringen und jährlich prüfen.',
        ],
        faq: [
          {
            q: 'Welche Fehlerkorrektur ist bei Logos sinnvoll?',
            a: 'Stufe H (30 %) erlaubt größere Logos und bleibt auch bei Verschmutzung lesbar.',
          },
          {
            q: 'Wie halten Codes im Außenbereich?',
            a: 'Aluverbund oder hinter Acryl, matt kaschiert – so überstehen sie Witterung und Reinigung.',
          },
          {
            q: 'Kann die Hochschule Codes zentral verwalten?',
            a: 'Indem Ziele über stabile Kurz-Adressen laufen, bleiben bestehende Codes dauerhaft nutzbar.',
          },
        ],
        toolLinks: [{ label: 'Webseite-QR-Code erstellen', href: '/?type=url' }],
        blogLinks: [
          { label: 'Statisch vs. dynamisch – was Campus-Betreiber wissen müssen', href: '/blog/dynamische-vs-statische-qr-codes' },
        ],
      },
      {
        slug: 'kitas',
        title: 'QR-Codes für Kitas & Kindergärten',
        metaTitle: 'QR-Codes für Kitas: Elterninfo, Speiseplan & Anmeldung',
        metaDescription:
          'Praktische QR-Code-Anwendungen für Kitas: Anmeldung, Speiseplan, Ferienplan und Notfallhinweise – datensparsam für Eltern und Erziehende.',
        intro: [
          'Der Zettel im Hausaufgabenheft geht verloren, die Info an der Tür wird überklebt. QR-Codes in Kita-Eingang, Gruppenraum und Elternbrief führen zu Seiten, die Sie jederzeit aktualisieren können – ohne Neudruck und ohne Verteiler.',
          'Wichtig ist die Datensparsamkeit: Für die meisten Anwendungen genügt eine öffentliche Info-Seite ohne Personenbezug.',
        ],
        useCases: [
          {
            title: 'Anmeldung & Eingewöhnung',
            text: 'Der Code im Infobrief führt zum Anmeldeformular oder zur Liste der mitgebrachten Sachen.',
          },
          {
            title: 'Speise- und Ferienplan',
            text: 'Ein Code am Eingang zeigt den aktuellen Wochenplan – die Kita pflegt nur noch die Seite.',
          },
          {
            title: 'Notfall- & Kontaktinformationen',
            text: 'Hinweise zu Notfallnummern und Abläufen als statische Seite – ohne dass Daten im Code selbst liegen.',
          },
          {
            title: 'Elternabend & Termine',
            text: 'Termin-Code im Brief: Eltern speichern den Abend direkt im Kalender, die Nicht-Erscheinen-Quote sinkt.',
          },
        ],
        steps: [
          'Zielseite vorbereiten (Formular, Plan oder Info-Seite).',
          'QR-Typ wählen (Webseite oder Termin) und Code erstellen.',
          'Im Eingangsbereich und im Elternbrief platzieren – mit Klartext-Hinweis.',
          'Mit ein bis zwei Eltern testen, bevor der Brief in die Verteilung geht.',
        ],
        faq: [
          {
            q: 'Dürfen Fotos von Kindern hinter dem Code liegen?',
            a: 'Nur mit klarer Einwilligung der Erziehungsberechtigten. Informationen ohne Personenbezug sind unkritisch.',
          },
          {
            q: 'Was, wenn Eltern kein Smartphone haben?',
            a: 'Wichtige Informationen immer zusätzlich in Papierform anbieten – der Code ist die bequeme Alternative, nicht der einzige Weg.',
          },
          {
            q: 'Wie oft wechselt der Code?',
            a: 'Prinzipiell nie – die Zielseite ändert sich, der gedruckte Code bleibt jahrelang gültig.',
          },
        ],
        toolLinks: [
          { label: 'Info-Seite verlinken', href: '/?type=url' },
          { label: 'Termin-Code für Elternabende', href: '/?type=event' },
        ],
        blogLinks: [
          { label: 'QR-Codes in der Bildung', href: '/blog/qr-codes-schulen-bildung' },
          { label: 'DSGVO-Grundlagen', href: '/blog/qr-code-dsgvo-datenschutz' },
        ],
      },
    ],
  },
  {
    slug: 'veranstaltungen',
    label: 'Für Veranstaltungen',
    title: 'QR-Codes für Veranstaltungen',
    metaTitle: 'QR-Codes für Events: Einladung, Programm & Check-in',
    metaDescription:
      'QR-Codes für Vereinsfeste, Konzerte, Messen und Hochzeiten: Einladungen, Programm, RSVP und Einlass-Check-in in der Praxis.',
    intro: [
      'Veranstaltungen leben von reibungsloser Organisation: Einladung, Programm, Anfahrt, Check-in. QR-Codes übernehmen an jeder Stelle die lästige Tipparbeit – für Gäste wie Orga-Teams.',
      'Ob Vereinsfest, Hochzeit, Firmenfeier oder Messestand: die folgenden Anwendungsfälle funktionieren mit den Standardsmartphones Ihrer Gäste.',
    ],
    subs: [
      {
        slug: 'einladungen-rsvp',
        title: 'Einladung mit RSVP-QR-Code',
        metaTitle: 'Einladung mit QR-Code: Zusagen digital erfassen',
        metaDescription:
          'Einladungen mit QR-Code: Gäste scannen und sagen direkt zu – für Vereinsfeste, Hochzeiten und Firmenfeiern. So erstellen Sie den RSVP-Code.',
        intro: [
          'Die Papier-Einladung bleibt beliebt – die Rückläufer nicht. Ein QR-Code auf der Einladung führt zum kurzen Zusageformular: Name, Anzahl der Personen, Essenswünsche.',
          'Das Orga-Team erhält alle Zusagen gebündelt und muss nicht mehr telefonisch nachfassen.',
        ],
        useCases: [
          {
            title: 'Zusage-Formular',
            text: 'Ein Code auf der Karte führt zum Anmeldeformular – auch von Verwandten ohne E-Mail-Konto problemlos per Smartphone nutzbar.',
          },
          {
            title: 'Termin im Kalender',
            text: 'Mit dem Typ „Termin“ legen Gäste Datum und Ort direkt im Kalender ab – inklusive Erinnerungsfunktion.',
          },
          {
            title: 'Anfahrt & Parkplatz',
            text: 'Ein Standort-QR-Code führt Gäste per Navigation zum Eingang – Gold wert bei ländlichen Festplätzen.',
          },
          {
            title: 'Spenden & Tageskasse',
            text: 'Für Vereine: Ein GiroCode-Code auf dem Programmheft ermöglicht kontaktlose Spenden per Banking-App.',
          },
        ],
        steps: [
          'Formular- oder Kalender-Adresse vorbereiten.',
          'QR-Typ wählen (Webseite für RSVP, Termin für Kalender, Standort für Anfahrt).',
          'Code in die Gestaltung der Einladung einbinden – mit Hinweistext.',
          'Gedruckte Einladung vorab mit zwei Geräten testen.',
        ],
        faq: [
          {
            q: 'Funktioniert der Code auch auf dickem Karton?',
            a: 'Ja. Wichtig ist nur, keine Stempel oder Klebestellen auf der Codefläche zu platzieren.',
          },
          {
            q: 'Kann ich nach dem Druck noch das Ziel ändern?',
            a: 'Statische Codes nicht – es sei denn, das Ziel ist eine dauerhafte Kurz-Adresse, die Sie selbst weiterleiten.',
          },
          {
            q: 'Wie viele Zusagen kann ein Formular erfassen?',
            a: 'Das hängt vom Formulardienst ab – die meisten Anbieter decken Vereinsgrößen problemlos ab.',
          },
        ],
        toolLinks: [
          { label: 'Termin-QR-Code erstellen', href: '/?type=event' },
          { label: 'Standort auf der Karte', href: '/?type=standort' },
        ],
        blogLinks: [
          { label: 'QR-Codes für Veranstaltungen: die Übersicht', href: '/blog/qr-codes-veranstaltungen-events' },
        ],
      },
      {
        slug: 'programm',
        title: 'Programm & Tagesordnung per QR-Code',
        metaTitle: 'Programm-Heft mit QR-Code: Ablauf immer aktuell halten',
        metaDescription:
          'Mit QR-Codes bleiben Programm, Tagesordnung und Last-Minute-Änderungen auch nach dem Druck aktuell – für Vereine, Messen und Konzerte.',
        intro: [
          'Programmhefte werden gedruckt, bevor das letzte Band feststeht. Änderungen landen dann als Zettel auf der Pinnwand. Ein QR-Code löst das Problem elegant: Das gedruckte Heft zeigt auf eine Seite, die Sie jederzeit aktualisieren können.',
          'Auch für Tagesordnungen von Mitgliederversammlungen und Ablaufpläne von Crews ist das ein Gewinn.',
        ],
        useCases: [
          {
            title: 'Live-Programmseite',
            text: 'Die Seite hinter dem Code zeigt die aktuelle Tagesordnung inklusive Last-Minute-Verschiebungen.',
          },
          {
            title: 'Sprecher- & Referenteninfos',
            text: 'Biografien und Unterlagen müssen nicht neu gedruckt werden – der Code im Heft führt zur aktuellen Version.',
          },
          {
            title: 'Feedback & Umfragen',
            text: 'Nach der Veranstaltung führt der Code zur kurzen Zufriedenheitsumfrage – die Datenbasis fürs nächste Jahr.',
          },
          {
            title: 'Ergebnisse & Protokolle',
            text: 'Beschlüsse der Mitgliederversammlung erscheinen als PDF hinter dem Code des Ablaufplans.',
          },
        ],
        steps: [
          'Stabile Ziel-URL festlegen (z. B. eine Unterseite Ihrer Website).',
          'QR-Typ „Webseite“ erstellen und in das Layout einbinden.',
          'Inhalt der Zielseite während der Veranstaltung pflegen.',
          'Nach Abschluss die Seite als Archiv belassen – Codes bleiben gültig.',
        ],
        faq: [
          {
            q: 'Wie schnell sind Änderungen sichtbar?',
            a: 'Sobald Sie die Zielseite speichern – ohne Neudruck, ohne Verteiler.',
          },
          {
            q: 'Brauchen wir eine eigene Website?',
            a: 'Nein. Auch eine frei zugängliche Unterseite oder ein veröffentlichtes Dokument reicht.',
          },
          {
            q: 'Was, wenn das WLAN vor Ort ausfällt?',
            a: 'Halten Sie kritische Informationen zusätzlich im Heft – der Code ist Ergänzung, kein Ersatz.',
          },
        ],
        toolLinks: [{ label: 'Webseite-QR-Code erstellen', href: '/?type=url' }],
        blogLinks: [
          { label: 'Dynamisch vs. statisch erklärt', href: '/blog/dynamische-vs-statische-qr-codes' },
        ],
      },
      {
        slug: 'tickets-check-in',
        title: 'Tickets & Einlass-Check-in mit QR-Code',
        metaTitle: 'QR-Tickets für Events: Einlass sicher und schnell abwickeln',
        metaDescription:
          'Wie Veranstalter QR-Tickets für Konzerte, Messen und Vereinsfeste erstellen – und den Einlass mit Smartphone-Scan abwickeln.',
        intro: [
          'QR-Tickets sind Standard auf Konzerten und Messen – und für Vereinsfeste ebenso umsetzbar. Jedes Ticket trägt einen individuellen Code, den das Einlass-Team per Smartphone-scannen lässt.',
          'Wichtig ist der Unterschied zum einfachen Web-Code: Der Code muss pro Ticket eindeutig sein, was eine statische URL allein nicht leisten kann.',
        ],
        useCases: [
          {
            title: 'Digitale Tickets per E-Mail',
            text: 'Der Code im PDF erreicht jedes Smartphone – kein Ausdruck, kein Verlust beim Waschbecken.',
          },
          {
            title: 'Schneller Einlass',
            text: 'Ein Scan pro Gast statt Geld zählen und Zettel sortieren – die Einlassgeschwindigkeit verdoppelt sich erfahrungsgemäß.',
          },
          {
            title: 'Controllen & Gästelisten',
            text: 'Bereits eingelöste Codes werden markiert – Doppelversuche fallen sofort auf.',
          },
          {
            title: 'Personalisierte Kontingente',
            text: 'Für Vereine: Kontingente pro Ticketkategorie (Vorverkauf, Ermäßigt, Normal) kennzeichnen.',
          },
        ],
        steps: [
          'Ticketdaten pro Gast erfassen (Name, Kategorie, eindeutige Kennung).',
          'Pro Ticket einen Code mit individuellem Inhalt erzeugen (z. B. Name + Ticketnummer als Text).',
          'Codes in das Ticket-PDF einbinden und versenden.',
          'Einlass-Team mit einer Liste bereits eingelöster Kennungen arbeiten lassen.',
        ],
        faq: [
          {
            q: 'Reicht ein einfacher Link für alle Tickets?',
            a: 'Für den Nachweis individueller Tickets nein – dann braucht jeder Gast einen eigenen Code.',
          },
          {
            q: 'Welche Größe braucht ein Ticket-Code?',
            a: 'Im A6-Ticket reichen 3–4 cm; bei schlechtem Licht mehr.',
          },
          {
            q: 'Funktioniert das ohne professionelles Ticketing?',
            a: 'Ja – für kleine Veranstaltungen reichen Tabellenliste plus Einzelcodes aus diesem Generator.',
          },
        ],
        toolLinks: [
          { label: 'Text-QR-Code pro Ticket erstellen', href: '/?type=text' },
          { label: 'Termin-QR-Code fürs Programm', href: '/?type=event' },
        ],
        blogLinks: [
          { label: 'Veranstaltungs-Übersicht ansehen', href: '/blog/qr-codes-veranstaltungen-events' },
        ],
      },
      {
        slug: 'hochzeiten',
        title: 'QR-Codes für Hochzeiten & Familienfeste',
        metaTitle: 'QR-Codes für Hochzeiten: Einladung, Anfahrt & Ablauf',
        metaDescription:
          'Hochzeits- und Festplanung mit QR-Codes: RSVP, Trauungs-Anfahrt, Tagesablauf und Fotosammlung – elegant für Gäste, stressfrei für Orga.',
        intro: [
          'Hochzeits-Einladungen sind gestalterisch hochwertig – die Rückläufer trotzdem lästig. Ein dezenter QR-Code auf der Karte übernimmt Zusage, Anfahrt und Ablauf, ohne die Papier-Kultur anzutasten.',
          'Für Gäste bedeutet das: ein Scan statt Tippen. Für das Orga-Team: alle Zusagen an einem Ort statt in fünf Messenger-Gruppen.',
        ],
        useCases: [
          {
            title: 'Zusage per Scan',
            text: 'Rückseite der Einladung führt zum kurzen Formular: Personenzahl, Essenswünsche, Unverträglichkeiten.',
          },
          {
            title: 'Anfahrt & Parkplatz',
            text: 'Standort-Code mit exakten Koordinaten – bei Scheunen, Weinbergen und Hofstellen der einziger sicherer Wegweiser.',
          },
          {
            title: 'Tagesablauf im Kalender',
            text: 'Ablauf von Trauung bis Mitternacht als Termin-Codes – Gäste behalten die Übersicht auf dem Smartphone.',
          },
          {
            title: 'Fotos & Dank sammeln',
            text: 'Nach dem Fest führt ein Code im Dankesbrief zum geteilten Foto-Album oder zur Dankeskarte mit GiroCode.',
          },
        ],
        steps: [
          'Formular-, Karten- oder Kalender-Adresse vorbereiten.',
          'Passenden Typ wählen und Code mit ruhigem Design erstellen.',
          'In die Gestaltung der Einladung einbinden – kleine Größe, genug Ruhezone.',
          'Probeexemplar drucken und mit zwei Geräten scannen lassen.',
        ],
        faq: [
          {
            q: 'Wirkt ein Code auf einer hochwertigen Karte unpassend?',
            a: 'Nein, wenn er ruhig gesetzt wird: kleines Format, klare Beschriftung „Rückseite“, viel Weißraum.',
          },
          {
            q: 'Was, wenn Gäste ohne Smartphone kommen?',
            a: 'Telefonnummer für Rückfragen mit angeben – der Code bleibt ein Angebot, keine Pflicht.',
          },
          {
            q: 'Kann ich das Foto-Album nach dem Fest stilllegen?',
            a: 'Das Album selbst liegt beim Anbieter; alternativ führt der Code auf eine eigene Seite, die Sie nach Abschluss aktualisieren.',
          },
        ],
        toolLinks: [
          { label: 'Termin-Code für den Ablauf', href: '/?type=event' },
          { label: 'Standort für die Trauung', href: '/?type=standort' },
        ],
        blogLinks: [
          { label: 'Einladung mit RSVP-Code', href: '/blog/qr-codes-veranstaltungen-events' },
        ],
      },
    ],
  },
  {
    slug: 'immobilien',
    label: 'Für Immobilien',
    title: 'QR-Codes für Immobilien & Hausverwaltung',
    metaTitle: 'QR-Codes für Immobilien: Objektausschild, Besichtigung & Verwaltung',
    metaDescription:
      'QR-Codes für Makler, Eigentümer und Hausverwaltungen: Exposé am Ausschild, Besichtigungs-Termine, Mieterkommunikation und SEPA-Miete.',
    intro: [
      'Immobilien laufen über Schilder, Karten und Aushänge – ideale Träger für QR-Codes. Ob Verkauf, Vermietung oder Verwaltung: Der Scan überbrückt den Moment zwischen Straße und Exposé, zwischen Klingelschild und Formular.',
      'Alle Anwendungen bleiben statisch und datensparsam: keine Tracking-Zwischenstationen, keine personenbezogenen Inhalte im Code.',
    ],
    subs: [
      {
        slug: 'objekte',
        title: 'QR-Code am Objektausschild: Exposé mit einem Scan',
        metaTitle: 'QR-Code fürs Immobilien-Schild: Exposé & Grundriss direkt am Objekt',
        metaDescription:
          'Wie Makler und Eigentümer mit QR-Codes am Verkaufs-/Vermietungsschild Exposé, Grundrisse und Kontakt bereitstellen – mit Größen- und Platzierungsregeln.',
        intro: [
          'Wer am Objekt vorbeigeht, will Details – telefonisch erreichbar ist der Makler selten. Der Code am Ausschild führt in Sekunden zu Exposé, Grundrissen, Fotos und Kontaktmöglichkeit, rund um die Uhr.',
          'Technisch anspruchsvoll ist nur eines: die Lesbarkeit aus dem Stand auf der Gegenseite der Straße. Daraus folgt die Mindestgröße.',
        ],
        useCases: [
          {
            title: 'Exposé & Grundrisse',
            text: 'Eine Adresse für alle Unterlagen – aktualisierbar, ohne das Schild auszuwechseln.',
          },
          {
            title: 'Kontakt in einem Tap',
            text: 'vCard- oder Telefon-Code: Interessenten speichern den Ansprechpartner direkt, bevor das Gespräch vergessen ist.',
          },
          {
            title: 'Virtueller Rundgang',
            text: 'Video oder 360°-Tour hinter dem Code – auch wenn das Objekt längst verkauft ist, bleibt der Kanal nutzbar.',
          },
          {
            title: 'Besichtigungstermin buchen',
            text: 'Der Code führt zum Kalender oder Formular – Zusagen laufen strukturiert ein.',
          },
        ],
        steps: [
          'Zielseite festlegen (Exposé-PDF-Seite, Kontakt oder Buchung).',
          'QR-Typ „Webseite“ bzw. „Visitenkarte“ wählen und Code erstellen.',
          'Am Schild platzieren: mind. 12 cm für Straßensicht, Ruhezone freihalten.',
          'Druck als SVG an die Schilderwerkstatt übergeben und vor Ort scannen testen.',
        ],
        faq: [
          {
            q: 'Welche Größe braucht das Schild?',
            a: 'Ab etwa 12 cm Kantenlänge bleibt der Code aus 3–5 Metern zuverlässig scanbar – bei hochhängenden Schildern entsprechend mehr.',
          },
          {
            q: 'Was, wenn das Objekt verkauft ist?',
            a: 'Die Zielseite zeigt dann einen Hinweis oder Alternativobjekte – der Schildcode bleibt verwertbar.',
          },
          {
            q: 'Darf der Code auf Reflektionsfolie liegen?',
            a: 'Besser matt kaschieren; Reflexionen sind der häufigste Fehlergrund im Außenbereich.',
          },
        ],
        toolLinks: [
          { label: 'Exposé-Link als Code', href: '/?type=url' },
          { label: 'Kontakt (vCard)', href: '/?type=vcard' },
        ],
        blogLinks: [
          { label: 'Plakate & Außenschilder richtig dimensionieren', href: '/blog/qr-code-drucken-kontrast-groesse' },
        ],
      },
      {
        slug: 'besichtigungen',
        title: 'QR-Codes für Besichtigungen & Makler-Teams',
        metaTitle: 'Besichtigungen mit QR-Code: Anfahrt, Termin & Feedback',
        metaDescription:
          'QR-Codes für Besichtigungstermine: Anfahrt, Termin-Codes für Interessenten, Feedback nach der Besichtigung und Kontakt für Makler-Teams.',
        intro: [
          'Besichtigungen scheitern selten am Objekt, häufig an der Anfahrt. Ein Standort-Code in der Einladung führt Interessenten exakt zum Hofeinfahrt-Punkt – und ein Termin-Code spart die Rückfrage nach dem genauen Datum.',
          'Nach der Besichtigung liefert ein Feedback-Code die wichtigste Information für den nächsten Schritt: Warum wurde nicht gekauft?',
        ],
        useCases: [
          {
            title: 'Exakte Anfahrt',
            text: 'Koordinaten-Code in der Terminbestätigung – kein „dritter Hof links“, sondern Navigation.',
          },
          {
            title: 'Termin im Kalender',
            text: 'Der Termin-Code legt Besichtigung inkl. Adresse ab, inklusive Erinnerungsfunktion.',
          },
          {
            title: 'Feedback nach der Besichtigung',
            text: 'Kurze Umfrage hinter dem Code: Der maklereigene Datensatz zu Preis, Zustand und Erwartungen.',
          },
          {
            title: 'Team-Kontakt',
            text: 'vCard des zuständigen Maklers auf der Mappe – für den schnellen Austausch vor Ort.',
          },
        ],
        steps: [
          'Koordinaten des Treffpunkts präzise ermitteln (Karten-Link prüfen).',
          'Standort- und Termin-Code erstellen, in die Einladung einbetten.',
          'Feedback-Seite vorbereiten und nach dem Termin teilen.',
          'Alle Codes einmal vor dem Versand testen.',
        ],
        faq: [
          {
            q: 'Reicht die Adresse für die Navigation?',
            a: 'Bei Neubau oft ja; bei Höfen, Gewerbearealen und ländlichen Wegen sind Koordinaten deutlich zuverlässiger.',
          },
          {
            q: 'Wie kurz sollte die Feedback-Umfrage sein?',
            a: 'Drei Fragen maximal – alles darüber senkt die Rücklaufquote massiv.',
          },
          {
            q: 'Kostet die Nutzung etwas?',
            a: 'Nein – alle Codes sind kostenlos, ohne Konto und ohne Laufzeitbegrenzung.',
          },
        ],
        toolLinks: [
          { label: 'Standort-Code erstellen', href: '/?type=standort' },
          { label: 'Termin-Code erstellen', href: '/?type=event' },
        ],
        blogLinks: [
          { label: 'Veranstaltungs-Codes: RSVP & Programm', href: '/blog/qr-codes-veranstaltungen-events' },
        ],
      },
      {
        slug: 'verwaltung',
        title: 'QR-Codes für Hausverwaltung & Mieterkommunikation',
        metaTitle: 'Hausverwaltung mit QR-Code: Mieterinfo, Mängel & SEPA-Miete',
        metaDescription:
          'QR-Codes für Hausverwaltungen: Mieter-Informationen, Mängelmeldung, Abstellgenehmigung und SEPA-GiroCode für die Mietzahlung.',
        intro: [
          'Mieterkommunikation läuft über Aushänge, Briefkästen und Flyer – mit QR-Codes werden daraus digitale Kanäle ohne App-Zwang. Besonders bewährt: Info-Seiten je Haus, Mängel-Meldewege und der GiroCode für die Überweisung.',
          'Datenschutz spielt mit: Meldewege ohne Personenbezug im Code, Formulare mit klarer Verantwortlicher-Angabe.',
        ],
        useCases: [
          {
            title: 'Haus-Info-Board',
            text: 'Aushang im Treppenhaus führt zur Info-Seite: Hausordnung, Mülltermine, Stromausfall-Hinweise – immer aktuell.',
          },
          {
            title: 'Mängelmeldung',
            text: 'Code am Zählerschrank oder im Flur: Kurzformular statt Telefonwarteschleife, inklusive Foto-Option.',
          },
          {
            title: 'Miete per GiroCode',
            text: 'Im Mieterblatt: Der SEPA-Code überträgt Betrag und Kontodaten fehlerfrei in die Banking-App.',
          },
          {
            title: 'Paket-Abstellort',
            text: 'Ablage-Hinweis für Boten am Eingang – weniger Fehllieferungen, besonders bei Mehrfamilienhäusern.',
          },
        ],
        steps: [
          'Zielsen je Haus vorbereiten (Info-Seite, Formular oder Kontodaten).',
          'Passenden Typ wählen (Webseite, Text, SEPA oder Paket-Abstellort).',
          'Im Treppenhaus, am Aushang und in Mieterbriefen platzieren.',
          'Quartalsweise prüfen: Seiten erreichbar, Kontodaten korrekt?',
        ],
        faq: [
          {
            q: 'Ist die Mängelmeldung über QR datensicher?',
            a: 'Der Code selbst speichert nichts. Wählen Sie ein Formular mit Serverstandort in der EU und dokumentieren Sie es in der Datenschutzerklärung.',
          },
          {
            q: 'Kann ich pro Haus unterschiedliche Codes nutzen?',
            a: 'Ja – mit eigener Adresse pro Objekt lassen sich Anfragen auch objektbezogen zuordnen.',
          },
          {
            q: 'Was, wenn sich die Bankverbindung ändert?',
            a: 'Dann ist ein neuer GiroCode nötig. Planen Sie Mietblätter daher mit möglichst stabilen Kontodaten.',
          },
        ],
        toolLinks: [
          { label: 'SEPA-GiroCode erstellen', href: '/?type=sepa' },
          { label: 'Paket-Abstellort-Code', href: '/?type=delivery' },
        ],
        blogLinks: [
          { label: 'SEPA-GiroCode Schritt für Schritt', href: '/blog/sepa-girocode-qr-code-erstellen' },
          { label: 'Paket-Abstellort einrichten', href: '/blog/paket-abstellort-qr-code' },
        ],
      },
    ],
  },
  {
    slug: 'gesundheit',
    label: 'Für Gesundheit & Fitness',
    title: 'QR-Codes für Praxen, Therapeuten & Fitness',
    metaTitle: 'QR-Codes für Praxen, Therapeuten & Studios: Termine & Infos',
    metaDescription:
      'Datensparsame QR-Code-Anwendungen für Gesundheitsanbieter: Terminanfrage, Übungsvideos, Studio-Kursplan und Bewertungen – ohne sensible Daten im Code.',
    intro: [
      'In Praxen und Studios steht Vertrauen an erster Stelle – QR-Codes müssen hier besonders datensparsam eingesetzt werden. Die gute Nachricht: Die nützlichsten Anwendungen (Termin, Übungsmaterial, Kursplan, Bewertung) funktionieren ohne jede Gesundheitsinformation im Code selbst.',
      'Grundsatz: Immer nur auf eigene, klar beschriftete Zielseiten verlinken und sensible Inhalte niemals im Code hinterlegen.',
    ],
    subs: [
      {
        slug: 'arztpraxen',
        title: 'QR-Codes für Arztpraxen & Gesundheitszentren',
        metaTitle: 'QR-Codes für Praxen: Termin, WLAN & Praxis-Infos',
        metaDescription:
          'Wie Praxen QR-Codes datensparsam einsetzen: Terminanfrage, Wartezimmer-WLAN, Praxisinformationen und Kontakt – rechtssicher umgesetzt.',
        intro: [
          'Zwischen Wartezimmer und Empfang gibt es viele wiederkehrende Fragen: Wann ist Sprechstunde, wie geht die Terminverschiebung, wie lautet das WLAN? Eine Info-Seite mit QR-Code beantwortet sie, ohne den Empfang zu entlasten.',
          'Wichtig: keine Patientendaten in Codes oder unbedenklich wirkenden Zielseiten – nur allgemeine Informationen und Anfrage-Formulare.',
        ],
        useCases: [
          {
            title: 'Terminanfrage & Sprechzeiten',
            text: 'Am Eingang oder auf der Tür: Code zur Terminseite mit aktuellen Sprechzeiten und Anfrageformular.',
          },
          {
            title: 'WLAN im Wartezimmer',
            text: 'Gäste-Netz per WLAN-Code – bequem für Kinder und lange Wartezeiten, ohne Passwortzettel.',
          },
          {
            title: 'Vorbereitungshinweise',
            text: '„Nüchtern erscheinen“, Unterlagen mitbringen: Aufklärungsseiten hinter dem Code erreichen alle Patienten gleichzeitig.',
          },
          {
            title: 'Bewertung nach dem Besuch',
            text: 'Freiwillige Einladung an der Kasse – ohne Gegenleistung, im Rahmen der Google-Regeln.',
          },
        ],
        steps: [
          'Zielseite festlegen (Praxis-Info, Terminformular oder WLAN).',
          'QR-Typ wählen und Code mit klarer Beschriftung erstellen.',
          'Am Eingang, an der Rezeption und auf Papierbögen platzieren.',
          'Vor der Nutzung durch das Team testen.',
        ],
        faq: [
          {
            q: 'Darf ein Code auf einen Krankenschein führen?',
            a: 'Nein. Gesundheitsdaten gehören nicht in QR-Codes oder öffentliche Zielseiten – nutzen Sie geschützte Praxissysteme.',
          },
          {
            q: 'Reicht eine statische Info-Seite?',
            a: 'Für Sprechzeiten und Hinweise ja – die Seite wird gepflegt, der Code bleibt.',
          },
          {
            q: 'Wie sicher ist das WLAN für Patienten?',
            a: 'Ein isoliertes Gastnetz ohne Zugang zum Praxisnetz ist Voraussetzung – Gastzugang im Router aktivieren.',
          },
        ],
        toolLinks: [
          { label: 'Termin-/Info-Seite verlinken', href: '/?type=url' },
          { label: 'WLAN fürs Wartezimmer', href: '/?type=wifi' },
        ],
        blogLinks: [
          { label: 'DSGVO bei QR-Codes', href: '/blog/qr-code-dsgvo-datenschutz' },
        ],
      },
      {
        slug: 'therapeuten',
        title: 'QR-Codes für Therapeuten & Heilberufe',
        metaTitle: 'QR-Codes für Therapie: Übungspläne, Termine & Anleitungen',
        metaDescription:
          'Therapeuten und Heilpraktiker: QR-Codes für Übungsvideos, Hausaufgaben, Termine und Praxis-Kontakt – ohne sensible Daten im Code.',
        intro: [
          'Therapie-Erfolg hängt an der Heimübung – und an verständlichen Anleitungen. Ein QR-Code am Übungsblatt führt zum Video oder zur Anleitung, ohne dass Papier kopiert oder Links getippt werden müssen.',
          'Auch hier gilt: Codes enthalten nur den Verweis, niemals Diagnosen oder Patientendaten.',
        ],
        useCases: [
          {
            title: 'Übungsvideos & Anleitungen',
            text: 'Am Therapieblatt: Code zum Video der korrekten Durchführung – zu Hause jederzeit abrufbar.',
          },
          {
            title: 'Termin buchen & verschieben',
            text: 'Direkter Weg zur Online-Buchung oder zum Praxis-Kontaktformular.',
          },
          {
            title: 'Praxis-Informationen',
            text: 'Hinweise zu Kassenleistungen, Hausmitteln oder Anfahrt als eigene Seite.',
          },
          {
            title: 'Empfehlung & Bewertung',
            text: 'Zufriedene Patienten empfehlen weiter – der Code auf der Abschlusskarte macht den Weg kurz.',
          },
        ],
        steps: [
          'Materialseite oder Video-Adresse vorbereiten (ohne personenbezogene Inhalte).',
          'QR-Typ „Webseite“ wählen und Code erstellen.',
          'Auf Übungsblättern und in der Praxis platzieren – mit Beschriftung „Übung ansehen“.',
          'Mit Testpersonen prüfen: Funktioniert das Video auf dem üblichen Gerät?',
        ],
        faq: [
          {
            q: 'Dürfen Übungsblätter mit Namen codiert werden?',
            a: 'Nein – Codes nur auf unterlagenfreie Seiten. Der Blattname bleibt auf dem Papier.',
          },
          {
            q: 'Wie oft wechselt das Video?',
            a: 'Selten. Änderungen laufen über die Zielseite; der Code auf den Blättern bleibt jahrelang gültig.',
          },
          {
            q: 'Geht das auch ohne Website?',
            a: 'Ja – ein öffentliches Dokument oder Video-Plattform-Link reicht als Ziel.',
          },
        ],
        toolLinks: [
          { label: 'Übungsseite verlinken', href: '/?type=url' },
          { label: 'Termin-Code erstellen', href: '/?type=event' },
        ],
        blogLinks: [
          { label: 'Lehrmittel-Codes für Bildung', href: '/qr-codes-fuer/schulen/lehrmittel' },
        ],
      },
      {
        slug: 'sport-fitness',
        title: 'QR-Codes für Fitnessstudios & Sportvereine',
        metaTitle: 'QR-Codes für Fitness & Sport: Kursplan, Anmeldung, Bewertung',
        metaDescription:
          'Fitnessstudios und Vereine: QR-Codes für Kursplan, Probetraining, Anmeldung und Bewertungen – von der Wandtafel bis zum Flyer.',
        intro: [
          'Der Kursplan an der Wand veraltet schneller als gedruckt wird – ein QR-Code führt zur dynamischen Version. Und wer sich für ein Probetraining interessiert, scannt lieber, als einen Namen zu tippen.',
          'Studios und Vereine profitieren zusätzlich von der Bewertungs-Schleife nach dem Training.',
        ],
        useCases: [
          {
            title: 'Kursplan immer aktuell',
            text: 'Code an der Theke oder Wandtafel führt zur Live-Übersicht – Ausfälle und neue Slots sofort sichtbar.',
          },
          {
            title: 'Probetraining & Mitgliedschaft',
            text: 'Flyer und Wandtafel führen zum Anmeldeformular – Interessenten melden sich spontan an.',
          },
          {
            title: 'Übungs- und Trainingsvideos',
            text: 'An Geräten: Code zur Erklärung der richtigen Ausführung – personaltrainer-ähnlich, ohne Aufwand.',
          },
          {
            title: 'Bewertung nach dem Abschluss',
            text: 'Aufenthaltskarte oder Abschlussmail mit Code zur Google-Bewertung.',
          },
        ],
        steps: [
          'Zielseite wählen (Kursplan, Anmeldung, Video oder Bewertung).',
          'QR-Typ „Webseite“ wählen und Code erstellen.',
          'An Theke, Geräten und auf Flyern platzieren – Größe nach Abstand wählen.',
          'Vierteljährlich Together mit dem Kursplan aktualisieren.',
        ],
        faq: [
          {
            q: 'Wie oft wechselt der Code beim Kursplan?',
            a: 'Nie – nur die Seite dahinter. Genau das ist der Vorteil gegenüber gedruckten Plänen.',
          },
          {
            q: 'Funktioniert der Code an der Geräte-Wand?',
            a: 'Ja, ab 4 cm und mit mattierter Beschriftung; Bewegung beim Vorbeilaufen verzeiht nur große Codes.',
          },
          {
            q: 'Kostenlose Nutzung auch für Vereine?',
            a: 'Ja – kein Konto, kein Abo, unbegrenzte Codes.',
          },
        ],
        toolLinks: [
          { label: 'Kursplan-Seite verlinken', href: '/?type=url' },
          { label: 'Termin-Code fürs Probetraining', href: '/?type=event' },
        ],
        blogLinks: [
          { label: 'Marketing-Messbarkeit im Überblick', href: '/blog/qr-code-marketing-messbar-machen' },
        ],
      },
    ],
  },
];

export const MATERIALS_HUB: SeoHub = {
  slug: 'auf',
  label: 'Auf Marketing-Materialien',
  title: 'QR-Codes auf Marketing-Materialien',
  metaTitle: 'QR-Codes auf Flyern, Plakaten & Visitenkarten | QR-Generator Deutschland',
  metaDescription:
    'Wie QR-Codes auf Visitenkarten, Flyern, Plakaten und Verpackungen korrekt eingesetzt werden – Größen, Gestaltung und Platzierung in der Praxis.',
  intro: [
    'Drucksachen wirken lange, digitale Ziele ändern sich schnell. QR-Codes verbinden beides: Auf Visitenkarte, Flyer, Plakat oder Verpackung führen sie in einem Schritt vom Papier ins Digitale.',
    'Entscheidend sind drei Dinge: ausreichende Größe, starker Kontrast und eine klare Handlungsaufforderung. Die folgenden Leitfäden zeigen es am konkreten Material.',
  ],
  subs: [
    {
      slug: 'visitenkarten',
      title: 'QR-Code auf Visitenkarten',
      metaTitle: 'QR-Code auf Visitenkarten: Kontakt in einem Scan speichern',
      metaDescription:
        'So gelingt der QR-Code auf der Visitenkarte: vCard-Code erstellen, richtig platzieren und Größe wählen – mit Schritt-für-Schritt-Anleitung.',
      intro: [
        'Die Visitenkarte ist das meistgekopierte Werbemittel – und das am häufigsten entsorgte. Ein vCard-QR-Code verwandelt sie in einen gespeicherten Kontakt: Scannen, speichern, fertig.',
        'Damit der Code funktioniert, braucht er Platz und Kontrast – beides lässt sich in jedes Kartenlayout integrieren.',
      ],
      useCases: [
        {
          title: 'Kontakt direkt speichern',
          text: 'Der vCard-Code überträgt Name, Telefonnummern, Adresse und Website in einen Schritt – kein Abtippen, keine Tippfehler.',
        },
        {
          title: 'Mehrseitige Karte im Format',
          text: 'Rückseite der Karte als Code-Fläche nutzen – die Vorderseite bleibt gestalterisch ruhig.',
        },
        {
          title: 'Team-Konsistenz',
          text: 'Ein einheitliches Kartenlayout mit Code auf allen Visitenkarten des Betriebs stärkt den professionellen Eindruck.',
        },
        {
          title: 'Messenauftritt',
          text: 'Auf der Messe übernimmt der Code die Kontaktübergabe – auch wenn das Gespräch im Gehen stattfindet.',
        },
      ],
      steps: [
        'QR-Typ „Visitenkarte“ wählen und Kontaktdaten vollständig ausfüllen.',
        'Code als PNG (mind. 600 px) oder SVG herunterladen.',
        'Auf der Karte platzieren: mindestens 2,5 cm Kantenlänge, freie Ruhezone.',
        'Gedruckte Probe mit zwei Smartphones testen.',
      ],
      faq: [
        {
          q: 'Front oder Rückseite?',
          a: 'Rückseite ist ideal: Die Vorderseite bleibt ruhig, der Code hat genug Fläche.',
        },
        {
          q: 'Wie groß muss der Code sein?',
          a: 'Mindestens 2,5 cm – besser 3 cm. Kleinere Codes scheitern bei schlechterem Kamerahandys.',
        },
        {
          q: 'Darf das Logo in der Mitte sein?',
          a: 'Ja, bis ca. 25 % Fläche und mit hoher Fehlerkorrektur (Stufe H).',
        },
      ],
      toolLinks: [
        { label: 'vCard-QR-Code erstellen', href: '/?type=vcard' },
        { label: 'Firmen-Webseite verlinken', href: '/?type=url' },
      ],
      blogLinks: [
        { label: 'Digitale Visitenkarte: vollständige Anleitung', href: '/blog/vcard-qr-code-visitenkarte' },
      ],
    },
    {
      slug: 'flyer',
      title: 'QR-Code auf Flyern',
      metaTitle: 'QR-Code auf Flyern richtig einsetzen',
      metaDescription:
        'QR-Codes auf Flyern: Platzierung, Größe und Formulierungen, die den Scan-Rate wirklich erhöhen – mit Praxisbeispielen aus dem Marketing.',
      intro: [
        'Flyer haben Sekunden, um zu wirken. Ein gut platziertER QR-Code verwandelt diese Sekunden in eine messbare Aktion: Anmeldung, Bestellung, Bewertung oder Termin.',
        'Die häufigsten Fehler – zu klein, kein Handlungstext, unruhiger Hintergrund – lassen sich in Minuten beheben.',
      ],
      useCases: [
        {
          title: 'Aktion & Gutschein',
          text: '„10 % mit diesem Code“: Der Flyer wird zum Gutschein, der Scan zum Kaufargument.',
        },
        {
          title: 'Event-Anmeldung',
          text: 'Kurzformular hinter dem Code – deutlich höhere Zusageraten als per Telefon oder E-Mail.',
        },
        {
          title: 'Mehrseitiges Material bündeln',
          text: 'Programme, Preislisten oder Unterlagen bündeln: Eine Seite, ein Code, immer aktuell.',
        },
        {
          title: 'Umfrage & Feedback',
          text: 'Nach dem Termin führt der Code auf dem Flyer zur kurzen Umfrage.',
        },
      ],
      steps: [
        'Ziel und Handlungsaufforderung festlegen („Jetzt anmelden“, „Gutschein sichern“).',
        'QR-Typ passend zum Ziel wählen und Code erstellen.',
        'Auf dem Flyer platzieren: freie Fläche, Kontrast zum Hintergrund, ab 4 cm Kantenlänge.',
        'Scan-Rate nach dem Versand messen und Variante B testen.',
      ],
      faq: [
        {
          q: 'Wie viele Codes pro Flyer?',
          a: 'Einer. Mehrere Codes teilen die Aufmerksamkeit und erschweren die Auswertung.',
        },
        {
          q: 'Darf der Code über den Falz laufen?',
          a: 'Nein – Faltlinien beschädigen Module und machen Codes unlesbar.',
        },
        {
          q: 'Welche Farben sind erlaubt?',
          a: 'Dunkle Module auf hellem Grund. Starke Markenfarben funktionieren, wenn der Kontrast hoch genug bleibt.',
        },
      ],
      toolLinks: [
        { label: 'Webseite-QR-Code für Flyer', href: '/?type=url' },
        { label: 'Termin-QR-Code für Aktionen', href: '/?type=event' },
      ],
      blogLinks: [
        { label: 'Drucksachen-Praxis: Plakat, Flyer, Verpackung', href: '/blog/qr-codes-flyer-plakate-drucksachen' },
      ],
    },
    {
      slug: 'plakate',
      title: 'QR-Code auf Plakaten & Aushängen',
      metaTitle: 'QR-Code auf Plakaten: großformatig und zuverlässig scannbar',
      metaDescription:
        'QR-Codes auf Plakaten und Außenwerbung: Abstandsregeln, Größen und Platzierung für zuverlässige Scans aus der Distanz.',
      intro: [
        'Plakate werden aus der Entfernung und aus der Bewegung betrachtet – beides fordert den QR-Code. Die Faustregel: Der Code wächst mit dem Betrachtungsabstand, und die Handlungsaufforderung muss auch aus drei Metern lesbar sein.',
        'Ob Schaufenster, Schwarzes Brett oder Straßenrand: die folgende Rechnung gilt überall.',
      ],
      useCases: [
        {
          title: 'Veranstaltungshinweis',
          text: 'Konzert- oder Vereinsplakat mit Anfahrts- und Ticket-Code: Interessierte werden zu Besuchern.',
        },
        {
          title: 'Schaufenster & Fensterplakat',
          text: 'Auch nach Ladenschluss informiert der Code: Öffnungszeiten, Bestellseite, Speisekarte.',
        },
        {
          title: 'Immobilien-Objekt',
          text: 'Am Objektschild führt der Code zu Exposé, Grundriss und Kontakt – Anfragen auch außerhalb der Sprechzeiten.',
        },
        {
          title: 'Wahl- & Informationskampagne',
          text: 'Parteien und Initiativen bündeln Programme hinter einem Code statt langer Adressen.',
        },
      ],
      steps: [
        'Betrachtungsabstand schätzen und Codegröße danach bemessen (Faustregel: 1 cm Codegröße je 10 cm Abstand).',
        'QR-Typ wählen und Code in hoher Auflösung als PNG oder SVG herunterladen.',
        'Auf dem Layout mit großzügiger Ruhezone platzieren; Handlungsaufforderung darunter in groß.',
        'Am Aufstellungsort mit Abstand testen – auch bei Dämmerung.',
      ],
      faq: [
        {
          q: 'Wie groß muss ein Code auf einem Plakat sein?',
          a: 'Bei 2–3 m Betrachtungsabstand mind. 12–15 cm Kantenlänge.',
        },
        {
          q: 'Kann der Code dunkel hinterlegt sein?',
          a: 'Besser hell hinterlegen. Auf dunklem Grund braucht der Code einen hellen Rahmen als Ruhezone.',
        },
        {
          q: 'Was ist mit Aushängen hinter Glas?',
          a: 'Reflexionen sind der Feind: matt kaschieren oder schräg platzieren.',
        },
      ],
      toolLinks: [
        { label: 'Webseite-QR-Code für Plakate', href: '/?type=url' },
        { label: 'Standort-QR-Code für den Treffpunkt', href: '/?type=standort' },
      ],
      blogLinks: [
        { label: 'Drucken & Gestaltung im Detail', href: '/blog/qr-code-drucken-kontrast-groesse' },
      ],
    },
    {
      slug: 'verpackungen',
      title: 'QR-Code auf Produktverpackungen',
      metaTitle: 'QR-Codes auf Verpackungen: Herkunft, Pflege & Zubehör',
      metaDescription:
        'QR-Codes auf Produktverpackungen: Herkunftsnachweise, Pflegeanleitungen und Zubehör-Links sinnvoll einsetzen – ein Leitfaden.',
      intro: [
        'Die Verpackung ist das letzte Werbemittel in der Hand des Kunden – und die beste Gelegenheit für die Verbindung ins Digitale: Pflegeanleitungen, Herkunftsnachweise, Zubehör oder Garantie-Registrierung.',
        'Voraussetzung ist ein Code, der den Weg vom Regal bis zur Papierkammer überlebt: robust gedruckt und klar beschriftet.',
      ],
      useCases: [
        {
          title: 'Pflege & Anleitung',
          text: 'Statt beiliegendem Faltblatt: Der Code führt zu Videos und ausführlichen Anleitungen – aktuell und mehrsprachig.',
        },
        {
          title: 'Herkunft & Transparenz',
          text: 'Manufakturen zeigen die Herkunft der Rohstoffe digital – ein starkes Argument im Fachhandel.',
        },
        {
          title: 'Registrierung & Garantie',
          text: 'Ein Scan führt zum Registrierungsformular – die Garantieabwicklung wird für beide Seiten leichter.',
        },
        {
          title: 'Nachkauf & Zubehör',
          text: 'Passendes Zubehör und Verbrauchsmaterialien hinter dem Code – Wiederkauf wird zur Nebensache.',
        },
      ],
      steps: [
        'Ziel festlegen: Anleitung, Registrierung oder Produktseite.',
        'QR-Typ „Webseite“ wählen und Code erstellen (Fehlerkorrektur H für robuste Codes).',
        'In den Verpackungsdruck aufnehmen – mit ausreichend Rand und matt Finish.',
        'Produktionstest: Code nach simulierter Reibung und Lagerung scannen.',
      ],
      faq: [
        {
          q: 'Wie halten Codes auf Wellpappe?',
          a: 'Direktdruck oder Aufkleber mit mattem Laminat; Wellenrelief vermeiden, da Module verzerrt werden.',
        },
        {
          q: 'Wie viele Codes kann ich kostenpflichtig verwenden?',
          a: 'Keine – die Codes aus diesem Generator sind statisch und kostenlos, ohne Limit.',
        },
        {
          q: 'Kann der Code auf Mehrwegverpackungen wiederverwendet werden?',
          a: 'Ja, solange die Ziel-URL stabil bleibt und die Verpackung den Code schützt.',
        },
      ],
      toolLinks: [{ label: 'Webseite-QR-Code erstellen', href: '/?type=url' }],
      blogLinks: [
        { label: 'Statisch vs. dynamisch: was für Verpackungen zählt', href: '/blog/dynamische-vs-statische-qr-codes' },
      ],
    },
    {
      slug: 'tickets-einladungen',
      title: 'QR-Code auf Tickets & Einladungen',
      metaTitle: 'QR-Code auf Tickets und Einladungen: Check-in & RSVP',
      metaDescription:
        'So gelingt der QR-Code auf Tickets, Einladungskarten und Programmheften: Check-in, Zusage und Ablauf-Infos in einem Scan.',
      intro: [
        'Ticket und Einladung sind der Moment vor dem Event – hier entscheidet sich, ob die Zusage leicht fällt und der Einlass reibungslos klappt. Ein QR-Code verbindet Papier und Prozess: RSVP-Formular auf der Einladung, individuelle Kennung auf dem Ticket.',
        'Die Druckregeln sind dieselben wie bei anderen Trägern: kontrastreich, groß genug, mit freier Ruhezone – Karten überstehen nur wenige Biegetests.',
      ],
      useCases: [
        {
          title: 'Zusage auf der Einladung',
          text: 'Rückseite der Karte führt zum RSVP-Formular – die Papier-Kultur bleibt, die Auswertung wird digital.',
        },
        {
          title: 'Einlass-Kontrolle mit Einzelkennung',
          text: 'Pro Ticket eine eigene Kennung (Name + Nummer als Text-Code) – einmal gescannt, in der Liste abgehakt.',
        },
        {
          title: 'Ablauf & Programm',
          text: 'Der Code im Ticket führt zur Live-Programmseite – auch bei Terminverschiebungen aktuell.',
        },
        {
          title: 'Anreise & Parken',
          text: 'Standort- oder Webcode mit Anfahrtsbeschreibung – besonders bei Outdoor-Orten mit unklarer Adresse.',
        },
      ],
      steps: [
        'Ziel festlegen: RSVP, Ticket-Kennung, Programm oder Anfahrt.',
        'Passenden Typ wählen; bei Einzeltickets den Freitext-Code pro Person.',
        'Kontrastreich drucken, mindestens 3 cm Kantenlänge.',
        'Vor dem Versand mit zwei Geräten testen – inkl. Karten-Biegung.',
      ],
      faq: [
        {
          q: 'Reicht ein einziger Code für alle Tickets?',
          a: 'Für den Nachweis individueller Tickets nein – dann braucht jeder Gast eine eigene Kennung.',
        },
        {
          q: 'Was, wenn die Karte mal geknickt wird?',
          a: 'Hohe Fehlerkorrektur und ausreichende Größe helfen; den Code trotzdem nicht auf die Falzlinie legen.',
        },
        {
          q: 'Brauche ich ein Ticketing-System?',
          a: 'Für kleine Veranstaltungen genügen Einzelcodes aus diesem Generator plus Gästeliste.',
        },
      ],
      toolLinks: [
        { label: 'RSVP-Formular verlinken', href: '/?type=url' },
        { label: 'Text-Code pro Ticket', href: '/?type=text' },
      ],
      blogLinks: [
        { label: 'Tickets & Check-in im Detail', href: '/blog/qr-codes-veranstaltungen-events' },
      ],
    },
  ],
};

export const ALL_HUBS = [...HUBS, MATERIALS_HUB];

export function findHub(slug: string): SeoHub | undefined {
  return ALL_HUBS.find((h) => h.slug === slug);
}

export function findSub(hub: SeoHub, subSlug: string): SeoSubPage | undefined {
  return hub.subs.find((s) => s.slug === subSlug);
}