/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GermanCitySEO } from '../types/qr';

export const GERMAN_CITIES: GermanCitySEO[] = [
  {
    slug: 'berlin',
    name: 'Berlin',
    state: 'Berlin',
    tagline: 'QR-Codes für Berliner Altbau-WLAN, WGs & Home-Office',
    metaDescription: 'Erstellen Sie kostenlose QR-Codes für Berliner Haushalte: Fritz!Box Gäste-WLAN, WG-Nebenkosten GiroCode und Paket-Abstellort an der Haustür.',
    badge: 'Beliebt in Berlin',
    stats: {
      homeOfficeRatio: '38% Home-Office Quote',
      fiberInternet: 'Glasfaser & Kabel Highspeed',
      avgHouseholds: '2,1 Mio. Haushalte',
    },
    popularUseCases: [
      {
        title: 'Berliner Altbau Gäste-WLAN',
        desc: 'Teilen Sie Ihr WLAN sofort mit Gästen im Prenzlauer Berg, Kreuzberg oder Mitte – ohne ellenlange Router-Passwörter.',
        qrType: 'wifi',
        defaultData: {
          ssid: 'Berliner-Gäste-WLAN',
          password: 'hauptstadt-highspeed-2026',
          encryption: 'WPA',
          hidden: false,
          routerPreset: 'fritzbox',
        },
        customization: {
          foregroundColor: '#0f172a',
          frameType: 'bottom-bar',
          frameText: 'WLAN VERBINDEN',
          logoType: 'none',
        },
      },
      {
        title: 'WG-Kasse & Miete SEPA GiroCode',
        desc: 'Mietanteil, WG-Putzmittel oder Nebenkostenabrechnung direkt per Sparkasse Berlin oder N26 scannen.',
        qrType: 'sepa',
        defaultData: {
          name: 'WG Kasse Kreuzberg',
          iban: 'DE02 1005 0000 1098 7654 32',
          bic: 'BELADEBE100',
          amount: '45.00',
          purpose: 'WG Einkauf & Internet Berlin',
        },
        customization: {
          foregroundColor: '#1e3a8a',
          frameType: 'badge-card',
          frameText: 'SEPA ÜBERWEISEN',
          logoType: 'none',
        },
      },
      {
        title: 'Altbau Hinterhof Paket-Abstellort',
        desc: 'Hinweis für DHL & Hermes an der Klingel: Paket im 2. Hinterhof beim Nachbarn oder Schuppen abstellen.',
        qrType: 'delivery',
        defaultData: {
          recipientName: 'Schmidt (2. Hinterhof, 3. OG links)',
          deliveryLocation: 'Im Hausflur unter der Treppe oder bei Müller im EG abgeben',
          parcelServices: ['DHL', 'Hermes', 'Amazon'],
          phone: '+49 176 12345678',
          specialInstructions: 'Bitte nicht im Regen stehen lassen. Danke!',
        },
        customization: {
          foregroundColor: '#b45309',
          frameType: 'bottom-bar',
          frameText: 'PAKET HINWEIS',
          logoType: 'none',
        },
      },
    ],
    localTips: [
      'In Berliner Mehrfamilienhäusern empfiehlt sich ein laminierter QR-Code an der Wohnungstür für Paketboten, um verpasste Zustellungen im Späti zu vermeiden.',
      'Für Airbnb-Hosts in Berlin: Kombinieren Sie den WLAN-Code mit Hinweisen zur Berliner Mülltrennung (Gelber Sack, Bio, Glas).',
      'DSGVO-Tipp: Bei unserem Generator werden keine Passwörter auf Servern gespeichert – alles wird lokal im Browser gerendert.',
    ],
    faqs: [
      {
        question: 'Funktioniert der WLAN QR-Code mit Berliner AVM Fritz!Boxen?',
        answer: 'Ja, 100%. Die erstellten QR-Codes folgen dem offiziellen WLAN-Standard und sind zu allen Fritz!Box Modellen (z.B. 7590, 6690, 5590) sowie Telekom-Routern voll kompatibel.',
      },
      {
        question: 'Kann die Berliner Sparkasse diesen SEPA GiroCode scannen?',
        answer: 'Ja! Der GiroCode entspricht der offiziellen EPC-Norm des European Payments Council und wird von der Sparkassen-App, Volksbank, DKB, Commerzbank und Deutsche Bank fehlerfrei erkannt.',
      },
    ],
  },
  {
    slug: 'muenchen',
    name: 'München',
    state: 'Bayern',
    tagline: 'QR-Codes für Münchner Home-Office, Kaution & Gäste-Netzwerk',
    metaDescription: 'Kostenlose QR-Codes für München: Schnelles Gäste-WLAN, SEPA GiroCode für Handwerker & Hausverwaltung und Kontakt-Karten.',
    badge: 'Bayern Spitzenreiter',
    stats: {
      homeOfficeRatio: '42% Remote Work Quote',
      fiberInternet: 'M-net & Telekom Highspeed',
      avgHouseholds: '850.000 Haushalte',
    },
    popularUseCases: [
      {
        title: 'Münchner Home-Office Highspeed WLAN',
        desc: 'Verbinden Sie Notebooks, Tablets und Gäste in Schwabing, Bogenhausen oder Haidhausen im Handumdrehen.',
        qrType: 'wifi',
        defaultData: {
          ssid: 'Munich-HomeOffice-5G',
          password: 'servus-highspeed-muc',
          encryption: 'WPA',
          hidden: false,
          routerPreset: 'fritzbox',
        },
        customization: {
          foregroundColor: '#0369a1',
          frameType: 'bottom-bar',
          frameText: 'WLAN SCANNEN',
          logoType: 'none',
        },
      },
      {
        title: 'Hausverwaltung & Mietkaution GiroCode',
        desc: 'Nebenkosten, Handwerkerrechnungen oder Stellplatzmiete in München bequem per Banking-App überweisen.',
        qrType: 'sepa',
        defaultData: {
          name: 'Hausverwaltung Isarblick München',
          iban: 'DE89 7002 0270 0123 4567 89',
          bic: 'HYVEDEMMXXX',
          amount: '120.00',
          purpose: 'Nebenkostenabrechnung WEG 45/2',
        },
        customization: {
          foregroundColor: '#15803d',
          frameType: 'badge-card',
          frameText: 'GIROCODE SCANNEN',
          logoType: 'none',
        },
      },
      {
        title: 'Digitale Visitenkarte für Freelancer & Berater',
        desc: 'vCard QR-Code für Münchner Selbstständige und Berater – scanbar mit jedem iPhone oder Android Smartphone.',
        qrType: 'vcard',
        defaultData: {
          firstName: 'Maximilian',
          lastName: 'Brunner',
          organization: 'Brunner Consulting München',
          title: 'IT & Cloud Architekt',
          phone: '+49 89 9876543',
          mobile: '+49 171 8899001',
          email: 'maximilian@brunner-muc.de',
          street: 'Leopoldstraße 140',
          zip: '80804',
          city: 'München',
          country: 'Deutschland',
          website: 'https://brunner-consulting.de',
          note: 'Home-Office & Remote Beratung in ganz Bayern',
        },
        customization: {
          foregroundColor: '#1e293b',
          frameType: 'bottom-bar',
          frameText: 'KONTAKT SPEICHERN',
          logoType: 'none',
        },
      },
    ],
    localTips: [
      'In München haben viele Wohnungen strenge Hausordnungen: Ein gedruckter QR-Code mit den Ruhezeiten und Müllregeln erspart Ärger mit Nachbarn.',
      'Drucken Sie den QR-Code als A4 Aufsteller mit unserer Druckfunktion aus – ideal für den Flur oder die Garderobe.',
    ],
    faqs: [
      {
        question: 'Wie funktioniert der EPC GiroCode mit der Stadtsparkasse München?',
        answer: 'Öffnen Sie die Sparkassen-App, tippen Sie auf "Fotoüberweisung / QR-Code scannen" und halten Sie die Kamera auf den Code. Alle Daten werden automatisch und fehlerfrei ausgefüllt.',
      },
    ],
  },
  {
    slug: 'hamburg',
    name: 'Hamburg',
    state: 'Hamburg',
    tagline: 'QR-Codes für Hamburger Wohnungen, Hafencity & Treppenhäuser',
    metaDescription: 'Erstellen Sie QR-Codes für Hamburg: WLAN für Gäste in Altona & Eimsbüttel, Paket-Abstellverträge und SEPA Überweisungen.',
    badge: 'Norddeutschland Nr. 1',
    stats: {
      homeOfficeRatio: '39% Home-Office',
      fiberInternet: 'Willy.tel & Telekom',
      avgHouseholds: '1,05 Mio. Haushalte',
    },
    popularUseCases: [
      {
        title: 'Moin! Hamburger Gäste-WLAN',
        desc: 'Kein langes Suchen nach dem Router unter der Treppe: Sofortiger Internetzugang für Familie und Freunde.',
        qrType: 'wifi',
        defaultData: {
          ssid: 'Moin-Gastzugang-HH',
          password: 'elbe-alster-highspeed',
          encryption: 'WPA',
          hidden: false,
          routerPreset: 'fritzbox',
        },
        customization: {
          foregroundColor: '#0284c7',
          frameType: 'bottom-bar',
          frameText: 'WLAN VERBINDEN',
          logoType: 'none',
        },
      },
      {
        title: 'Treppenhaus Paketbox Abstellort',
        desc: 'Abstellanweisung für DHL & DPD im Hamburger Mehrfamilienhaus: Hinter der Hoftür oder beim Nachbarn ablegen.',
        qrType: 'delivery',
        defaultData: {
          recipientName: 'Familie Hansen (3. Etage)',
          deliveryLocation: 'Im Hausflur rechts neben den Briefkästen',
          parcelServices: ['DHL', 'Hermes', 'Amazon', 'DPD'],
          phone: '+49 170 5544332',
          specialInstructions: 'Bitte kurz klingeln nach dem Abstellen!',
        },
        customization: {
          foregroundColor: '#dc2626',
          frameType: 'bottom-bar',
          frameText: 'PAKET ABLEGEN',
          logoType: 'none',
        },
      },
    ],
    localTips: [
      'Mit Willy.tel und Glasfaser in Hamburg ist das Heimnetz blitzschnell – teilen Sie den 5GHz Gastzugang separat, um das Hauptnetz zu schützen.',
    ],
    faqs: [
      {
        question: 'Brauchen Gäste eine spezielle App zum Scannen?',
        answer: 'Nein! Jedes neuere iPhone (ab iOS 11) und Android Smartphone kann QR-Codes direkt mit der normalen Kamera-App scannen.',
      },
    ],
  },
  {
    slug: 'frankfurt',
    name: 'Frankfurt am Main',
    state: 'Hessen',
    tagline: 'QR-Codes für Finanzmetropole, Banküberweisung & Smart Home',
    metaDescription: 'Erstellen Sie professionelle QR-Codes in Frankfurt am Main: SEPA GiroCode Überweisungen, Home-Office Visitenkarten & Gäste-WLAN.',
    badge: 'Finanzplatz Deutschland',
    stats: {
      homeOfficeRatio: '44% Home-Office Quote',
      fiberInternet: 'DE-CIX Knotenpunkt Frankfurt',
      avgHouseholds: '410.000 Haushalte',
    },
    popularUseCases: [
      {
        title: 'SEPA GiroCode für Rechnungen & Honorare',
        desc: 'Schnelle Rechnungsbegleichung ohne Tippfehler für Frankfurter Dienstleister, Handwerker und Freiberufler.',
        qrType: 'sepa',
        defaultData: {
          name: 'Main Consulting & Services FFM',
          iban: 'DE27 5008 0000 0987 6543 21',
          bic: 'DRESDEFF500',
          amount: '250.00',
          purpose: 'Rechnung Nr. 2026-1048',
        },
        customization: {
          foregroundColor: '#0f766e',
          frameType: 'badge-card',
          frameText: 'SEPA BEZAHLEN',
          logoType: 'none',
        },
      },
      {
        title: 'Smart Home & Gäste-WLAN Frankfurt',
        desc: 'Der schnellste Weg für Besucher ins Frankfurter Highspeed-Heimnetzwerk am DE-CIX Internetknoten.',
        qrType: 'wifi',
        defaultData: {
          ssid: 'Skyline-Home-WLAN',
          password: 'frankfurt-main-fiber',
          encryption: 'WPA',
          hidden: false,
        },
        customization: {
          foregroundColor: '#334155',
          frameType: 'bottom-bar',
          frameText: 'WLAN VERBINDEN',
          logoType: 'none',
        },
      },
    ],
    localTips: [
      'In Frankfurt am Main sitzt der weltgrößte Internetknoten DE-CIX – Ihr Heimnetzwerk profitiert von extrem niedrigen Latenzen.',
    ],
    faqs: [
      {
        question: 'Sind SEPA GiroCodes in Deutschland rechtlich sicher?',
        answer: 'Ja, der EPC-GiroCode ist ein von der Deutschen Kreditwirtschaft anerkannter Standard. Er enthält lediglich Empfängername, IBAN, BIC und Verwendungszweck.',
      },
    ],
  },
  {
    slug: 'koeln',
    name: 'Köln',
    state: 'Nordrhein-Westfalen',
    tagline: 'QR-Codes für Veedel-Gemeinschaften, WGs & Nachbarschaftshilfe',
    metaDescription: 'Erstellen Sie kostenlose QR-Codes für Köln: WLAN für Gäste, Veedel-Nachbarschaftskontakte und SEPA Zahlungen.',
    badge: 'Rheinland Herz',
    stats: {
      homeOfficeRatio: '37% Home-Office',
      fiberInternet: 'NetCologne & Telekom',
      avgHouseholds: '570.000 Haushalte',
    },
    popularUseCases: [
      {
        title: 'NetCologne Gäste-WLAN fürs Veedel',
        desc: 'Perfekt für die Kölner Wohnung in Ehrenfeld, Belgisches Viertel oder Nippes – WLAN-Freigabe für Freunde.',
        qrType: 'wifi',
        defaultData: {
          ssid: 'Koelle-Gaeste-WLAN',
          password: 'dom-am-rhein-2026',
          encryption: 'WPA',
          hidden: false,
        },
        customization: {
          foregroundColor: '#b91c1c',
          frameType: 'bottom-bar',
          frameText: 'WLAN VERBINDEN',
          logoType: 'none',
        },
      },
      {
        title: 'Nachbarschaftshilfe WhatsApp QR-Gruppe',
        desc: 'Verbinden Sie die Hausgemeinschaft im Kölner Mehrfamilienhaus für Blumen gießen und Paketannahme.',
        qrType: 'whatsapp',
        defaultData: {
          phoneNumber: '491760000000',
          message: 'Hallo Nachbar! Ich wohne im 2. Stock und möchte mich mit der Hausgemeinschaft vernetzen.',
        },
        customization: {
          foregroundColor: '#16a34a',
          frameType: 'bottom-bar',
          frameText: 'WHATSAPP CHAT',
          logoType: 'none',
        },
      },
    ],
    localTips: [
      'NetCologne-Kunden können den Gastzugang direkt in der Router-Konfiguration aktivieren und diesen QR-Code dafür verwenden.',
    ],
    faqs: [
      {
        question: 'Kann ich den Code ausdrucken und im Hausflur anbringen?',
        answer: 'Ja! Nutzen Sie unsere integrierte Druckvorlage (DIN A4 Aufsteller) mit sauberem Rahmen und klarer Anleitung.',
      },
    ],
  },
  {
    slug: 'stuttgart',
    name: 'Stuttgart',
    state: 'Baden-Württemberg',
    tagline: 'QR-Codes für Kehrwoche-Plan, Home-Office & Häuslebauer',
    metaDescription: 'QR-Codes für Stuttgart: Digitaler Kehrwoche-Reinigungsplan, Handwerker SEPA GiroCode und schwäbisches Gäste-WLAN.',
    badge: 'Tüftler & Denker',
    stats: {
      homeOfficeRatio: '41% Home-Office',
      fiberInternet: 'Telekom & Gigabit Region Stuttgart',
      avgHouseholds: '330.000 Haushalte',
    },
    popularUseCases: [
      {
        title: 'Digitaler Kehrwoche-Plan für die Hausgemeinschaft',
        desc: 'Der schwäbische Klassiker modern gelöst: QR-Code an die Pinnwand hängen, der direkt zum Putzplan-Dokument führt.',
        qrType: 'url',
        defaultData: {
          url: 'https://beispiel-hausgemeinschaft.de/kehrwoche-plan',
        },
        customization: {
          foregroundColor: '#374151',
          frameType: 'badge-card',
          frameText: 'KEHRWOCHE PLAN',
          logoType: 'none',
        },
      },
      {
        title: 'Handwerker & Sanierung GiroCode',
        desc: 'Rechnungen für Dachdecker, Maler oder Heizungsbauer in Stuttgart per Sofortüberweisung begleichen.',
        qrType: 'sepa',
        defaultData: {
          name: 'Meisterbetrieb Haustechnik Stuttgart',
          iban: 'DE45 6005 0101 0123 4567 89',
          bic: 'SOLADESTXXX',
          amount: '480.00',
          purpose: 'Rechnung Wartung Wärmepumpe 2026',
        },
        customization: {
          foregroundColor: '#047857',
          frameType: 'badge-card',
          frameText: 'SEPA BEZAHLEN',
          logoType: 'none',
        },
      },
    ],
    localTips: [
      'Ein QR-Code für den Kehrwoche-Reinigungsplan vermeidet Streitigkeiten im Hausflur und ist jederzeit auf dem Smartphone abrufbar.',
    ],
    faqs: [
      {
        question: 'Bleibt der QR-Code dauerhaft gültig?',
        answer: 'Ja! Unsere statischen QR-Codes verfallen niemals und funktionieren ohne jedes Ablaufdatum oder Abo.',
      },
    ],
  },
  {
    slug: 'duesseldorf',
    name: 'Düsseldorf',
    state: 'Nordrhein-Westfalen',
    tagline: 'QR-Codes für Lifestyle, Home-Office am Rhein & Messekontakte',
    metaDescription: 'Kostenlose QR-Codes in Düsseldorf erstellen: Schnelles WLAN für Gäste, Messe-Visitenkarten und Paketabsteller.',
    badge: 'Rheinschiene',
    stats: {
      homeOfficeRatio: '38% Home-Office',
      fiberInternet: 'Vodafone & Telekom',
      avgHouseholds: '360.000 Haushalte',
    },
    popularUseCases: [
      {
        title: 'Düsseldorfer Messe & Home-Office vCard',
        desc: 'Kontaktdaten professionell per Smartphone übergeben – ideal für Selbstständige und Kreative am Rhein.',
        qrType: 'vcard',
        defaultData: {
          firstName: 'Sophie',
          lastName: 'Mertens',
          organization: 'Creative Studio Düsseldorf',
          title: 'Design Director',
          email: 'sophie@creative-dus.de',
          mobile: '+49 172 3344556',
          city: 'Düsseldorf',
          website: 'https://creative-dus.de',
          note: 'Messe & Remote Projektanfragen',
        },
        customization: {
          foregroundColor: '#4338ca',
          frameType: 'bottom-bar',
          frameText: 'KONTAKT SPEICHERN',
          logoType: 'none',
        },
      },
    ],
    localTips: ['Für Düsseldorfer Altstadt- und Medienhafen-Bewohner besonders nützlich: QR-Codes für Lieferdienste an schwer zugänglichen Toreingängen.'],
    faqs: [
      {
        question: 'Kann ich mein eigenes Firmenlogo in die Mitte setzen?',
        answer: 'Ja, wählen Sie einfach "Eigenes Logo" und laden Sie Ihr Bild hoch. Die Fehlerkorrektur wird automatisch auf "High (H)" gesetzt.',
      },
    ],
  },
  {
    slug: 'leipzig',
    name: 'Leipzig',
    state: 'Sachsen',
    tagline: 'QR-Codes für Kreativ-Lofts, WG-Leben & Hausgemeinschaften',
    metaDescription: 'QR-Code Generator für Leipzig: Fritz!Box Gäste-WLAN für Altbauwohnungen, Flohmarkt GiroCode und Paketbox-Hinweise.',
    badge: 'Boomtown Ost',
    stats: {
      homeOfficeRatio: '36% Home-Office',
      fiberInternet: 'Telekom & Pyur',
      avgHouseholds: '340.000 Haushalte',
    },
    popularUseCases: [
      {
        title: 'Leipziger Altbau Gäste-WLAN',
        desc: 'WLAN-Zugang in Plagwitz, Connewitz oder Gohlis – unkompliziert für Mitbewohner und Freunde.',
        qrType: 'wifi',
        defaultData: {
          ssid: 'Leipzig-Loft-WLAN',
          password: 'boomtown-highspeed-le',
          encryption: 'WPA',
          hidden: false,
        },
        customization: {
          foregroundColor: '#0d9488',
          frameType: 'bottom-bar',
          frameText: 'WLAN VERBINDEN',
          logoType: 'none',
        },
      },
    ],
    localTips: ['In Leipziger Gründerzeit-Häusern sind die Wände dick – platzieren Sie den QR-Code am besten in der Nähe des Repeaters.'],
    faqs: [
      {
        question: 'Werden meine Daten in einer Cloud gespeichert?',
        answer: 'Nein, niemals! Alle QR-Codes werden direkt in Ihrem Webbrowser generiert (Client-Side). Wir haben keinen Zugriff auf Passwörter oder IBANs.',
      },
    ],
  },
];

export interface GermanHomeGuide {
  id: string;
  title: string;
  summary: string;
  icon: string;
  qrType: string;
  instructions: string[];
}

export const GERMAN_HOME_GUIDES: GermanHomeGuide[] = [
  {
    id: 'fritzbox-wlan',
    title: 'Fritz!Box & Speedport Gäste-WLAN für Zuhause',
    summary: 'Nie wieder 20-stellige kryptische Passwörter vom Router-Aufkleber im Flur abtippen.',
    icon: 'wifi',
    qrType: 'wifi',
    instructions: [
      'Aktivieren Sie in Ihrer Fritz!Box (unter fritz.box) das "Gästenetz" für maximale Sicherheit.',
      'Geben Sie den Netzwerknamen (SSID) und das Passwort in unseren Generator ein.',
      'Drucken Sie das fertige Schild mit dem "Drucken (A4)"-Button aus und hängen Sie es im Flur oder an den Kühlschrank.',
      'Ihre Gäste halten einfach ihre Smartphone-Kamera drauf und sind sofort ohne App online!',
    ],
  },
  {
    id: 'sepa-girocode',
    title: 'SEPA GiroCode für Miete, GEZ & Rechnungen',
    summary: 'Tippfehler bei 22-stelligen IBANs gehören der Vergangenheit an – Standard nach European Payments Council.',
    icon: 'credit-card',
    qrType: 'sepa',
    instructions: [
      'Geben Sie Empfängername, deutsche IBAN (z.B. Sparkasse, DKB, ING) und Verwendungszweck ein.',
      'Legen Sie optional einen festen Betrag in Euro fest.',
      'Jede deutsche Banking-App erkennt den Code über die "Fotoüberweisung"-Funktion.',
      'Ideal für WG-Abrechnungen, private Handwerker oder Nebenkosten.',
    ],
  },
  {
    id: 'paketbote-haustuer',
    title: 'Haustür & Paketbote: Abstellgenehmigung QR-Code',
    summary: 'Verpassen Sie keine Lieferungen mehr während Home-Office Video-Calls oder Abwesenheit.',
    icon: 'package',
    qrType: 'delivery',
    instructions: [
      'Geben Sie Ihren Namen und den gewünschten wetterfesten Abstellort (z.B. Carport, hinter der Regentonne) an.',
      'Wählen Sie die zuständigen Paketdienste (DHL, Hermes, Amazon, DPD, GLS).',
      'Kleben Sie den laminierten QR-Code neben die Klingel oder an den Briefkasten.',
      'Der Zusteller scannt den Code und sieht sofort die exakte Anweisung.',
    ],
  },
  {
    id: 'umzug-keller',
    title: 'Keller, Umzugskartons & Vorratskammer organisieren',
    summary: 'Wissen, was in welcher Kiste ist, ohne jede Kiste im Keller öffnen zu müssen.',
    icon: 'archive',
    qrType: 'text',
    instructions: [
      'Erstellen Sie für jeden Karton einen QR-Code mit Textinhalt (z.B. "Karton #4: Winterkleidung, Skischuhe, Daunenjacken").',
      'Drucken Sie den Code aus und kleben Sie ihn gut sichtbar auf die Stirnseite des Kartons.',
      'Ein kurzer Scan mit dem Handy verrät den kompletten Inhalt in Sekunden.',
    ],
  },
  {
    id: 'notfall-kuehlschrank',
    title: 'Notfall-Kontakt & Hausarzt für den Kühlschrank',
    summary: 'Wichtige Telefonnummern für Babysitter, Angehörige und Rettungskräfte sofort griffbereit.',
    icon: 'heart-pulse',
    qrType: 'vcard',
    instructions: [
      'Erstellen Sie eine vCard mit Hausarzt, Kinderarzt, Giftnotruf und nahen Verwandten.',
      'Platzieren Sie den QR-Code gut sichtbar am Kühlschrank in der Küche (bekannter Rettungsort in Deutschland).',
      'Im Notfall reicht ein Scan, um den Anruf ohne Nummerneingabe zu starten.',
    ],
  },
];
