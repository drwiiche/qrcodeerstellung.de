/** Global ambient types. */

// Side-effect CSS imports (previously provided by vite/client).
declare module '*.css';
