/** Canonical production origin — single source of truth for SEO URLs. */
export const SITE_URL = 'https://qr-generator-deutschland.de';
