/**
 * Blog content layer — powered by Keystatic (open-source file-based headless CMS).
 *
 * Reads:  Keystatic's Reader API parses content/posts/<slug>.mdoc (YAML frontmatter).
 * Writes: the admin API persists the same Keystatic file format (Keystatic ships no
 *         public writer SDK), so files remain editable by Keystatic tooling too.
 *
 * Server-only: never import this from a client component.
 */
import { promises as fs } from 'fs';
import path from 'path';
import { createReader } from '@keystatic/core/reader';
import { marked } from 'marked';
import keystaticConfig, { POST_CATEGORIES } from '../../keystatic.config';

const POSTS_DIR = path.join(process.cwd(), 'content', 'posts');

export interface PostMeta {
  slug: string;
  title: string;
  excerpt: string;
  /** ISO date (YYYY-MM-DD) */
  date: string;
  category: string;
  categoryLabel: string;
  readingMinutes: number;
}

export interface Post extends PostMeta {
  body: string;
  html: string;
}

export interface PostInput {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  body: string;
}

export const SLUG_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

export function categoryLabel(value: string): string {
  return POST_CATEGORIES.find((c) => c.value === value)?.label ?? 'Allgemein';
}

export function isValidCategory(value: string): boolean {
  return POST_CATEGORIES.some((c) => c.value === value);
}

function readingMinutes(body: string): number {
  const words = body.trim().split(/\s+/).filter(Boolean).length;
  // German technical prose: ~200 words per minute.
  return Math.max(1, Math.round(words / 200));
}

// ---- read ------------------------------------------------------------------

interface RawEntry {
  title: string;
  excerpt?: string;
  publishedDate?: string;
  category?: string;
}

interface PostsReader {
  collections: {
    posts: {
      all: () => Promise<{ slug: string }[]>;
      read: (slug: string) => Promise<RawEntry | null | undefined>;
    };
  };
}

let readerPromise: PostsReader | null = null;
function getReader(): PostsReader {
  if (!readerPromise) {
    readerPromise = createReader(process.cwd(), keystaticConfig) as unknown as PostsReader;
  }
  return readerPromise;
}

async function readEntry(slug: string): Promise<{ meta: PostMeta; body: string } | null> {
  if (!SLUG_PATTERN.test(slug)) return null;
  const entry = await getReader().collections.posts.read(slug);
  if (!entry || typeof entry !== 'object') return null;

  const file = path.join(POSTS_DIR, `${slug}.mdoc`);
  const raw = await fs.readFile(file, 'utf8').catch(() => '');
  const body = raw.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n?/, '').trim();

  const date = DATE_PATTERN.test(entry.publishedDate || '') ? entry.publishedDate! : '2026-01-01';
  const cat = isValidCategory(entry.category || '') ? entry.category! : 'anleitungen';

  return {
    meta: {
      slug,
      title: entry.title || slug,
      excerpt: (entry.excerpt || '').trim(),
      date,
      category: cat,
      categoryLabel: categoryLabel(cat),
      readingMinutes: readingMinutes(body),
    },
    body,
  };
}

/** All posts, newest first. */
export async function getAllPosts(): Promise<PostMeta[]> {
  const entries = await getReader().collections.posts.all();
  const metas = await Promise.all(entries.map((e) => readEntry(e.slug)));
  return metas
    .filter((m): m is { meta: PostMeta; body: string } => m !== null)
    .map((m) => m.meta)
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
}

/** One post with raw markdown body + rendered HTML. */
export async function getPost(slug: string): Promise<Post | null> {
  const found = await readEntry(slug);
  if (!found) return null;
  return {
    ...found.meta,
    body: found.body,
    html: marked.parse(found.body, { gfm: true, async: false }) as string,
  };
}

/** Newest posts from the same category first, then latest overall. */
export async function getRelatedPosts(slug: string, category: string, limit = 3): Promise<PostMeta[]> {
  const all = await getAllPosts();
  const sameCat = all.filter((p) => p.slug !== slug && p.category === category);
  const rest = all.filter((p) => p.slug !== slug && p.category !== category);
  return [...sameCat, ...rest].slice(0, limit);
}

// ---- write (admin) ---------------------------------------------------------

function buildFile(input: PostInput): string {
  const fm = [
    '---',
    `title: ${JSON.stringify(input.title)}`,
    `excerpt: ${JSON.stringify(input.excerpt)}`,
    `publishedDate: ${input.date}`,
    `category: ${input.category}`,
    '---',
    '',
    '',
  ].join('\n');
  return fm + input.body.replace(/^\s+/, '') + '\n';
}

export type PostValidationResult =
  | { ok: true; value: PostInput; error?: never }
  | { ok: false; value?: never; error: string };

export function validatePostInput(input: unknown): PostValidationResult {
  if (typeof input !== 'object' || input === null) {
    return { ok: false, error: 'Ungültige Daten.' };
  }
  const i = input as Record<string, unknown>;
  const slug = String(i.slug ?? '').trim();
  const title = String(i.title ?? '').trim();
  const excerpt = String(i.excerpt ?? '').trim();
  const date = String(i.date ?? '').trim();
  const category = String(i.category ?? '').trim();
  const body = String(i.body ?? '');

  if (!title) return { ok: false, error: 'Ein Titel ist erforderlich.' };
  if (!SLUG_PATTERN.test(slug)) {
    return { ok: false, error: 'Slug erforderlich: nur kleine Buchstaben, Ziffern und Bindestriche.' };
  }
  if (!DATE_PATTERN.test(date)) return { ok: false, error: 'Datum im Format JJJJ-MM-TT erforderlich.' };
  if (!isValidCategory(category)) return { ok: false, error: 'Unbekannte Kategorie.' };
  if (body.trim().length < 50) return { ok: false, error: 'Der Inhalt ist zu kurz (mind. 50 Zeichen).' };
  if (excerpt.length > 300) return { ok: false, error: 'Die Kurzbeschreibung darf max. 300 Zeichen haben.' };

  return { ok: true, value: { slug, title, excerpt, date, category, body } };
}

async function ensurePostsDir() {
  await fs.mkdir(POSTS_DIR, { recursive: true });
}

export async function createPost(input: PostInput, { overwrite = false } = {}): Promise<void> {
  await ensurePostsDir();
  const file = path.join(POSTS_DIR, `${input.slug}.mdoc`);
  if (!overwrite) {
    const exists = await fs.access(file).then(() => true, () => false);
    if (exists) throw new Error('Ein Beitrag mit diesem Slug existiert bereits.');
  }
  await fs.writeFile(file, buildFile(input), 'utf8');
}

export async function updatePost(originalSlug: string, input: PostInput): Promise<void> {
  await ensurePostsDir();
  const originalFile = path.join(POSTS_DIR, `${originalSlug}.mdoc`);
  const exists = await fs.access(originalFile).then(() => true, () => false);
  if (!exists) throw new Error('Beitrag nicht gefunden.');
  await fs.writeFile(path.join(POSTS_DIR, `${input.slug}.mdoc`), buildFile(input), 'utf8');
  if (originalSlug !== input.slug) {
    await fs.unlink(originalFile).catch(() => undefined);
  }
}

export async function deletePost(slug: string): Promise<void> {
  if (!SLUG_PATTERN.test(slug)) throw new Error('Ungültiger Slug.');
  await fs.unlink(path.join(POSTS_DIR, `${slug}.mdoc`));
}