/**
 * Contact message store — persists messages sent through the Impressum contact
 * form to .data/messages.json (atomic writes), so they show up in /admin.
 * Includes validation + a small per-IP rate limit against spam.
 */
import { promises as fs } from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface ContactMessage {
  id: string;
  subject: string;
  message: string;
  email?: string;
  createdAt: string;
  read: boolean;
}

const DATA_DIR = path.join(process.cwd(), '.data');
const FILE = path.join(DATA_DIR, 'messages.json');

const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const RATE_LIMIT_MAX = 5; // 5 messages per window per IP
const rateBuckets = new Map<string, number[]>();

export const MESSAGE_LIMITS = {
  subject: 200,
  message: 5000,
  email: 100,
  minMessage: 5,
} as const;

async function readAll(): Promise<ContactMessage[]> {
  try {
    const raw = await fs.readFile(FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function writeAll(messages: ContactMessage[]): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const tmp = FILE + '.tmp';
  await fs.writeFile(tmp, JSON.stringify(messages, null, 2), 'utf8');
  await fs.rename(tmp, FILE);
}

export async function listMessages(): Promise<ContactMessage[]> {
  const messages = await readAll();
  // newest first
  return messages.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function countUnread(messages: ContactMessage[]): number {
  return messages.filter((m) => !m.read).length;
}

/** Returns an error string (German) or null when the input is valid. */
export function validateMessage(input: {
  subject?: unknown;
  message?: unknown;
  email?: unknown;
}): string | null {
  const subject = typeof input.subject === 'string' ? input.subject.trim() : '';
  const message = typeof input.message === 'string' ? input.message.trim() : '';
  const email = typeof input.email === 'string' ? input.email.trim() : '';

  if (message.length < MESSAGE_LIMITS.minMessage) {
    return 'Bitte geben Sie eine Nachricht ein (mindestens 5 Zeichen).';
  }
  if (message.length > MESSAGE_LIMITS.message) {
    return `Die Nachricht darf maximal ${MESSAGE_LIMITS.message} Zeichen enthalten.`;
  }
  if (subject.length > MESSAGE_LIMITS.subject) {
    return `Der Betreff darf maximal ${MESSAGE_LIMITS.subject} Zeichen enthalten.`;
  }
  if (email.length > MESSAGE_LIMITS.email) {
    return 'Die E-Mail-Adresse ist zu lang.';
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    return 'Bitte geben Sie eine gültige E-Mail-Adresse an.';
  }
  return null;
}

/** Simple in-memory per-IP rate limit. Returns true when the request may proceed. */
export function rateLimitOk(ip: string): boolean {
  const now = Date.now();
  const bucket = (rateBuckets.get(ip) || []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS);
  if (bucket.length >= RATE_LIMIT_MAX) {
    rateBuckets.set(ip, bucket);
    return false;
  }
  bucket.push(now);
  rateBuckets.set(ip, bucket);
  return true;
}

export async function addMessage(input: {
  subject?: string;
  message: string;
  email?: string;
}): Promise<ContactMessage> {
  const entry: ContactMessage = {
    id: crypto.randomUUID(),
    subject: (input.subject || '').trim() || '(ohne Betreff)',
    message: input.message.trim(),
    email: input.email?.trim() || undefined,
    createdAt: new Date().toISOString(),
    read: false,
  };
  const messages = await readAll();
  messages.push(entry);
  // cap stored history at 500 so the file can never grow unbounded
  const trimmed = messages.slice(-500);
  await writeAll(trimmed);
  return entry;
}

export async function markMessage(id: string, read: boolean): Promise<boolean> {
  const messages = await readAll();
  const msg = messages.find((m) => m.id === id);
  if (!msg) return false;
  msg.read = read;
  await writeAll(messages);
  return true;
}

export async function deleteMessage(id: string): Promise<boolean> {
  const messages = await readAll();
  const next = messages.filter((m) => m.id !== id);
  if (next.length === messages.length) return false;
  await writeAll(next);
  return true;
}
