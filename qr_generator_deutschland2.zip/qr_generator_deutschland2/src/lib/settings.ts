/**
 * Server-side settings store.
 *
 * Persists all website-controllable configuration (contact data, ad providers,
 * analytics snippets) in .data/settings.json with atomic writes.
 * The store never exposes the admin password hash or session secret to callers
 * outside this module — API routes strip them before returning.
 */
import { promises as fs } from 'fs';
import path from 'path';
import crypto from 'crypto';

export type AdSlotPosition = 'below-hero' | 'mid-content' | 'above-footer';

export interface AdProvider {
  id: string;
  /** Display name, e.g. "Google AdSense", "AppLovin MAX" */
  name: string;
  /** adsense = standard <ins class="adsbygoogle">, custom = raw script/HTML snippet */
  type: 'adsense' | 'custom';
  /** AdSense publisher ID (ca-pub-xxxxxxxx) — type "adsense" only */
  clientId: string;
  /** AdSense slot IDs per position — type "adsense" only */
  slots: Partial<Record<AdSlotPosition, string>>;
  /** Raw HTML/JS snippet — type "custom" only (AppLovin, Ezoic, ... ) */
  snippet: string;
  positions: AdSlotPosition[];
  enabled: boolean;
}

export interface AnalyticsConfig {
  enabled: boolean;
  /** Google Analytics 4 measurement ID (G-XXXXXXX) */
  ga4Id: string;
  /** Google Tag Manager container ID (GTM-XXXX) */
  gtmId: string;
  /** Custom analytics snippet (Plausible, Matomo, ...) */
  customSnippet: string;
}

export interface SiteSettings {
  siteName: string;
  domain: string;
  contact: {
    company: string;
    street: string;
    zip: string;
    city: string;
    country: string;
    email: string;
    phone: string;
    responsiblePerson: string;
  };
  ads: {
    enabled: boolean;
    providers: AdProvider[];
  };
  analytics: AnalyticsConfig;
}

/** Internal shape — includes secrets that must never leave the server. */
interface StoredSettings extends SiteSettings {
  adminPasswordHash: string | null;
  sessionSecret: string;
}

const DATA_DIR = path.join(process.cwd(), '.data');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

const DEFAULTS: StoredSettings = {
  siteName: 'QR-Code Generator',
  domain: 'https://qr-generator-deutschland.de',
  contact: {
    company: 'QR-Generator Deutschland',
    street: 'Friedrichstraße 123',
    zip: '10117',
    city: 'Berlin',
    country: 'Deutschland',
    email: 'info@qr-generator-deutschland.de',
    phone: '+49 (0) 30 12345678',
    responsiblePerson: 'Maximilian Mustermann',
  },
  ads: {
    enabled: false,
    providers: [],
  },
  analytics: {
    enabled: false,
    ga4Id: '',
    gtmId: '',
    customSnippet: '',
  },
  adminPasswordHash: null,
  sessionSecret: crypto.randomBytes(32).toString('hex'),
};

let cache: StoredSettings | null = null;
let writeQueue: Promise<unknown> = Promise.resolve();

function isStored(v: unknown): v is StoredSettings {
  return typeof v === 'object' && v !== null && 'siteName' in v;
}

async function readFromDisk(): Promise<StoredSettings> {
  try {
    const raw = await fs.readFile(SETTINGS_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    if (isStored(parsed)) {
      // Merge over defaults so newly added fields always exist.
      return {
        ...DEFAULTS,
        ...parsed,
        contact: { ...DEFAULTS.contact, ...parsed.contact },
        ads: sanitizeAds({ ...DEFAULTS.ads, ...parsed.ads }),
        analytics: { ...DEFAULTS.analytics, ...parsed.analytics },
        // Keep the persisted secret (never regenerate per request).
        sessionSecret: parsed.sessionSecret || DEFAULTS.sessionSecret,
      };
    }
  } catch {
    // Missing/corrupt file → fall through to defaults.
  }
  return { ...DEFAULTS };
}

/** Full settings including secrets. Server-side only. */
export async function getStoredSettings(): Promise<StoredSettings> {
  if (!cache) {
    cache = await readFromDisk();
  }
  return cache;
}

/** Public subset safe to return from API routes / render client-side. */
export async function getSettings(): Promise<SiteSettings> {
  const s = await getStoredSettings();
  return {
    siteName: s.siteName,
    domain: s.domain,
    contact: s.contact,
    ads: s.ads,
    analytics: s.analytics,
  };
}

async function writeToDisk(next: StoredSettings): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const tmp = SETTINGS_FILE + `.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(next, null, 2), 'utf8');
  await fs.rename(tmp, SETTINGS_FILE);
}

/** Ad slot IDs are digits only — strips stray pasted characters/concatenations. */
function sanitizeAds(ads: SiteSettings['ads']): SiteSettings['ads'] {
  return {
    ...ads,
    providers: ads.providers.map((p) => ({
      ...p,
      clientId: (p.clientId || '').trim(),
      slots: Object.fromEntries(
        Object.entries(p.slots || {}).map(([k, v]) => [k, String(v || '').replace(/[^0-9]/g, '')])
      ) as AdProvider['slots'],
    })),
  };
}

/**
 * Update settings with a partial patch. Only known top-level keys are applied;
 * secrets can only be changed through this function's dedicated parameters.
 */
export async function updateSettings(patch: Partial<SiteSettings>): Promise<SiteSettings> {
  // Serialize writes to avoid interleaving.
  const job = writeQueue.then(async () => {
    const current = await getStoredSettings();
    const next: StoredSettings = {
      ...current,
      ...(patch.siteName !== undefined ? { siteName: patch.siteName } : {}),
      ...(patch.domain !== undefined ? { domain: patch.domain } : {}),
      ...(patch.contact !== undefined ? { contact: { ...current.contact, ...patch.contact } } : {}),
      ...(patch.ads !== undefined ? { ads: sanitizeAds(patch.ads) } : {}),
      ...(patch.analytics !== undefined ? { analytics: patch.analytics } : {}),
    };
    await writeToDisk(next);
    cache = next;
    return getSettings();
  });
  writeQueue = job.catch(() => undefined);
  return job;
}

export async function setAdminPasswordHash(hash: string | null): Promise<void> {
  const job = writeQueue.then(async () => {
    const current = await getStoredSettings();
    const next = { ...current, adminPasswordHash: hash };
    await writeToDisk(next);
    cache = next;
  });
  writeQueue = job.catch(() => undefined);
  return job;
}

export function invalidateSettingsCache(): void {
  cache = null;
}
