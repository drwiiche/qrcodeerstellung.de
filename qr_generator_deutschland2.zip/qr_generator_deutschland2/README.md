# QR-Code Generator Deutschland

Full-stack Next.js (App Router) application — a German QR-code generator with
an admin dashboard for runtime control of ads, analytics and site settings.

## Run locally

```bash
npm install
npm run dev        # http://localhost:3000
```

Other scripts:

| Script          | Purpose                          |
| --------------- | -------------------------------- |
| `npm run dev`   | Development server (port 3000)   |
| `npm run build` | Production build                 |
| `npm start`     | Serve the production build       |
| `npm test`      | Unit tests (node --test)         |
| `npm run lint`  | Type check (`tsc --noEmit`)      |

## Admin dashboard

Open **`/admin`** in the browser.

- **First visit:** choose the admin password (minimum 8 characters) — it is
  stored as a scrypt hash and protects every `/api/admin/*` route.
- Sections:
  - **Allgemein** — site name, domain, contact data (drives the Impressum).
  - **Werbung** — master on/off switch plus multiple ad providers
    (Google AdSense with publisher/slot IDs, or arbitrary HTML/JS snippets for
    AppLovin, Ezoic, …) each with selectable positions (below hero / mid
    content / above footer).
  - **Analyse** — GA4 measurement ID, GTM container ID, custom snippet
    (Plausible, Matomo, …). Scripts load only after the visitor consents in
    the cookie banner.
  - **Sicherheit** — change the admin password.

Settings persist to `.data/settings.json` (atomic writes, git-ignored).
No environment variables are required; the session secret is generated on
first run.

## Architecture

```
src/
  app/                  # App Router
    (site)/             # public pages, wrapped in SiteShell
      page.tsx          # home (generator) + WebApplication JSON-LD
      danke/ datenschutz/ agb/ impressum/
    admin/page.tsx      # dashboard (noindex)
    api/                # settings + admin auth/settings/password routes
    robots.ts sitemap.ts not-found.tsx loading.tsx
  components/
    SiteShell.tsx       # 'use client' provider: QR state, history, toasts, nav
    HomeView.tsx        # generator page content
    AdSlot.tsx          # consent-gated ad rendering
    AnalyticsScripts.tsx# consent-gated GA4/GTM/snippet injection
    admin/AdminDashboard.tsx
  lib/                  # settings store, auth (scrypt + HMAC cookie), site URL
```

## SEO (Google Search Central)

- Per-page `metadata` (title, description, canonical, Open Graph).
- `app/robots.ts` → `/robots.txt` (blocks `/api/`, `/admin/`, `/danke`).
- `app/sitemap.ts` → `/sitemap.xml` (indexable pages only).
- Real HTTP 404 via `app/not-found.tsx`.
- Server-rendered `WebApplication` JSON-LD on the home page.
- Self-hosted fonts (next/font), compressed images, mobile-first layout with
  sticky mobile CTA.

## Deployment

`npm run build && npm start` runs the app as a Node server (required for the
settings API). Put it behind your reverse proxy / PaaS of choice and serve
`https://qr-generator-deutschland.de`.
