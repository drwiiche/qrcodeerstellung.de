/**
 * Keystatic – open-source, file-based headless CMS (MIT) for Next.js.
 *
 * The schema below defines the blog content model. The site reads posts via
 * Keystatic's Reader API (src/lib/posts.ts) and the admin dashboard writes the
 * same file format through /api/admin/posts. Content lives as Markdown with
 * YAML frontmatter in content/posts/ — versionable, no database required.
 */
import { config, collection, fields } from '@keystatic/core';

export const POST_CATEGORIES = [
  { value: 'anleitungen', label: 'Anleitungen' },
  { value: 'gastronomie', label: 'Gastronomie' },
  { value: 'marketing', label: 'Marketing' },
  { value: 'technik', label: 'Technik & Tipps' },
  { value: 'recht', label: 'Recht & Privatsphäre' },
  { value: 'ideen', label: 'Anwendungsideen' },
] as const;

export default config({
  storage: { kind: 'local' },
  collections: {
    posts: collection({
      label: 'Blogbeiträge',
      // The file name is the slug (content/posts/<slug>.mdoc); fields live in
      // YAML frontmatter, body is plain Markdown. Written/read directly by the
      // admin API and the site (src/lib/posts.ts), hence the loose typing here.
      path: 'content/posts/*',
      format: { contentField: 'body' },
      schema: {
        title: fields.text({ label: 'Titel' }),
        excerpt: fields.text({
          label: 'Kurzbeschreibung (SEO & Vorschau)',
          multiline: true,
        }),
        publishedDate: fields.date({
          label: 'Veröffentlichungsdatum',
        }),
        category: fields.select({
          label: 'Kategorie',
          options: POST_CATEGORIES.map((c) => ({ label: c.label, value: c.value })),
          defaultValue: 'anleitungen',
        }),
        body: fields.markdoc({
          label: 'Inhalt (Markdown)',
        }),
      },
    } as never),
  },
});