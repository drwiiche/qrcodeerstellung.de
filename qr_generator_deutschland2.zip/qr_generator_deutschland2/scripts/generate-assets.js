import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import QRCode from 'qrcode';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Create crisp SVG favicon
const svgFavicon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#2563eb" />
      <stop offset="100%" stop-color="#1d4ed8" />
    </linearGradient>
  </defs>
  <rect width="64" height="64" rx="14" fill="url(#grad)" />
  <!-- QR Finder Patterns -->
  <rect x="10" y="10" width="18" height="18" rx="4" fill="#ffffff" />
  <rect x="14" y="14" width="10" height="10" rx="2" fill="#1d4ed8" />
  <rect x="17" y="17" width="4" height="4" rx="1" fill="#ffffff" />

  <rect x="36" y="10" width="18" height="18" rx="4" fill="#ffffff" />
  <rect x="40" y="14" width="10" height="10" rx="2" fill="#1d4ed8" />
  <rect x="43" y="17" width="4" height="4" rx="1" fill="#ffffff" />

  <rect x="10" y="36" width="18" height="18" rx="4" fill="#ffffff" />
  <rect x="14" y="40" width="10" height="10" rx="2" fill="#1d4ed8" />
  <rect x="17" y="43" width="4" height="4" rx="1" fill="#ffffff" />

  <!-- Data modules -->
  <rect x="36" y="36" width="6" height="6" rx="1.5" fill="#ffffff" />
  <rect x="48" y="36" width="6" height="6" rx="1.5" fill="#ffffff" />
  <rect x="42" y="42" width="6" height="6" rx="1.5" fill="#ffffff" />
  <rect x="36" y="48" width="6" height="6" rx="1.5" fill="#ffffff" />
  <rect x="48" y="48" width="6" height="6" rx="1.5" fill="#ffffff" />
</svg>`;

fs.writeFileSync(path.join(publicDir, 'favicon.svg'), svgFavicon, 'utf8');
console.log('✓ Created favicon.svg');

// 2. Helper to write uncompressed/deflated raw RGBA PNG
function createRgbaPng(width, height, pixelFn) {
  // pixelFn(x, y) => [r, g, b, a]
  const rowBytes = width * 4;
  const rawData = Buffer.alloc((rowBytes + 1) * height);
  
  for (let y = 0; y < height; y++) {
    const rowOffset = y * (rowBytes + 1);
    rawData[rowOffset] = 0; // Filter byte: None
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = pixelFn(x, y);
      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const deflated = zlib.deflateSync(rawData, { level: 9 });

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 6; // color type: RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace

  const ihdrChunk = createPngChunk('IHDR', ihdrData);
  const idatChunk = createPngChunk('IDAT', deflated);
  const iendChunk = createPngChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createPngChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const len = data.length;
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(len, 0);

  const crcTarget = Buffer.concat([typeBuf, data]);
  const crc = crc32(crcTarget);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc, 0);

  return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

// Table-based CRC32
const crcTable = [];
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Helper to wrap PNGs in ICO format
function createIcoFromPngs(pngBuffers) {
  // Header: 2 bytes reserved (0), 2 bytes type (1 = ICO), 2 bytes count
  const count = pngBuffers.length;
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0);
  header.writeUInt16LE(1, 2);
  header.writeUInt16LE(count, 4);

  let offset = 6 + count * 16;
  const dirEntries = [];

  for (const { width, height, buf } of pngBuffers) {
    const entry = Buffer.alloc(16);
    entry[0] = width >= 256 ? 0 : width;
    entry[1] = height >= 256 ? 0 : height;
    entry[2] = 0; // palette colors
    entry[3] = 0; // reserved
    entry.writeUInt16LE(1, 4); // color planes
    entry.writeUInt16LE(32, 6); // bits per pixel
    entry.writeUInt32LE(buf.length, 8); // size of image data
    entry.writeUInt32LE(offset, 12); // offset of image data
    dirEntries.push(entry);
    offset += buf.length;
  }

  return Buffer.concat([header, ...dirEntries, ...pngBuffers.map(p => p.buf)]);
}

// Generate Icons
async function generateAll() {
  // Generate high quality QR-based icons
  const sizes = [16, 32, 180, 192, 512];
  const pngMap = {};

  for (const size of sizes) {
    const buf = await QRCode.toBuffer('https://qr-generator-deutschland.de', {
      width: size,
      margin: size > 32 ? 2 : 1,
      color: {
        dark: '#1e40af', // deep blue
        light: '#ffffff'
      },
      errorCorrectionLevel: 'M'
    });
    pngMap[size] = buf;
  }

  fs.writeFileSync(path.join(publicDir, 'favicon-16x16.png'), pngMap[16]);
  fs.writeFileSync(path.join(publicDir, 'favicon-32x32.png'), pngMap[32]);
  fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), pngMap[180]);
  fs.writeFileSync(path.join(publicDir, 'android-chrome-192x192.png'), pngMap[192]);
  fs.writeFileSync(path.join(publicDir, 'android-chrome-512x512.png'), pngMap[512]);
  console.log('✓ Created PNG favicon set (16, 32, 180, 192, 512)');

  // Create ICO containing 16x16 and 32x32
  const icoBuf = createIcoFromPngs([
    { width: 16, height: 16, buf: pngMap[16] },
    { width: 32, height: 32, buf: pngMap[32] }
  ]);
  fs.writeFileSync(path.join(publicDir, 'favicon.ico'), icoBuf);
  console.log('✓ Created favicon.ico');

  // Generate 1200x630 OpenGraph image with dark blue gradient & QR sample
  const ogQrBuf = await QRCode.toBuffer('https://qr-generator-deutschland.de', {
    width: 360,
    margin: 2,
    color: {
      dark: '#1e3a8a',
      light: '#ffffff'
    }
  });

  // Decode QR png raw data to stamp it onto 1200x630
  // Or render a clean banner using createRgbaPng
  const ogWidth = 1200;
  const ogHeight = 630;

  const ogPng = createRgbaPng(ogWidth, ogHeight, (x, y) => {
    // Elegant dark slate to navy gradient
    const tX = x / ogWidth;
    const tY = y / ogHeight;
    const r = Math.floor(15 + 15 * tY);
    const g = Math.floor(23 + 25 * tX);
    const b = Math.floor(42 + 60 * tX + 40 * tY);

    // Decorative subtle top border line in bright blue
    if (y < 6) {
      return [37, 99, 235, 255]; // blue-600
    }

    // White QR card container on the right (x from 750 to 1100, y from 135 to 495)
    const cardX1 = 760;
    const cardX2 = 1110;
    const cardY1 = 140;
    const cardY2 = 490;
    const cornerRad = 24;

    if (x >= cardX1 && x <= cardX2 && y >= cardY1 && y <= cardY2) {
      // Rounded rect check
      const dx = Math.max(cardX1 + cornerRad - x, 0, x - (cardX2 - cornerRad));
      const dy = Math.max(cardY1 + cornerRad - y, 0, y - (cardY2 - cornerRad));
      if (dx * dx + dy * dy <= cornerRad * cornerRad) {
        // Inside white card
        // Draw inner QR pattern preview
        const innerX = x - (cardX1 + 25);
        const innerY = y - (cardY1 + 25);
        const innerSize = 300;
        if (innerX >= 0 && innerX < innerSize && innerY >= 0 && innerY < innerSize) {
          const modX = Math.floor(innerX / 12);
          const modY = Math.floor(innerY / 12);
          // Standard finder patterns
          const isFinderTopLeft = modX < 7 && modY < 7;
          const isFinderTopRight = modX >= 18 && modY < 7;
          const isFinderBottomLeft = modX < 7 && modY >= 18;

          if (isFinderTopLeft || isFinderTopRight || isFinderBottomLeft) {
            const fx = isFinderTopRight ? modX - 18 : modX;
            const fy = isFinderBottomLeft ? modY - 18 : modY;
            if (fx === 0 || fx === 6 || fy === 0 || fy === 6 || (fx >= 2 && fx <= 4 && fy >= 2 && fy <= 4)) {
              return [30, 58, 138, 255];
            }
            return [255, 255, 255, 255];
          }

          // Pseudo random data modules deterministically
          if ((modX * 13 + modY * 19 + (modX ^ modY)) % 3 === 0) {
            return [37, 99, 235, 255];
          }
          return [255, 255, 255, 255];
        }
        return [255, 255, 255, 255];
      }
    }

    // Subtle ambient glow behind card
    const glowDx = x - 935;
    const glowDy = y - 315;
    const distSq = glowDx * glowDx + glowDy * glowDy;
    if (distSq < 280 * 280) {
      const glow = Math.floor((1 - distSq / (280 * 280)) * 40);
      return [Math.min(255, r + glow / 2), Math.min(255, g + glow), Math.min(255, b + glow * 2), 255];
    }

    return [r, g, b, 255];
  });

  fs.writeFileSync(path.join(publicDir, 'og-image.png'), ogPng);
  console.log('✓ Created compressed og-image.png (1200x630)');
}

generateAll().catch(console.error);
