import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));

/** @type {import('next').NextConfig} */
const nextConfig = {
  // Pin the workspace root: a lockfile in the user home directory otherwise
  // gets picked up and mis-traces output files.
  outputFileTracingRoot: dir,
  reactStrictMode: true,
  poweredByHeader: false,
  eslint: {
    ignoreDuringBuilds: true,
  },
  webpack(config) {
    // Explicit "@/..." alias — Next's tsconfig paths detection is unreliable
    // with the installed TypeScript 7 native compiler.
    config.resolve.alias['@'] = dir;
    return config;
  },
};

export default nextConfig;
