# UI — the interface layer, extracted

This folder is the user interface of the QR-Generator Deutschland app, lifted out
so it can be dropped into another tool. Every file marked as *identical* below is
byte-for-byte the file the live site serves; nothing was rewritten, restyled or
"cleaned up" on the way over.

```
UI/
├─ src/
│  ├─ index.css              design tokens + base layer (Tailwind v4, CSS-first)
│  ├─ app/                   the App Router shell: fonts, chrome, the homepage
│  ├─ components/            every screen and control (34 files, 9 139 lines)
│  ├─ lib/                   helpers the components read from
│  ├─ data/                  the content the UI renders
│  ├─ types/  utils/         the tool's payload model and renderers
├─ content/posts/            blog posts (only needed if you keep the blog admin)
├─ keystatic.config.ts       blog schema, read by src/lib/posts.ts
├─ scripts/check-completeness.mjs
├─ package.json  tsconfig.json  next.config.mjs  postcss.config.mjs
└─ README.md
```

It builds and runs on its own. It is not a component library you pull in as a
dependency — it is a Next.js app whose pages happen to contain only the UI, so
you extend it in place.

## Run it

```bash
cd UI
npm install          # or: npm ci
npm run dev          # http://localhost:3200
# or
npm run build && npm start
```

Then: `npm run check` (imports all resolve and every package is declared) and
`npm run typecheck`.

## Design system

Everything visual comes from `src/index.css`. There is no `tailwind.config.js` —
this is Tailwind v4, configured in CSS through `@theme`.

| Token | Value | Used for |
| --- | --- | --- |
| `--color-ink` | `#15140f` | body text, dark surfaces, nav |
| `--color-ink-2` | `#24211a` | raised dark surfaces |
| `--color-paper` | `#faf8f3` | page background |
| `--color-paper-2` | `#f1ece2` | inset panels |
| `--color-rule` | `#e0dacf` | hairlines, borders |
| `--color-accent` | `#b23a26` | fills, marks |
| `--color-accent-text` | `#9a2f1d` | accent as text (5.61:1 on paper) |
| `--color-acid` | `#eea98f` | the one warm highlight on ink |
| `--color-muted` | `#635e53` | secondary text |
| `--radius-sheet` | `2px` | cards, panels |
| `--radius-control` | `3px` | inputs, buttons |

Type is Archivo (UI), Archivo Black (display), JetBrains Mono (specs, codes),
all loaded through `next/font/google` in `src/app/layout.tsx` — no webfont CDN,
no `@font-face` to maintain.

Two rules the CSS encodes and the components respect: structure is square (pills
are banned), and saturated colour is reserved for information — a QR type, a
state — never for decoration.

## What is in here

### Screens and layout

| File | Lines | What it is |
| --- | --- | --- |
| `components/SiteShell.tsx` | 789 | The whole page frame: nav, footer, cookie banner, and the generator's state machine. This is the file to read first. |
| `components/HomeView.tsx` | 234 | The homepage: hero, the tool, the sections below it. |
| `components/Navbar.tsx` | 323 | Top bar with the type menu and the language switcher. |
| `components/HeroQrVisual.tsx` | 347 | The large decorative QR in the hero, drawn client-side. |
| `components/SeoLandingPage.tsx` | 561 | The long-form landing template used by every German topic page. |
| `components/ProgrammaticSeoSection.tsx` | 229 | The generated link grid that sits at the bottom of those pages. |
| `components/NotFoundPage.tsx` | 77 | 404. |
| `components/ImpressumPage.tsx` | 240 · `PrivacyPolicyPage.tsx` 113 · `TermsPage.tsx` 85 · `ThankYouPage.tsx` 171 | Legal and confirmation screens. German copy, real structure. |

### The tool

| File | Lines | What it is |
| --- | --- | --- |
| `components/QRForm.tsx` | 1022 | The input side: one field schema per QR type, validation, hints. |
| `components/QRPreviewCard.tsx` | 418 | The output side: live preview, download, size and format choice. |
| `components/QRCustomizer.tsx` | 829 | Colour, module style, quiet zone, logo. |
| `components/QRTypeSelector.tsx` | 89 | The type tabs. |
| `components/AdvancedTypeForm.tsx` | 79 | The extra fields a few types need. |
| `components/IroColorPicker.tsx` | 98 | Wrapper around `@jaames/iro`. |
| `components/PrintableCard.tsx` | 184 | The A4 print sheet / cut-out card. |
| `components/ScanTestModal.tsx` | 154 | "Check it scans" capture-and-verify dialog. |
| `components/HistoryDrawer.tsx` | 159 | Recent codes, kept in `localStorage`. |
| `components/TemplateGallery.tsx` | 145 | Starting templates. |
| `components/Toast.tsx` | 58 | Transient messages. |

### Everything else

| File | What it is |
| --- | --- |
| `components/AdSlot.tsx` | Consent-gated ad unit, three positions. |
| `components/CookieBanner.tsx` | Consent banner and the storage it writes. |
| `components/AnalyticsScripts.tsx` | GA4 / GTM / custom snippet, loaded only after consent. |
| `components/ErrorBoundary.tsx` | Error screen that keeps the chrome. |
| `components/Byline.tsx`, `JsonLd.tsx` | Editorial byline, structured-data wrapper. |
| `components/i18n/UiProvider.tsx` | `useUi()` — every string in the tool comes from here. |
| `components/i18n/LanguageSwitcher.tsx` | The 12-locale menu. |
| `components/i18n/LocaleLanding.tsx`, `GuidePage.tsx` | Localized landing and long-form guide templates. |
| `components/admin/AdminDashboard.tsx` (944) · `BlogAdmin.tsx` (362) | The password-protected dashboard: site settings, ads, analytics, blog, contact messages, password. |
| `lib/i18n/ui/*.ts` | Twelve dictionaries, flat dotted keys, `de.ts` is canonical. |
| `lib/settings.ts`, `auth.ts`, `messages.ts`, `posts.ts` | Server-side stores behind the dashboard. |
| `lib/admin-client.ts` | `adminFetch()` — cookie or bearer, see Gotchas. |
| `lib/qrTypeSchema.ts`, `lib/api-qr.ts` | Field schema and the public API's parameter handling. |
| `lib/typeColor.ts` | The per-type colour map. |
| `data/qr-typen-*.ts` | The content of each type page. |
| `types/qr.ts`, `utils/*.ts` | The payload model, validators, and renderers (Wi-Fi, SEPA, vCard, event, delivery, text). |

## Turning it into the label generator

The UI is deliberately split so the tool-specific part is a small number of
files. Nothing in `components/` needs restyling; you swap the payload model and
the type list underneath it.

1. **`src/types/qr.ts`** — the shape of a generator's state. Add your label
   types here (dimensions, barcode format, canvas presets).
2. **`src/data/qr-typen-*.ts`** — the type list the selector and the landing
   pages read. Replace the 20 QR types with your label types.
3. **`src/utils/payloads.ts`** — turns form state into the encoded payload. This
   is where a QR string is currently built; a label generator builds a document
   spec instead.
4. **`src/utils/qrRenderer.ts`** — the client-side renderer behind the preview and
   the download. Swap the renderer, keep the download plumbing (SVG/PNG/A4).
5. **`src/app/api/qr/route.ts`** — the server endpoint. Mirror it as
   `/api/label`, keep `lib/api-qr.ts`'s parameter handling.
6. **`src/components/QRForm.tsx`** — the field schemas at the top of the file map
   one-to-one to the entries in `qrTypeSchema.ts`; changing the schema is mostly
   mechanical.

Everything else — nav, hero, preview card, customizer, print sheet, history,
consent, admin, i18n — is payload-agnostic and works as-is.

### Renaming

There is no hard-coded brand inside the components: the site name, domain and
contact details come from `lib/settings.ts` defaults and the admin dashboard, and
`lib/site.ts` holds the one canonical origin (`SITE_URL`) used for metadata. Copy
`src/app/(site)/page.tsx`'s metadata block for your own homepage title and
description.

## What was deliberately left out

This folder contains the interface, not the site's SEO surface. Excluded:

- `src/lib/i18n/guides/**` — 1.6 MB of guide prose in 12 languages, one long-form
  page per type per locale. Only `guides/slugs.ts` is here, because the language
  switcher and the locale landing template read the slug map.
- `src/app/[locale]/**`, `src/app/(site)/blog/**`, `/standards`, `/qr-codes-fuer`,
  `/qr-codes-auf`, `/anleitungen`, `/vorlagen`, `/impressum`, `/datenschutz`,
  `/agb` and the rest of the German route tree — page files that compose these
  components. `src/app/(site)/page.tsx` is kept as the one worked example.
- `robots.ts`, `sitemap.ts`, the OG image route, the tests.

If you later want the guide pages, copy `src/lib/i18n/guides/` and
`src/app/[locale]/` from the original project — they sit on top of these
components unchanged.

## Gotchas worth knowing before you start

- **Tailwind v4, CSS-first.** Add tokens to the `@theme` block in `src/index.css`,
  not to a JS config file; there isn't one.
- **`@/` means the project root**, wired twice: `tsconfig.json` `paths` and
  `webpack.resolve.alias` in `next.config.mjs`. Both are needed.
- **The tool's copy is not in the components.** Strings come from
  `lib/i18n/ui/*.ts` through `useUi()`. `de.ts` is canonical and a test in the
  original project enforces that all twelve files have identical key sets — if
  you add a key, add it to all twelve.
- **Admin auth has no password until you set one.** The first login with any
  password of 8+ characters becomes the admin password (`api/admin/login`). On a
  new deployment, set it deliberately or require one from an environment
  variable.
- **`.data/` is runtime state** (`settings.json`, `messages.json`). It is
  gitignored and must live on persistent storage, or settings and the admin
  password reset on every deploy.
- **The dashboard works without cookies.** `lib/admin-client.ts` sends the
  session token as a bearer header as well, because sandboxed preview iframes
  drop the session cookie. The HttpOnly cookie is still the primary path.

## Provenance

Of the 133 files here (excluding `node_modules`, `.next` and the regenerated
lockfile), **128 are sha256-identical** to the originating app — every component,
every stylesheet, every helper, every data file, byte for byte.

The four that differ had to: `package.json` (trimmed to the dependencies this
subset actually uses), `next.config.mjs` (the site's 18 SEO redirects removed,
port changed to 3200), `.gitignore`, and this README, which has no counterpart.
`scripts/check-completeness.mjs` is new.
