import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));

/** @type {import('next').NextConfig} */
const nextConfig = {
  outputFileTracingRoot: dir,
  allowedDevOrigins: ['*.e2b.app', '*.arena.ai', 'localhost:3200'],
  reactStrictMode: true,
  poweredByHeader: false,
  eslint: { ignoreDuringBuilds: true },
  webpack(config) {
    // Explicit "@/..." alias — the same one the original app uses.
    config.resolve.alias['@'] = dir;
    return config;
  },
};

export default nextConfig;
