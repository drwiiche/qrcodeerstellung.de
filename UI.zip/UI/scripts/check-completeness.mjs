#!/usr/bin/env node
/**
 * Completeness check for the extracted UI.
 *
 * Walks every .ts/.tsx file under src/, extracts each import specifier, and
 * answers two questions:
 *
 *   1. Does every local import ("./x", "../x", "@/x") resolve to a file that
 *      is actually present in this folder?
 *   2. Does every bare import (a package) appear in package.json?
 *
 * A file that is missing here is a file you would discover was missing in the
 * middle of a build in your new project. Run with `npm run check`.
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { builtinModules } from 'node:module';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
const declared = new Set([
  ...Object.keys(pkg.dependencies ?? {}),
  ...Object.keys(pkg.devDependencies ?? {}),
]);

const BUILTINS = new Set(builtinModules);

const EXTS = ['', '.ts', '.tsx', '.js', '.jsx', '.mjs', '.json', '/index.ts', '/index.tsx'];

function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (entry === 'node_modules' || entry === '.next') continue;
    if (statSync(full).isDirectory()) walk(full, out);
    else if (/\.(ts|tsx|mjs|js)$/.test(entry)) out.push(full);
  }
  return out;
}

function resolvesLocal(spec, fromFile) {
  const base = spec.startsWith('@/') ? join(root, spec.slice(2)) : resolve(dirname(fromFile), spec);
  return EXTS.some((ext) => existsSync(base + ext));
}

const files = walk(join(root, 'src'));
const IMPORT_RE = /(?:^|[^\w$.])(?:import|export)\s+(?:[\s\S]*?\sfrom\s+)?['"]([^'"]+)['"]/g;
const REQUIRE_RE = /\brequire\(\s*['"]([^'"]+)['"]\s*\)/g;

const missingLocal = [];
const missingPackage = new Map();
const usedPackages = new Set();

for (const file of files) {
  const source = readFileSync(file, 'utf8');
  for (const re of [IMPORT_RE, REQUIRE_RE]) {
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(source))) {
      const spec = m[1];
      if (spec.startsWith('.') || spec.startsWith('@/')) {
        if (!resolvesLocal(spec, file)) {
          missingLocal.push({ file: file.slice(root.length + 1), spec });
        }
      } else if (spec.startsWith('node:') || BUILTINS.has(spec)) {
        /* Node builtin — nothing to install. */
      } else {
        const name = spec.startsWith('@') ? spec.split('/').slice(0, 2).join('/') : spec.split('/')[0];
        usedPackages.add(name);
        if (!declared.has(name)) {
          if (!missingPackage.has(name)) missingPackage.set(name, []);
          missingPackage.get(name).push(file.slice(root.length + 1));
        }
      }
    }
  }
}

const unused = [...declared].filter((d) => !usedPackages.has(d));

console.log(`scanned ${files.length} files in src/`);
console.log(`packages used: ${usedPackages.size}`);

if (missingLocal.length) {
  console.log(`\nMISSING LOCAL FILES (${missingLocal.length}):`);
  for (const { file, spec } of missingLocal) console.log(`  ${file}  ->  ${spec}`);
} else {
  console.log('local imports: all resolve');
}

if (missingPackage.size) {
  console.log(`\nUNDECLARED PACKAGES (${missingPackage.size}):`);
  for (const [name, where] of missingPackage) console.log(`  ${name}  (${where.length} file(s), e.g. ${where[0]})`);
} else {
  console.log('package imports: all declared in package.json');
}

if (unused.length) console.log(`\ndeclared but unused (harmless): ${unused.join(', ')}`);

process.exit(missingLocal.length || missingPackage.size ? 1 : 0);
