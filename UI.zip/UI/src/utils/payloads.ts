/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Payload builders for the second wave of QR types: social profiles, MECARD
 * contact cards, and the three payment formats.
 *
 * These live here rather than inline in the shell so the public API and the
 * browser form share one implementation, and so each format can be tested
 * against its specification instead of against a screenshot.
 */

// ---------------------------------------------------------------------------
// Social profiles
// ---------------------------------------------------------------------------

export type SocialNetwork = 'facebook' | 'twitter' | 'youtube' | 'instagram';

const SOCIAL_HOSTS: Record<SocialNetwork, string[]> = {
  facebook: ['facebook.com', 'www.facebook.com', 'm.facebook.com', 'fb.com'],
  twitter: ['x.com', 'www.x.com', 'twitter.com', 'www.twitter.com'],
  youtube: ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be'],
  instagram: ['instagram.com', 'www.instagram.com'],
};

const SOCIAL_BASE: Record<SocialNetwork, string> = {
  facebook: 'https://www.facebook.com/',
  twitter: 'https://x.com/',
  youtube: 'https://www.youtube.com/@',
  instagram: 'https://www.instagram.com/',
};

/** Strip a leading @ and any stray whitespace or full URL framing. */
function cleanHandle(raw: string): string {
  let h = raw.trim();
  /* Keep the host exactly as the user pasted it, www included: rewriting it
     would change a URL that already works. */
  h = h.replace(/^https?:\/\//i, '');
  h = h.replace(/^@+/, '');
  return h.trim();
}

/**
 * Build a profile URL.
 *
 * Accepts either a handle ("mustermann", "@mustermann") or a full profile URL.
 * A full URL is only accepted when its host actually belongs to that network,
 * so pasting an Instagram link into the Facebook field does not silently
 * produce a code that points at the wrong place.
 */
export function formatSocialPayload(network: SocialNetwork, rawInput: string): string {
  const value = cleanHandle(rawInput);
  if (!value) return 'https://' + SOCIAL_HOSTS[network][0];

  const hostPart = value.split('/')[0].toLowerCase();
  const isUrl = SOCIAL_HOSTS[network].some((h) => hostPart === h);

  if (isUrl) {
    return `https://${value}`;
  }

  /* Anything that still contains a slash without a matching host is treated as
     a path on the network's own base, which is what the user meant. */
  return SOCIAL_BASE[network] + value.replace(/^\/+/, '');
}

// ---------------------------------------------------------------------------
// MECARD
// ---------------------------------------------------------------------------

const MECARD_ESCAPE = /([\\;:,])/g;

function mecardValue(v: string): string {
  return v.replace(MECARD_ESCAPE, '\\$1').replace(/\r?\n/g, ' ');
}

export interface MecardData {
  lastName: string;
  firstName: string;
  organization: string;
  phone: string;
  email: string;
  url: string;
  address: string;
  note: string;
}

/**
 * MECARD is the older, denser contact format that some scanners still prefer
 * over vCard. The syntax is a flat semicolon list terminated by a double
 * semicolon, and any literal semicolon inside a value has to be escaped.
 */
export function formatMecardPayload(d: MecardData): string {
  const parts: string[] = [];

  const last = mecardValue(d.lastName ?? '');
  const first = mecardValue(d.firstName ?? '');
  const name = last && first ? `${last},${first}` : last || first;
  if (name) parts.push(`N:${name}`);

  if (d.organization) parts.push(`ORG:${mecardValue(d.organization)}`);
  if (d.phone) parts.push(`TEL:${mecardValue(d.phone)}`);
  if (d.email) parts.push(`EMAIL:${mecardValue(d.email)}`);
  if (d.address) parts.push(`ADR:${mecardValue(d.address)}`);
  if (d.url) parts.push(`URL:${mecardValue(d.url)}`);
  if (d.note) parts.push(`NOTE:${mecardValue(d.note)}`);

  return `MECARD:${parts.join(';')};;`;
}

// ---------------------------------------------------------------------------
// Bitcoin (BIP21)
// ---------------------------------------------------------------------------

/**
 * BIP21 URI. The amount is in BTC and is passed through as written, because
 * rewriting it would change what the payer sends.
 */
export function formatBitcoinPayload(address: string, amount: string, label: string): string {
  const addr = address.trim();
  if (!addr) return 'bitcoin:';

  const params: string[] = [];
  const cleanAmount = amount.trim().replace(',', '.');
  if (cleanAmount && Number.isFinite(Number(cleanAmount))) {
    params.push(`amount=${cleanAmount}`);
  }
  if (label.trim()) params.push(`label=${encodeURIComponent(label.trim())}`);

  return `bitcoin:${addr}${params.length ? '?' + params.join('&') : ''}`;
}

// ---------------------------------------------------------------------------
// PayPal
// ---------------------------------------------------------------------------

/**
 * paypal.me link. The handle is the part after paypal.me/ in the user's own
 * profile URL, so a pasted URL is reduced to that handle.
 */
export function formatPaypalPayload(handle: string, amount: string): string {
  let h = handle.trim().replace(/^https?:\/\//i, '').replace(/^www\./i, '');
  h = h.replace(/^paypal\.me\//i, '').replace(/^paypal\.com\/(paypalme\/)?/i, '');
  h = h.replace(/^@+/, '').replace(/^\/+/, '').replace(/\/+$/, '');
  if (!h) return 'https://www.paypal.me/';

  const cleanAmount = amount.trim().replace(',', '.');
  const hasAmount = cleanAmount && Number.isFinite(Number(cleanAmount)) && Number(cleanAmount) > 0;
  return `https://www.paypal.me/${h}${hasAmount ? '/' + cleanAmount : ''}`;
}

// ---------------------------------------------------------------------------
// Pix (BR Code / EMV Merchant Presented Mode)
// ---------------------------------------------------------------------------

/**
 * CRC-16/CCITT-FALSE: polynomial 0x1021, initial value 0xFFFF, no reflection,
 * no final xor. The check value for the ASCII string "123456789" is 0x29B1,
 * which is what the test asserts.
 */
export function pixCrc16(input: string): string {
  let crc = 0xffff;
  for (let i = 0; i < input.length; i++) {
    crc ^= input.charCodeAt(i) << 8;
    for (let bit = 0; bit < 8; bit++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/** One EMV field: 2-digit id, 2-digit length, then the value. */
function tlv(id: string, value: string): string {
  const len = String(value.length).padStart(2, '0');
  if (value.length > 99) {
    throw new Error(`Pix field ${id} is too long (${value.length} characters, maximum 99).`);
  }
  return `${id}${len}${value}`;
}

/**
 * Pix BR Code per the Banco Central do Brasil EMV specification.
 *
 * Names and city are upper-cased and stripped of diacritics on purpose: the
 * specification allows UTF-8, but several banking apps still reject accented
 * characters, and a payload that half the apps refuse is worse than one that
 * all of them read.
 */
export function formatPixPayload(input: {
  key: string;
  name: string;
  city: string;
  amount?: string;
  txid?: string;
}): string {
  const ascii = (s: string) =>
    s
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^\x20-\x7E]/g, '')
      .trim()
      .toUpperCase();

  const key = input.key.trim();
  if (!key) return '';

  const merchantAccount =
    tlv('00', 'br.gov.bcb.pix') + tlv('01', key.slice(0, 77));

  let payload = '';
  payload += tlv('00', '01'); // payload format indicator
  payload += tlv('26', merchantAccount);
  payload += tlv('52', '0000'); // merchant category code: not specified
  payload += tlv('53', '986'); // currency: BRL

  const amount = (input.amount ?? '').trim().replace(',', '.');
  if (amount && Number.isFinite(Number(amount)) && Number(amount) > 0) {
    payload += tlv('54', Number(amount).toFixed(2));
  }

  payload += tlv('58', 'BR');
  payload += tlv('59', ascii(input.name || 'RECEBEDOR').slice(0, 25) || 'RECEBEDOR');
  payload += tlv('60', ascii(input.city || 'BRASIL').slice(0, 15) || 'BRASIL');

  /* Field 62 carries the transaction id. "***" means the payer's app generates
     one, which is what a static printed code should use. */
  const txid = (input.txid || '***').replace(/[^A-Za-z0-9*]/g, '').toUpperCase().slice(0, 25) || '***';
  payload += tlv('62', tlv('05', txid));

  payload += '6304';
  return payload + pixCrc16(payload);
}

// ---------------------------------------------------------------------------
// Dispatch
// ---------------------------------------------------------------------------

export type AdvancedType =
  | 'mecard'
  | 'facebook'
  | 'twitter'
  | 'youtube'
  | 'instagram'
  | 'bitcoin'
  | 'paypal'
  | 'pix';

/** Build the payload for any schema-driven type from a flat value map. */
export function formatAdvancedPayload(
  type: AdvancedType,
  v: Record<string, string>
): string {
  switch (type) {
    case 'mecard':
      return formatMecardPayload({
        lastName: v.lastName ?? '',
        firstName: v.firstName ?? '',
        organization: v.organization ?? '',
        phone: v.phone ?? '',
        email: v.email ?? '',
        url: v.url ?? '',
        address: v.address ?? '',
        note: v.note ?? '',
      });
    case 'facebook':
    case 'twitter':
    case 'youtube':
    case 'instagram':
      return formatSocialPayload(type, v.handle ?? '');
    case 'bitcoin':
      return formatBitcoinPayload(v.address ?? '', v.amount ?? '', v.label ?? '');
    case 'paypal':
      return formatPaypalPayload(v.handle ?? '', v.amount ?? '');
    case 'pix':
      return formatPixPayload({
        key: v.key ?? '',
        name: v.name ?? '',
        city: v.city ?? '',
        amount: v.amount ?? '',
        txid: v.txid ?? '',
      });
    default:
      return '';
  }
}
