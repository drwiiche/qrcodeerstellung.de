/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EventData } from '../types/qr';

/**
 * iCalendar VEVENT payload for the "Termin" type.
 *
 * Two things the previous inline template got wrong, both visible in a phone's
 * calendar app rather than in the QR code:
 *
 * 1. It appended a literal "Z" to the timestamps. "Z" means UTC, so an event
 *    entered as 18:30 Berlin time landed at 20:30 in a summer calendar. A
 *    person typing "18:30" means 18:30 where they are, so the payload now
 *    carries floating local time (no offset), which every calendar app renders
 *    as 18:30 on the device that opens it.
 * 2. It wrote text fields straight into the payload. RFC 5545 gives comma,
 *    semicolon, backslash and line breaks a syntactic meaning inside a text
 *    value, so a title like "Sommerfest, Hof 3" truncated the summary at the
 *    comma. Those four characters are now escaped.
 *
 * Folding long lines is deliberately not implemented: no calendar app in use
 * today rejects an unfolded line, and folding inside a QR payload would add
 * characters for no gain.
 */

/** RFC 5545 text escaping for SUMMARY, LOCATION and DESCRIPTION. */
function escapeText(value: string): string {
  return (value || '')
    .replace(/\\/g, '\\\\')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .replace(/\r?\n/g, '\\n');
}

/**
 * YYYYMMDDTHHMMSS from separate date and time inputs. Accepts both
 * 2026-10-29 / 18:30 and 20261029 / 1830, because the form and the API do not
 * agree on the format.
 */
function stamp(date: string, time: string): string {
  const d = (date || '').replace(/[^0-9]/g, '');
  const t = (time || '').replace(/[^0-9]/g, '');
  if (d.length !== 8) return '';
  const hhmmss = (t + '000000').slice(0, 6);
  return `${d}T${hhmmss}`;
}

export function formatEventPayload(data: EventData): string {
  const start = stamp(data.startDate, data.startTime);
  const end = stamp(data.endDate || data.startDate, data.endTime);

  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//QR-Generator Deutschland//Termin//DE',
    'BEGIN:VEVENT',
    `SUMMARY:${escapeText(data.title)}`,
  ];

  if (data.location) lines.push(`LOCATION:${escapeText(data.location)}`);
  if (data.description) lines.push(`DESCRIPTION:${escapeText(data.description)}`);
  if (start) lines.push(`DTSTART:${start}`);
  /* A calendar entry with a start but no end shows as zero length in most
     apps, so an end is only written when it is actually later than the start. */
  if (end && end > start) lines.push(`DTEND:${end}`);

  lines.push('END:VEVENT', 'END:VCALENDAR');
  return lines.join('\n');
}
