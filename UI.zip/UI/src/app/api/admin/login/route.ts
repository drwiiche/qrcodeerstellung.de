import { NextResponse } from 'next/server';
import { getStoredSettings, setAdminPasswordHash } from '@/src/lib/settings';
import { verifyPassword, createSessionToken, setSessionCookie, hashPassword } from '@/src/lib/auth';

/**
 * POST /api/admin/login
 * Body: { password }
 * - First run (no password set yet): the submitted password BECOMES the admin password.
 * - Otherwise verifies against the stored scrypt hash and sets the session cookie.
 */
export async function POST(req: Request) {
  let password: unknown;
  try {
    ({ password } = await req.json());
  } catch {
    return NextResponse.json({ error: 'Ungültige Anfrage.' }, { status: 400 });
  }
  if (typeof password !== 'string' || password.length < 8) {
    return NextResponse.json(
      { error: 'Das Passwort muss mindestens 8 Zeichen lang sein.' },
      { status: 400 }
    );
  }

  const stored = await getStoredSettings();

  if (!stored.adminPasswordHash) {
    // First run — bootstrap the admin password.
    await setAdminPasswordHash(hashPassword(password));
  } else if (!verifyPassword(password, stored.adminPasswordHash)) {
    return NextResponse.json({ error: 'Falsches Passwort.' }, { status: 401 });
  }

  const token = await createSessionToken();
  await setSessionCookie(token);
  /* The token is also returned so the client can fall back to a bearer header
     when the cookie cannot be stored (sandboxed preview iframes). */
  return NextResponse.json({ ok: true, firstRun: !stored.adminPasswordHash, token });
}
