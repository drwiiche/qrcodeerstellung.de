import { NextResponse } from 'next/server';
import { isAdminRequest, verifyPassword, hashPassword } from '@/src/lib/auth';
import { getStoredSettings, setAdminPasswordHash } from '@/src/lib/settings';

/**
 * PUT /api/admin/password
 * Body: { currentPassword, newPassword }
 */
export async function PUT(req: Request) {
  if (!(await isAdminRequest(req))) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  let body: { currentPassword?: unknown; newPassword?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ungültige Anfrage.' }, { status: 400 });
  }
  const { currentPassword, newPassword } = body;
  if (typeof newPassword !== 'string' || newPassword.length < 8) {
    return NextResponse.json(
      { error: 'Das neue Passwort muss mindestens 8 Zeichen lang sein.' },
      { status: 400 }
    );
  }
  const stored = await getStoredSettings();
  if (!verifyPassword(String(currentPassword ?? ''), stored.adminPasswordHash)) {
    return NextResponse.json({ error: 'Aktuelles Passwort ist falsch.' }, { status: 401 });
  }
  await setAdminPasswordHash(hashPassword(newPassword));
  return NextResponse.json({ ok: true });
}
