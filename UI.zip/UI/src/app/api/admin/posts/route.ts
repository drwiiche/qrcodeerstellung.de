import { NextResponse } from 'next/server';
import { isAdminRequest } from '@/src/lib/auth';
import { getAllPosts, getPost, createPost, validatePostInput } from '@/src/lib/posts';

/**
 * GET /api/admin/posts — all posts incl. markdown body (admin only),
 * newest first. Powers the dashboard's blog editor.
 */
export async function GET(req: Request) {
  if (!(await isAdminRequest(req))) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  const metas = await getAllPosts();
  const posts = await Promise.all(metas.map(async (m) => ({ ...(await getPost(m.slug)) })));
  return NextResponse.json({ posts });
}

/** POST /api/admin/posts — create a post (admin only). */
export async function POST(req: Request) {
  if (!(await isAdminRequest(req))) {
    return NextResponse.json({ error: 'Nicht autorisiert.' }, { status: 401 });
  }
  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ungültiges JSON.' }, { status: 400 });
  }
  const parsed = validatePostInput(payload);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }
  try {
    await createPost(parsed.value);
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Speichern fehlgeschlagen.' }, { status: 409 });
  }
  return NextResponse.json({ ok: true, slug: parsed.value.slug }, { status: 201 });
}