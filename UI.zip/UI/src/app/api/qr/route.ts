/**
 * GET /api/qr — public QR image endpoint.
 *
 * Everything happens in this process: no database, no queue, no third-party
 * rendering service. That is the same promise the browser tool makes, and it
 * is the reason the endpoint can be offered without a key.
 *
 * Examples
 *   /api/qr?type=url&url=https://example.com
 *   /api/qr?type=wifi&ssid=Cafe&password=espresso&format=png&size=1024
 *   /api/qr?type=sepa&name=Max%20Mustermann&iban=DE89370400440532013000&amount=24.90
 *   /api/qr?type=vcard&firstName=Ana&lastName=Silva&email=ana@example.com&format=json
 */
import { NextRequest } from 'next/server';
import QRCode from 'qrcode';
import { ApiError, buildPayload, parseOptions } from '@/src/lib/api-qr';

export const runtime = 'nodejs';

/*
 * Small in-memory token bucket. It is per-instance and therefore approximate,
 * which is fine: it exists to stop accidental loops, not determined abuse.
 * A real limit would need shared state, and that is a different promise.
 */
const BUCKETS = new Map<string, { tokens: number; resetAt: number }>();
const LIMIT = 60;
const WINDOW_MS = 60_000;

function rateLimited(key: string): boolean {
  const now = Date.now();
  const b = BUCKETS.get(key);
  if (!b || now > b.resetAt) {
    BUCKETS.set(key, { tokens: LIMIT - 1, resetAt: now + WINDOW_MS });
    return false;
  }
  if (b.tokens <= 0) return true;
  b.tokens -= 1;
  return false;
}

/** Cache hard: the same URL always produces the same bytes. */
const CACHE = 'public, max-age=86400, s-maxage=31536000, immutable';

/* Public endpoint: embedding a QR via <img src> from another site is a
   first-class use case, so CORS has to be open. */
const CORS = { 'Access-Control-Allow-Origin': '*' };

export async function GET(req: NextRequest) {
  const ip =
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('x-real-ip') ||
    'anon';

  if (rateLimited(ip)) {
    return Response.json(
      { error: 'Rate limit reached: 60 requests per minute per address.' },
      { status: 429, headers: { 'Retry-After': '60' } }
    );
  }

  const params = req.nextUrl.searchParams;

  try {
    const type = (params.get('type') ?? 'url').toLowerCase();
    const payload = buildPayload(type, params);
    const opts = parseOptions(params);

    if (opts.format === 'json') {
      return Response.json(
        { type, payload, length: payload.length },
        { headers: { 'Cache-Control': CACHE, ...CORS } }
      );
    }

    if (opts.format === 'svg') {
      const svg = await QRCode.toString(payload, {
        type: 'svg',
        errorCorrectionLevel: opts.ecc,
        margin: opts.margin,
        width: opts.size,
        color: { dark: opts.dark, light: opts.light },
      });
      return new Response(svg, {
        headers: {
          'Content-Type': 'image/svg+xml; charset=utf-8',
          'Cache-Control': CACHE,
          'X-QR-Payload-Length': String(payload.length),
          ...CORS,
        },
      });
    }

    const buffer = await QRCode.toBuffer(payload, {
      type: 'png',
      errorCorrectionLevel: opts.ecc,
      margin: opts.margin,
      width: opts.size,
      color: { dark: opts.dark, light: opts.light },
    });

    return new Response(new Uint8Array(buffer), {
      headers: {
        'Content-Type': 'image/png',
        'Cache-Control': CACHE,
        'X-QR-Payload-Length': String(payload.length),
        ...CORS,
      },
    });
  } catch (err) {
    if (err instanceof ApiError) {
      return Response.json({ error: err.message }, { status: err.status, headers: CORS });
    }
    return Response.json(
      { error: 'Could not encode this input. It is probably too long for a QR symbol.' },
      { status: 422, headers: CORS }
    );
  }
}

export async function OPTIONS() {
  return new Response(null, {
    status: 204,
    headers: {
      Allow: 'GET, OPTIONS',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
    },
  });
}
