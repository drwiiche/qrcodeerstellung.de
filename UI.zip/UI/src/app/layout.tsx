import type { Metadata, Viewport } from 'next';
import { Archivo, Archivo_Black, JetBrains_Mono } from 'next/font/google';
import { SITE_URL } from '@/src/lib/site';
import '../index.css';

const archivo = Archivo({
  subsets: ['latin'],
  display: 'swap',
  style: ['normal', 'italic'],
  variable: '--font-archivo',
  weight: ['400', '500', '600', '700'],
});

const archivoBlack = Archivo_Black({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-archivo-black',
  weight: '400',
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-jetbrains',
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: 'QR-Code erstellen: kostenlos, ohne Anmeldung',
  description:
    'Hochauflösende QR-Codes für Zuhause und Alltag: Fritz!Box Gäste-WLAN, SEPA GiroCode, vCard, Paketabstellort. Kostenlos, ohne Anmeldung, als SVG.',
  /*
   * No `keywords` here. This layout wraps the localized tree as well, so a
   * German keyword list defined here shipped on every /pl, /he or /ar page,
   * where it was both untranslated and useless: Google has ignored meta
   * keywords for over a decade. The German list lives in `(site)/layout.tsx`,
   * which is the subtree that actually contains German pages.
   */
  applicationName: 'QR-Code Generator',
  manifest: '/manifest.json',
  icons: {
    icon: [
      { url: '/favicon.svg', type: 'image/svg+xml' },
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
    ],
    shortcut: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    type: 'website',
    locale: 'de_DE',
    siteName: 'QR-Generator Deutschland',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'QR-Generator Deutschland – Vorschau und Generator',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#0b1220',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de" className={`${archivo.variable} ${archivoBlack.variable} ${jetbrains.variable}`}>
      <body className="bg-paper text-ink antialiased">
        {children}
      </body>
    </html>
  );
}
