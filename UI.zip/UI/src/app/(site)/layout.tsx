import type { Metadata } from 'next';
import { SiteShell } from '../../components/SiteShell';

/*
 * German-only metadata. The German pages are the ones this list describes, so
 * it sits in the German subtree instead of the root layout, which also wraps
 * the eleven localized trees.
 */
export const metadata: Metadata = {
  keywords: [
    'QR Code Generator Deutschland',
    'WLAN QR Code Fritzbox',
    'GiroCode SEPA Überweisung erstellen',
    'vCard Visitenkarte QR',
    'QR Code für Zuhause',
  ],
};

export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return <SiteShell>{children}</SiteShell>;
}
