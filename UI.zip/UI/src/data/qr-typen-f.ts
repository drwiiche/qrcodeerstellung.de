/**
 * German type pages, sixth batch.
 *
 * Three noun pages: two that the competitor analysis found open (Excel, Anwesenheit)
 * and one that the German market asks for and that no competitor writes honestly
 * (Buchung, where the honest answer is that a code is a link and not a booking
 * engine).
 *
 * The Anwesenheit page states a labour-law consequence, so it carries sources and
 * says in one sentence that it is not legal advice.
 */
import type { SeoSubPage } from './seo-pages';

const excel: SeoSubPage = {
  slug: 'excel',
  title: 'Excel-Datei als QR-Code bereitstellen',
  metaTitle: 'Excel QR-Code erstellen: Tabelle per Scan öffnen',
  metaDescription:
    'Ein QR-Code, der eine Excel-Datei öffnet: warum ein Live-Link oft nur intern funktioniert, welche Freigabeform trägt und wann eine PDF besser ist.',
  intro: [
    'Der Wunsch ist meistens derselbe wie bei der PDF: Die Tabelle soll beim Scannen aufgehen. Der Unterschied liegt im Empfänger. Eine PDF liest jeder, eine Excel-Datei braucht eine App, und ein Freigabelink aus einem Cloud-Speicher braucht oft ein Konto beim selben Anbieter.',
    'Deshalb ist die erste Entscheidung bei diesem Typ nicht der Code, sondern die Freigabe: Wer soll die Datei öffnen dürfen, und was soll er darin tun?',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Die Adresse der Datei oder des Freigabelinks, zum Beispiel https://ihre-domain.de/downloads/inventurliste.xlsx. Der Code selbst enthält keine Tabelle und keine Zellen, nur diese Zeichenkette.',
        'Das ist bei Tabellen wichtiger als bei PDFs, weil Tabellen häufig ersetzt werden. Die Liste wird wöchentlich fortgeschrieben, die Datei also regelmäßig neu hochgeladen. Bleibt der Dateiname gleich, bleibt der gedruckte Code gültig. Arbeiten Sie mit Datum im Dateinamen, bekommen Sie für jede Fassung einen neuen Code, und das will niemand.',
      ],
      bullets: [
        'Dateiname ohne Leerzeichen, ohne Umlaute, ohne Datum',
        'Ein Code pro Liste, nicht ein Code für einen Ordner mit zwanzig Listen',
        'Adresse auf der eigenen Domain ist stabiler als jede Freigabe',
        'Vor dem Druck mit einem fremden Handy ohne Konto testen',
      ],
    },
    {
      title: 'Die Freigabe ist die eigentliche Falle',
      body: [
        'Ein Link aus einem Cloud-Speicher ist selten so offen, wie er aussieht. Drei Fälle sind üblich und nur einer davon ist für einen gedruckten Code brauchbar.',
        'Der Bearbeitungslink: Jeder mit dem Link kann die Tabelle ändern, auch löschen. Auf einem gedruckten Etikett ist das ein Datenverlust mit Ansage. Der Ansichtslink: Jeder kann lesen, niemand ändern, das ist die richtige Form. Und der Link mit Anmeldepflicht, der aussieht wie ein Ansichtslink und beim Kunden eine Kontomaske zeigt, was in der Praxis die häufigste Beschwerde nach dem Druck ist.',
        'Wer die Wahl hat, legt die Datei als Datei auf den eigenen Webspace. Dann gilt: Wer die Adresse kennt, lädt sie herunter, ohne Konto und ohne Cloud.',
      ],
    },
    {
      title: 'Wann eine PDF die bessere Wahl ist',
      body: [
        'Wenn niemand die Datei bearbeiten soll, ist eine PDF besser. Sie öffnet auf jedem Gerät, in jedem Browser und ohne Zusatz-App. Eine Excel-Datei auf einem Telefon ist fast immer die falsche Erfahrung: kleine Zellen, horizontales Scrollen, und wer nur nachsehen will, muss die Datei erst herunterladen und dann öffnen.',
        'Wenn die Tabelle ausdrücklich zum Ausfüllen gedacht ist, gehört sie nicht hinter einen Code. Eine Liste, die am Telefon ausgefüllt werden soll, ist ein Formular, und das Formular steht im Browser, nicht in einer Datei.',
      ],
    },
    {
      title: 'Bestandslisten und Lagerorte',
      body: [
        'Der praktisch sinnvollste Fall für diesen Typ ist die Lagerkennzeichnung. Ein Regal, ein Behälter, eine Kiste bekommt einen Code, der auf die Bestandsliste oder das Datenblatt zeigt. Der Code steht dann dauerhaft am Ort, die Datei dahinter wechselt mit jeder Inventur.',
        'In dieser Verwendung zählt Haltbarkeit mehr als Gestaltung: wetterfestes Material, gedruckt mit klarem Kontrast, an einer Stelle, an der niemand mit dem Hubwagen dagegen fährt. Zwei Zentimeter genügen, wenn das Telefon zwanzig Zentimeter entfernt ist, was beim Lesen eines Regalschilds normal ist.',
      ],
      bullets: [
        'Je Regal oder Behälter ein eigener Code, nicht ein Code für das ganze Lager',
        'Beschriftung mit dem, was dahinter liegt, sonst wird der Code nicht wiedererkannt',
        'Bei Kälte, Feuchtigkeit oder Öl: laminiert oder als Aluverbund, nicht Papier',
      ],
    },
    {
      title: 'Zugriff und Datenschutz',
      body: [
        'Eine Tabelle ist gefährlicher öffentlich als eine PDF, weil sie oft mehr enthält als den sichtbaren Teil. Kundennamen in einer zweiten Spalte, Preise in einem ausgeblendeten Blatt, Notizen in Kommentaren: Beim Herunterladen kommt das alles mit.',
        'Prüfen Sie die Datei deshalb vor der Veröffentlichung in einem Durchgang: alle Blätter, alle Spalten, alle Kommentare, verborgene Zeilen. Für alles, was personenbezogene Daten enthält, gilt dasselbe wie bei der PDF. Kein QR-Code, sondern ein geschützter Bereich mit Anmeldung.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Lager und Regal',
      text: 'Der Code am Regal zeigt auf die Bestandsliste. Die Liste wird je Inventur ersetzt, der Code bleibt am Regal.',
    },
    {
      title: 'Preisliste für das Team',
      text: 'Der Code im Aufenthaltsraum führt auf die aktuelle Liste mit Einkaufspreisen. Kein Ausdruck im Umlauf, keine veraltete Fassung an der Wand.',
    },
    {
      title: 'Prüfliste am Prüfplatz',
      text: 'Der Code öffnet die dokumentierte Prüfliste, die ausgefüllt zurückkommt. Wenn zurückgeschrieben wird, ist ein Formular besser als eine Datei.',
    },
    {
      title: 'Lieferantenliste am Arbeitsplatz',
      text: 'Der Code auf dem Schreibtisch öffnet die Kontaktliste. Für Kollegen, die selten nachsehen, und für Aushilfen am ersten Tag.',
    },
  ],
  steps: [
    'Die Datei prüfen: alle Blätter, ausgeblendete Spalten, Kommentare, personenbezogene Daten.',
    'Die Datei auf die eigene Domain legen oder als Ansichtslink ohne Anmeldepflicht freigeben.',
    'Die Adresse in einem privaten Fenster und ohne Konto öffnen, also in einem Inkognito-Fenster.',
    'Typ „Webseite“ wählen, Adresse einfügen, als SVG herunterladen.',
    'Den gedruckten Code am Einsatzort scannen, mit dem Gerät, das dort üblich ist.',
  ],
  faq: [
    {
      q: 'Öffnet sich die Excel-Datei auf dem Handy?',
      a: 'Nur mit einer Tabellen-App oder über die Webversion des Anbieters. Wer nur nachsehen will, ist mit einer PDF deutlich besser bedient.',
    },
    {
      q: 'Warum verlangt der Link von Kunden eine Anmeldung?',
      a: 'Weil der Freigabelink an ein Konto gebunden ist. Bei einem gedruckten Code ist das ein Fehler, der erst beim Kunden auftritt. Nutzen Sie einen Ansichtslink oder hosten Sie die Datei als Datei.',
    },
    {
      q: 'Kann jeder mit dem Link die Datei ändern?',
      a: 'Beim Bearbeitungslink ja, und das ist auf einem gedruckten Etikett gefährlich. Verwenden Sie einen Ansichtslink und behalten Sie die Bearbeitung bei sich.',
    },
    {
      q: 'Wie oft kann ich die Datei austauschen?',
      a: 'So oft Sie wollen, solange die Adresse gleich bleibt. Deshalb kein Datum in den Dateinamen.',
    },
    {
      q: 'Ist das für große Bestände geeignet?',
      a: 'Ja, aber je Regal mit eigenem Code. Ein einzelner Code für ein ganzes Lager führt zu Listen, die niemand mehr findet.',
    },
  ],
  toolLinks: [
    { label: 'Excel-QR-Code erstellen', href: '/?type=url' },
    { label: 'PDF als QR-Code bereitstellen', href: '/qr-code-generator/pdf' },
  ],
  blogLinks: [
    { label: 'QR-Code und Datenschutz: was der Code verrät', href: '/blog/qr-code-dsgvo-datenschutz' },
    { label: 'QR-Code drucken: Kontrast, Größe, Material', href: '/blog/qr-code-drucken-kontrast-groesse' },
  ],
};

const anwesenheit: SeoSubPage = {
  slug: 'anwesenheit',
  title: 'Anwesenheit per QR-Code erfassen',
  metaTitle: 'Anwesenheits-QR-Code: Anmeldung über ein Formular',
  metaDescription:
    'Anwesenheit per QR-Code erfassen: warum der Code nur auf ein Formular zeigt, was gegen Screenshots hilft und wann Betriebsrat und Datenschutz mitreden.',
  intro: [
    'Ein Anwesenheits-Code ist ein Code auf ein Formular. Er zählt nicht selbst, er speichert nichts und er weiß nicht, wer gescannt hat. Wer das erwartet, kauft später ein System und stellt fest, dass ein gedruckter Code das nicht leisten kann.',
    'Was er leistet, ist die Abschaffung der Unterschriftenliste. Für Vereine, Seminare, Kurse und Schulen ist das der ganze Nutzen, und der ist echt.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Die Adresse eines Formulars: eine Google-Formular-Seite, ein Microsoft-Formular, ein eigenes Formular auf der eigenen Seite. Der Code enthält nur diese Adresse, die Erfassung passiert im Formular.',
        'Die Formularfrage entscheidet über die Datenqualität. Eine einzige Frage nach dem Namen produziert Tippfehler und Doppelanmeldungen. Besser sind zwei Felder, Name und eine Kennung, und ein Pflichtfeld, das nur die Teilnehmenden kennen, zum Beispiel die Kursnummer.',
      ],
      bullets: [
        'Ein Code pro Termin, nicht ein Code für das ganze Halbjahr',
        'Ein Feld für die Kennung, das nicht erratbar ist',
        'Zeitstempel im Formular automatisch erfassen lassen, nicht abfragen',
        'Nach dem Termin den Code entwerten, sonst melden sich Leute im Nachhinein an',
      ],
    },
    {
      title: 'Was der Code nicht beweist',
      body: [
        'Ein Foto des Codes lässt sich weitergeben. Wer den Code zu Hause hat, kann sich von zu Hause anmelden. Gegen dieses Szenario hilft kein statischer Code, sondern nur ein Merkmal, das sich ändert: ein Code pro Termin, ein kurzes Zeitfenster, in dem das Formular offen ist, oder eine Kennung, die nur vor Ort ausgegeben wird.',
        'Für einen Verein ist das meistens ausreichend. Für eine Prüfung, eine Fortbildung mit Zertifikat oder eine Anwesenheitspflicht mit rechtlicher Folge ist es nicht ausreichend, und dort gehört ein System hin, das mehr prüft als einen Scan.',
      ],
    },
    {
      title: 'Wenn Beschäftigte erfasst werden',
      body: [
        'Anwesenheit von Mitarbeitenden ist etwas anderes als die Teilnahmeliste eines Kurses. Sie ist personenbezogen, sie wird aufbewahrt, und sie kann zur Leistungskontrolle taugen. In Betrieben mit Betriebsrat ist die Einführung und Ausgestaltung eines solchen Systems mitbestimmungspflichtig, weil § 87 Abs. 1 Nr. 6 BetrVG technische Einrichtungen erfasst, die zur Überwachung von Verhalten oder Leistung geeignet sind.',
        'Wer so etwas einführt, klärt das vorher mit dem Betriebsrat und mit einer Datenschutzbeauftragten, nicht nachher. Diese Seite ist keine Rechtsberatung, sie sagt nur, dass an dieser Stelle zwei Stellen mitreden, die bei einer Kursliste nicht mitreden.',
      ],
    },
    {
      title: 'Formular statt Zettel: was sich ändert',
      body: [
        'Der Gewinn liegt nicht im Code, sondern in der Auswertung. Eine Unterschriftenliste muss abgetippt werden, ein Formular liefert eine Tabelle, die sich filtern und zählen lässt. Bei fünfzig Terminen im Jahr ist das der Unterschied zwischen einer Stunde und einem Nachmittag.',
        'Der zweite Gewinn ist die Vollständigkeit. Auf einer Liste fehlen Unterschriften, weil der Stift fehlt oder jemand später kommt. Im Formular ist das Feld entweder ausgefüllt oder die Anmeldung fehlt, und beides ist sichtbar.',
      ],
      bullets: [
        'Export als Tabelle einplanen, bevor das Formular gebaut wird',
        'Fragen so formulieren, dass die Auswertung ohne Nacharbeit funktioniert',
        'Teilnehmende vorher informieren, was erhoben wird und wie lange es bleibt',
      ],
    },
    {
      title: 'Aufhängen und beschriften',
      body: [
        'Der Code hängt dort, wo die Leute ankommen: am Eingang, an der Garderobe, am Tisch. A5 auf einem Ständer ist die übliche Größe, bei einem Aushang aus zwei Metern Entfernung sind 10 bis 15 Zentimeter Kantenlänge nötig.',
        'Die Beschriftung muss zwei Dinge sagen: wofür der Scan ist und dass er eine halbe Minute dauert. Ein Code ohne Beschriftung am Eingang wird für eine Anmeldung zum WLAN gehalten.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Vereinstraining',
      text: 'Der Code am Halleneingang, das Formular fragt Name und Mitgliedsnummer. Die Anwesenheit liegt abends als Tabelle vor.',
    },
    {
      title: 'Seminar und Fortbildung',
      text: 'Ein Code pro Termin, ein Feld mit der Seminarnummer, Zeitstempel automatisch. Nach dem Termin wird der Code entwertet.',
    },
    {
      title: 'Schule und Elternabend',
      text: 'Der Code am Eingang der Aula, das Formular erfasst Name und Klasse. Für die Teilnahmeliste, nicht für Noten.',
    },
    {
      title: 'Ehrenamt und Helferliste',
      text: 'Der Code im Helferraum, das Formular erfasst Schicht und Name. Wer später kommt, trägt sich nach.',
    },
  ],
  steps: [
    'Das Formular bauen und die Felder so wählen, dass die spätere Auswertung ohne Nacharbeit funktioniert.',
    'Das Formular in einem privaten Fenster öffnen und auf dem Handy ausfüllen, einmal komplett.',
    'Die Adresse in den Generator eintragen und als SVG herunterladen.',
    'Den Code am Eingang aufhängen, beschriftet mit Zweck und Dauer.',
    'Nach dem ersten Termin die Tabelle exportieren und prüfen, ob die Daten brauchbar sind.',
  ],
  faq: [
    {
      q: 'Kann jemand sich von zu Hause anmelden?',
      a: 'Ja, wenn er den Code oder dessen Adresse kennt. Dagegen helfen ein Code pro Termin, ein kurzes Zeitfenster und eine Kennung, die nur vor Ort ausgegeben wird.',
    },
    {
      q: 'Ist ein QR-Code ein sicherer Nachweis?',
      a: 'Nein. Er ist eine Abkürzung zum Formular. Für Prüfungen und zertifizierte Fortbildungen braucht es ein Verfahren, das mehr prüft als einen Scan.',
    },
    {
      q: 'Brauche ich für Mitarbeitende eine Betriebsvereinbarung?',
      a: 'In Betrieben mit Betriebsrat ist die Einführung eines solchen Systems mitbestimmungspflichtig. Klären Sie das vorher mit Betriebsrat und Datenschutzbeauftragter.',
    },
    {
      q: 'Welches Formular soll ich nehmen?',
      a: 'Das, dessen Antworten Sie als Tabelle exportieren können, und das die Teilnehmenden ohne Konto ausfüllen können. Anbieterunabhängig ist ein eigenes Formular.',
    },
    {
      q: 'Wie lange darf ich die Daten behalten?',
      a: 'Nur so lange, wie der Zweck es verlangt. Legen Sie die Frist fest, bevor Sie das erste Mal erfassen, und löschen Sie danach.',
    },
  ],
  sources: [
    {
      label: '§ 87 Betriebsverfassungsgesetz, Mitbestimmungsrechte (gesetze-im-internet.de)',
      href: 'https://www.gesetze-im-internet.de/betrvg/__87.html',
    },
    {
      label: 'Bundesarbeitsgericht: Pflicht zur Arbeitszeiterfassung, Beschluss 1 ABR 22/21',
      href: 'https://juris.bundesarbeitsgericht.de/cgi-bin/rechtsprechung/document.py?Gericht=bag&Art=pm&Datum=2022-09-13&nr=26176',
    },
  ],
  toolLinks: [
    { label: 'Anwesenheits-Code erstellen', href: '/?type=url' },
    { label: 'QR-Codes für Schulen und Bildung', href: '/blog/qr-codes-schulen-bildung' },
  ],
  blogLinks: [
    { label: 'QR-Codes für Veranstaltungen', href: '/blog/qr-codes-veranstaltungen-events' },
    { label: 'QR-Code und Datenschutz', href: '/blog/qr-code-dsgvo-datenschutz' },
  ],
};

const buchung: SeoSubPage = {
  slug: 'buchung',
  title: 'Terminbuchung per QR-Code',
  metaTitle: 'Buchungs-QR-Code: Termin per Scan vereinbaren',
  metaDescription:
    'Ein QR-Code, der zur Buchungsseite führt: was er leistet, was nicht, welche Rolle die Kalender-App spielt und wo der Code im Ablauf wirklich hilft.',
  intro: [
    'Ein Buchungs-Code ist ein Link auf eine Seite, auf der gebucht wird. Das ist wenig Technik, aber eine deutliche Verbesserung im Ablauf, weil er genau an der Stelle greift, an der Termine scheitern: am Tresen, am Telefon, an der Werkstattür, wenn das Telefon schon in der Hand ist.',
    'Wichtig ist die Erwartung an das, was dahinter liegt: Der Code öffnet einen Kalender, er ist keiner.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Die Adresse der Buchungsseite: ein Link auf einen Buchungsdienst, auf ein eigenes Formular mit Terminwunsch oder auf eine Seite, die den Kalender einbettet. Alles, was der Code tut, ist diese Adresse öffnen.',
        'Daraus folgt die wichtigste Frage vor dem Druck: Ist die Seite auf dem Handy in unter einer Minute benutzbar? Eine Buchungsseite mit Monatskalender am Desktop ist auf dem Telefon oft unbedienbar, und genau dort wird der Code gescannt.',
      ],
      bullets: [
        'Die Buchungsseite am Handy testen, nicht am Rechner',
        'Anzahl der Klicks bis zum bestätigten Termin zählen, ideal sind unter fünf',
        'Bestätigung per E-Mail muss ohne Konto funktionieren',
        'Ein Code pro Standort und Leistung, nicht ein Code für alles',
      ],
    },
    {
      title: 'Code oder Termin-Code: der Unterschied',
      body: [
        'Diese beiden Typen werden oft verwechselt, und die Verwechslung kostet Termine. Der Buchungs-Code führt zu einer Seite, auf der der Kunde selbst einen freien Termin auswählt. Der Termin-Code legt einen bereits festgelegten Termin in den Kalender, mit Datum, Uhrzeit und Ort.',
        'Für eine Werkstatt, eine Praxis oder ein Studio ist der Buchungs-Code richtig. Für eine Einladung, einen Kursabend oder eine Sprechstunde mit festen Zeiten ist der Termin-Code richtig. Beides zu vermischen führt dazu, dass Kunden eine Bestätigung erwarten, die nicht kommt.',
      ],
    },
    {
      title: 'Wo der Code im Ablauf wirkt',
      body: [
        'Am wirksamsten ist er dort, wo gerade niemand Zeit hat: an der Theke, wenn die Schlange länger ist als die Geduld, an der Werkstattür nach Feierabend, am Telefon, wo der Anruf auf die Mailbox läuft. Der Code verschiebt die Terminvergabe in den Moment, in dem der Kunde ohnehin auf sein Telefon schaut.',
        'Weniger wirkt er auf Flyern und Plakaten ohne Bezug. Wer einen Flyer in der Hand hat, ist selten in der Situation, einen Termin zu brauchen. Was dort wirkt, ist der Hinweis auf die Öffnungszeiten und die Adresse, nicht die Buchung.',
      ],
      bullets: [
        'An der Kasse, an der Tür, auf der Rechnung, in der Absage-E-Mail',
        'Beschriftung mit dem Nutzen: „Termin in 30 Sekunden buchen“',
        'Direkt neben Öffnungszeiten, weil beides dieselbe Frage beantwortet',
      ],
    },
    {
      title: 'Was der Code nicht leistet',
      body: [
        'Er synchronisiert keine Kalender, er verschickt keine Erinnerungen und er verhindert keine Doppelbuchungen. Das alles ist Aufgabe des Dienstes hinter dem Code. Wenn dort ein Kalender ohne Doppelbuchungsschutz liegt, ist der Code nicht schuld, und der Fehler wird trotzdem am Code gesehen.',
        'Er ersetzt auch nicht die telefonische Erreichbarkeit für die Fälle, die sich nicht buchen lassen: Notfälle, Rückfragen, Reklamationen. Ein Betrieb, der auf Buchung umstellt und das Telefon abschaltet, verliert genau die Kunden, die den höchsten Wert haben.',
      ],
    },
    {
      title: 'Gestaltung und Platzierung',
      body: [
        'Auf einem Tresenaufsteller sind 4 bis 5 Zentimeter Kantenlänge bei 40 bis 60 Zentimetern Abstand richtig. Auf einem Türschild, das aus einem Meter gelesen wird, 10 Zentimeter. Der Code darf nicht hinter Glas mit Reflexion stehen, wenn er auf einem Tresen liegt, denn Blendung ist der häufigste Grund, warum ein an sich guter Code nicht liest.',
        'Setzen Sie einen Satz daneben, der die Angst vor dem Formular nimmt: keine Anmeldung, keine App, Bestätigung per E-Mail. Wer schon einmal in einer Endlosschleife aus Cookie-Fenstern gebucht hat, zögert sonst.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Friseur und Studio',
      text: 'Der Aufsteller an der Kasse, der Code führt auf die Buchungsseite. Wer telefonisch nicht durchkommt, bucht abends vom Sofa.',
    },
    {
      title: 'Praxis und Therapie',
      text: 'Der Code auf der Rechnung für die Folgetermine. Kein Anruf in der Sprechstunde, kein Zettel, der verloren geht.',
    },
    {
      title: 'Werkstatt und Service',
      text: 'Der Code an der Tür für die Terminvereinbarung nach Feierabend. Mit dem Hinweis, dass Notfälle weiter telefonisch laufen.',
    },
    {
      title: 'Besichtigung und Vermietung',
      text: 'Der Code am Objekt führt auf die Terminseite für Besichtigungen. Wer vorbeifährt und niemanden antrifft, kann direkt buchen.',
    },
  ],
  steps: [
    'Die Buchungsseite am Handy durchspielen: Termin wählen, bestätigen, Bestätigungsmail prüfen.',
    'Die Adresse in den Generator eintragen und als SVG herunterladen.',
    'Den Code dort aufhängen, wo gewartet wird, und mit einer Zeile beschriften, was er tut.',
    'Nach vier Wochen die Zahl der Online-Buchungen mit der Zeit davor vergleichen.',
  ],
  faq: [
    {
      q: 'Was ist der Unterschied zum Termin-QR-Code?',
      a: 'Der Buchungs-Code führt auf eine Seite, auf der der Kunde einen freien Termin auswählt. Der Termin-Code legt einen festen Termin in den Kalender.',
    },
    {
      q: 'Kann der Code Termine bestätigen?',
      a: 'Nein. Die Bestätigung kommt vom Buchungsdienst hinter dem Link, meist per E-Mail.',
    },
    {
      q: 'Brauchen Kunden eine App?',
      a: 'Bei einem guten Ablauf nicht. Wer eine App verlangt, verliert die Kunden, die nur einmal etwas buchen wollen.',
    },
    {
      q: 'Wie viele Scans sind zu erwarten?',
      a: 'Das hängt vom Ort ab und lässt sich nicht seriös vorhersagen. Ein statischer Code zählt ohnehin nichts. Messbar ist die Zahl der Buchungen.',
    },
    {
      q: 'Kann ich denselben Code für mehrere Leistungen nutzen?',
      a: 'Ja, wenn die Buchungsseite die Auswahl anbietet. Ein Code pro Standort ist sinnvoll, ein Code pro Leistung nur, wenn die Wege im Alltag getrennt sind.',
    },
  ],
  toolLinks: [
    { label: 'Buchungs-QR-Code erstellen', href: '/?type=url' },
    { label: 'Termin-QR-Code für den Kalender', href: '/qr-code-generator/termin' },
  ],
  blogLinks: [
    { label: 'QR-Codes für Handwerk und lokale Betriebe', href: '/blog/qr-codes-handwerk-lokal' },
    { label: 'QR-Codes für Veranstaltungen', href: '/blog/qr-codes-veranstaltungen-events' },
  ],
};

export const TYPEN_PART_SIX = [excel, anwesenheit, buchung];
