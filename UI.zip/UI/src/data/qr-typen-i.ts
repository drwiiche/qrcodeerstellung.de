/**
 * German type pages, eighth batch, closing the noun-page list from the competitor
 * analysis: product, logo, templates.
 *
 * The product page is the only one here that touches a standard we already write
 * about, so it links into the /standards cluster instead of restating it. The logo
 * page carries the numbers from the QR standard (error correction levels) because
 * every claim on it depends on them. The templates page links to the gallery that
 * already exists instead of duplicating it.
 */
import type { SeoSubPage } from './seo-pages';

const produkt: SeoSubPage = {
  slug: 'produkt',
  title: 'Produkt-QR-Code anbringen',
  metaTitle: 'Produkt-QR-Code: Anleitung, Herkunft, Ersatzteile',
  metaDescription:
    'Ein Code am Produkt führt zu Anleitung, Ersatzteilen oder Herkunft. Was er leistet, was GS1 Digital Link damit zu tun hat und worauf das Etikett ankommt.',
  intro: [
    'Ein Produkt-QR-Code ist die Verbindung zwischen einem Gegenstand und allem, was man darüber wissen will: Anleitung, Ersatzteil, Pflege, Herkunft, Garantie. Der Code selbst enthält davon nichts, er zeigt auf eine Seite.',
    'Der Nutzen entsteht deshalb nicht durch den Code, sondern durch die Entscheidung, was auf der Zielseite steht. Eine Seite, die nur ein Firmenlogo zeigt, ist der Grund, warum Leute aufhören, Produktcodes zu scannen.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Meistens eine Adresse auf der eigenen Domain, die auf eine produktspezifische Seite führt, zum Beispiel ihre-domain.de/p/artikel-4711. Diese Seite enthält dann, was für dieses Produkt gilt: Anleitung in der Sprache des Käufers, Ersatzteilliste, Pflegehinweise, Entsorgung, Kontakt.',
        'Eine zweite, technische Form ist der GS1 Digital Link. Dabei steht im Code kein freier Link, sondern eine Adresse mit einer Artikelnummer nach dem GS1-Standard, die sowohl ein Kassenscanner als auch ein Telefon auswerten kann. Wer Produkte im Handel führt, sollte das mit seinem Handel und mit GS1 klären, bevor ein Etikett gedruckt wird, denn die Nummernvergabe folgt eigenen Regeln.',
      ],
      bullets: [
        'Eine Seite pro Produkt oder Produktfamilie, nicht eine Seite für alles',
        'Sprache des Zielmarkts berücksichtigen, nicht nur Deutsch',
        'Keine Kampagnen-Adresse mit Ablaufdatum auf einem Produkt',
        'Bei GS1 Digital Link: Nummernvergabe vorher klären',
      ],
    },
    {
      title: 'Was auf der Zielseite stehen muss, damit sie etwas taugt',
      body: [
        'Die erste Frage eines Käufers ist fast immer praktisch: Wie schalte ich das ein, wie reinige ich das, welches Ersatzteil passt. Wer diese drei Fragen auf der Seite beantwortet, bekommt wiederverwendete Codes statt einmaliger Scans.',
        'Die zweite Frage betrifft den Fall, dass etwas nicht funktioniert: Kontakt, Garantie, Rückgabe. Ein Code, der dorthin führt, spart dem Betrieb Telefonate, weil der Kunde den Weg selbst findet.',
        'Was nicht auf die Seite gehört: eine Werbefläche, ein Newsletter-Fenster, ein Video, das automatisch startet. Wer im Laden vor dem Regal steht, hat kein Interesse an einer Markenkampagne, sondern an einer Antwort.',
      ],
    },
    {
      title: 'Rechtliche Nachbarschaft, nicht Rechtsberatung',
      body: [
        'Bei einigen Produkten ist ein Datenträger am Produkt nicht nur freiwillig. Für Batterien ist ab Februar 2027 ein digitaler Produktpass vorgesehen, der über einen Datenträger erreichbar sein soll. Bei Wein und aromatisierten Weinerzeugnissen sind Zutaten und Nährwerte vorgeschrieben, und der Code ist der übliche Weg dorthin.',
        'Diese Seite entscheidet das nicht. Wer wissen will, ob für sein Produkt etwas gilt, findet die Einordnung mit Quellen in unserem Standard-Bereich, und für den eigenen Fall gehört die Frage zu einer Anwältin oder einem Anwalt.',
      ],
      bullets: [
        'Batterien: Datenträger ab Februar 2027 vorgesehen, Details im Standard-Bereich',
        'Wein: Zutaten und Nährwerte über den Code verbreitet',
        'Ob eine Pflicht greift, hängt vom Produkt ab, nicht vom Code-Typ',
      ],
    },
    {
      title: 'Das Etikett hält länger als der Druck',
      body: [
        'Ein Produktetikett wird angefasst, gewaschen, gekühlt, in eine Tasche geworfen und mit dem Fingernagel über die Kante geschoben. Papier unter Folie hält das nicht aus. Für Produkte, die länger als ein Jahr im Umlauf sind, braucht es ein Material, das zum Einsatz passt: Folie, Kunststoff, Direktdruck auf die Verpackung oder eine Metallplatte.',
        'Die zweite Frage ist die Größe. Auf einer Verpackung, die in der Hand gehalten wird, reichen 2 Zentimeter. Bei einem Etikett auf einem Regal oder einer Maschine, die aus einem Meter gelesen wird, sind 10 Zentimeter nötig. Der Code darf nicht über eine Kante, eine Falz oder eine Rundung laufen, weil dort die Module verzerrt werden.',
      ],
      bullets: [
        'Kein Code über eine Kante oder Rundung drucken',
        'Kontrast prüfen, auch unter Kunstlicht im Laden',
        'Ruhezone von vier Modulen freihalten, auch bei kleiner Fläche',
        'Materiellem Test machen: kratzen, wischen, kühlen',
      ],
    },
    {
      title: 'Was der Code nicht leistet',
      body: [
        'Er ist kein Herkunftsnachweis. Ein Link auf eine Seite behauptet nichts über den Weg des Produkts, und eine gefälschte Ware kann einen echten Link tragen. Wer Fälschungen abwehren will, braucht eindeutige, individualisierte Merkmale und eine Prüfung, nicht nur einen QR-Code.',
        'Er ersetzt auch nicht die gesetzlich vorgeschriebenen Angaben auf der Verpackung oder im Beipackzettel. Ein Code, der auf eine Seite führt, ist eine Ergänzung, und bei manchen Angaben ist die Verpackung selbst der Ort, an dem sie stehen müssen.',
      ],
    },
  ],
  useCases: [
    { title: 'Ersatzteile und Zubehör', text: 'Der Code am Gerät führt auf die Teileliste mit den passenden Nummern. Der Kunde bestellt das richtige Teil statt des fast richtigen.' },
    { title: 'Pflege und Reinigung', text: 'Der Code am Etikett erklärt, was das Material verträgt. Ein Satz, der teure Fehler verhindert.' },
    { title: 'Anleitung in der Sprache des Käufers', text: 'Eine Seite, mehrere Sprachen, ein Etikett. Der Exportmarkt braucht keinen zweiten Aufdruck.' },
    { title: 'Registrierung und Garantie', text: 'Der Code auf der Packung führt zum Formular. Die Garantieverlängerung wird zum Anlass, das Produkt zu registrieren.' },
  ],
  steps: [
    'Festlegen, was der Käufer nach dem Scan tun soll, bevor der Code gebaut wird.',
    'Die Zielseite bauen, mit Anleitung, Ersatzteilen und Kontakt, in der Sprache des Markts.',
    'Die Adresse dauerhaft anlegen, ohne Jahreszahl und ohne Kampagnenbegriff.',
    'Den Code testen: auf dem Material, unter Ladenlicht, mit zwei Telefonen.',
    'Nach dem ersten Halbjahr die Zahl der Seitenaufrufe mit den Verkäufen vergleichen, nicht die Scans.',
  ],
  faq: [
    { q: 'Brauche ich GS1 Digital Link?', a: 'Wenn das Produkt über den Handel läuft und an der Kasse gescannt werden soll, ist das der passende Standard. Für ein Etikett auf einer Maschine im eigenen Betrieb genügt ein normaler Link.' },
    { q: 'Muss der Code auf die Verpackung oder ins Produkt?', a: 'Auf die Verpackung, solange sie existiert, und zusätzlich am Produkt, wenn es länger genutzt wird als die Verpackung lebt.' },
    { q: 'Eignet sich der Code als Fälschungsschutz?', a: 'Nicht als solcher. Ein Link beweist keine Herkunft. Dafür braucht es individualisierte Merkmale und eine Prüfung.' },
    { q: 'Was ist mit dem digitalen Produktpass?', a: 'Für Batterien ist ab Februar 2027 ein Datenträger vorgesehen. Ob und wie das eigene Produkt betroffen ist, klärt der Standard-Bereich und im Zweifel eine Beratung.' },
    { q: 'Wie groß muss der Code sein?', a: '2 Zentimeter auf der Verpackung in der Hand, 10 Zentimeter auf einem Etikett, das aus einem Meter gelesen wird.' },
  ],
  sources: [
    { label: 'GS1: Digital Link und GTIN', href: 'https://www.gs1.org/standards/id-keys/gtin' },
    { label: 'EUR-Lex: Verordnung (EU) 2024/1781 (ESPR)', href: 'https://eur-lex.europa.eu/eli/reg/2024/1781/oj' },
  ],
  toolLinks: [
    { label: 'Produkt-Code erstellen', href: '/?type=url' },
    { label: 'Digitaler Produktpass: was gilt', href: '/standards/digitaler-produktpass' },
  ],
  blogLinks: [
    { label: 'QR-Codes auf Produkten und Verpackungen', href: '/blog/qr-code-marketing-messbar-machen' },
  ],
};

const mitLogo: SeoSubPage = {
  slug: 'mit-logo',
  title: 'QR-Code mit Logo erstellen',
  metaTitle: 'QR-Code mit Logo: wie viel Logo er verträgt',
  metaDescription:
    'Ein Logo in der Mitte kostet Lesbarkeit. Wie viel Fläche möglich ist, welche Fehlerkorrektur nötig ist und warum der Test am Druck entscheidet.',
  intro: [
    'Ein QR-Code mit Logo sieht nach Gestaltung aus und ist technisch eine Fehlerkorrektur, die man absichtlich verbraucht. Der Code trägt Redundanz, um beschädigte Stellen zu überstehen, und ein Logo in der Mitte ist eine Beschädigung, die hübsch aussieht.',
    'Deshalb ist die Frage nicht, ob ein Logo geht, sondern wie viel Fläche es kosten darf, damit der Code noch liest. Diese Seite nennt die Zahlen, die dahinterstehen.',
  ],
  sections: [
    {
      title: 'Wie die Fehlerkorrektur funktioniert',
      body: [
        'Ein QR-Code enthält mehr Daten, als zum Lesen nötig wären. Der Anteil, der ersetzt werden kann, hängt von der gewählten Stufe ab: L etwa 7 Prozent, M etwa 15, Q etwa 25, H etwa 30 Prozent der Fläche.',
        'Für einen Code mit Logo ist H die richtige Stufe, weil dort rund ein Drittel der Fläche fehlen darf. Das ist der Grund, warum Codes mit Logo fast immer auf H gebaut werden, und gleichzeitig der Grund, warum sie mehr Module brauchen: Die Redundanz muss ja auch irgendwohin. Ein Code mit Logo ist bei gleicher Datenmenge dichter als einer ohne, und deshalb im Druck empfindlicher.',
      ],
      bullets: [
        'Logo nur mit Fehlerkorrektur H',
        'Logo unter etwa einem Viertel der Codefläche halten',
        'Der Code wird dichter, deshalb größer drucken als ohne Logo',
        'Bei langen Adressen lieber gar kein Logo',
      ],
    },
    {
      title: 'Wo das Logo hin darf und wo nicht',
      body: [
        'In die Mitte, weil dort die Fehlerkorrektur am wirksamsten greift und weil die Positionierhilfen an den Rändern unverletzt bleiben. Die drei großen Quadrate in den Ecken und die Taktmuster dazwischen sind die Teile, an denen der Scanner den Code überhaupt findet. Ein Logo, das eines davon berührt, macht den Code unlesbar, auch wenn rechnerisch noch Fläche frei wäre.',
        'Auch die Ruhezone bleibt tabu. Vier Module Rand gehören zum Code, und ein Rahmen, der bis an das Muster reicht, ist derselbe Fehler wie ein Logo auf einer Ecke.',
      ],
    },
    {
      title: 'Kontrast: der häufigste Grund, warum es nicht liest',
      body: [
        'Ein Logo mit hellen Flächen in der Mitte ist unproblematisch, eines mit einem Verlauf von Hell zu Dunkel ist es nicht. Der Scanner unterscheidet hell und dunkel, und wenn das Logo selbst Muster in Modulgröße mitbringt, entstehen falsche Module.',
        'Dasselbe gilt für den Code selbst: dunkle Module auf hellem Grund, nicht umgekehrt. Ein weißer Code auf schwarzem Etikett sieht gut aus und liest auf vielen Geräten schlechter, weil die Erkennung auf dunkle Muster auf hellem Grund ausgelegt ist.',
      ],
      bullets: [
        'Einfarbiges Logo, keine feinen Linien',
        'Kein Logo mit Modulmuster, kein Foto, kein Verlauf',
        'Keine Umfärbung des Codes in Markenfarben mit geringem Kontrast',
        'Weißer Rand um das Logo, mindestens ein Modul breit',
      ],
    },
    {
      title: 'Testen, und zwar am fertigen Gegenstand',
      body: [
        'Ein Code mit Logo, der am Monitor liest, sagt nichts über den Druck. Papier hat weniger Kontrast, Tinte verläuft, und das Logo wird beim Skalieren weich. Testen Sie auf dem echten Material, mit mindestens zwei Telefonen, aus dem Abstand, aus dem später gescannt wird.',
        'Wenn es knapp wird, gibt es drei Stellschrauben: die Adresse kürzen, den Code größer drucken oder das Logo verkleinern. Die Reihenfolge ist Absicht, denn die Adresse ist der Faktor, der am meisten bringt und am wenigsten kostet.',
      ],
    },
    {
      title: 'Wann ein Logo keine gute Idee ist',
      body: [
        'Bei Codes, die klein gedruckt werden: auf Visitenkarten, auf Beipackzetteln, auf Produkten mit wenig Platz. Dort zählt jedes Modul, und ein Logo nimmt Platz weg, den die Lesbarkeit dringend braucht.',
        'Auch bei langen Adressen mit vielen Parametern, bei Codes auf unruhigem Untergrund und bei allem, was aus mehr als einem Meter gelesen wird. Für ein Plakat in drei Metern Entfernung ist ein Logo im Code ein Detail, das niemand sieht und der Scanner nicht braucht.',
      ],
    },
  ],
  useCases: [
    { title: 'Aufsteller mit Marke', text: 'Der Code mit Logo auf dem Tresenaufsteller, groß genug gedruckt, damit die Redundanz nicht auf Kosten der Lesbarkeit geht.' },
    { title: 'Flyer und Plakat', text: 'Ein Logo im Code fällt hier nicht auf, weil der Code groß ist. Trotzdem: erst die Adresse kürzen, dann das Logo.' },
    { title: 'Verpackung', text: 'Das Logo gehört auf die Verpackung, nicht zwingend in den Code. Zwei Markenzeichen auf vier Quadratzentimetern sind eines zu viel.' },
    { title: 'Visitenkarte', text: 'Hier ist das Logo im Code meistens die falsche Entscheidung. Lieber ein Code ohne Logo, dafür in voller Größe auf weißem Grund.' },
  ],
  steps: [
    'Die Adresse so kurz wie möglich machen, das bringt mehr als jede Gestaltung.',
    'Im Generator die Fehlerkorrektur auf H stellen, dann erst das Logo einsetzen.',
    'Das Logo auf höchstens ein Viertel der Codefläche bringen, mit weißem Rand.',
    'Als SVG herunterladen und in der endgültigen Größe auf das echte Material drucken.',
    'Mit zwei Telefonen testen, im Licht der Umgebung, in der der Code stehen wird.',
  ],
  faq: [
    { q: 'Wie groß darf das Logo sein?', a: 'Bis etwa ein Viertel der Codefläche, mit Fehlerkorrektur H. Mehr geht auf Kosten der Lesbarkeit, besonders im Druck.' },
    { q: 'Warum wird der Code mit Logo dichter?', a: 'Weil die zusätzliche Fehlerkorrektur mehr Module braucht. Bei gleicher Datenmenge ist der Code größer oder die einzelnen Module kleiner.' },
    { q: 'Kann ich den Code in Markenfarben drucken?', a: 'Ja, solange der Kontrast zwischen Modulen und Grund hoch bleibt. Dunkel auf hell, nicht hell auf dunkel.' },
    { q: 'Liest ein Code mit Logo auf jedem Telefon?', a: 'Nicht garantiert. Ältere Kameras und schlechte Beleuchtung kosten Reserve, die das Logo schon verbraucht hat. Testen ist Pflicht.' },
    { q: 'Gibt es eine Alternative zum Logo im Code?', a: 'Ja, das Logo neben den Code. Es ist immer lesbar, kostet keine Redundanz und wirkt auf einem Aufsteller genauso.' },
  ],
  sources: [
    { label: 'ISO/IEC 18004: QR-Code-Spezifikation, Fehlerkorrekturstufen', href: 'https://www.iso.org/standard/62021.html' },
  ],
  toolLinks: [
    { label: 'QR-Code mit Logo erstellen', href: '/?type=url' },
    { label: 'Vorlagen für Schilder und Aufsteller', href: '/vorlagen' },
  ],
  blogLinks: [
    { label: 'QR-Code drucken: Kontrast, Größe, Material', href: '/blog/qr-code-drucken-kontrast-groesse' },
  ],
};

const vorlagen: SeoSubPage = {
  slug: 'vorlagen',
  title: 'Vorlagen für QR-Code-Schilder',
  metaTitle: 'QR-Code Vorlagen: Schilder, Aufsteller, Etiketten',
  metaDescription:
    'Welche Vorlage zu welchem Ort passt, warum ein Rahmen die Ruhezone nicht ersetzen darf und wie aus einem Code ein Schild wird, das gescannt wird.',
  intro: [
    'Eine Vorlage löst ein anderes Problem als der Code. Der Code funktioniert oder nicht, die Vorlage entscheidet, ob jemand ihn überhaupt scannt. Ein guter Code auf einem schlecht gestalteten Zettel wird übersehen.',
    'Die Auswahl folgt dem Ort: Was hinter einer Theke steht, sieht anders aus als was an einer Tür hängt oder auf ein Produkt geklebt wird. Die fertigen Vorlagen liegen in der Galerie, diese Seite hilft bei der Wahl.',
  ],
  sections: [
    {
      title: 'Die drei Grundformen und wann sie passen',
      body: [
        'Der Aufsteller für den Tresen: A6 oder A5, mit einem Fuß, wird aus 40 bis 60 Zentimetern gelesen, Code 4 bis 5 Zentimeter. Er funktioniert an Kassen, auf Tischen, an Empfängen.',
        'Das Aushang-Schild für die Wand oder die Tür: A4 oder A5, Code 10 Zentimeter, weil aus einem bis zwei Metern gelesen wird. Es funktioniert an Eingängen, in Fluren, an Fahrzeugen.',
        'Das Etikett für Produkt, Regal oder Maschine: klein, wetterfest, Code 2 bis 3 Zentimeter. Es funktioniert überall dort, wo der Code dauerhaft an einem Gegenstand bleiben muss.',
      ],
      bullets: [
        'Tresen: Aufsteller, A6 bis A5, Code 4 bis 5 Zentimeter',
        'Wand und Tür: Aushang, A4, Code 10 Zentimeter',
        'Produkt und Regal: Etikett, Code 2 bis 3 Zentimeter, wetterfest',
      ],
    },
    {
      title: 'Was eine Vorlage leisten soll und was nicht',
      body: [
        'Eine Vorlage soll drei Dinge tun: den Code in der richtigen Größe platzieren, eine Beschriftung führen, die sagt, was passiert, und eine Ruhezone um den Code freihalten. Alles andere ist Geschmack.',
        'Was sie nicht leisten darf: den Code in eine Grafik einbetten, die bis an das Muster reicht. Vier Module Rand gehören zum Code. Ein Rahmen, der diese Zone überdeckt, ist derselbe Fehler wie ein zu kleines Druckmaß, nur schwerer zu erkennen.',
      ],
    },
    {
      title: 'Die Beschriftung entscheidet über die Scanrate',
      body: [
        'Niemand scannt einen Code, ohne zu wissen, was ihn erwartet. Der Text unter oder über dem Code ist deshalb kein Schmuck, sondern der Grund für den Scan. Drei Angaben gehören hin: was passiert, wie lange es dauert und ob etwas verlangt wird.',
        'Beispiele, die funktionieren: „Speisekarte ansehen, keine App nötig", „Bewertung abgeben, etwa 30 Sekunden", „Anleitung als PDF, 2 Seiten". Beispiele, die nicht funktionieren: „QR-Code", „Scannen Sie hier", „Willkommen".',
      ],
      bullets: [
        'Was passiert nach dem Scan',
        'Wie lange es dauert',
        'Ob eine App, ein Konto oder Daten verlangt werden',
      ],
    },
    {
      title: 'Drucken: die drei Fehler, die am häufigsten passieren',
      body: [
        'Der erste ist die Größe: Der Code wird kleiner gedruckt als geplant, weil das Layout eng wurde. Dann lieber den Text kürzen als den Code verkleinern.',
        'Der zweite ist das Material. Ein Ausdruck auf Normalpapier im Schaufenster ist nach einem Sommer vergilbt. Für alles, was länger als ein halbes Jahr hängt, gehört eine Folie, ein Laminat oder Aluverbund dazu.',
        'Der dritte ist die Lage. Ein Aufsteller hinter Glas mit Gegenlicht, ein Schild in Kniehöhe, ein Code an einer Stelle, an der Leute vorbeigehen statt stehenzubleiben. Der Code kann technisch einwandfrei sein und trotzdem nie gescannt werden.',
      ],
    },
    {
      title: 'Vorlage anpassen, ohne den Code zu beschädigen',
      body: [
        'Arbeiten Sie mit dem Code als SVG, nicht als PNG. Ein SVG lässt sich beliebig skalieren, ohne dass die Kanten weich werden, und genau das passiert bei einem PNG, das jemand im Layoutprogramm vergrößert.',
        'Platzieren Sie den Code als eigenes Objekt, nicht als Teil einer Grafik, und ändern Sie seine Proportionen nicht. Ein gestauchter oder gestreckter Code ist kein Code mehr. Wenn das Layout nicht passt, ändern Sie das Layout.',
      ],
    },
  ],
  useCases: [
    { title: 'Gastronomie', text: 'Aufsteller für den Tisch, Aushang für die Tür, Etikett für den Thekenbereich. Alle drei in derselben Gestaltung, damit sie zusammengehören.' },
    { title: 'Handwerk und Service', text: 'Der Aushang an der Tür mit Telefon und Terminbuchung, dazu ein Etikett am Gerät mit der Anleitung.' },
    { title: 'Verein', text: 'Der Aushang am Vereinsheim mit Trainingszeiten und Beitrittsformular, ein Aufsteller für Veranstaltungen.' },
    { title: 'Lager und Werkstatt', text: 'Etiketten an Regalen und Maschinen, wetterfest, mit Beschriftung, die den Inhalt nennt.' },
  ],
  steps: [
    'Den Ort bestimmen und daraus die Größe ableiten, nicht umgekehrt.',
    'Eine passende Vorlage in der Galerie wählen, statt eine neue zu bauen.',
    'Den Code als SVG einsetzen und seine Proportionen nicht verändern.',
    'Die Beschriftung schreiben: was passiert, wie lange, was wird verlangt.',
    'Einen Probedruck machen und am echten Ort mit einem echten Telefon scannen.',
  ],
  faq: [
    { q: 'Welche Größe brauche ich?', a: 'Nach Abstand: 2 bis 3 Zentimeter in der Hand, 4 bis 5 Zentimeter auf dem Tresen, 10 Zentimeter an Wand und Tür.' },
    { q: 'Kann ich die Vorlage verändern?', a: 'Ja, solange die Ruhezone von vier Modulen um den Code frei bleibt und der Code nicht gestaucht wird.' },
    { q: 'SVG oder PNG?', a: 'Immer SVG für den Druck. PNG nur für Bildschirm und Präsentation, weil es beim Vergrößern weich wird.' },
    { q: 'Wie lange hält ein Aushang draußen?', a: 'Papier hinter Glas etwa einen Sommer. Für dauerhaft: Laminat, Folie oder Aluverbund.' },
    { q: 'Gibt es fertige Vorlagen zum Download?', a: 'Ja, in der Vorlagen-Galerie. Diese Seite erklärt die Auswahl, die Galerie liefert die Dateien.' },
  ],
  toolLinks: [
    { label: 'Zur Vorlagen-Galerie', href: '/vorlagen' },
    { label: 'QR-Code mit Logo erstellen', href: '/qr-code-generator/mit-logo' },
  ],
  blogLinks: [
    { label: 'QR-Code drucken: Kontrast, Größe, Material', href: '/blog/qr-code-drucken-kontrast-groesse' },
    { label: 'QR-Codes auf Flyern und Plakaten', href: '/blog/qr-codes-flyer-plakate-drucksachen' },
  ],
};

export const TYPEN_PART_NINE = [produkt, mitLogo, vorlagen];
