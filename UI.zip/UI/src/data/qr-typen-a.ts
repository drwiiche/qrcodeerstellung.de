/**
 * Per-type landing pages under /qr-code-generator/….
 *
 * The competitor set (me-qr.com runs 57 of these in 32 languages) shows why
 * this family exists: the person searching "WLAN QR Code erstellen" wants a
 * form with the type already selected, not a homepage where a chip must be
 * clicked first. We had the generator and none of the pages.
 *
 * Deliberately not included:
 *   - wifi and menu, because both already have their own multilingual guide
 *     clusters (/wlan-qr-code, /menu-qr-code). A second page on the same intent
 *     would compete with them, so the hub links there instead.
 *   - mecard, facebook, twitter, youtube, paypal, bitcoin, pix: the generator
 *     supports them, the search volume in Germany does not justify a page yet.
 *
 * Every page describes what our generator actually writes, checked against
 * src/utils/*.ts. Where a format is a de-facto convention rather than a
 * standard, the page says so.
 */
import type { SeoHub, SeoSubPage } from './seo-pages';

const link: SeoSubPage = {
  slug: 'link',
  title: 'QR-Code für einen Link erstellen',
  metaTitle: 'Link QR-Code erstellen: URL in QR-Code umwandeln',
  metaDescription:
    'Eine Webadresse in einen QR-Code umwandeln: wie lang die URL sein darf, warum Umlaute kodiert werden müssen und welche Kantenlänge im Druck reicht.',
  intro: [
    'Der Link-Code ist der einfachste Fall und der häufigste. Im Code steht nichts als die Adresse, zum Beispiel https://example.de/speisekarte. Jede Kamera liest ihn, jede App öffnet ihn, es gibt kein Format, das scheitern kann.',
    'Genau deshalb entscheidet hier nicht die Technik, sondern die Zielseite und die Länge der Adresse. Beides sehen Sie erst, wenn Sie den Code gedruckt haben.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Die vollständige URL als reiner Text, mit https:// am Anfang. Der Code ist statisch: Die Adresse ist in die Pixel eingebrannt und ändert sich nie. Das ist der Vorteil und die Verpflichtung, denn wenn die Seite umzieht, ist jeder gedruckte Code tot.',
        'Das Protokoll gehört dazu. Ohne https:// erkennt nicht jede Kamera-App die Zeichenfolge als Adresse und bietet nur an, sie zu kopieren.',
      ],
      bullets: [
        'Kurz und stabil: example.de/karte statt example.de/veranstaltung/2026/herbst?utm_source=flyer&id=4711',
        'Kleinschreibung prüfen, Pfade sind auf den meisten Servern case-sensitive',
        'Umlaute und Leerzeichen müssen prozentkodiert sein, sonst entsteht eine Adresse, die der Server nicht kennt',
        'Keine Weiterleitung dazwischen, ein Zwischenschritt ist ein zusätzlicher Punkt, an dem es scheitern kann',
      ],
    },
    {
      title: 'Wie lang darf die Adresse sein?',
      body: [
        'Technisch passen in einen QR-Code der Version 40 mehrere tausend Zeichen. Praktisch zählt etwas anderes: Mit jedem Zeichen wächst die Modulzahl, und damit wird jeder einzelne Punkt kleiner. Bei einer Adresse von 300 Zeichen braucht der Code auf einem Flyer deutlich mehr Fläche als bei 30 Zeichen, um noch lesbar zu sein.',
        'Als Arbeitsregel gilt: unter 100 Zeichen ist unkritisch, bis 200 Zeichen geht es mit ausreichender Größe, darüber sollte man kürzen. Ein Kurzpfad auf der eigenen Domain löst das besser als ein Fremdanbieter, weil die Adresse dann Ihnen gehört.',
      ],
    },
    {
      title: 'Welche Größe braucht der Link-Code?',
      body: [
        'Die Kantenlänge richtet sich nach dem Leseabstand, nicht nach dem Geschmack. Für eine Handreichung von 20 bis 30 Zentimetern reichen 2,5 Zentimeter. Auf einem Tischaufsteller mit 50 Zentimetern Abstand sind es 4 bis 5 Zentimeter, auf einem Aushang in ein bis zwei Metern Abstand 10 bis 15 Zentimeter.',
        'Bei langen Adressen erhöhen Sie den Wert um etwa ein Drittel, weil das Muster dichter wird. Und: Ruhezone von vier Modulen frei halten, also ringsum keine Grafik, kein Text, kein Rahmen direkt am Muster.',
      ],
    },
    {
      title: 'Wann der Link-Code die falsche Wahl ist',
      body: [
        'Wenn die Zielseite sich ändern muss, ohne dass der Code neu gedruckt werden kann. Dann braucht es einen dynamischen Code mit Weiterleitung, und der kostet Unabhängigkeit: Der Anbieter dazwischen kann die Weiterleitung abschalten oder abrechnen.',
        'Wenn die Aktion eine App öffnen soll, ist ein Link nicht das beste Format. Für WLAN, Kontakte, Telefonnummern und Zahlungen gibt es eigene Typen, die der Scanner direkt versteht und nicht erst über den Browser schickt.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Speisekarte am Tisch',
      text: 'Kurze Adresse auf die Seite, die sich aktualisieren lässt, Aufsteller mit 4 Zentimetern Kantenlänge. Der Code bleibt gültig, solange die Adresse bleibt.',
    },
    {
      title: 'Aufsteller auf der Messe',
      text: 'Ein Link auf die Terminseite oder das Datenblatt. Wichtig ist die Zielseite ohne Anmeldung, sonst bricht der Kontakt an der Login-Maske ab.',
    },
    {
      title: 'Etikett auf einem Produkt',
      text: 'Der Link gehört auf eine dauerhaft erreichbare Seite, nicht auf eine Kampagnen-URL mit Ablaufdatum. Produkte überleben Kampagnen.',
    },
  ],
  steps: [
    'Zielseite aufrufen und die Adresse kopieren, die in der Adresszeile steht, ohne Tracking-Parameter.',
    'Adresse kürzen, falls sie über 200 Zeichen hat, am besten als Kurzpfad auf der eigenen Domain.',
    'Typ „Webseite" wählen oder direkt über den Link öffnen, Adresse einfügen, Code erzeugen.',
    'Als SVG herunterladen, wenn gedruckt wird, als PNG nur für Bildschirm und Präsentation.',
    'Auf dem gedruckten Material in typischer Umgebung scannen, nicht am Monitor.',
  ],
  faq: [
    {
      q: 'Kann ich die Adresse im Code später ändern?',
      a: 'Nein, ein statischer Code enthält die Adresse fest. Wer ändern will, braucht einen dynamischen Code mit Weiterleitung über einen Dienst, und bezahlt dafür mit Abhängigkeit.',
    },
    {
      q: 'Warum sollte die URL kurz sein?',
      a: 'Weil jede zusätzliche Zeichenfolge das Muster dichter macht. Bei gleicher Druckgröße wird der Code schwerer lesbar, bei gleicher Lesbarkeit muss er größer gedruckt werden.',
    },
    {
      q: 'Funktioniert ein Link-Code auch offline?',
      a: 'Der Code wird gelesen, die Seite nicht geladen. Für Inhalte ohne Netz ist der Typ Freitext die richtige Wahl, weil der Text direkt im Code steht.',
    },
    {
      q: 'Brauche ich eine App zum Scannen?',
      a: 'Nein. Ab iOS 11 liest die Kamera QR-Codes im Sucher, Android bietet die Erkennung in der Kamera-App und in den Schnelleinstellungen. Eine Zusatz-App ist nicht nötig.',
    },
  ],
  toolLinks: [
    { label: 'Link-QR-Code erstellen', href: '/?type=url' },
    { label: 'Druckgrößen und Kontrast', href: '/qr-codes-auf' },
  ],
  blogLinks: [
    { label: 'Statisch oder dynamisch: was nach dem Druck noch geht', href: '/blog/dynamische-vs-statische-qr-codes' },
  ],
};

const vcard: SeoSubPage = {
  slug: 'vcard',
  title: 'vCard-QR-Code für die Visitenkarte',
  metaTitle: 'vCard QR-Code erstellen: Kontaktdaten auf der Karte',
  metaDescription:
    'Kontaktdaten als vCard in einem QR-Code: Versionsunterschiede, welche Felder iOS und Android wirklich übernehmen und warum ein Foto den Code sprengt.',
  intro: [
    'Ein vCard-Code ersetzt das Abtippen einer Visitenkarte: Der Scan öffnet den Kontakt-Dialog des Telefons, vorbefüllt mit Name, Nummer, Firma und Adresse. Der Nutzer bestätigt nur noch.',
    'Das Format ist ein alter Standard mit zwei Versionen, und genau daran scheitern die meisten Karten, die nicht funktionieren.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Ein vCard-Block nach RFC 6350, bei uns in Version 3.0. Die sieht so aus: BEGIN:VCARD, VERSION:3.0, dann die Felder N, FN, ORG, TITLE, TEL, EMAIL, ADR, URL, NOTE, am Ende END:VCARD.',
        'Version 3.0 ist bewusst gewählt. Version 4.0 ist sauberer spezifiziert, wird aber von älteren Android-Adressbüchern und manchen Scanner-Apps nur teilweise gelesen. 3.0 versteht jedes Gerät, das in den letzten fünfzehn Jahren gebaut wurde.',
      ],
      bullets: [
        'N und FN sind Pflicht, ohne Namen zeigt das Telefon keinen Kontakt an',
        'Telefonnummern mit Ländervorwahl, also +49 statt 0151',
        'Ein Feld pro Information, nicht alles in NOTE stopfen',
        'Foto weglassen, ein eingebettetes Bild vervielfacht die Datenmenge',
      ],
    },
    {
      title: 'Warum ein Foto den Code unbrauchbar macht',
      body: [
        'Ein eingebettetes JPEG landet Base64-kodiert im selben Code. Aus einer Karte mit 600 Zeichen werden so schnell 20.000 Zeichen, und die Modulzahl explodiert. Auf einer Visitenkarte von 85 Millimetern Breite ist das nicht mehr lesbar zu bekommen.',
        'Wer ein Gesicht zeigen will, setzt es auf die Karte und lässt es aus dem Code. Bei uns im Generator ist das Feld dafür nicht vorgesehen, und das ist Absicht.',
      ],
    },
    {
      title: 'Wie groß muss der Code auf der Karte sein?',
      body: [
        'Eine Visitenkarte ist 85 mal 55 Millimeter groß, und der Code konkurriert mit Logo und Anschrift. Bei einem Leseabstand von 20 Zentimetern genügen 20 Millimeter Kantenlänge, angenehm sind 22 bis 25 Millimeter.',
        'Wichtig ist der Kontrast auf dem Kartenmaterial. Matt und hell drucken, nicht glänzend. Bei dunkler Karte mit hellem Aufdruck ist der Code für viele Kameras unlesbar, auch wenn er auf dem Entwurf gut aussieht.',
      ],
    },
    {
      title: 'vCard oder MECARD?',
      body: [
        'MECARD ist das ältere, kompaktere Format und enthält weniger Felder. Es ist kürzer und auf kleinen Flächen im Vorteil, aber es kennt keine Abteilungs- oder Titelangaben und wird von weniger Scanner-Apps vollständig ausgewertet.',
        'Für eine Visitenkarte ist vCard die sichere Wahl. MECARD lohnt sich, wenn der Platz wirklich knapp ist und nur Name, Nummer und E-Mail gebraucht werden.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Klassische Visitenkarte',
      text: 'Handwerksbetrieb, Beratung, Außendienst. Der Code ersetzt das Abtippen und sorgt dafür, dass die Nummer wirklich im Telefon landet statt in einer Schublade.',
    },
    {
      title: 'Mitarbeiterausweis und Namensschild',
      text: 'Ein Code auf der Rückseite des Schilds, mit Name und Durchwahl. Bei Veranstaltungen mit vielen Fremden der schnellste Weg zum Kontakt.',
    },
    {
      title: 'Fahrzeugbeschriftung',
      text: 'Der Code führt direkt zum Ansprechpartner im Betrieb, nicht zur Zentrale. Für Außendienst und Lieferfahrzeuge der Unterschied zwischen Rückruf und Rückfrage.',
    },
  ],
  steps: [
    'Typ „Visitenkarte" wählen und die Felder füllen, die auf der Karte stehen.',
    'Telefonnummern mit +49 und ohne Leerzeichen eingeben, das Telefon normalisiert sie sonst unterschiedlich.',
    'Code erzeugen, als SVG herunterladen und mit mindestens 20 Millimetern Kantenlänge platzieren.',
    'Auf der gedruckten Karte mit einem iPhone und einem Android-Gerät testen, beide ins Adressbuch übernehmen lassen.',
  ],
  faq: [
    {
      q: 'Welche vCard-Version ist die richtige?',
      a: 'Für Karten, die von jedem Gerät gelesen werden sollen, Version 3.0. Version 4.0 ist strenger spezifiziert, wird aber von älteren Android-Adressbüchern und manchen Scanner-Apps nur unvollständig übernommen.',
    },
    {
      q: 'Warum erscheint der Kontakt doppelt im Telefon?',
      a: 'Weil das Adressbuch beim zweiten Scan nicht erkennt, dass es derselbe Kontakt ist. Das passiert, wenn N und FN unterschiedlich aufgebaut sind. Name in beiden Feldern identisch halten hilft.',
    },
    {
      q: 'Kann ich das Firmenlogo in den Code legen?',
      a: 'Ja, mit hoher Fehlerkorrektur, aber es kostet Lesbarkeit. Bei 20 Millimetern auf einer Visitenkarte ist der Platz zu knapp, dort sollte das Logo neben dem Code stehen.',
    },
    {
      q: 'Enthält der Code personenbezogene Daten?',
      a: 'Ja, alles, was im vCard-Block steht, ist im Klartext lesbar. Wer eine Karte verteilt, veröffentlicht diese Angaben, deshalb gehören private Nummern nicht hinein.',
    },
  ],
  toolLinks: [
    { label: 'vCard-QR-Code erstellen', href: '/?type=vcard' },
    { label: 'QR-Codes auf Visitenkarten', href: '/qr-codes-auf/visitenkarten' },
  ],
  blogLinks: [{ label: 'vCard-QR-Code: Felder, Format, Fehler', href: '/blog/vcard-qr-code-visitenkarte' }],
};

const girocode: SeoSubPage = {
  slug: 'girocode',
  title: 'GiroCode erstellen: Überweisung per QR-Code',
  metaTitle: 'GiroCode erstellen: SEPA-Überweisung per QR-Code',
  metaDescription:
    'Der EPC-GiroCode nach EPC069-12: welche Zeilen er enthält, was der Betrag bewirkt und welche Banken ihn in der App ausführen.',
  intro: [
    'Ein GiroCode ist eine vorausgefüllte Überweisung in einem QR-Code. Der Kunde scannt, die Banking-App zeigt Empfänger, IBAN, Betrag und Verwendungszweck, er bestätigt mit PIN oder Fingerabdruck. Abtippen entfällt, Zahlendreher entfallen.',
    'Das Format ist kein deutscher Sonderweg, sondern eine Spezifikation des European Payments Council: EPC069-12. Sie legt Zeile für Zeile fest, was im Code stehen darf.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Der Inhalt ist eine Liste von Zeilen, jede Zeile ein Feld, in fester Reihenfolge. Die erste Zeile ist immer BCD, danach folgen Versionsnummer, Zeichensatz, Überweisungsart, optional die BIC, der Empfängername, die IBAN, der Betrag und der Verwendungszweck.',
        'Der Betrag darf leer bleiben. Dann öffnet die App das Feld zum Ausfüllen, was bei Spenden und offenen Rechnungen gewollt ist. Ist er gefüllt, steht er in Euro mit Punkt als Dezimaltrenner.',
      ],
      bullets: [
        'Zeile 1: BCD als Kennung des Formats',
        'Empfängername höchstens 70 Zeichen, IBAN ohne Leerzeichen',
        'Betrag als EUR mit Punkt, zum Beispiel 149.90',
        'Verwendungszweck höchstens 140 Zeichen',
        'BIC nur nötig, wenn die IBAN nicht aus dem SEPA-Raum stammt',
      ],
    },
    {
      title: 'Was der Betrag verändert',
      body: [
        'Mit Betrag ist der Code eine Zahlungsaufforderung mit festem Ziel. Das ist für Rechnungen und Beiträge richtig, weil es Rückfragen vermeidet. Ohne Betrag ist er ein Zahlungsangebot, etwa für Spendenboxen oder Trinkgeld.',
        'Ein Nachteil des festen Betrags: Bei Teilzahlung oder abweichendem Betrag muss der Nutzer das Feld in der App überschreiben. Das können nicht alle Banking-Apps gleich gut.',
      ],
    },
    {
      title: 'Welche Apps führen den Code aus?',
      body: [
        'Die Sparkassen-App, VR Banking, Commerzbank, Deutsche Bank, N26, DKB, ING und die meisten anderen deutschen Banking-Apps erkennen das Format und füllen das Überweisungsformular vor. Ein Ausführen ohne Bestätigung findet nicht statt, der Nutzer behält die Kontrolle.',
        'Was nicht geht: Der Code löst keine Lastschrift aus und ersetzt kein Mandat. Er ist eine Einzelüberweisung, mehr nicht.',
      ],
    },
    {
      title: 'Größe und Platzierung auf der Rechnung',
      body: [
        'Der GiroCode gehört neben den Zahlbetrag, nicht in die Fußzeile. Bei einem Leseabstand von 30 Zentimetern reichen 2,5 Zentimeter Kantenlänge, auf einem Aufsteller für den Tresen sollten es 4 Zentimeter sein.',
        'Der Code muss dunkel auf hell stehen. Auf einer Rechnung mit farbigem Kopfbalken also nicht in den Balken legen, sondern in den weißen Bereich daneben. Ein Test mit zwei verschiedenen Banking-Apps vor dem Versand ist Pflicht, weil manche Apps strenger prüfen als andere.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Rechnung mit Zahlungsziel',
      text: 'Betrag und Verwendungszweck vorbelegt, der Kunde zahlt am Tag des Rechnungseingangs statt am Wochenende danach.',
    },
    {
      title: 'Vereinsbeitrag',
      text: 'Der Code auf dem Anschreiben, mit Mitgliedsnummer im Verwendungszweck. Das erspart die halbe Beitragsverwaltung.',
    },
    {
      title: 'Spendenaufruf',
      text: 'Betrag leer lassen, damit Spender selbst entscheiden. Auf Flyern und Plakaten mit 4 Zentimetern Kantenlänge.',
    },
  ],
  steps: [
    'Empfängername exakt so eintragen, wie er beim Konto hinterlegt ist, das erleichtert den Abgleich.',
    'IBAN ohne Leerzeichen einfügen, BIC nur bei Bedarf.',
    'Betrag nur dann setzen, wenn er feststeht. Dezimaltrenner ist der Punkt.',
    'Code erzeugen, als SVG herunterladen und in die Rechnungsvorlage neben den Zahlbetrag setzen.',
    'Mit zwei Banking-Apps scannen, bevor die Rechnung rausgeht.',
  ],
  faq: [
    {
      q: 'Ist der GiroCode ein deutscher Standard?',
      a: 'Nein, er kommt vom European Payments Council und heißt offiziell EPC QR Code, Spezifikation EPC069-12. Er funktioniert im gesamten SEPA-Raum, deutsche Banking-Apps unterstützen ihn flächendeckend.',
    },
    {
      q: 'Kann der Kunde den Betrag ändern?',
      a: 'In den meisten Apps ja, das Feld ist editierbar. Bei festen Forderungen sollte man den Betrag trotzdem setzen, weil es Fehler vermeidet.',
    },
    {
      q: 'Ersetzt der Code die Lastschrift?',
      a: 'Nein. Er löst eine einzelne Überweisung aus. Für wiederkehrende Zahlungen bleibt das Lastschriftmandat der passende Weg.',
    },
    {
      q: 'Warum erkennt eine App den Code nicht?',
      a: 'Meistens wegen Zeilenreihenfolge oder Zeichensatz, seltener wegen der Druckgröße. Ein mit einer anderen App erzeugter Code lässt sich zum Gegenprüfen scannen.',
    },
  ],
  toolLinks: [
    { label: 'SEPA GiroCode erstellen', href: '/?type=sepa' },
    { label: 'E-Rechnung: was der Code dort darf', href: '/standards/erechnung' },
  ],
  blogLinks: [{ label: 'GiroCode im Detail: Aufbau und Fehlerquellen', href: '/blog/sepa-girocode-qr-code-erstellen' }],
};

const whatsapp: SeoSubPage = {
  slug: 'whatsapp',
  title: 'WhatsApp-QR-Code erstellen',
  metaTitle: 'WhatsApp QR-Code erstellen: Chat ohne Nummer speichern',
  metaDescription:
    'Ein Code, der einen WhatsApp-Chat öffnet, ohne dass die Nummer ins Adressbuch muss. Mit Ländervorwahl, vorbereiteter Nachricht und den Grenzen des wa.me-Links.',
  intro: [
    'Ein WhatsApp-Code öffnet den Chat mit einer Nummer, ohne dass der Kunde sie speichern muss. Das ist der ganze Trick: Die Hürde zwischen Interesse und erster Nachricht fällt weg.',
    'Technisch steckt kein WhatsApp-Format dahinter, sondern ein normaler Link auf wa.me. Das hat Folgen für die Grenzen des Verfahrens.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Eine Adresse der Form https://wa.me/4915112345678, optional mit einem Text hinter ?text=. Der Link öffnet WhatsApp und den Chat mit genau dieser Nummer. Die Nummer steht ohne Plus und ohne führende Null, also 49 für Deutschland und dann die Nummer ohne die erste 0.',
        'Der optionale Text ist der interessantere Teil: Er erscheint im Eingabefeld, und der Kunde muss nur noch auf Senden tippen. „Hallo, ich interessiere mich für den Kostenvoranschlag" senkt die Hemmschwelle deutlich mehr als ein leeres Feld.',
      ],
      bullets: [
        'Ländervorwahl ohne Plus, deutsche Nummern beginnen mit 49',
        'Keine Leerzeichen, keine Bindestriche, keine Klammern',
        'Texte mit Umlauten werden kodiert, das übernimmt der Generator',
        'Die Nummer muss bei WhatsApp registriert sein, sonst führt der Link ins Leere',
      ],
    },
    {
      title: 'Was der Link nicht kann',
      body: [
        'Er öffnet keinen Gruppenchat, keine Broadcast-Liste und kein Katalog. Wer eine Gruppe anbieten will, braucht den Einladungslink aus der Gruppe selbst und kann ihn als Link-Code abbilden.',
        'Er ersetzt auch keine Zustimmung. Wer eine Nummer druckt, veröffentlicht sie. Bei dienstlichen Nummern ist das gewollt, bei privaten Nummern selten.',
      ],
    },
    {
      title: 'Warum der Code auf Papier wirkt',
      body: [
        'Der Kunde muss nichts installieren, weil WhatsApp auf dem Gerät schon liegt. Er muss nichts speichern, weil der Link direkt in den Chat führt. Es gibt keinen Login und kein Formular, das ausgefüllt werden müsste.',
        'Das ist im Handwerk und im lokalen Handel der kürzeste Weg von einem Flyer zu einer Anfrage. Auf dem Fahrzeug, auf dem Aufsteller und auf dem Angebot funktioniert er gleich.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Bei 30 Zentimetern Abstand reichen 2,5 Zentimeter. Auf dem Fahrzeug, wo aus ein bis zwei Metern gescannt wird, sollten es 8 bis 10 Zentimeter sein, und die Fläche muss sauber und plan sein, sonst bricht das Muster beim Waschen auf.',
        'Ein Wort unter dem Code erhöht die Scanrate messbar: „WhatsApp öffnen" oder „Frage per WhatsApp". Ohne Beschriftung wird ein Code auf einem Flyer häufig übersehen.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Handwerksbetrieb',
      text: 'Der Code auf dem Angebot führt in den Chat mit dem Büro. Kunden antworten schneller als per E-Mail, und Rückfragen bleiben beim richtigen Auftrag.',
    },
    {
      title: 'Ladengeschäft',
      text: 'Aufsteller mit der Nummer des Ladens, für Fragen zu Beständen. Kein Kunde muss mehr anrufen und in eine Warteschlange.',
    },
    {
      title: 'Selbstständige ohne Empfang',
      text: 'Eine Nummer, ein Chat, kein Postfach, das nur wöchentlich gelesen wird. Wichtig ist die Zusage, wann geantwortet wird.',
    },
  ],
  steps: [
    'Nummer in internationaler Schreibweise vorbereiten, 49 und dann ohne führende Null.',
    'Typ „WhatsApp" wählen und die Nummer eintragen.',
    'Begrüßungstext formulieren, kurz und ohne Anrede, weil der Kunde ihn selbst abschickt.',
    'Code erzeugen und als SVG im Layout platzieren, mit Beschriftung darunter.',
    'Selbst scannen und prüfen, dass der Chat mit dem richtigen Absender öffnet.',
  ],
  faq: [
    {
      q: 'Muss die Nummer bei WhatsApp registriert sein?',
      a: 'Ja. Der Link öffnet den Chat mit einer Nummer, die bei WhatsApp aktiv sein muss. Sonst zeigt die App eine Fehlermeldung und der Kunde steht wieder vor einer Hürde.',
    },
    {
      q: 'Geht das auch mit einer Festnetznummer?',
      a: 'Nur, wenn die Nummer in einem WhatsApp-Business-Konto aktiv ist. Eine gewöhnliche Festnetzleitung ohne WhatsApp-Konto führt ins Leere.',
    },
    {
      q: 'Ist der Code datenschutzrechtlich problematisch?',
      a: 'Die Nummer steht im Klartext im Code, wer sie druckt, veröffentlicht sie. Für geschäftliche Nummern ist das üblich, für private Nummern sollte man es lassen.',
    },
  ],
  toolLinks: [
    { label: 'WhatsApp-QR-Code erstellen', href: '/?type=whatsapp' },
    { label: 'QR-Codes für Unternehmen', href: '/qr-codes-fuer/unternehmen' },
  ],
  blogLinks: [{ label: 'QR-Codes im Handwerk: lokal sichtbar werden', href: '/blog/qr-codes-handwerk-lokal' }],
};

const instagram: SeoSubPage = {
  slug: 'instagram',
  title: 'Instagram-QR-Code erstellen',
  metaTitle: 'Instagram QR-Code: Profil per Code öffnen lassen',
  metaDescription:
    'Warum der eigene Instagram-Code der App nicht auf ein Schild gehört, was stattdessen darauf steht und wie der Code im Laden funktioniert.',
  intro: [
    'Ein Instagram-Code führt Gäste auf ein Profil, ohne dass sie den Namen tippen. Für lokale Geschäfte ist das ein Weg, aus einem Besuch einen Follower zu machen.',
    'Ein wichtiger Unterschied vorweg: Instagram hat einen eigenen Profil-Code in der App. Der ist zum Zeigen auf dem Handy gedacht, nicht zum Drucken.',
  ],
  sections: [
    {
      title: 'Warum der App-Code nicht auf das Schild gehört',
      body: [
        'Der Instagram-Code in der App zeigt ein Muster, das die Instagram-Kamera liest. Fremde Kamera-Apps und Android-Geräte ohne Instagram erkennen es nicht immer zuverlässig, und der Code lässt sich in der App jederzeit neu erzeugen. Ein Aufkleber mit dem alten Muster wird damit wertlos.',
        'Ein QR-Code auf instagram.com/profilname ist dagegen eine gewöhnliche Adresse. Jede Kamera liest ihn, und der Name im Pfad bleibt stabil, solange der Profilname sich nicht ändert.',
      ],
      bullets: [
        'Gedruckt wird die Profiladresse, nicht das In-App-Muster',
        'Profilname ohne @ in den Pfad, also instagram.com/werkstatt.nord',
        'Profilnamen nicht ändern, ohne die gedruckten Codes zu tauschen',
        'Auf dem Schild dazuschreiben, was dort zu sehen ist',
      ],
    },
    {
      title: 'Was den Unterschied zwischen Scan und Follower macht',
      body: [
        'Der Code bringt den Gast auf das Profil, nicht zum Folgen. Was danach passiert, entscheidet das Profil: ein klares erstes Bild, drei Beiträge, die zeigen, was es hier gibt, und ein Link, der zur richtigen Stelle führt.',
        'Ein Code auf dem Tisch ohne Grund zu scannen wird ignoriert. Der Code mit einer Zeile daneben („Heute Abend: was wir kochen") wird gescannt, weil ein Versprechen daran hängt.',
      ],
    },
    {
      title: 'Größe, Platzierung und Material',
      body: [
        'Am Tisch 2,5 bis 3 Zentimeter, am Fenster und auf Plakaten 8 bis 15 Zentimeter. Immer dunkel auf hell, immer mit Ruhezone, nie über eine glänzende Fläche gespannt.',
        'Im Gastraum sammelt sich Fett und Feuchtigkeit auf Aufstellern. Ein Ausdruck unter Klarsichtfolie ist nach zwei Wochen unlesbar. Matt laminierte Karten oder Klebefolie für den Außenbereich halten deutlich länger.',
      ],
    },
    {
      title: 'Die Zeile, die aus einem Scan einen Follower macht',
      body: [
        'Ein Code ohne Kontext wird nicht gescannt. Es gibt keinen Grund dafür, und niemand scannt aus Langeweile. Ein Code mit einer Zeile daneben hat einen Grund: „Heute im Angebot" oder „So sieht es bei uns aus" funktioniert, weil etwas Konkretes versprochen wird.',
        'Was nicht funktioniert: „Folge uns auf Instagram". Das ist eine Bitte ohne Gegenwert. Wer den Code aufstellt, sollte die Zeile so schreiben, als wäre sie eine Empfehlung an einen Gast, nicht ein Aufruf an ein Publikum.',
      ],
      bullets: [
        'Zeile über den Code, konkreter Anlass, keine Aufforderung',
        'Profilbild und erste drei Beiträge vor dem Aufstellen prüfen',
        'Kein Hinweis auf „täglich neue Inhalte", wenn es nicht stimmt',
        'Aufstellort dort, wo gewartet wird, nicht am Ausgang',
      ],
    },
  ],
  useCases: [
    {
      title: 'Gastronomie',
      text: 'Aufsteller mit dem heutigen Gericht und einem Code zum Profil. Das Profil zeigt die Karte und die Öffnungszeiten, die sich ändern dürfen.',
    },
    {
      title: 'Einzelhandel',
      text: 'Am Regal oder an der Kasse, für Neuheiten, die nicht im Laden stehen. Der Code führt zum Profil und von dort zum Shop.',
    },
    {
      title: 'Studio und Friseur',
      text: 'Auf der Preisliste, damit Interessierte vorher sehen, wie gearbeitet wird. Das ersetzt die Frage nach Referenzen.',
    },
  ],
  steps: [
    'Profilnamen in der App prüfen und exakt übernehmen.',
    'Typ „Instagram" wählen, den Namen ohne @ eintragen.',
    'Code erzeugen und als SVG herunterladen.',
    'Mit Beschriftung drucken, die sagt, was im Profil zu sehen ist.',
    'Auf einem fremden Telefon ohne Instagram testen, was dann passiert.',
  ],
  faq: [
    {
      q: 'Kann ich den Profil-Code aus der Instagram-App drucken?',
      a: 'Technisch ja, praktisch nicht empfehlenswert. Er lässt sich in der App neu erzeugen, und nicht jede Kamera-App liest ihn. Die Profiladresse als gewöhnlicher QR-Code ist stabiler.',
    },
    {
      q: 'Was passiert ohne installierte Instagram-App?',
      a: 'Der Browser öffnet die Profilseite. Instagram zeigt dort eine Anmelde- oder Installationsmaske, je nach Gerät und Einstellung. Der Weg zum Profil bleibt aber sichtbar.',
    },
    {
      q: 'Darf der Code auf Produkten stehen?',
      a: 'Ja, solange er auf eine eigene Seite führt und nicht als Gewinnspiel getarnt ist. Wer Follower per Code kauft, verstößt gegen die Instagram-Bedingungen, nicht gegen das Wettbewerbsrecht.',
    },
  ],
  toolLinks: [
    { label: 'Instagram-QR-Code erstellen', href: '/?type=instagram' },
    { label: 'QR-Codes für die Gastronomie', href: '/qr-codes-fuer/unternehmen/gastronomie' },
  ],
  blogLinks: [],
};

const email: SeoSubPage = {
  slug: 'email',
  title: 'E-Mail-QR-Code erstellen',
  metaTitle: 'E-Mail QR-Code erstellen: mailto mit Betreff',
  metaDescription:
    'Ein Code, der eine neue E-Mail mit Empfänger, Betreff und Text öffnet. Wann mailto funktioniert, wann es scheitert und warum ein Formular oft besser ist.',
  intro: [
    'Ein E-Mail-Code öffnet das Mailprogramm mit einer neuen Nachricht, Empfänger und auf Wunsch Betreff und Text bereits eingetragen. Für Rückfragen, Bewerbungen und Bestellungen ist das ein sehr kurzer Weg.',
    'Die Technik dahinter ist ein mailto-Link, und der hat eine Eigenheit: Er braucht ein eingerichtetes Mailkonto auf dem Gerät.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Ein Link der Form mailto:info@example.de, optional mit ?subject= und &body=. Betreff und Text werden prozentkodiert, damit Umlaute und Zeilenumbrüche ankommen.',
        'Ein vorbereiteter Betreff ist der wichtigste Teil, weil er die Zuordnung erledigt: „Anfrage Aufsteller" landet im richtigen Postfach und muss nicht einsortiert werden. Ein vorbereiteter Text sollte kurz sein, weil der Kunde ihn ohnehin überschreibt.',
      ],
      bullets: [
        'Empfängeradresse vollständig, keine Anzeigenamen',
        'Betreff so wählen, dass er im Postfach zuordenbar ist',
        'Textkörper höchstens ein bis zwei Zeilen',
        'Mehrere Empfänger sind erlaubt, bringen aber mehr Spam-Risiko',
      ],
    },
    {
      title: 'Wann mailto scheitert',
      body: [
        'Wenn auf dem Gerät kein Mailkonto eingerichtet ist. Das ist bei jüngeren Nutzern häufiger als erwartet: Mail läuft im Browser, die App hat kein Konto. Dann führt der Link zu einer Fehlermeldung oder ins Leere.',
        'Zweitens bei Webmail-Nutzern, deren Browser den Link nicht an einen Anbieter übergibt. Drittens bei Unternehmensgeräten, auf denen der Administrator externe Mailprogramme gesperrt hat.',
      ],
    },
    {
      title: 'Wann ein Formular die bessere Wahl ist',
      body: [
        'Wenn Sie wissen müssen, dass die Nachricht angekommen ist. Ein Formular auf der eigenen Seite liefert eine Bestätigung und eine Serverkopie, mailto liefert nichts davon. Bei Bewerbungen, Reklamationen und allem mit Fristen ist das Formular besser.',
        'Der E-Mail-Code bleibt für alles richtig, was reine Kontaktaufnahme ist: Rückfrage, Terminwunsch, kurze Bestellung. Er ist schneller als jedes Formular und braucht keine Datenverarbeitung auf Ihrer Seite.',
      ],
    },
    {
      title: 'Der Betreff entscheidet über die Ablage',
      body: [
        'Ein Postfach mit 200 Mails am Tag sortiert sich über den Betreff, nicht über den Absender. Wer den Betreff vorgibt, lenkt die Mail in die richtige Ablage, bevor sie gelesen wird.',
        'Bewährt sind Betreffzeilen mit einem festen Präfix und einem Platzhalter, den der Kunde ergänzt: „Aufsteller-Anfrage: " oder „Bewerbung: Name". Ein Präfix wie „Anfrage" allein reicht nicht, weil es in jedem Postfach schon zwanzig Mal vorkommt.',
      ],
      bullets: [
        'Fester Anfang, offenes Ende: Präfix plus das, was der Kunde ergänzt',
        'Objekt benennen, nicht den Vorgang: „Speisekarte Aufsteller" statt „Anfrage"',
        'Kein Fragezeichen im Betreff, das landet im Spamfilter mancher Postfächer',
        'Die Adresse selbst sichtbar lassen, sie ist der eigentliche Inhalt',
      ],
    },
  ],
  useCases: [
    {
      title: 'Bewerbung im Schaufenster',
      text: 'Ein Plakat mit dem Code, Betreff bereits „Bewerbung". Die Mail landet ohne Tippfehler in der richtigen Ablage.',
    },
    {
      title: 'Angebot und Rechnung',
      text: 'Der Code neben den Kontaktdaten, mit Betreff und Vertragsnummer. Das erspart Rückfragen zur Zuordnung.',
    },
    {
      title: 'Verein und Ehrenamt',
      text: 'Anmeldung per Mail statt per Formular, weil niemand die Vereinsseite pflegen will. Der Code steht auf dem Flyer und funktioniert jahrelang.',
    },
  ],
  steps: [
    'Empfängeradresse prüfen, sie bleibt dauerhaft sichtbar.',
    'Betreff festlegen, der die Zuordnung erlaubt.',
    'Typ „E-Mail" wählen und Felder füllen.',
    'Code erzeugen und mit einem Hinweis drucken, was passiert: „Mail schreiben".',
    'Auf einem Telefon mit Konto und einem ohne testen.',
  ],
  faq: [
    {
      q: 'Öffnet der Code wirklich das Mailprogramm?',
      a: 'Ja, wenn ein Mailkonto eingerichtet ist und der Link an eine App übergeben wird. Ohne Konto oder bei gesperrten Mailprogrammen endet der Weg in einer Fehlermeldung.',
    },
    {
      q: 'Kann der Kunde Betreff und Text ändern?',
      a: 'Ja, beides ist nur vorbefüllt. Deshalb kurz halten und den Betreff so formulieren, dass er auch nach einer Änderung noch passt.',
    },
    {
      q: 'Ist der Code DSGVO-konform?',
      a: 'Er verarbeitet selbst keine Daten, die Adresse steht aber im Klartext im Code. Wer eine geschäftliche Adresse druckt, veröffentlicht sie, was bei info@ üblich ist.',
    },
  ],
  toolLinks: [
    { label: 'E-Mail-QR-Code erstellen', href: '/?type=email' },
    { label: 'QR-Code und Recht', href: '/qr-code-recht' },
  ],
  blogLinks: [],
};

export const TYPEN_PART_ONE = [link, vcard, girocode, whatsapp, instagram, email];
