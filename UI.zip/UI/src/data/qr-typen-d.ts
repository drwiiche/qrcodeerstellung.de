/**
 * Wave 3: the answer pages.
 *
 * The competitor set runs 25 "best / top" listicles. They are how a tool gets
 * named when somebody asks an assistant for a recommendation, and we had none.
 *
 * The rules these three pages follow, because a comparison page is the easiest
 * place on a website to become dishonest:
 *   - no claim about a named competitor that we have not verified. Prices,
 *     limits and features change weekly, so the pages compare *models* (static,
 *     dynamic, subscription, shortener, self-hosted) rather than companies;
 *   - the self-assessment says where we lose. A page that concludes we win every
 *     criterion is an advertisement, not a comparison;
 *   - every criterion is something the reader can test in five minutes.
 */
import type { SeoSubPage } from './seo-pages';

const kostenlos: SeoSubPage = {
  slug: 'kostenlos',
  title: 'QR-Code-Generator kostenlos und ohne Anmeldung',
  metaTitle: 'QR-Code-Generator kostenlos: ohne Konto, ohne Ablauf',
  metaDescription:
    'Was hier kostenlos ist und was nicht: 20 Typen, PNG und SVG, kein Konto, kein Ablaufdatum. Dazu woran man kostenlose Angebote erkennt, die es nicht sind.',
  intro: [
    'Kostenlos heißt bei den meisten QR-Generatoren: kostenlos bis zu einer Grenze, die im Kleingedruckten steht. Bei uns heißt es: Der Code wird im Browser erzeugt, gehört Ihnen, und es gibt nichts, was ablaufen kann.',
    'Diese Seite sagt beides, was enthalten ist und was nicht. Die zweite Hälfte ist die wichtigere.',
  ],
  sections: [
    {
      title: 'Was hier kostenlos ist',
      body: [
        'Alle zwanzig Typen, alle Exportformate und die Vorlagen, ohne Konto, ohne Anmeldung, ohne Scanbegrenzung. Der Code entsteht im Browser, es wird kein Code auf einem Server gespeichert und keiner gezählt.',
      ],
      bullets: [
        '20 Typen: WLAN, GiroCode, vCard, Termin, Standort, WhatsApp, Telefon, SMS, Mail und weitere',
        'Download als PNG für Bildschirm und als SVG für den Druck',
        '26 Vorlagen mit fertigem Layout für Aufsteller, Etiketten und Karten',
        'Öffentliche API ohne Schlüssel, liefert SVG, PNG oder die rohe Zeichenkette',
        'Kein Ablaufdatum, keine Scanbegrenzung, keine Wasserzeichen im Code',
      ],
    },
    {
      title: 'Was hier nicht enthalten ist',
      body: [
        'Dynamische Codes mit Weiterleitung. Ein solcher Code führt nicht auf Ihr Ziel, sondern auf einen Dienst, der weiterleitet, und dieser Dienst ist das, was Geld kostet. Wir bieten ihn nicht an, also gibt es hier auch keine Seiten mit Klickstatistik.',
        'Scanstatistiken, Teamverwaltung, Kampagnenverwaltung, ein Konto mit Verlauf über Geräte hinweg, eine eigene Scan-App. Alles Funktionen, die einen Server brauchen, der mitdenkt. Unser Code ist fertig, wenn er heruntergeladen ist.',
      ],
      bullets: [
        'Keine dynamischen Codes, also keine nachträgliche Zieländerung',
        'Keine Scanstatistik und kein Besuchertracking im Code',
        'Keine Teamkonten und keine Freigabeprozesse',
        'Keine Massenverwaltung in der Oberfläche, dafür die API',
      ],
    },
    {
      title: 'Woran man kostenlose Angebote erkennt, die es nicht sind',
      body: [
        'Der Test dauert fünf Minuten und braucht kein Konto: Code erzeugen, mit einem zweiten Gerät scannen, zwei Wochen warten, denselben Code erneut scannen. Wer nach zwei Wochen eine Zahlungsseite sieht, hatte keinen kostenlosen Code, sondern eine Testphase.',
        'Die zweite Falle ist die Scanbegrenzung. Manche Dienste zählen Scans und schalten den Code nach einer Zahl ab. Das steht in den AGB, nicht auf der Preisseite. Ein Blick in den Abschnitt über Laufzeit und Kündigung genügt meistens.',
      ],
      bullets: [
        'Wasserzeichen oder Werberahmen im Code: Zeichen für ein kostenloses Konto mit Absicht',
        'Pflichtkonto vor dem Download: dann hängt der Code an einem Login',
        'Formulierung „kostenlos" ohne Angabe zur Laufzeit: nachfragen oder testen',
        'Code-Adresse führt auf eine fremde Kurzdomain: da liegt ein Dienst dazwischen',
      ],
    },
    {
      title: 'Warum ein statischer Code nicht ablaufen kann',
      body: [
        'Ein statischer Code enthält die Daten selbst. Es gibt keinen Vertrag, keine Frist und keinen Server, der ihn abschalten könnte. Er funktioniert so lange, wie ein Gerät das Muster lesen kann.',
        'Kaputt geht er nur durch zwei Dinge: Die Zielseite verschwindet, oder der Aufdruck wird zerstört. Das erste ist Ihre Entscheidung, das zweite eine Frage von Material und Druck.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Verein ohne Budget',
      text: 'Codes für WLAN im Vereinsheim, GiroCode für Beiträge und ein Standort-Code für das Sommerfest. Kein Konto, keine Kosten, kein Ablauf.',
    },
    {
      title: 'Handwerk mit vielen Aufstellern',
      text: 'Fünfzig Codes für fünfzig Geräte, alle statisch. Wer sie in einem Jahr erneut druckt, braucht sie nicht neu zu erzeugen.',
    },
    {
      title: 'Entwickler ohne Schlüssel',
      text: 'Ein GET-Request gegen die API, Antwort als SVG. Kein Account, kein Rate-Limit-Vertrag, keine Registrierung im Build-Prozess.',
    },
  ],
  steps: [
    'Typ wählen und Daten eintragen, ohne Konto.',
    'Als SVG herunterladen, wenn gedruckt wird.',
    'Code auf dem echten Material scannen, mit einem zweiten Gerät.',
    'Datei und Zielseite so ablegen, dass beides in zwei Jahren noch da ist.',
  ],
  faq: [
    {
      q: 'Ist wirklich alles kostenlos?',
      a: 'Ja, für alle zwanzig Typen und alle Exportformate. Es gibt kein Konto, keine Testphase und keine Scanbegrenzung, weil es keinen Server gibt, der etwas zählen würde.',
    },
    {
      q: 'Wo ist der Haken?',
      a: 'Es gibt keinen versteckten, aber eine Grenze: Dynamische Codes mit nachträglicher Zieländerung und Scanstatistik bieten wir nicht an. Wer das braucht, ist bei einem Anbieter mit Abo besser aufgehoben.',
    },
    {
      q: 'Laufen die Codes irgendwann ab?',
      a: 'Nein. Der Inhalt steckt im Muster. Der Code funktioniert, solange die Zielseite erreichbar ist und der Aufdruck lesbar bleibt.',
    },
    {
      q: 'Darf ich die Codes gewerblich nutzen?',
      a: 'Ja, ohne Lizenzbeschränkung, auch auf Produkten und in Anzeigen. Es gibt keine Zählung und keine Rückfrage.',
    },
  ],
  toolLinks: [
    { label: 'QR-Code jetzt erstellen', href: '/' },
    { label: 'API ohne Schlüssel', href: '/qr-api' },
  ],
  blogLinks: [{ label: 'Statisch oder dynamisch: der Unterschied', href: '/blog/dynamische-vs-statische-qr-codes' }],
};

const vergleich: SeoSubPage = {
  slug: 'vergleich',
  title: 'QR-Code-Generator im Vergleich',
  metaTitle: 'QR-Code-Generator Vergleich: fünf Modelle, fünf Risiken',
  metaDescription:
    'Anbieter vergleichen heißt meistens Feature-Listen vergleichen. Nützlicher ist der Vergleich der Bauformen: statisch, dynamisch, Abo, Kurzlink, selbst gehostet.',
  intro: [
    'Eine Liste mit Häkchen hilft bei der Auswahl nicht, weil inzwischen jedes Werkzeug alle Typen kann. Was wirklich unterscheidet, ist die Bauform: Wo liegen die Daten, wer kann sie abschalten, und was kostet das über fünf Jahre.',
    'Deshalb vergleicht diese Seite keine Firmen, sondern fünf Modelle, mit dem Test, mit dem Sie jedes davon in fünf Minuten prüfen können.',
  ],
  sections: [
    {
      title: 'Warum Anbieterlisten wenig taugen',
      body: [
        'Feature-Tabellen sind kopierbar und veralten schnell. Zwei Anbieter mit identischer Liste können sich in dem Punkt unterscheiden, der zählt: ob der Code nach der Testphase noch funktioniert.',
        'Dazu kommt, dass Vergleichslisten häufig von Provisionen abhängen. Das ist kein Betrug, aber es erklärt, warum in solchen Listen selten steht, wann ein Werkzeug die falsche Wahl ist.',
      ],
    },
    {
      title: 'Die fünf Modelle',
      body: [
        'Statisch: Die Daten stecken im Muster. Kein Dienst dazwischen, keine laufenden Kosten, keine Änderung nach dem Druck. Richtig für alles, was lange hängen soll.',
        'Dynamisch mit Weiterleitung: Der Code führt auf einen Dienst, der auf das eigentliche Ziel weiterleitet. Zieländerung und Statistik werden möglich, dafür hängt der gedruckte Code am Anbieter.',
        'Abo-Modell: Meist die Verpackung des dynamischen Modells. Solange gezahlt wird, funktioniert alles, danach ist die Weiterleitung abgeschaltet oder eingeschränkt.',
        'Kurzlink-Anbieter: Eine Sonderform, bei der die Kurzdomain das Produkt ist. Billig, aber die Domain gehört nicht Ihnen, und Kurzdomains werden regelmäßig abgeschaltet.',
        'Selbst gehostet oder API: Sie erzeugen die Codes selbst und hosten die Ziele. Maximale Kontrolle, maximale Verantwortung, keine Fremdabhängigkeit im gedruckten Code.',
      ],
      bullets: [
        'Statisch: Risiko ist die Zielseite, nicht der Anbieter',
        'Dynamisch: Risiko ist die Vertragslaufzeit und die Abschaltung',
        'Abo: gleiches Risiko, plus Zahlungsstrom',
        'Kurzlink: Risiko ist die fremde Domain',
        'Selbst gehostet: Risiko ist der eigene Server',
      ],
    },
    {
      title: 'Der Fünf-Minuten-Test für jeden Anbieter',
      body: [
        'Erzeugen Sie einen Code ohne Konto und ohne Zahlungsdaten. Wenn das nicht geht, ist das erste Kriterium schon entschieden.',
        'Dann: Als SVG exportieren. Ein PNG mit 500 Pixeln sieht am Bildschirm gut aus und ist im Druck unbrauchbar. Wer keinen Vektor anbietet, will nicht, dass Sie drucken.',
        'Danach: Auf einem zweiten Gerät scannen. Und in zwei Wochen noch einmal. Und schließlich die AGB auf die Wörter Laufzeit, Löschung und Begrenzung durchsuchen. Wer das nicht findet, hat das Kleingedruckte nicht gelesen, nicht gefunden.',
      ],
      bullets: [
        'Code ohne Konto möglich: ja oder nein',
        'SVG-Export vorhanden: ja oder nein',
        'Scan funktioniert nach zwei Wochen noch: Prüfen, nicht annehmen',
        'Code-Adresse ist die eigene Domain oder eine fremde',
        'Laufzeit und Löschung in den AGB benannt',
      ],
    },
    {
      title: 'Wo wir in diesem Vergleich stehen',
      body: [
        'Wir bauen ausschließlich Codes des ersten Modells. Das ist bei Druckerzeugnissen, Schildern, Etiketten, Rechnungen und WLAN-Karten die robustere Wahl, weil nichts abgeschaltet werden kann und niemand eine Rechnung schickt.',
        'Damit fehlt uns das, was das zweite und dritte Modell leisten: Zieländerung nach dem Druck, Scanstatistik, A/B-Tests, Kampagnen mit Laufzeit. Für einen Flyer mit wechselnder Aktion im nächsten Quartal sind wir die falsche Wahl, und das steht auch auf der Seite zur dynamischen Alternative.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Druckerzeugnis mit langer Laufzeit',
      text: 'Schild, Etikett, Karte, Rechnung: statisch. Der Code soll in drei Jahren noch funktionieren, und niemand will dafür jährlich zahlen.',
    },
    {
      title: 'Kampagne mit wechselndem Ziel',
      text: 'Plakat mit QR, Ziel wechselt monatlich: dynamisch. Dann ist der Anbieter dazwischen der Preis für die Flexibilität.',
    },
    {
      title: 'Produkt mit Seriennummer',
      text: 'Ein Code pro Serie, gedruckt in hoher Auflage: statisch plus API, damit die Erzeugung in die Fertigung passt.',
    },
  ],
  steps: [
    'Zweck festlegen: dauerhaft gedruckt oder Kampagne mit Änderungsbedarf.',
    'Bei dauerhaft: statisch, SVG, eigene Zielseite, fertig.',
    'Bei Kampagne: Anbieter nach Laufzeit und Export testen, nicht nach Feature-Liste.',
    'In beiden Fällen den Fünf-Minuten-Test machen, bevor Geld fließt.',
  ],
  faq: [
    {
      q: 'Welcher QR-Code-Generator ist der beste?',
      a: 'Der, dessen Bauform zu Ihrer Laufzeit passt. Für dauerhaft gedruckte Codes ist ein statischer Generator die bessere Wahl, für Kampagnen mit Änderungsbedarf ein Dienst mit Weiterleitung.',
    },
    {
      q: 'Kann ich später zu einem anderen Anbieter wechseln?',
      a: 'Bei statischen Codes ja, aber nur mit neuem Druck, weil die Daten im Muster stecken. Bei dynamischen Codes hängt der gedruckte Code am alten Anbieter, ein Wechsel verlangt einen neuen Aufdruck.',
    },
    {
      q: 'Was kostet ein dynamischer Code wirklich?',
      a: 'Die Preise unterscheiden sich stark, deshalb nennt diese Seite keine. Der eigentliche Preis ist nicht die Gebühr, sondern die Abhängigkeit: Solange gezahlt wird, funktioniert der gedruckte Code.',
    },
    {
      q: 'Sind Vergleichslisten im Netz unabhängig?',
      a: 'Oft nicht. Viele haben Provisionslinks oder gehören einem Anbieter. Ein Test mit einem eigenen Code sagt mehr als jede Liste.',
    },
  ],
  toolLinks: [
    { label: 'Statischen Code erstellen', href: '/' },
    { label: 'Kostenlos und ohne Anmeldung', href: '/qr-code-generator/kostenlos' },
  ],
  blogLinks: [{ label: 'Statisch oder dynamisch im Detail', href: '/blog/dynamische-vs-statische-qr-codes' }],
};

const bester: SeoSubPage = {
  slug: 'bester-qr-code-generator',
  title: 'Bester QR-Code-Generator: fünf Prüfungen',
  metaTitle: 'Bester QR-Code-Generator: fünf Prüfungen vor der Wahl',
  metaDescription:
    'Es gibt keinen besten QR-Code-Generator, es gibt den passenden. Fünf Prüfungen, die in fünf Minuten zeigen, ob ein Werkzeug hält, was es verspricht.',
  intro: [
    'Wer nach dem besten QR-Code-Generator sucht, bekommt Listen, in denen jedes Werkzeug empfohlen wird. Diese Seite macht das Gegenteil: fünf Prüfungen, mit denen Sie selbst entscheiden, und eine klare Auskunft, für wen wir die falsche Wahl sind.',
    'Alle Prüfungen laufen ohne Konto und ohne Zahlungsdaten.',
  ],
  sections: [
    {
      title: 'Prüfung 1: Geht ein Code ohne Konto?',
      body: [
        'Erzeugen Sie einen Code, ohne sich zu registrieren. Geht das nicht, hängt der Code an einem Login, und der Login kann verschwinden. Das ist bei kurzen Projekten kein Problem, bei gedruckten Sachen schon.',
        'Zweite Frage im gleichen Schritt: Steht im Code eine Fremdadresse? Eine kurze Domain mit sinnlosen Zeichen bedeutet, dass ein Dienst weiterleitet. Das ist ein Hinweis, kein Urteil, aber Sie sollten wissen, ob Sie einen Link drucken oder Daten.',
      ],
    },
    {
      title: 'Prüfung 2: Kommt ein Vektor heraus?',
      body: [
        'Laden Sie als SVG herunter. Ein PNG mit 512 Pixeln ist für den Bildschirm gedacht. Wer eine Druckerei beliefert, braucht Flächen, keine Pixel, sonst wird der Code auf dem Plakat weichgezeichnet.',
        'Wenn kein Vektor angeboten wird, ist das Werkzeug auf Bildschirmnutzung ausgelegt. Für eine Speisekarte am Tisch kann das reichen, für ein Außenschild nicht.',
      ],
    },
    {
      title: 'Prüfung 3: Funktioniert der Code in zwei Wochen noch?',
      body: [
        'Das ist die einzige Prüfung, die Zeit kostet, und die einzige, die eine Testphase entlarvt. Erzeugen, scannen, zwei Wochen warten, erneut scannen. Alles andere lässt sich am selben Tag messen, dieses nicht.',
        'Gegenprobe ohne Wartezeit: Suchen Sie in den AGB nach den Wörtern Laufzeit, Löschung, Begrenzung, kostenpflichtig. Finden Sie sie nicht, gibt es sie wahrscheinlich, Sie haben nur nicht gründlich genug gesucht.',
      ],
    },
    {
      title: 'Prüfung 4: Was steht hinter der Seite für den Nutzer?',
      body: [
        'Der Code bringt jemanden auf eine Seite. Wenn dort eine Anmeldemaske, ein Cookie-Fenster mit drei Anbietern oder ein Video mit Autoplay wartet, war der Code erfolgreich und der Kontakt trotzdem verloren.',
        'Scannen Sie den fertigen Code mit einem fremden Telefon im Mobilfunknetz, nicht im WLAN. Das zeigt, was der Gast wirklich sieht.',
      ],
    },
    {
      title: 'Prüfung 5: Ist die Zielseite dauerhaft?',
      body: [
        'Ein statischer Code ist nur so gut wie die Seite, auf die er zeigt. Eine Kampagnenseite mit Ablaufdatum ist die häufigste Ursache für einen Code, der nach einem Jahr ins Leere führt.',
        'Wer keinen dauerhaften Ort für die Inhalte hat, sollte den Code nicht drucken. Das ist keine Frage des Anbieters, sondern der eigenen Struktur.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Wenn wir die richtige Wahl sind',
      text: 'Der Code soll lange halten, alles Gedruckte, kein Abo, keine Statistik nötig, Druckqualität gefragt. Zwanzig Typen, SVG, ohne Konto, ohne Ablauf.',
    },
    {
      title: 'Wenn ein anderer Anbieter besser ist',
      text: 'Das Ziel soll sich nach dem Druck ändern, Scans sollen gemessen werden, mehrere Personen sollen Kampagnen verwalten. Das braucht einen Dienst mit Weiterleitung und Abo.',
    },
    {
      title: 'Wenn beides gebraucht wird',
      text: 'Statische Codes für Schilder und Etiketten, dynamische für Kampagnen. Die beiden schließen sich nicht aus, sie gehören nur auf verschiedene Flächen.',
    },
  ],
  steps: [
    'Zweck notieren: dauerhaft oder Kampagne.',
    'Die fünf Prüfungen in dieser Reihenfolge machen, Prüfung 3 mit Wartezeit.',
    'Ergebnis gegen den Zweck stellen, nicht gegen die Feature-Liste.',
    'Erst dann Geld ausgeben oder sich festlegen.',
  ],
  faq: [
    {
      q: 'Gibt es einen objektiv besten QR-Code-Generator?',
      a: 'Nein. Es gibt Werkzeuge, die zu einer Laufzeit und einem Zweck passen. Für dauerhaft gedruckte Codes sind statische Werkzeuge im Vorteil, für Kampagnen Dienste mit Weiterleitung.',
    },
    {
      q: 'Woran erkenne ich einen guten Anbieter in einer Minute?',
      a: 'Daran, ob ein Code ohne Konto entsteht und ob es einen SVG-Export gibt. Fehlt eines von beidem, ist der Anbieter auf etwas anderes ausgelegt als auf Druck.',
    },
    {
      q: 'Warum empfehlen viele Listen dasselbe?',
      a: 'Weil sie über Provisionslinks finanziert sind. Das ist kein Geheimnis, steht aber selten in der Liste selbst. Ein eigener Test ist die verlässlichere Grundlage.',
    },
  ],
  toolLinks: [
    { label: 'Code ohne Konto erstellen', href: '/' },
    { label: 'Die fünf Modelle im Vergleich', href: '/qr-code-generator/vergleich' },
  ],
  blogLinks: [{ label: 'Häufige QR-Code-Fehler', href: '/blog/qr-code-fehler-haeufige-probleme' }],
};

export const TYPEN_PART_FOUR = [kostenlos, vergleich, bester];
