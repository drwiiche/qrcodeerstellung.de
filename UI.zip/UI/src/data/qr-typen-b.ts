import type { SeoHub, SeoSubPage } from './seo-pages';
import { TYPEN_PART_ONE } from './qr-typen-a';
import { TYPEN_PART_THREE } from './qr-typen-c';
import { TYPEN_PART_FOUR } from './qr-typen-d';
import { TYPEN_PART_FIVE } from './qr-typen-e';
import { TYPEN_PART_SIX } from './qr-typen-f';
import { TYPEN_PART_SEVEN } from './qr-typen-g';
import { TYPEN_PART_EIGHT } from './qr-typen-h';
import { TYPEN_PART_NINE } from './qr-typen-i';

const telefon: SeoSubPage = {
  slug: 'telefon',
  title: 'Telefonnummer als QR-Code',
  metaTitle: 'Telefonnummer QR-Code: Anruf per Scan starten',
  metaDescription:
    'Ein Code, der die Wahltaste drückt: tel-Link, internationale Schreibweise, Kostenhinweis und die Fälle, in denen ein Anruf besser ist als ein Formular.',
  intro: [
    'Ein Telefon-Code wählt eine Nummer, sobald der Scan bestätigt wird. Kein Abtippen, keine Zahlendreher, kein Suchen im Browser. Auf einem Fahrzeug, einem Aushang oder einer Speisekarte ist das der direkteste Weg zum Kontakt.',
    'Technisch ist es ein tel-Link. Was darauf steht, entscheidet über Erfolg oder Fehlwahl.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Die Nummer im Format tel:+493012345678. Das Plus und die Ländervorwahl gehören dazu, sonst funktioniert der Code im Ausland nicht und manche Geräte wählen die führende Null als Amtskennzahl.',
        'Es gibt keine Leerzeichen, keine Bindestriche und keine Klammern im Code. Der Generator entfernt sie, weil sie in einem tel-Link nichts zu suchen haben.',
      ],
      bullets: [
        'Immer mit +49 beginnen, danach die Nummer ohne führende Null',
        'Keine Durchwahl-Trennzeichen, keine Schrägstriche',
        'Eine Nummer pro Code, nicht zwei Alternativen in einem Code',
        'Beschriftung unter dem Code, die sagt, was passiert',
      ],
    },
    {
      title: 'Wann ein Anruf besser ist als ein Formular',
      body: [
        'Wenn es dringend ist, wenn es wenig Text braucht und wenn der Anrufer ohnehin Fragen hat, die ein Formular nicht abdeckt. Handwerksbetriebe kennen den Unterschied zwischen „Anfrage per Formular" und „Anruf, weil Wasser läuft".',
        'Der Code hilft dabei, weil er die Schwelle senkt. Ein Kunde, der die Nummer erst eintippen muss, ruft oft nicht an. Ein Kunde, der nur den Code hält, ruft an.',
      ],
    },
    {
      title: 'Was Sie über Kosten und Zeiten dazuschreiben sollten',
      body: [
        'Ein Anruf kostet den Anrufer Geld, eine Festnetznummer weniger als eine Mobilnummer, eine Servicenummer mehr. Bei 0180- und 0900-Nummern ist die Preisangabe nicht nur guter Stil, sondern Pflicht.',
        'Genauso wichtig: die Zeiten. „Mo bis Fr, 7 bis 16 Uhr" unter dem Code verhindert, dass jemand um 22 Uhr anruft und beim nächsten Mal nicht mehr anruft.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf einem Fahrzeug aus 2 Metern Entfernung mindestens 8 bis 10 Zentimeter Kantenlänge. Auf einem Aufsteller am Tresen reichen 3 Zentimeter. Auf einem Aushang im Treppenhaus 10 bis 15 Zentimeter.',
        'Platzieren Sie den Code dort, wo das Telefon ohnehin in der Hand ist: an der Tür, am Tresen, am Fahrzeugheck. Ein Code im Schaufenster wird seltener gescannt als einer an der Klingelanlage.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Handwerksfahrzeug',
      text: 'Der Code auf der Heckklappe, darunter die Nummer in Klarschrift für alle, die nicht scannen. Beides zusammen deckt alle Fälle ab.',
    },
    {
      title: 'Notdienst und Hotline',
      text: 'Auf dem Aushang im Treppenhaus, mit Hinweis auf die Zeiten. Der Unterschied zwischen „Notdienst" und „Büro" muss daneben stehen, nicht im Code.',
    },
    {
      title: 'Gastronomie',
      text: 'Auf der Speisekarte für Rückfragen zu Allergenen. Wer nicht scannen will, liest die Nummer darunter.',
    },
  ],
  steps: [
    'Nummer in internationaler Schreibweise zusammensetzen: +49 und dann ohne führende Null.',
    'Typ „Telefon" wählen und die Nummer eintragen.',
    'Code erzeugen und immer mit Klarschrift-Nummer daneben drucken.',
    'Zusatzzeile für Zeiten oder Kosten ergänzen.',
    'Selbst scannen und prüfen, dass die richtige Nummer in der Wählmaske steht.',
  ],
  faq: [
    {
      q: 'Wird der Anruf automatisch gestartet?',
      a: 'Nein. Der Scan öffnet die Wählmaske mit der Nummer, der Nutzer bestätigt. Automatisches Wählen wäre auf einem gedruckten Code auch riskant.',
    },
    {
      q: 'Muss die Nummer international geschrieben sein?',
      a: 'Sie sollte. Mit +49 funktioniert der Code auch, wenn ein ausländisches Gerät scannt, und die führende Null wird nicht als Amtskennzahl missverstanden.',
    },
    {
      q: 'Warum sollte die Nummer auch als Text daneben stehen?',
      a: 'Weil nicht jeder scannt und weil ein beschädigter Code sonst den gesamten Kontaktweg zerstört. Die Klarschrift ist die Rückfallebene.',
    },
  ],
  toolLinks: [
    { label: 'Telefon-QR-Code erstellen', href: '/?type=phone' },
    { label: 'QR-Codes auf Fahrzeugen', href: '/qr-codes-auf' },
  ],
  blogLinks: [],
};

const sms: SeoSubPage = {
  slug: 'sms',
  title: 'SMS-QR-Code erstellen',
  metaTitle: 'SMS QR-Code erstellen: Nachricht vorschreiben',
  metaDescription:
    'Ein Code, der eine SMS mit Nummer und vorbereitetem Text öffnet. Wann SMS noch sinnvoll ist, was der Empfänger zahlt und wie die Nachricht kurz bleibt.',
  intro: [
    'Ein SMS-Code öffnet die Nachrichten-App mit einer vorbereiteten Kurznachricht an eine feste Nummer. Der Absender muss nur noch auf Senden tippen.',
    'SMS ist das älteste Format hier und in Deutschland weiterhin relevant, aber nicht für jeden Zweck. Die Technik ist unauffällig, die Entscheidung ist inhaltlich.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Ein Verweis der Form SMSTO:+493012345678:Text. Die Nummer international, dahinter der vorbefüllte Nachrichtentext. iOS und Android verstehen das Format, auch wenn einzelne Apps es unterschiedlich darstellen.',
        'Der Text im Code ist auf 160 Zeichen begrenzt, sonst zerfällt die Nachricht in mehrere Teile. Für „Termin 14.03. bestätigt" reicht das, für eine Bestellung nicht.',
      ],
      bullets: [
        'Kurzer Text, maximal 160 Zeichen',
        'Keine Umlaute-Notation erzwingen, moderne Geräte können Unicode, kostet aber Zeichen',
        'Nummer vor dem Doppelpunkt, Text dahinter, keine Anführungszeichen',
        'Empfängernummer muss SMS empfangen können',
      ],
    },
    {
      title: 'Wann SMS noch der richtige Weg ist',
      body: [
        'Wenn der Kontakt kein Smartphone mit Messenger hat, wenn die Nachricht ohne App ankommen muss oder wenn es um eine kurze Bestätigung geht. In der Pflege, im Vereinswesen und bei älteren Zielgruppen ist SMS weiterhin zuverlässiger als WhatsApp.',
        'Für Rückfragen und Beratung ist SMS ungeeignet. Wer eine SMS mit einer Frage bekommt, antwortet meist nicht, weil Tippen auf dem Telefon mühsam ist und Kosten entstehen können.',
      ],
    },
    {
      title: 'Kosten und Erwartung',
      body: [
        'Der Code bezahlt keine SMS. Wer die Nachricht abschickt, zahlt den Preis seines Tarifs an die Zielnummer hinzu, und der Empfänger zahlt gegebenenfalls für die Antwort, wenn es eine Servicenummer ist.',
        'Deshalb gehört unter den Code, was passiert: „Termin bestätigen" oder „Kurzinfo anfordern". Ein unklarer Code wird nicht gescannt, weil niemand eine unbekannte Nummer anschreiben will.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Wie beim Telefon-Code: 3 Zentimeter am Tresen, 8 bis 10 Zentimeter am Fahrzeug, 10 bis 15 Zentimeter am Aushang. Bei SMS zusätzlich eine Zeile, die den Zweck nennt.',
        'SMS-Codes gehören nicht auf Produkte oder Verpackungen. Der Kunde hat dort keine Veranlassung, eine Bestätigung zu senden, und die Nummer veraltet mit dem Anlass.',
      ],
    },
    {
      title: 'SMS, WhatsApp oder Anruf: die Abgrenzung',
      body: [
        'Die drei Wege lösen unterschiedliche Aufgaben. Der Anruf klärt eine Situation, die eine Rückfrage braucht. WhatsApp setzt eine Unterhaltung fort, in der Bilder und Sprache möglich sind. SMS ist der einzige Weg, der ohne Messenger und ohne Telefonat eine kurze Bestätigung überträgt.',
        'Wenn eine Bestätigung ohne Rückfrage gebraucht wird, ist SMS richtig. Wenn eine Rückfrage wahrscheinlich ist, ist der Anruf besser. Und wenn es um Fotos, Adressen oder Angebote geht, ist WhatsApp der passende Kanal, nicht SMS.',
      ],
      bullets: [
        'Bestätigung ohne Rückfrage: SMS',
        'Rückfrage mit Bild oder Sprache: WhatsApp',
        'Sofortige Klärung: Anruf',
        'Alle drei zusammen auf einem Flyer überfordern, eins wählen',
      ],
    },
  ],
  useCases: [
    {
      title: 'Terminbestätigung',
      text: 'Auf der Terminkarte, Text bereits als „Ich bestätige den Termin am ..." formuliert. Der Kunde sendet nur noch ab.',
    },
    {
      title: 'Verein und Pflege',
      text: 'Für Menschen ohne Messenger. Der Code steht auf dem Anschreiben und funktioniert auch auf einfachen Geräten.',
    },
    {
      title: 'Lieferung und Abholung',
      text: 'Kurze Rückmeldung statt Anruf. Wichtig ist die Erwartung: Es kommt keine automatische Antwort, und das gehört dazugesagt.',
    },
  ],
  steps: [
    'Empfängernummer international zusammensetzen.',
    'Bestätigungstext vorbereiten und auf 160 Zeichen kürzen.',
    'Typ „SMS" wählen, Nummer und Text eintragen.',
    'Code mit Beschriftung drucken, die den Anlass nennt.',
    'Auf einem iPhone und einem Android-Gerät testen, weil die Übergabe unterschiedlich aussieht.',
  ],
  faq: [
    {
      q: 'Wird die SMS automatisch gesendet?',
      a: 'Nein. Der Scan öffnet die Nachrichten-App mit vorbereiteter Nummer und Text. Der Absender bestätigt selbst.',
    },
    {
      q: 'Wer bezahlt die SMS?',
      a: 'Der Absender, zu den Konditionen seines Mobilfunkvertrags. Bei Servicenummern kann zusätzlich ein Preisaufschlag entstehen, auf den die Preisangabepflicht hinweist.',
    },
    {
      q: 'Warum werden Umlaute zu Sonderzeichen?',
      a: 'Weil klassische SMS im 7-Bit-Zeichensatz nur einen Teil der Zeichen kennt. Wer Unicode nutzt, verliert Zeichen, aber Behörden und moderne Geräte zeigen die Nachricht korrekt.',
    },
  ],
  toolLinks: [
    { label: 'SMS-QR-Code erstellen', href: '/?type=sms' },
    { label: 'Telefonnummer als QR-Code', href: '/qr-code-generator/telefon' },
  ],
  blogLinks: [],
};

const standort: SeoSubPage = {
  slug: 'standort',
  title: 'Standort-QR-Code für Google Maps',
  metaTitle: 'Standort QR-Code: Koordinaten in Google Maps öffnen',
  metaDescription:
    'Ein Code mit Koordinaten statt einer Adresse. Wann das besser navigiert, wie Sie die richtigen Werte finden und warum der Pin am Eingang stehen muss.',
  intro: [
    'Ein Standort-Code öffnet die Karten-App an einem festen Punkt. Der Gast muss nichts eintippen und landet direkt beim Eingang statt in der Straße davor.',
    'Der Unterschied zur Adresse ist wichtig: Eine Adresse beschreibt eine Straße, ein Koordinatenpaar beschreibt einen Punkt.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Ein Link auf Google Maps mit Breiten- und Längengrad, also https://www.google.com/maps/search/?api=1&query=52.520,13.405. Dezimalpunkt, kein Komma, Breitengrad zuerst, negative Werte für Süd und West.',
        'Diese Form ist robuster als ein geo:-URI, weil sie in jedem Browser und in jeder Karten-App geöffnet werden kann. iOS-Geräte übergeben den Link an Google Maps, wenn die App installiert ist, sonst an den Browser.',
      ],
      bullets: [
        'Breitengrad zuerst, Längengrad zweitens, mit Punkt als Trenner',
        'Deutschland liegt zwischen 47 und 55 Grad Nord und 6 und 15 Grad Ost',
        'Koordinaten aus Google Maps entnehmen: Pin setzen, Rechtsklick, Werte kopieren',
        'Fünf bis sechs Nachkommastellen reichen, mehr ergibt keinen Sinn',
      ],
    },
    {
      title: 'Warum der Pin genauer ist als die Adresse',
      body: [
        'Eine Straßenadresse führt bei großen Grundstücken, Hinterhöfen und Gewerbegebieten regelmäßig an die falsche Seite des Gebäudes. Wer auf die Rückseite geschickt wird, findet den Eingang nicht.',
        'Mit einem Pin setzen Sie den Punkt selbst: an die Einfahrt, an die Rampe, an den Lieferanteneingang. Das ist der eigentliche Wert dieses Code-Typs, nicht die Bequemlichkeit.',
      ],
    },
    {
      title: 'Was der Code nicht leistet',
      body: [
        'Er navigiert nicht von selbst los. Er öffnet die Karte mit dem Ziel; die Route muss der Nutzer starten. Startpunkt ist in der Regel der aktuelle Standort des Geräts.',
        'Er ersetzt auch keine Zufahrtsbeschreibung. Bei Parkplätzen, die nur über eine bestimmte Zufahrt erreichbar sind, bleibt ein Satz Text daneben notwendig.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf einem Flyer oder einer Einladung 2,5 bis 3 Zentimeter. Auf einem Schild am Grundstück 10 bis 15 Zentimeter, weil aus mehreren Metern gescannt wird.',
        'Bei Outdoor-Codes gilt: matter Kunststoff oder Aluverbund, kein Papier unter Folie. Ein Standort-Schild steht jahrelang in der Sonne, und ein vergilbter Ausdruck ist nach einem Sommer unlesbar.',
      ],
    },
    {
      title: 'Koordinaten finden, ohne ein Konto zu brauchen',
      body: [
        'In Google Maps den Standort suchen, lange auf die Stelle tippen, dann erscheinen die Koordinaten zum Kopieren. Am Rechner geht es genauso mit einem Rechtsklick auf den Punkt. Ein Konto ist dafür nicht nötig.',
        'Vorsicht bei der Reihenfolge. Manche Kartenanwendungen zeigen den Längengrad zuerst. In Deutschland liegt der Breitengrad zwischen 47 und 55, der Längengrad zwischen 6 und 15. Wer die Werte vertauscht, landet in Somalia, und der Code zeigt es erst nach dem Druck.',
      ],
      bullets: [
        'Breitengrad zuerst: 50 bis 55 ist in Norddeutschland plausibel',
        'Längengrad: 6 an der Grenze zu Belgien, 15 an der Oder',
        'Vor dem Druck mit der eigenen Karten-App gegenprüfen',
        'Bei mehreren Eingängen je Eingang ein eigener Code',
      ],
    },
  ],
  useCases: [
    {
      title: 'Einladung und Veranstaltung',
      text: 'Der Code auf der Einladung führt zum Festplatz, nicht zur Straße. Relevant bei Veranstaltungsorten mit mehreren Eingängen.',
    },
    {
      title: 'Lieferanteneingang',
      text: 'Der Code auf der Lieferschein-Rückseite zeigt die Rampe. Das erspart die Rückfrage, die jeden Tag kommt.',
    },
    {
      title: 'Filiale und Kanzlei',
      text: 'Der Code führt zur Tür, nicht zum Gebäude. Wichtig in Innenstädten, wo Navi-Ziele gern hinter dem Haus landen.',
    },
  ],
  steps: [
    'Punkt in Google Maps suchen, Pin setzen und die Koordinaten kopieren.',
    'In den Generator eintragen, Breitengrad und Längengrad getrennt.',
    'Eine kurze Bezeichnung setzen, die auf der Karte als Text hilft.',
    'Code erzeugen und mit „Route starten" beschriften.',
    'Selbst scannen und prüfen, ob der Pin wirklich am richtigen Eingang sitzt.',
  ],
  faq: [
    {
      q: 'Funktioniert der Code auch ohne Google-Maps-App?',
      a: 'Ja. Der Link öffnet die Kartenanwendung oder ersatzweise den Browser mit Google Maps. Der Nutzer kann von dort in seine bevorzugte Karten-App wechseln.',
    },
    {
      q: 'Sind die Koordinaten datenschutzrechtlich unbedenklich?',
      a: 'Ja. Es sind Ortskoordinaten ohne Personenbezug, und der Code fragt nichts ab.',
    },
    {
      q: 'Wie viele Nachkommastellen brauche ich?',
      a: 'Fünf reichen für Meter, sechs für Zentimeter. Mehr ist bei einem gedruckten Code kein Gewinn, weil der Pin ohnehin auf die Hausnummern-Ebene zeigt.',
    },
  ],
  toolLinks: [
    { label: 'Standort-QR-Code erstellen', href: '/?type=standort' },
    { label: 'QR-Codes für Veranstaltungen', href: '/qr-codes-fuer/veranstaltungen' },
  ],
  blogLinks: [],
};

const termin: SeoSubPage = {
  slug: 'termin',
  title: 'Termin-QR-Code für den Kalender',
  metaTitle: 'Termin QR-Code: Kalendereintrag per Scan anlegen',
  metaDescription:
    'Ein Code, der Titel, Ort, Beginn und Ende in den Kalender schreibt. Warum Zeitzonen den Eintrag verschieben und was ein Kalender-Code nicht kann.',
  intro: [
    'Ein Termin-Code legt einen Kalendereintrag an: Titel, Ort, Beginn, Ende. Für Kurse, Einladungen, Sprechstunden und Veranstaltungen ist das der bequemste Weg, jemandem einen Termin zu geben, ohne dass er ihn falsch abschreibt.',
    'Der Code enthält eine Kalenderdatei, kein Bild einer Einladung. Deshalb ist die Formatfrage entscheidend und nicht die Gestaltung.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Ein VEVENT-Block nach RFC 5545: BEGIN:VEVENT, SUMMARY als Titel, LOCATION als Ort, DESCRIPTION als Beschreibung, dazu DTSTART und DTEND.',
        'Bei uns stehen die Zeiten als lokale Zeit im Code, ohne Zeitzonenkennung. Das ist Absicht: Wer 18:30 eingibt, meint 18:30 vor Ort, und das Gerät zeigt 18:30. Eine Umrechnung auf UTC würde bei deutschen Terminen im Sommer zwei Stunden verschieben.',
      ],
      bullets: [
        'Datum als JJJJMMTT, Zeit als HHMMSS',
        'Kommas im Titel werden maskiert, sonst endet der Titel an dieser Stelle',
        'Keine Wiederholung, keine Erinnerung, keine Teilnehmer',
        'Ein Scan legt einen Eintrag an, kein Abonnement',
      ],
    },
    {
      title: 'Der Unterschied zwischen Termin und Kalenderabo',
      body: [
        'Ein Termin-Code fügt einen einzelnen Eintrag hinzu. Wer zehn Veranstaltungen im Jahr anbietet, hat damit zehn Codes, nicht einen. Ein Kalenderabo wäre ein anderer Weg, braucht aber eine ICS-Datei auf einem Server und wird von diesem Code-Typ nicht abgedeckt.',
        'Für die meisten Fälle ist der einzelne Termin richtig, weil ein Abo nur mit zusätzlicher Erklärung funktioniert und den Kalender des Gastes dauerhaft verändert.',
      ],
    },
    {
      title: 'Was typischerweise schiefgeht',
      body: [
        'Die Zeitzone. Wer einen Code von einer Plattform mit UTC-Zeit übernimmt, bekommt Einträge, die ein oder zwei Stunden versetzt stehen. Der Fehler ist im Code unsichtbar und zeigt sich erst im Kalender.',
        'Das fehlende Ende. Ein Eintrag mit Beginn und ohne Ende ist in manchen Apps als 15-Minuten-Block angelegt, in anderen zieht er sich über den ganzen Tag. Beginn und Ende gehören zusammen.',
        'Die Bestätigung im Kalender. Kein Code kann einen Eintrag automatisch bestätigen, der Nutzer muss etwas antippen. Deshalb ist ein Hinweis „Termin speichern" unter dem Code hilfreich.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf Einladungen und Plakaten 3 Zentimeter, auf Aufstellern 4 bis 5 Zentimeter, auf Aushängen aus zwei Metern 10 bis 15 Zentimeter.',
        'Der Ort kommt bei diesem Code-Typ doppelt vor, als Koordinate im Text und als Raumangabe im Kalender. Beides sollte stimmen, sonst steht im Kalendereintrag ein Ort, der nicht stimmt.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Kurs und Workshop',
      text: 'Der Code auf dem Flyer legt Termin und Ort an. Für Reihen mit mehreren Terminen braucht jeder Termin einen eigenen Code.',
    },
    {
      title: 'Sprechstunde',
      text: 'Auf dem Aushang an der Tür. Wer freitags vorbeikommt und geschlossen ist, hat den Termin im Kalender.',
    },
    {
      title: 'Vereinsversammlung',
      text: 'Einladung mit Code, dazu die Tagesordnung im Kalendereintrag als Beschreibung. So ist sie beim Termin vorhanden.',
    },
  ],
  steps: [
    'Titel, Ort, Start- und Endzeit festlegen, ohne Zeitzonen-Umrechnung.',
    'Typ „Termin" wählen und die Felder füllen.',
    'Beschreibung kurz halten, sie landet im Kalendereintrag und wird mit dem Termin gelesen.',
    'Beschriftung unter den Code setzen: „Termin speichern".',
    'Selbst scannen und prüfen, ob der Eintrag mit der richtigen Uhrzeit erscheint.',
  ],
  faq: [
    {
      q: 'Warum steht der Termin im Kalender ein bis zwei Stunden versetzt?',
      a: 'Weil der Code die Zeit als UTC enthielt, der Kalender aber in Ortszeit anzeigt. Unsere Codes enthalten lokale Zeit ohne Zeitzonenkennung, damit 18:30 als 18:30 erscheint.',
    },
    {
      q: 'Wird eine Erinnerung gesetzt?',
      a: 'Nein. Der Kalendereintrag enthält keine Erinnerungszeit. Die legt der Gast in seinem Kalender selbst fest.',
    },
    {
      q: 'Kann ich mehrere Termine in einen Code packen?',
      a: 'Technisch könnte eine Datei mehrere VEVENT-Blöcke enthalten. Der Code wird dadurch deutlich dichter und die Lesbarkeit sinkt. Für Terminreihen ist eine kleine Seite mit Kalenderdatei der bessere Weg.',
    },
  ],
  toolLinks: [
    { label: 'Termin-QR-Code erstellen', href: '/?type=event' },
    { label: 'QR-Codes für Veranstaltungen', href: '/qr-codes-fuer/veranstaltungen' },
  ],
  blogLinks: [{ label: 'QR-Codes für Einladungen und Tickets', href: '/blog/qr-codes-flyer-plakate-drucksachen' }],
};

const text: SeoSubPage = {
  slug: 'text',
  title: 'Freitext-QR-Code erstellen',
  metaTitle: 'Freitext QR-Code: Text ohne Internetabruf lesen',
  metaDescription:
    'Ein Code, der nur aus Text besteht: wie viele Zeichen sinnvoll sind, warum er offline funktioniert und wo er gegenüber einem Link gewinnt.',
  intro: [
    'Ein Freitext-Code enthält die Zeichen selbst. Kein Link, keine Seite, kein Server. Die Kamera zeigt den Text an, und das funktioniert auch ohne Netz.',
    'Das ist der einzige Code-Typ, der ohne Empfangsqualität und ohne gehostete Seite funktioniert, und genau darin liegt seine Verwendung: auf Geräten, in Kellern, an Orten mit Funkloch.',
  ],
  sections: [
    {
      title: 'Wie viel Text passt hinein?',
      body: [
        'Technisch passen in einen QR-Code der Version 40 mehrere tausend Zeichen, je nach Zeichensatz und Fehlerkorrektur. Praktisch scheitert es früher, weil die Modulzahl wächst und der Code auf der gedruckten Fläche unlesbar klein wird.',
        'Arbeitswerte: Bis 200 Zeichen bleibt der Code bei 3 Zentimetern lesbar. Bis 500 Zeichen braucht er 5 Zentimeter. Ab 1.000 Zeichen wird es auf Papier unhandlich, und man sollte prüfen, ob ein Link nicht der bessere Weg ist.',
      ],
      bullets: [
        'Umlaute und Emoji erhöhen den Platzbedarf, weil sie mehrere Bytes belegen',
        'Zeilenumbrüche sind erlaubt und werden vom Scanner mit angezeigt',
        'Fehlerkorrektur M ist bei Text ein guter Kompromiss aus Größe und Robustheit',
        'Große Buchstaben und Ziffern sind sparsamer als Kleinbuchstaben und Umlaute',
      ],
    },
    {
      title: 'Wann Text besser ist als ein Link',
      body: [
        'Wenn der Inhalt nie ändern soll und niemand eine Seite pflegen will. Seriennummern, Inventarnummern, Prüfvermerke, Notfallhinweise, Ablesewerte: alles kurz, alles stabil, alles ohne Netz lesbar.',
        'Zweitens, wenn der Code lange liegen bleibt. Ein Link veraltet mit seiner Zielseite, ein Text nicht. Wer ein Etikett für zehn Jahre druckt, ist mit Text auf der sicheren Seite.',
      ],
    },
    {
      title: 'Wo Text ungeeignet ist',
      body: [
        'Sobald der Inhalt mehr als eine Bildschirmseite füllt oder sich ändern kann. Ein langer Rechtstext im Code wird am Telefon nicht gelesen und ist im Druck nicht unterzubringen.',
        'Auch für alles, was ein Gerät öffnen soll, ist Text falsch. Ein Text-Code, der eine Telefonnummer enthält, wählt nicht, er zeigt nur Ziffern.',
      ],
    },
    {
      title: 'Größe und Material',
      body: [
        'Für Inventar- und Geräteetiketten: 2 bis 3 Zentimeter, mit wetterfester Folie, direkt auf der Fläche, nicht über eine Rundung gespannt.',
        'Für Notfallhinweise an der Tür oder im Keller: 5 Zentimeter, weil aus einem Meter Abstand und bei schlechtem Licht gescannt wird. Bei Text-Codes zusätzlich den Anfang des Inhalts in Klarschrift daneben, damit im Zweifel wenigstens das lesbar ist.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Anlagen und Geräte',
      text: 'Inventarnummer und Standort als Text auf dem Typenschild. Lesbar ohne Netz, auch im Keller und im Container.',
    },
    {
      title: 'Notfallhinweise',
      text: 'Kurze Anweisung am Zugang zu Technikräumen. Kein Server, der ausfallen kann, nur Zeichen im Code.',
    },
    {
      title: 'Prüfvermerke',
      text: 'Datum und Kürzel der letzten Prüfung, direkt am Gegenstand. Wer prüft, liest und trägt den nächsten Vermerk ein.',
    },
  ],
  steps: [
    'Text vorbereiten, auf das Notwendige kürzen, keine Formatierung.',
    'Typ „Freitext" wählen und den Text einfügen.',
    'Fehlerkorrektur nach Druckgröße wählen, bei kleinen Etiketten höher.',
    'Als SVG herunterladen und auf dem echten Material drucken.',
    'Bei schlechtem Licht scannen, nicht in der Mittagssonne am Schreibtisch.',
  ],
  faq: [
    {
      q: 'Funktioniert ein Text-Code ohne Internet?',
      a: 'Ja. Der Text steht im Code selbst. Das Telefon braucht kein Netz, um ihn anzuzeigen. Nur wenn Sie den Text zusätzlich in einer App speichern wollen, gelten deren Regeln.',
    },
    {
      q: 'Kann der Text nachträglich geändert werden?',
      a: 'Nein. Der Inhalt ist in das Muster eingebrannt. Für änderbare Inhalte braucht es einen Link auf eine Seite, die Sie pflegen.',
    },
    {
      q: 'Warum wird mein Code bei langem Text so groß?',
      a: 'Weil mehr Zeichen mehr Module bedeuten. Bei gleicher Kantenlänge wird jeder Punkt kleiner. Kürzen Sie den Text oder drucken Sie größer, alles andere ist ein Kompromiss.',
    },
  ],
  toolLinks: [
    { label: 'Freitext-QR-Code erstellen', href: '/?type=text' },
    { label: 'Kontrast und Druckgröße', href: '/qr-codes-auf' },
  ],
  blogLinks: [{ label: 'QR-Code drucken: Kontrast, Größe, Material', href: '/blog/qr-code-drucken-kontrast-groesse' }],
};

const paketabstellort: SeoSubPage = {
  slug: 'paketabstellort',
  title: 'Paketabstellort als QR-Code',
  metaTitle: 'Paketabstellort QR-Code: Ablageort für den Boten',
  metaDescription:
    'Ein Code an der Wohnungstür, der dem Paketboten Abstellort, Name und Hinweise zeigt. Was daran amtlich ist, was nicht, und wie er lesbar bleibt.',
  intro: [
    'Der Paketabstellort-Code hängt dort, wo der Bote klingelt, und zeigt ihm, wohin das Paket darf: Garage, Nachbar, Hinterhof, Packstation. Ein Scan statt Zettel, der abfällt.',
    'Wichtig zur Einordnung: Es gibt dafür keinen amtlichen Standard. Der Code enthält lesbaren Text, und der Bote liest ihn. Wer eine verbindliche Ablagevereinbarung will, findet sie in der App des jeweiligen Dienstleisters, nicht auf einem QR-Code.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Reiner Text in Zeilen: Empfänger, Abstellort, gültig für welche Dienste, Rückfragenummer, Zusatzhinweis. Keine Kodierung, keine Schnittstelle, kein Format, das ein System auswertet.',
        'Das klingt banal, ist aber der Punkt: Der Code funktioniert, weil ein Mensch ihn liest. Er funktioniert nicht, weil DHL, Hermes oder DPD ihn verarbeiten.',
      ],
      bullets: [
        'Empfänger mit Nachnamen, damit der Bote die Wohnung zuordnen kann',
        'Abstellort konkret: „Hintere Garage, Regal links" statt „beim Nachbarn"',
        'Dienste nennen, für die der Hinweis gilt',
        'Nummer für Rückfragen, damit der Bote nicht klingeln muss',
      ],
    },
    {
      title: 'Was amtlich ist und was nicht',
      body: [
        'Die Ablagevereinbarung mit einem Paketdienst ist ein Vertrag in der App oder im Kundenkonto des Dienstes. Dort wird der Ablageort hinterlegt und gilt für die Zustellung.',
        'Ein QR-Code ist eine Ergänzung für den Fall, dass kein Auftrag hinterlegt ist oder ein anderer Dienst zustellt. Er ist eine Bitte, keine Weisung. Wer das sauber trennen will, schreibt es auf das Schild: „Bitte hier ablegen, Ablageauftrag ist hinterlegt."',
      ],
    },
    {
      title: 'Warum der Code trotzdem wirkt',
      body: [
        'Weil der Bote unter Zeitdruck steht und jeder zusätzliche Klingelversuch Zeit kostet. Ein Schild mit klarer Anweisung wird gelesen, ein Zettel mit Handschrift oft nicht.',
        'Der zweite Effekt ist die Wiederholbarkeit. Ein gedrucktes Schild hält länger als ein Zettel mit Tesafilm, und es fällt nicht ab, wenn die Tür ins Schloss zieht.',
      ],
    },
    {
      title: 'Größe, Material und Haltbarkeit',
      body: [
        'Mindestens 5 Zentimeter Kantenlänge, weil im Treppenhaus aus etwa einem Meter und oft bei schwachem Licht gescannt wird. Dazu die Kernaussage in Klarschrift: „Pakete in die Garage".',
        'Ein Schild an einer Außentür braucht wetterfeste Folie oder Aluverbund. Papier hinter Klarsichtfolie hält einen Winter, danach ist der Code ausgeblichen. Und: keine personenbezogenen Daten wie die volle Anschrift offen sichtbar anbringen, der Nachname genügt.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Mehrfamilienhaus',
      text: 'Ein Schild pro Wohnung, mit Nachname und Abstellort. Im Treppenhaus der einfachste Weg, Zustellungen ohne Klingeln zu ermöglichen.',
    },
    {
      title: 'Homeoffice',
      text: 'Tagsüber niemand da, Ablage in der Garage. Der Code erspart die Benachrichtigungskarte und den Weg zur Filiale.',
    },
    {
      title: 'Gewerbe und Lager',
      text: 'Anlieferung an die Rampe statt an den Haupteingang. Mit Hinweis auf Zeiten und Ansprechpartner.',
    },
  ],
  steps: [
    'Abstellort festlegen und so konkret formulieren, dass ihn ein Fremder findet.',
    'Empfängernamen und Rückfragenummer ergänzen, nichts darüber hinaus.',
    'Typ „Paket" wählen und den Text eintragen.',
    'Code mit mindestens 5 Zentimetern Kantenlänge drucken, Kernaussage in Klarschrift daneben.',
    'Wetterfest anbringen und nach einem Monat selbst scannen.',
  ],
  faq: [
    {
      q: 'Ist der QR-Code eine verbindliche Ablagevereinbarung?',
      a: 'Nein. Verbindlich ist die Ablagevereinbarung im Kundenkonto des Paketdienstes. Der Code ist ein Hinweis für den Boten und wirkt, weil er gelesen wird.',
    },
    {
      q: 'Welche Daten dürfen auf das Schild?',
      a: 'So wenig wie möglich: Nachname, Abstellort, Rückfragenummer. Die vollständige Anschrift und private Telefonnummern gehören nicht offen an die Tür.',
    },
    {
      q: 'Warum ist der Code nach einem Jahr unlesbar?',
      a: 'Weil Tintenstrahl auf Papier ausbleicht und Feuchtigkeit die Folie unterwandert. Für außen nur wetterfeste Folie oder Aluverbund verwenden.',
    },
  ],
  toolLinks: [
    { label: 'Paket-QR-Code erstellen', href: '/?type=delivery' },
    { label: 'QR-Codes für Immobilien', href: '/qr-codes-fuer/immobilien' },
  ],
  blogLinks: [{ label: 'Paketabstellort: der Code an der Wohnungstür', href: '/blog/paket-abstellort-qr-code' }],
};

export const TYPEN_PART_TWO = [telefon, sms, standort, termin, text, paketabstellort];

export const TYPEN_HUB: SeoHub = {
  slug: 'qr-code-generator',
  basePath: '/qr-code-generator',
  label: 'QR-Code-Generator',
  title: 'QR-Code-Generator für jeden Typ',
  metaTitle: 'QR-Code-Generator: ein Typ, ein Format, ein Code',
  metaDescription:
    'Jeder QR-Typ im Detail: Link, vCard, GiroCode, WhatsApp, Instagram, Mail, Telefon, SMS, Standort, Termin, Freitext, Paketabstellort, PDF, Excel, Google-Bewertung, Anwesenheit, Buchung.',
  intro: [
    'Ein QR-Code ist kein Format, sondern ein Behälter. Was er auslöst, hängt davon ab, was drinsteht: eine Adresse öffnet den Browser, ein vCard-Block den Kontakt-Dialog, ein tel-Link die Wählmaske, ein VEVENT den Kalender.',
    'Diese Übersicht erklärt für jeden Typ, was im Code landet, welche Grenzen der Standard setzt und wie groß der Code im Druck sein muss. Jede Seite öffnet den Generator mit dem passenden Typ vorausgewählt.',
  ],
  sections: [
    {
      title: 'Warum der Typ vor der Gestaltung kommt',
      body: [
        'Die meisten QR-Codes, die nicht funktionieren, funktionieren nicht wegen der Farbe. Sie funktionieren nicht, weil der Inhalt nicht zu dem passt, was der Nutzer erwartet. Ein Text-Code, der eine Telefonnummer enthält, wählt nichts. Ein Link-Code auf eine Seite mit Anmeldemaske verliert den halben Kontakt.',
        'Wer den Typ richtig wählt, umgeht die halbe Fehlerursachenliste: WLAN bekommt einen WIFI-Block, kein Link auf eine Seite mit dem Passwort. Zahlungen bekommen EPC069-12, keine IBAN im Fließtext.',
      ],
    },
    {
      title: 'Statisch ist hier die Regel',
      body: [
        'Alle Codes auf dieser Seite erzeugen statische Codes: Der Inhalt steckt im Muster, es gibt keinen Dienst dazwischen, der zählt, weiterleitet oder abschalten kann. Das ist bei allen Typen der richtige Ausgangspunkt, weil der Code nicht von der Verfügbarkeit eines Anbieters abhängt.',
        'Der Preis dafür ist die Dauerhaftigkeit: Wer die Zielseite umzieht, muss den Code neu drucken. Bei Kontaktdaten, WLAN und Zahlungsdaten ist das selten ein Problem, bei Kampagnenlinks häufiger.',
      ],
    },
    {
      title: 'Zwei Typen haben eigene Anleitungen',
      body: [
        'WLAN und Speisekarte sind hier nicht aufgeführt, weil sie bereits eigene Anleitungen mit eigener mehrsprachiger Fassung haben. Beim WLAN-Code lohnt die Anleitung, weil das Format eine Eigenheit mit WPA3 hat. Bei der Speisekarte liegt der Aufwand nicht im Code, sondern in der Zielseite.',
        'Alle übrigen Typen des Generators stehen oben in der Liste: zusätzlich zu den ersten zwölf sind Facebook, YouTube, X, PayPal und MECARD dazugekommen. Nicht beschrieben sind Bitcoin und Pix, weil beide für den deutschen Markt keine Rolle spielen, sowie WLAN und Speisekarte, die ihre eigenen Anleitungen haben.',
      ],
    },
  ],
  faq: [
    {
      q: 'Welcher QR-Typ ist der richtige für meine Website?',
      a: 'Der Link-Typ. Er enthält nur die Adresse, wird von jeder Kamera gelesen und braucht kein Zusatzformat. Für Kontakte, WLAN, Zahlungen und Termine gibt es dagegen eigene Typen, die das Telefon direkt versteht.',
    },
    {
      q: 'Sind die Codes hier kostenlos und ohne Ablaufdatum?',
      a: 'Ja. Alle Typen erzeugen statische Codes ohne Konto, ohne Scanbegrenzung und ohne Ablauf. Sie funktionieren, solange das Gerät den gedruckten Code lesen kann.',
    },
    {
      q: 'Kann ich die Codes gewerblich nutzen?',
      a: 'Ja. Die Codes gehören Ihnen, es gibt keine Lizenzbeschränkung für den Aufdruck auf Produkten, Schildern oder Rechnungen.',
    },
  ],
  subs: [
    ...TYPEN_PART_ONE,
    ...TYPEN_PART_TWO,
    ...TYPEN_PART_THREE,
    ...TYPEN_PART_FOUR,
    ...TYPEN_PART_FIVE,
    ...TYPEN_PART_SIX,
    ...TYPEN_PART_SEVEN,
    ...TYPEN_PART_EIGHT,
    ...TYPEN_PART_NINE,
  ],
  relatedLinks: [
    { label: 'Kostenlos und ohne Anmeldung: was das heißt', href: '/qr-code-generator/kostenlos' },
    { label: 'Die fünf Bauformen im Vergleich', href: '/qr-code-generator/vergleich' },
    { label: 'WLAN QR-Code: Gastnetz, Speedport, die WPA3-Falle', href: '/wlan-qr-code' },
    { label: 'Speisekarten-QR-Code für die Gastronomie', href: '/qr-codes-fuer/unternehmen/gastronomie' },
    { label: 'Druckgrößen, Kontrast und Material', href: '/qr-codes-auf' },
    { label: 'Statisch oder dynamisch: was nach dem Druck noch geht', href: '/blog/dynamische-vs-statische-qr-codes' },
  ],
  consolidated: [],
  sources: [
    { label: 'EPC069-12: Quick Response Code, SEPA credit transfer', href: 'https://www.europeanpaymentscouncil.eu/' },
    { label: 'RFC 6350: vCard Format Specification', href: 'https://www.rfc-editor.org/rfc/rfc6350' },
    { label: 'RFC 5545: iCalendar, VEVENT', href: 'https://www.rfc-editor.org/rfc/rfc5545' },
    { label: 'ISO/IEC 18004: QR-Code-Symbologie', href: 'https://www.iso.org/standard/62021.html' },
  ],
};
