/**
 * DACH standards cluster.
 *
 * The strategy note this came from lists 150 use cases. Most of them are
 * variations on a theme the site already covers once, and publishing 150 thin
 * pages built from one template is exactly the pattern Google's scaled content
 * policy targets. So this cluster takes the one idea in that document that no
 * international generator can copy: German and EU rules that specify, permit or
 * forbid a QR code on a physical object.
 *
 * Every page here states what the rule actually requires, cites the primary
 * source, and says plainly where something is voluntary. Two widespread myths
 * are corrected on purpose (the till receipt QR and the extent of the digital
 * product passport), because being the page that tells the truth is worth more
 * than being the page that repeats the brochure.
 */

import type { SeoHub, SeoSubPage } from './seo-pages';

const wine: SeoSubPage = {
  slug: 'wein-e-label',
  title: 'Weinetikett mit QR-Code: das E-Label nach EU-Recht',
  metaTitle: 'E-Label Wein: QR-Code für Zutaten und Nährwerte',
  metaDescription:
    'Seit Dezember 2023 braucht Wein Zutaten und Nährwerte. Was aufs Etikett muss, was der QR-Code tragen darf und welche Größe auf 100 mm funktioniert.',
  intro: [
    'Seit dem 8. Dezember 2023 gilt die Verordnung (EU) 2021/2117. Für Weine und aromatisierte Weinerzeugnisse, die ab diesem Datum hergestellt oder etikettiert werden, sind eine Zutatenliste und eine Nährwertdeklaration vorgeschrieben. Beides darf auf das Etikett gedruckt oder über einen QR-Code bereitgestellt werden.',
    'Das ist der eine Fall im deutschen Markt, in dem ein QR-Code auf einem Produkt nahezu unvermeidlich ist: Zutatenliste und Nährwerte in mehreren Sprachen passen auf ein 100-Millimeter-Etikett nicht.',
  ],
  sources: [
    {
      label: 'Verordnung (EU) 2021/2117, konsolidierter Text',
      href: 'https://eur-lex.europa.eu/eli/reg/2021/2117/oj',
    },
    {
      label: 'Verordnung (EU) 1169/2011, Lebensmittelinformations-Verordnung',
      href: 'https://eur-lex.europa.eu/eli/reg/2011/1169/oj',
    },
  ],
  sections: [
    {
      title: 'Was muss auf dem Etikett bleiben?',
      body: [
        'Zwei Angaben dürfen nicht ins Netz ausgelagert werden: der Brennwert, gekennzeichnet mit dem Symbol „E", und die Allergene, insbesondere Sulfite. Beides muss auf der Flasche stehen. Alles andere aus der Nährwertdeklaration und die vollständige Zutatenliste dürfen elektronisch bereitgestellt werden.',
        'Praktisch heißt das: Wer den QR-Code nutzt, druckt weiterhin „E" plus Kilojoule und Kilokalorien je 100 ml sowie den Allergenhinweis. Der Code übernimmt Fett, gesättigte Fettsäuren, Kohlenhydrate, Zucker, Eiweiß, Salz und die Zutatenliste.',
      ],
      bullets: [
        'Auf dem Etikett: Brennwert in kJ und kcal je 100 ml, Symbol „E", Allergene',
        'Über den Code: vollständige Nährwertdeklaration, Zutatenliste, Mengenangaben',
        'Bei Wein unter 10 Prozent Alkohol: zusätzlich das Mindesthaltbarkeitsdatum, ebenfalls elektronisch möglich',
      ],
    },
    {
      title: 'Was darf hinter dem Code nicht stehen?',
      body: [
        'Die Verordnung ist an dieser Stelle strenger, als die meisten Ratgeber erwähnen: Das elektronische Etikett darf keine Verkaufs- oder Marketinginhalte enthalten und keine personenbezogenen Daten der Nutzer erheben. Ein Shop-Link, ein Newsletter-Formular oder ein Zählpixel auf derselben Seite ist ein Risiko, das man sich spart.',
        'Für einen statischen QR-Code ist das ein Vorteil. Er führt direkt auf eine Seite, die Sie kontrollieren, ohne Weiterleitungsdienst dazwischen und ohne Zählung des Scans. Genau das verlangt die Vorschrift.',
      ],
    },
    {
      title: 'Wie lange muss die Seite erreichbar bleiben?',
      body: [
        'Die Informationen müssen verfügbar sein, solange das Erzeugnis im Verkehr ist. Ein statischer Code zeigt auf eine feste Adresse. Wenn Sie diese Adresse später umbauen, wird der aufgedruckte Code unbrauchbar, und das betrifft jede Flasche dieser Charge.',
        'Deshalb gilt für E-Labels eine andere Regel als für Werbecodes: Die Zielseite gehört auf eine Adresse, die nicht umzieht, und sie sollte nicht von einem Formularsystem abhängen, das in zwei Jahren abgeschaltet wird.',
      ],
    },
    {
      title: 'Welche Größe und Farbe funktioniert auf dem Etikett?',
      body: [
        'Ein Weinetikett ist klein und meist glänzend. Auf einer 100-Millimeter-Breite ist ein Code von 15 bis 18 Millimetern Kantenlänge die Untergrenze, mit ruhigem Rand von mindestens vier Modulen. Bei matten Etiketten und gutem Licht genügt das; bei Heißfolie oder Glanzlack sollte er größer sein.',
        'Der Code muss dunkler sein als der Untergrund. Ein heller Code auf dunklem Etikett sieht gut aus und scheitert bei der Kamera. Fehlerkorrekturstufe Q oder H, weil Etiketten beim Abfüllen und im Kühlregal Feuchtigkeit und Kratzer abbekommen.',
      ],
      bullets: [
        'Mindestens 15 mm Kantenlänge auf 100 mm Etikettbreite, lieber 18 mm',
        'Fehlerkorrektur Q oder H, Ruhezone vier Module',
        'Nie invertiert drucken, kein Glanzlack über dem Code',
        'Vor dem Druck auf dem echten Material scannen, nicht auf dem Bildschirm',
      ],
    },
  ],
  useCases: [
    {
      title: 'Weingut mit mehreren Lagen',
      text: 'Ein Code pro Wein, nicht pro Etikettengröße. Die Zutaten unterscheiden sich je Ausbau, die Nährwerte je Restzucker.',
    },
    {
      title: 'Preisliste und Bestellformular',
      text: 'Die Pflicht gilt auch für Preislisten mit Bestellfunktion. Für diese Listen ist ein sammelnder Code zulässig, der die Angaben aller Weine auf einer Seite zeigt.',
    },
    {
      title: 'Lohnabfüller und Genossenschaft',
      text: 'Wenn eine Etikettencharge für mehrere Abnehmer läuft, braucht jeder Wein seine eigene Zielseite. Der Code ist der einzige Ort, an dem die Unterscheidung noch möglich ist.',
    },
  ],
  steps: [
    'Zutatenliste und Nährwerte je 100 ml für den konkreten Wein zusammenstellen, aus Analysedaten oder berechnet aus Alkohol, Restzucker und Säure.',
    'Eine dauerhafte Seite je Wein anlegen, mehrsprachig in den Sprachen der Zielmärkte, ohne Shop-Elemente und ohne Formular.',
    'QR-Code als statischen Link auf genau diese Seite erzeugen, Fehlerkorrektur Q, Farbe dunkel auf hell.',
    'Auf dem echten Etikett drucken und mit drei Geräten bei Ladenlicht scannen, bevor die Charge läuft.',
    'Brennwert mit „E" und Allergene weiterhin auf das Etikett setzen, sonst ist das E-Label unvollständig.',
  ],
  faq: [
    {
      q: 'Ist ein QR-Code auf der Weinflasche Pflicht?',
      a: 'Nein. Pflicht sind Zutatenliste und Nährwertdeklaration. Sie dürfen gedruckt oder elektronisch bereitgestellt werden. Der Code ist der übliche Weg, weil beide Listen in mehreren Sprachen nicht auf das Etikett passen.',
    },
    {
      q: 'Muss der QR-Code auf jeder Flasche anders sein?',
      a: 'Ja, wenn sich die Angaben unterscheiden. Jeder Wein braucht seine eigene Zielseite. Bei Preislisten mit Bestellfunktion ist ausnahmsweise ein gemeinsamer Code auf eine Sammelseite zulässig.',
    },
    {
      q: 'Darf hinter dem Code ein Online-Shop stehen?',
      a: 'Die Verordnung verbietet Verkaufs- und Marketinginhalte auf dem elektronischen Etikett und die Erhebung personenbezogener Daten. Der Code sollte deshalb auf eine reine Informationsseite führen.',
    },
    {
      q: 'Gilt das auch für Bier und Spirituosen?',
      a: 'Nein. Die Regelung betrifft Wein und aromatisierte Weinerzeugnisse. Freiwillige Nährwertangaben per Code gibt es in anderen Kategorien, eine Pflicht besteht dort nicht.',
    },
  ],
  translations: [
    { lang: 'en', label: 'English version, for importers and buyers', href: '/wine-e-label' },
  ],
  toolLinks: [
    { label: 'URL-Code für die E-Label-Seite erstellen', href: '/?type=url' },
    { label: 'Druckgrößen nach Leseabstand', href: '/qr-codes-auf' },
  ],
  blogLinks: [
    { label: 'QR-Code drucken: Kontrast, Größe und Farben', href: '/blog/qr-code-drucken-kontrast-groesse' },
  ],
};

const dpp: SeoSubPage = {
  slug: 'digitaler-produktpass',
  title: 'Digitaler Produktpass: was ab 2027 wirklich gilt',
  metaTitle: 'Digitaler Produktpass: QR-Code und Fristen 2027',
  metaDescription:
    'ESPR und Batteriepass: welche Produkte wann einen QR-Code brauchen, was der Datenträger leisten muss und was für Textilien und Elektronik noch offen ist.',
  intro: [
    'Der Digitale Produktpass wird in vielen Beiträgen so beschrieben, als wäre er ab 2025 für Textilien, Elektronik und Möbel Pflicht. Das ist nicht der Fall. Die Verordnung (EU) 2024/1781 ist seit dem 18. Juli 2024 in Kraft, schreibt aber für keine Produktgruppe von sich aus einen Pass vor.',
    'Pflichten entstehen erst durch delegierte Rechtsakte je Produktgruppe. Der erste und bislang einzige verbindliche Termin betrifft Batterien.',
  ],
  sources: [
    {
      label: 'Verordnung (EU) 2024/1781 (ESPR)',
      href: 'https://eur-lex.europa.eu/eli/reg/2024/1781/oj',
    },
    {
      label: 'Verordnung (EU) 2023/1542 (Batterien), Artikel 77',
      href: 'https://eur-lex.europa.eu/eli/reg/2023/1542/oj',
    },
  ],
  sections: [
    {
      title: 'Wann wird der Produktpass Pflicht?',
      body: [
        'Der Batteriepass ist der erste verbindliche Fall. Ab dem 18. Februar 2027 brauchen Batterien für leichte Verkehrsmittel, Industriebatterien über 2 kWh und Traktionsbatterien für Elektrofahrzeuge einen digitalen Pass, abrufbar über einen Datenträger auf der Batterie.',
        'Für alle anderen Gruppen hängt das Datum am delegierten Rechtsakt, der noch nicht beschlossen ist. Der Arbeitsplan der Kommission nennt Eisen und Stahl, dann Textilien, Aluminium und Reifen, danach Möbel und Matratzen. Das sind Planungen, keine Fristen.',
      ],
      bullets: [
        '18. Juli 2024: ESPR in Kraft, Rahmen ohne Produktpflicht',
        '20. Juli 2026: zentrales Register der EU in Betrieb',
        '18. August 2026: physisches Batterieetikett verpflichtend',
        '18. Februar 2027: QR-Code und Batteriepass verpflichtend',
        'Ab 2027: delegierte Rechtsakte für weitere Gruppen, jeweils mit Übergangsfrist',
      ],
    },
    {
      title: 'Schreibt das Gesetz einen QR-Code vor?',
      body: [
        'Das Gesetz verlangt einen Datenträger, nicht ausdrücklich einen QR-Code. Welcher Träger zulässig ist, regelt der delegierte Rechtsakt je Produktgruppe. Für Batterien ist der QR-Code der vorgesehene Weg; in anderen Gruppen sind DataMatrix, NFC oder RFID im Gespräch.',
        'Für die Praxis heißt das: Wer heute einen QR-Code auf das Typenschild setzt, ist für den wahrscheinlichen Fall vorbereitet, sollte aber die endgültige Festlegung der eigenen Produktgruppe abwarten.',
      ],
    },
    {
      title: 'Was gehört hinter den Code?',
      body: [
        'Ein Produktpass ist kein Datenblatt als PDF. Er ist ein strukturierter Datensatz mit einem dauerhaften Produktidentifikator, der über das Produkt, seine Materialien, seine Reparierbarkeit und seine Entsorgung Auskunft gibt und der maschinell lesbar bleibt.',
        'Wer heute mit der Vorbereitung beginnt, sortiert Produktstammdaten: Materialzusammensetzung, Gewicht, Schadstoffe, Ersatzteile, Reparaturanleitungen. Der Code ist am Ende der kleinste Teil der Arbeit.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Hersteller von E-Bike-Akkus',
      text: 'Betroffen ab Februar 2027. Der Code sitzt auf dem Akkugehäuse und muss auch nach Jahren noch auf einen Datensatz zeigen, der die Zellchemie nennt.',
    },
    {
      title: 'Maschinenbauer mit Typenschild',
      text: 'Noch keine DPP-Pflicht, aber schon heute sinnvoll: Der Code führt zur Ersatzteilliste und zur Konformitätserklärung der konkreten Maschine.',
    },
    {
      title: 'Textil und Möbel',
      text: 'Beobachten statt handeln. Ohne delegierten Rechtsakt gibt es keine Pflicht, und ein Code auf jedem Etikett kostet Geld ohne rechtlichen Nutzen.',
    },
  ],
  steps: [
    'Produktgruppen im eigenen Sortiment auflisten und je Gruppe prüfen, ob ein delegierter Rechtsakt beschlossen oder angekündigt ist.',
    'Für Batterien ab 2 kWh: Datenmodell aufbauen und den dauerhaften Produktidentifikator festlegen, bevor über den Code entschieden wird.',
    'Zielseite so aufbauen, dass sie ohne Login und ohne App erreichbar ist und sich maschinell auslesen lässt.',
    'Datenträger auf dem Gehäuse platzieren: dauerhaft, kratzfest, mit Ruhezone, an einer Stelle, die beim Einbau nicht verdeckt wird.',
    'Erreichbarkeit über die Lebensdauer sicherstellen, nicht nur bis zum Ende der Garantie.',
  ],
  faq: [
    {
      q: 'Ist der Digitale Produktpass ab 2025 Pflicht?',
      a: 'Nein. Die ESPR ist seit Juli 2024 in Kraft, verpflichtet aber ohne delegierten Rechtsakt zu nichts. Der erste verbindliche Pass ist der Batteriepass ab 18. Februar 2027.',
    },
    {
      q: 'Brauchen Textilien 2027 schon einen Produktpass?',
      a: 'Nach derzeitigem Stand nicht. Textilien stehen im Arbeitsplan, ein delegierter Rechtsakt mit Frist liegt nicht vor. Wer das Gegenteil liest, liest eine Planung als Gesetz.',
    },
    {
      q: 'Reicht ein QR-Code auf der Verpackung?',
      a: 'Für den Batteriepass ist der Datenträger am Produkt vorgesehen, nicht an der Umverpackung. Für andere Gruppen entscheidet der jeweilige Rechtsakt.',
    },
  ],
  toolLinks: [
    { label: 'URL-Code für den Produktpass erstellen', href: '/?type=url' },
    { label: 'QR-Codes auf Verpackungen', href: '/qr-codes-auf' },
  ],
  blogLinks: [{ label: 'Statisch oder dynamisch: was nach dem Druck noch geht', href: '/blog/dynamische-vs-statische-qr-codes' }],
};

const erechnung: SeoSubPage = {
  slug: 'erechnung',
  title: 'E-Rechnung und QR-Code: was der Code leisten kann',
  metaTitle: 'E-Rechnung: QR-Code auf der Rechnung richtig nutzen',
  metaDescription:
    'Seit 2025 müssen Unternehmen E-Rechnungen empfangen. Was der QR-Code auf Papierrechnungen darf, wo GiroCode und E-Rechnung sich unterscheiden.',
  intro: [
    'Seit dem 1. Januar 2025 muss jedes inländische Unternehmen E-Rechnungen im B2B-Bereich empfangen können. Für das Ausstellen gelten Übergangsfristen: bis Ende 2026 ist Papier oder PDF mit Zustimmung des Empfängers noch zulässig, ab 2027 greift die Pflicht für Unternehmen über 800.000 Euro Vorjahresumsatz, ab 2028 für alle.',
    'In dieser Übergangszeit landen weiterhin Papierrechnungen auf dem Tisch, und dort taucht die Frage auf, ob ein QR-Code die E-Rechnung ersetzt. Er tut es nicht.',
  ],
  sources: [
    {
      label: '§ 14 UStG: Pflichtangaben in der Rechnung',
      href: 'https://www.gesetze-im-internet.de/ustg_1980/__14.html',
    },
    {
      label: '§ 27 Abs. 38 UStG: Übergangsregelungen E-Rechnung',
      href: 'https://www.gesetze-im-internet.de/ustg_1980/__27.html',
    },
    {
      label: '§ 33 UStDV: Angaben in der Rechnung',
      href: 'https://www.gesetze-im-internet.de/ustdv_1980/__33.html',
    },
  ],
  sections: [
    {
      title: 'Ersetzt ein QR-Code die E-Rechnung?',
      body: [
        'Nein. Eine E-Rechnung ist ein strukturierter, maschinenlesbarer Datensatz nach EN 16931, in Deutschland vor allem XRechnung als reines XML oder ZUGFeRD ab Version 2.0.1 als Hybrid aus PDF und XML. Ein QR-Code ist ein Träger für eine Adresse, kein Rechnungsformat.',
        'Was der Code leisten kann: auf den strukturierten Datensatz verweisen, ihn herunterladen lassen oder eine Prüfansicht öffnen. Das ist eine Arbeitserleichterung für den Empfänger, kein Ersatz für die Übermittlung.',
      ],
      bullets: [
        'E-Rechnung: strukturierter Datensatz nach EN 16931, per E-Mail oder Portal übermittelt',
        'QR-Code auf Papier: Verweis auf Download oder Prüfansicht, freiwillig',
        'GiroCode auf der Rechnung: Bezahlvorgang, ein völlig anderer Zweck',
      ],
    },
    {
      title: 'Warum zwei QR-Codes auf einer Rechnung meist zu viel sind',
      body: [
        'Auf Rechnungen begegnen sich zwei verschiedene Codes. Der EPC-GiroCode trägt IBAN, Betrag und Verwendungszweck und öffnet in der Banking-App eine vorausgefüllte Überweisung. Der zweite Code soll zur Rechnung selbst führen.',
        'Beide zusammen auf einem Blatt überfordern. Der GiroCode ist der stärkere, weil er eine Handlung auslöst und die Zahlungsdauer verkürzt. Wer zusätzlich auf die E-Rechnung verweisen will, platziert diesen Code in der Kopf- oder Fußzeile, nicht neben dem Zahlbetrag.',
      ],
    },
    {
      title: 'Was auf einem QR-Code zur Rechnung stehen darf',
      body: [
        'Der Code sollte auf eine Seite ohne Anmeldung führen, die den strukturierten Datensatz und eine lesbare Ansicht anbietet. Ein Link, der nach drei Monaten abläuft, ist bei einer Rechnung mit achtjähriger Aufbewahrungspflicht ein Eigentor.',
        'Die Pflichtangaben nach § 14 UStG müssen weiterhin in Textform auf der Rechnung stehen. Ein Code darf sie nicht ersetzen, auch nicht teilweise.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Handwerksbetrieb mit Papierrechnung',
      text: 'Bis Ende 2026 noch zulässig, mit Zustimmung des Kunden. Der GiroCode auf dem Blatt verkürzt die Zahlungsdauer sofort, unabhängig von der E-Rechnung.',
    },
    {
      title: 'Rechnungen an die öffentliche Hand',
      text: 'Hier gilt XRechnung bereits. Ein Code auf dem Ausdruck führt zur selben Datei, die ohnehin übermittelt wurde, und erspart Rückfragen.',
    },
    {
      title: 'Eingangsrechnungen prüfen',
      text: 'Ein Code auf der ausgedruckten Rechnung, der auf eine Prüfansicht führt, hilft der Buchhaltung mehr als ein Anhang, den niemand öffnet.',
    },
  ],
  steps: [
    'Zahlungsdaten als EPC-GiroCode nach EPC069-12 erzeugen, Betrag und Verwendungszweck vorbelegen.',
    'Zusätzlichen Code nur dann setzen, wenn es eine stabile Ablage für die Rechnungsdatei gibt.',
    'Im Layout den GiroCode neben den Zahlbetrag setzen, den Rechnungs-Code in die Fußzeile.',
    'Beide Codes auf dem Ausdruck testen, nicht nur am Bildschirm.',
  ],
  faq: [
    {
      q: 'Muss eine Rechnung ab 2025 einen QR-Code haben?',
      a: 'Nein. Weder § 14 UStG noch die E-Rechnungsregeln verlangen einen QR-Code. Pflicht ist der strukturierte Datensatz im B2B, nicht der Code.',
    },
    {
      q: 'Ist ein PDF mit QR-Code eine E-Rechnung?',
      a: 'Nein. ZUGFeRD besteht aus einem PDF und einer eingebetteten XML-Datei nach EN 16931. Ein PDF ohne diesen strukturierten Teil ist eine sonstige Rechnung.',
    },
    {
      q: 'Darf der GiroCode den Betrag enthalten?',
      a: 'Ja. Der EPC-GiroCode sieht ein optionales Betragsfeld vor. Vollständig vorbelegt sinkt die Fehlerquote beim Abtippen auf null.',
    },
  ],
  toolLinks: [
    { label: 'SEPA GiroCode erstellen', href: '/?type=sepa' },
    { label: 'QR-Code und Recht: Rechnung, Impressum', href: '/qr-code-recht' },
  ],
  blogLinks: [{ label: 'SEPA-GiroCode erstellen: Überweisung per QR-Code', href: '/blog/sepa-girocode-qr-code-erstellen' }],
};

const kassenbeleg: SeoSubPage = {
  slug: 'kassenbeleg-tse',
  title: 'QR-Code auf dem Kassenbeleg: was die KassenSichV erlaubt',
  metaTitle: 'Kassenbeleg mit QR-Code: TSE-Daten richtig drucken',
  metaDescription:
    'Der QR-Code auf dem Kassenbon ist nicht Pflicht, aber erlaubt: § 6 KassenSichV erlaubt TSE-Daten im Code statt in Klarschrift. Was drauf gehört.',
  intro: [
    'In vielen Beiträgen steht, ein Kassenbeleg müsse einen QR-Code enthalten. Das ist falsch. Das Bundesfinanzministerium stellt in seinen FAQ zur Belegausgabepflicht klar, dass ein QR-Code nicht gesetzlich vorgeschrieben ist.',
    'Erlaubt ist er trotzdem, und zwar mit einem konkreten Vorteil: Bestimmte Angaben der technischen Sicherheitseinrichtung müssen nicht in Klarschrift auf dem Bon stehen, wenn sie über einen aufgedruckten QR-Code auslesbar sind.',
  ],
  sources: [
    { label: '§ 146a AO: Ordnungsmäßigkeit elektronischer Aufzeichnungssysteme', href: 'https://www.gesetze-im-internet.de/ao_1977/__146a.html' },
    { label: 'Kassensicherungsverordnung (KassenSichV), § 6', href: 'https://www.gesetze-im-internet.de/kassensichv/' },
    {
      label: 'BMF: FAQ zur Belegausgabepflicht',
      href: 'https://www.bundesfinanzministerium.de/Content/DE/FAQ/FAQ-steuergerechtigkeit-belegpflicht.html',
    },
  ],
  sections: [
    {
      title: 'Muss ein QR-Code auf den Kassenbon?',
      body: [
        'Nein. Die Belegausgabepflicht verlangt einen Beleg, nicht einen Code. Seit dem 1. Januar 2020 muss jedes elektronische Aufzeichnungssystem einen Beleg ausgeben, auf Papier oder mit Zustimmung des Kunden elektronisch.',
        'Der Code ist eine Option mit zwei Wirkungen: Er verkürzt den Bon, weil Zeichenketten wie Prüfwert und Signaturzähler nicht mehr als lesbarer Text erscheinen müssen, und er beschleunigt eine Kassen-Nachschau, weil der Prüfer den Beleg maschinell verifizieren kann.',
      ],
    },
    {
      title: 'Welche Angaben dürfen in den Code?',
      body: [
        'Nach § 6 Satz 2 KassenSichV dürfen Angaben, die zur Absicherung der Buchungsdaten erforderlich sind, statt in lesbarer Form auch über einen QR-Code dargestellt werden. Betroffen sind typischerweise Transaktionsnummer, Seriennummer des Aufzeichnungssystems, Signaturzähler, Prüfwert sowie Beginn und Ende des Vorgangs.',
        'Nicht in den Code gehören die Pflichtangaben eines Belegs nach § 33 UStDV: Aussteller mit Anschrift, Datum, Art und Menge der Leistung, Entgelt, Steuerbetrag und Steuersatz. Diese müssen lesbar bleiben.',
      ],
      bullets: [
        'Im Code zulässig: TSE-Begleitdaten, die der Prüfwertverkettung dienen',
        'Lesbar auf dem Beleg: alle Angaben nach § 33 UStDV',
        'Format des Codes: nach DSFinV-K, damit Prüfprogramme ihn lesen können',
      ],
    },
    {
      title: 'Was der Code nicht löst',
      body: [
        'Ein QR-Code auf dem Bon sagt nichts über die Ordnungsmäßigkeit der Kasse. Wer glaubt, mit dem Aufdruck eine Prüfung zu bestehen, verwechselt Ursache und Darstellung. Die Aufzeichnung selbst muss durch eine zertifizierte TSE abgesichert sein.',
        'Ebenso wenig ersetzt der Code die Verfahrensdokumentation. Beides wird bei einer Nachschau getrennt geprüft.',
      ],
    },
    {
      title: 'Druckqualität: der Punkt, an dem es scheitert',
      body: [
        'Bonrollen sind thermisch, schmal und oft kontrastarm. Ein Code, der auf dem Bildschirm sitzt, wird auf 57-Millimeter-Papier bei 203 dpi schnell unlesbar. Praxiswert: mindestens 15 Millimeter Kantenlänge, Fehlerkorrektur M oder Q, kein Ausdruck über die vorgestanzte Kante.',
        'Weil der Code freiwillig ist, ist ein unlesbarer Code schlechter als keiner: Er kostet Papier und bringt bei der Prüfung nichts.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Gastronomie mit Bondrucker',
      text: 'Der häufigste Fall. Kassenhersteller bieten den Aufdruck als Schalter an, häufig standardmäßig aus. Erst prüfen, ob die Firmware das DSFinV-K-Format schreibt.',
    },
    {
      title: 'Einzelhandel mit elektronischem Beleg',
      text: 'Wird der Beleg als PDF oder in einer App ausgegeben, übernimmt der Code im Dokument dieselbe Rolle und spart Papier vollständig.',
    },
    {
      title: 'Nachschau vorbereiten',
      text: 'Ein funktionierender Code verkürzt die Prüfung vor Ort. Das ist ein Argument für den Aufdruck, aber kein gesetzliches.',
    },
  ],
  steps: [
    'Prüfen, ob das Kassensystem den QR-Code nach DSFinV-K überhaupt ausgeben kann, und ob er aktiviert ist.',
    'Testbon mit mehreren Positionen drucken und mit zwei Geräten scannen.',
    'Kantenlänge auf dem echten Rollenpapier messen, nicht im PDF.',
    'Pflichtangaben nach § 33 UStDV weiterhin in Klarschrift prüfen.',
    'Verfahrensdokumentation ergänzen, wenn der Code genutzt wird.',
  ],
  faq: [
    {
      q: 'Ist der QR-Code auf dem Kassenbon Pflicht?',
      a: 'Nein. Das BMF führt in den FAQ zur Belegausgabepflicht aus, dass ein QR-Code freiwillig ist. Die Belegausgabepflicht besteht unabhängig davon.',
    },
    {
      q: 'Darf ich die TSE-Daten im Code verstecken?',
      a: 'Ja. § 6 Satz 2 KassenSichV erlaubt, bestimmte Angaben zur Absicherung der Buchungsdaten über einen QR-Code statt in lesbarer Form darzustellen. Die Pflichtangaben nach § 33 UStDV bleiben lesbar.',
    },
    {
      q: 'Welchen Inhalt muss der Code haben?',
      a: 'Der Aufbau ist in der DSFinV-K beschrieben, damit Prüfprogramme den Beleg maschinell auswerten können. Ein selbst gebauter Code mit eigenen Feldern hilft bei der Nachschau nicht.',
    },
  ],
  toolLinks: [
    { label: 'Freitext-Code für Prüfwerte erstellen', href: '/?type=text' },
    { label: 'QR-Code und Recht', href: '/qr-code-recht' },
  ],
  blogLinks: [],
};

const rettungskarte: SeoSubPage = {
  slug: 'rettungskarte',
  title: 'Rettungskarte am Auto: QR-Code richtig anbringen',
  metaTitle: 'Rettungskarte mit QR-Code: Position und Grenzen',
  metaDescription:
    'Rettungskarte hinter der Sonnenblende, QR-Code an Scheibe, B-Säule und Tankklappe: was Feuerwehren erwarten, was freiwillig ist und was schiefgeht.',
  intro: [
    'Eine Rettungskarte zeigt der Feuerwehr, wo Airbags, Gurtstraffer, Batterie und Verstärkungen im konkreten Fahrzeug sitzen. Sie ist seit 2009 als gemeinsamer Standard von VDA und ADAC etabliert und für die meisten Modelle kostenlos beim Hersteller erhältlich.',
    'Der QR-Code ist eine Ergänzung dazu, keine Pflicht. Er hilft nur unter einer Bedingung: Er muss zur passenden Rettungskarte des Fahrzeugmodells führen.',
  ],
  sources: [
    { label: 'ADAC: Rettungskarten und Rettungsdatenblätter', href: 'https://www.adac.de/verkehr/sicherheit/rettungskarte/' },
    { label: 'RES-QR: Etiketten und Hintergrund', href: 'https://www.res-qr.de/' },
  ],
  sections: [
    {
      title: 'Wo gehört was hin?',
      body: [
        'Die Rettungskarte selbst gehört hinter die Fahrer-Sonnenblende, mit der bedruckten Seite nach innen gefaltet, damit sie nicht ausbleicht. Ein Aufkleber „Rettungskarte im Fahrzeug" an der Windschutzscheibe sagt den Einsatzkräften, dass sie dort nachsehen können.',
        'QR-Etiketten haben drei etablierte Positionen: Windschutzscheibe, B-Säule und Innenseite der Tankklappe. Bei Elektro- und Hybridfahrzeugen kommt die Ladeklappe dazu.',
      ],
      bullets: [
        'Rettungskarte: hinter der Sonnenblende, gefaltet, farbig gedruckt',
        'Aufkleber: oberer oder unterer Rand der Windschutzscheibe',
        'QR-Code: Windschutzscheibe, B-Säule, Tank- und Ladeklappe',
      ],
    },
    {
      title: 'Warum die Modellzuordnung entscheidend ist',
      body: [
        'Die Rettungskarte gilt für ein Modell, nicht für eine Marke. Ein Code, der auf die Startseite eines Herstellers führt, zwingt die Einsatzkraft im Einsatz zu einer Suche, die sie nicht machen wird.',
        'Zwei Wege sind üblich: die modellspezifischen Codes der kommerziellen Anbieter, oder ein eigener statischer Code, der direkt auf das PDF des eigenen Fahrzeugmodells zeigt. Der zweite Weg verlangt, dass die Adresse dauerhaft erreichbar bleibt.',
      ],
    },
    {
      title: 'Was ein selbst erstellter Code nicht kann',
      body: [
        'Ein QR-Code auf einem Aufkleber ersetzt keine Rettungskarte. Er ist ein Zeiger. Wer keinen Zugriff auf ein dauerhaft gehostetes, modellspezifisches Dokument hat, sollte die gedruckte Karte hinter der Sonnenblende nutzen und den Code weglassen.',
        'Ebenso wichtig: Der Code muss ohne App, ohne Login und ohne Netz im Funkloch funktionieren. Alles, was eine Anmeldung oder ein Skript zum Nachladen braucht, ist im Einsatz unbrauchbar.',
      ],
    },
    {
      title: 'Haltbarkeit im Auto',
      body: [
        'Ein Fahrzeuginnenraum erreicht im Sommer über 70 Grad, und an der Windschutzscheibe kommt UV-Licht dazu. Papieraufkleber bleichen aus, gedruckte Codes auf Normalpapier werden unlesbar.',
        'Für den Außenbereich geeignet sind wetterfeste Folienetiketten, die im Schatten der Sonnenblende oder an der B-Säule innen sitzen. Vor dem Verkleben die Fläche entfetten, sonst löst sich die Folie bei Wärme.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Privatfahrzeug',
      text: 'Karte vom Hersteller herunterladen, hinter der Sonnenblende deponieren, Aufkleber an die Scheibe. Ein Code ist optional.',
    },
    {
      title: 'Fuhrpark und Mietflotte',
      text: 'Hier lohnt der Code: Das Typenschild ist einheitlich, die Dokumente liegen zentral, und der Code führt jede Einsatzkraft zum richtigen Modell.',
    },
    {
      title: 'Oldtimer und Umbauten',
      text: 'Für Fahrzeuge ohne Herstellerkarte gibt es keine Standardlösung. Der Code auf ein selbst erstelltes Datenblatt ist besser als nichts, aber nur mit korrekten Angaben.',
    },
  ],
  steps: [
    'Rettungskarte für das eigene Modell beim Hersteller, ADAC oder DEKRA herunterladen.',
    'Dokument dauerhaft ablegen, mit sprechender Adresse, ohne Login.',
    'QR-Code als statischen Link auf genau dieses Dokument erstellen.',
    'Auf wetterfeste Folie drucken, mindestens 30 Millimeter Kantenlänge für den Abstand im Freien.',
    'An B-Säule und Tankklappe kleben, zusätzlich Karte hinter die Sonnenblende.',
  ],
  faq: [
    {
      q: 'Ist eine Rettungskarte Pflicht?',
      a: 'Nein. Es gibt keine gesetzliche Pflicht. Die Karte ist ein freiwilliges Hilfsmittel, das 2009 als gemeinsamer Standard von VDA und ADAC eingeführt wurde, und sie ist für die meisten Modelle kostenlos erhältlich.',
    },
    {
      q: 'Reicht ein QR-Code an der Windschutzscheibe?',
      a: 'Nur als Ergänzung. Die Rettungskarte hinter der Sonnenblende ist der international kommunizierte Ort. Der Code hilft, wenn die Karte fehlt oder nass geworden ist.',
    },
    {
      q: 'Welche Größe braucht der Code am Auto?',
      a: 'Mindestens 30 Millimeter Kantenlänge, weil aus ein bis zwei Metern Abstand und bei Wind gescannt wird. An der Tankklappe genügen 25 Millimeter.',
    },
  ],
  toolLinks: [
    { label: 'URL-Code für die Rettungskarte erstellen', href: '/?type=url' },
    { label: 'Wetterfeste Codes: Material und Größe', href: '/qr-codes-auf' },
  ],
  blogLinks: [{ label: 'QR-Codes auf Fahrzeugen und Schildern', href: '/blog/qr-codes-flyer-plakate-drucksachen' }],
};

const trinkwasser: SeoSubPage = {
  slug: 'trinkwasser',
  title: 'Trinkwasser-Prüfbericht im Mietshaus: Aushang per QR-Code',
  metaTitle: 'Trinkwasser Prüfbericht: Aushang mit QR-Code',
  metaDescription:
    'Legionellenprüfung alle drei Jahre, Information der Mieter, Prüfbericht im Treppenhaus: was die TrinkwV 2023 verlangt und wie ein QR-Code dabei hilft.',
  intro: [
    'Die Trinkwasserverordnung in der Fassung von 2023 verpflichtet Betreiber von Wasserversorgungsanlagen zu Untersuchungen und zur Information der Verbraucher. In Mehrfamilienhäusern trifft das den Vermieter oder die Eigentümergemeinschaft.',
    'Der Prüfbericht landet regelmäßig als Kopie im Treppenhaus. Ein QR-Code ersetzt den Aushang nicht, er macht ihn lesbar und aktuell.',
  ],
  sources: [
    { label: 'Trinkwasserverordnung 2023 (TrinkwV)', href: 'https://www.gesetze-im-internet.de/trinkwv_2023/' },
    { label: 'Umweltbundesamt: Trinkwasser und Legionellen', href: 'https://www.umweltbundesamt.de/themen/wasser/trinkwasser' },
  ],
  sections: [
    {
      title: 'Wann ist die Legionellenprüfung Pflicht?',
      body: [
        'Nach § 31 TrinkwV muss untersucht werden, wenn drei Dinge zusammenkommen: eine Großanlage zur Trinkwassererwärmung mit mehr als 400 Litern Speicherinhalt oder mehr als drei Litern Inhalt in mindestens einer Leitung zwischen Erwärmer und Entnahmestelle, Duschen im Gebäude und kein Ein- oder Zweifamilienhaus.',
        'Vermietung gilt dabei als gewerbliche Tätigkeit. Wer eine Wohnung vermietet und die genannte Anlage betreibt, muss mindestens alle drei Jahre untersuchen lassen. Bei öffentlicher Tätigkeit gilt ein Jahr.',
      ],
      bullets: [
        'Großanlage: über 400 Liter Speicher oder über 3 Liter in der Leitung',
        'Duschen vorhanden, kein Ein- oder Zweifamilienhaus',
        'Gewerbliche Nutzung, also auch Vermietung: alle drei Jahre',
        'Technischer Maßnahmenwert: 100 KBE Legionellen je 100 ml',
      ],
    },
    {
      title: 'Was passiert bei einem auffälligen Befund?',
      body: [
        'Wird der Maßnahmenwert überschritten, greifen die Pflichten aus § 51 TrinkwV: Das Gesundheitsamt ist zu informieren, sofern die Untersuchungsstelle das nicht bereits getan hat, die Ursache ist zu klären, eine Risikoabschätzung zu erstellen und Maßnahmen sind umzusetzen.',
        'In dieser Situation ist Information das Wichtigste. Ein Aushang, der auf ein verständliches Dokument führt, ist besser als eine Laborseite, die niemand einordnen kann.',
      ],
    },
    {
      title: 'Muss der unauffällige Befund ausgehängt werden?',
      body: [
        'Das ist der Punkt, an dem die Rechtslage unterschiedlich gelesen wird. Die TrinkwV verlangt eine Information der Verbraucher, unter anderem zur Wasserbeschaffenheit und zu Bleileitungen. Ob ein unauffälliger Untersuchungsbefund selbst im Treppenhaus hängen muss, beantworten Gesundheitsämter unterschiedlich.',
        'Wer auf der sicheren Seite sein will, informiert: ein Aushang mit Datum, Untersuchungsstelle, Ergebnis und einer Kontaktmöglichkeit. Das ist keine Pflichtlektüre, aber es beendet Rückfragen.',
      ],
    },
    {
      title: 'Wie ein QR-Code dabei hilft',
      body: [
        'Der Prüfbericht ist mehrere Seiten lang und nennt Probenahmestellen. Als Aushang wird er auf eine Seite geschrumpft und ist dann unlesbar. Ein Code daneben führt auf das vollständige Dokument, ohne dass jemand Kopien machen muss.',
        'Wichtig ist die Dauerhaftigkeit: Solange das Dokument gilt, muss die Adresse halten. Ein Link auf einen Filehoster mit Ablaufdatum ist ungeeignet.',
      ],
      bullets: [
        'Code mindestens 25 Millimeter, DIN A4 Aushang, Leseabstand ein Meter',
        'Zielseite ohne Login, mit Datum der Untersuchung im Titel',
        'Alte Berichte nicht löschen, sondern kennzeichnen',
      ],
    },
  ],
  useCases: [
    {
      title: 'Hausverwaltung mit mehreren Objekten',
      text: 'Ein Code pro Objekt auf einem einheitlichen Aushang. Die Verwaltung aktualisiert die Datei, der Aushang bleibt hängen.',
    },
    {
      title: 'WEG mit zentraler Warmwasserbereitung',
      text: 'Die Gemeinschaft ist Betreiber. Der Verwalter hängt aus, der Beirat will den Nachweis sehen. Ein dauerhafter Link erspart Diskussionen.',
    },
    {
      title: 'Gewerbeobjekt mit öffentlichem Verkehr',
      text: 'Bei öffentlicher Tätigkeit gilt die jährliche Untersuchung. Der Aushang gehört dann in den Eingangsbereich, nicht ins Treppenhaus.',
    },
  ],
  steps: [
    'Prüfen, ob die eigene Anlage unter § 31 TrinkwV fällt: Speichergröße, Leitungslänge, Duschen, Gebäudetyp.',
    'Untersuchung durch eine zugelassene Stelle beauftragen und den Bericht dauerhaft ablegen.',
    'Bericht als PDF auf eine feste Adresse legen, ohne Login und ohne Ablaufdatum.',
    'QR-Code auf den Aushang setzen, mit Datum der Untersuchung daneben.',
    'Bei Befund: Gesundheitsamt, Ursachenklärung und Maßnahmen dokumentieren, nicht nur aushängen.',
  ],
  faq: [
    {
      q: 'Muss der Vermieter die Legionellenprüfung bezahlen?',
      a: 'Die regelmäßige Untersuchung ist Pflicht des Betreibers und kann als Betriebskosten umgelegt werden, wenn der Mietvertrag das vorsieht. Sanierungskosten und Zweitprüfungen sind nicht umlagefähig.',
    },
    {
      q: 'Wie oft muss untersucht werden?',
      a: 'Bei gewerblicher Tätigkeit, also auch bei Vermietung, mindestens alle drei Jahre nach § 31 TrinkwV. Bei öffentlicher Abgabe mindestens jährlich, sofern das Gesundheitsamt nichts anderes zulässt.',
    },
    {
      q: 'Reicht ein QR-Code als Aushang?',
      a: 'Ein Code allein informiert niemanden, der ihn nicht scannt. Er sollte neben einer kurzen gedruckten Zusammenfassung stehen, nicht an ihrer Stelle.',
    },
  ],
  toolLinks: [
    { label: 'URL-Code für den Prüfbericht erstellen', href: '/?type=url' },
    { label: 'Aushänge, die nicht abgerissen werden', href: '/qr-codes-fuer/schulen' },
  ],
  blogLinks: [],
};

export const STANDARDS_HUB: SeoHub = {
  slug: 'standards',
  basePath: '/standards',
  label: 'DACH-Standards',
  title: 'QR-Codes in deutschen und EU-Regeln',
  metaTitle: 'QR-Code nach deutscher Norm: E-Label, E-Rechnung, DPP',
  metaDescription:
    'Wo deutsche und EU-Regeln einen QR-Code verlangen, erlauben oder verbieten: Weinetikett, E-Rechnung, Kassenbeleg, Produktpass, Rettungskarte.',
  intro: [
    'Die meisten Seiten über QR-Codes erklären, was technisch möglich ist. Diese hier erklärt, was in Deutschland und der EU geregelt ist: Wo ein Code Pflicht ist (fast nirgends), wo er ausdrücklich erlaubt ist (öfter als gedacht) und wo er als Pflicht gilt, obwohl er es nicht ist.',
    'Jede Seite nennt die Rechtsquelle und sagt, was freiwillig bleibt. Das ist der Unterschied zwischen einer Beratung und einem Werbetext.',
  ],
  sections: [
    {
      title: 'Wo ist ein QR-Code tatsächlich Pflicht?',
      body: [
        'Erstaunlich selten. Bei Wein und aromatisierten Weinerzeugnissen ist die Angabe von Zutaten und Nährwerten vorgeschrieben, der Code ist nur der übliche Weg dorthin. Beim Digitalen Produktpass ist ab Februar 2027 für Batterien ein Datenträger vorgeschrieben, ein QR-Code wird dafür vorgesehen, steht aber nicht als Technologie im Gesetz.',
        'Bei Kassenbelegen, Rechnungen, Rettungskarten und Trinkwasseraushängen ist der Code freiwillig. Diese Seiten sagen das jeweils im ersten Absatz, damit niemand auf einer Annahme Geld ausgibt.',
      ],
    },
    {
      title: 'Warum diese Seiten auf einen deutschen Generator gehören',
      body: [
        'Ein US-amerikanischer Generator kann zu § 31 TrinkwV nichts sagen, weil er die Verordnung nicht kennt, und er wird zu einer Weinflasche keine Aussage über das Symbol „E" treffen. Regulatorische Inhalte sind der Teil des Marktes, den ein internationales Werkzeug strukturell nicht bedient.',
        'Dazu kommt die technische Seite: Statische Codes ohne Weiterleitungsdienst sind bei Regelungen, die keine Datenerhebung erlauben, die passende Bauform. Ein E-Label darf keine personenbezogenen Daten sammeln. Ein Code, der direkt auf eine Seite zeigt, sammelt keine.',
      ],
    },
    {
      title: 'Prüfen, nicht glauben',
      body: [
        'Alle Angaben hier sind mit Stand Oktober 2026 gegen die Primärquelle geprüft und verlinkt. Wo die Rechtslage unterschiedlich ausgelegt wird, steht das dabei. Das ersetzt keine Rechtsberatung, und das steht auch dabei.',
        'Wer eine Abweichung findet, kann sie über die Seite mit den redaktionellen Richtlinien melden. Korrekturen werden mit Datum nachgeführt.',
      ],
    },
  ],
  faq: [
    {
      q: 'Für welchen Bereich ist ein QR-Code gesetzlich vorgeschrieben?',
      a: 'Für keinen Bereich ist der QR-Code als Technologie zwingend. Bei Wein sind die Angaben dahinter Pflicht, beim Produktpass ab 2027 ein Datenträger. Beim Rest ist der Code freiwillig.',
    },
    {
      q: 'Muss ich für ein E-Label einen dynamischen Code verwenden?',
      a: 'Nein, und für das E-Label ist ein statischer Code sogar naheliegender: Die Verordnung verbietet die Erhebung personenbezogener Daten, ein statischer Code erhebt keine.',
    },
    {
      q: 'Sind diese Seiten Rechtsberatung?',
      a: 'Nein. Sie ordnen ein, was in der Verordnung und in den Verwaltungsvorschriften steht, mit Quellenangabe. Die Bewertung des eigenen Falls gehört zu einer Anwältin oder einem Anwalt.',
    },
  ],
  sources: [
    { label: 'Gesetze im Internet: Trinkwasserverordnung 2023', href: 'https://www.gesetze-im-internet.de/trinkwv_2023/' },
    { label: 'EUR-Lex: Verordnung (EU) 2024/1781 (ESPR)', href: 'https://eur-lex.europa.eu/eli/reg/2024/1781/oj' },
  ],
  subs: [wine, dpp, erechnung, kassenbeleg, rettungskarte, trinkwasser],
  relatedLinks: [
    {
      label: 'Wine e-label, English version for importers and buyers',
      href: '/wine-e-label',
    },
  ],
  consolidated: [],
};
