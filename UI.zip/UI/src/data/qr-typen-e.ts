/**
 * German type pages, fifth batch.
 *
 * Both pages answer a search the German market makes and the market leader does
 * not serve in a form a German reader would recognise: the PDF code (their
 * strongest file-format page, missing here) and the Google review code (the
 * highest-intent local query in the set, and the page on our site that has to
 * be careful, because Google's policy is specific about what may not be asked
 * for).
 */
import type { SeoSubPage } from './seo-pages';

const pdf: SeoSubPage = {
  slug: 'pdf',
  title: 'PDF als QR-Code bereitstellen',
  metaTitle: 'PDF QR-Code erstellen: Dokument per Scan öffnen',
  metaDescription:
    'Ein QR-Code, der ein PDF öffnet: welcher Link in den Code gehört, wo die Datei liegen sollte und warum die Adresse wichtiger ist als die Datei selbst.',
  intro: [
    'Im Code steht kein Dokument, sondern eine Adresse. Der Scan öffnet die PDF-Datei dort, wo sie liegt: auf Ihrem Server, in Ihrem Cloud-Ordner, in Ihrem Shop. Wer den Code druckt, entscheidet damit vor allem eines, nämlich wie stabil diese Adresse in den nächsten Jahren bleibt.',
    'Das ist der Unterschied zwischen einem PDF-Code, der drei Jahre funktioniert, und einem, der nach dem nächsten Aufräumen im Ordner tot ist. Die Technik ist ein Link, die Sorgfalt liegt beim Hoster.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Die vollständige Adresse der Datei, mit https:// und Dateiendung, zum Beispiel https://ihre-domain.de/downloads/preisliste-2026.pdf. Der Code ist statisch: Die Adresse ist in das Muster eingebrannt, die Datei dahinter nicht.',
        'Das ist der praktisch wichtigste Punkt dieser Seite. Sie können die Datei jederzeit ersetzen, solange die Adresse gleich bleibt. Neue Preise, korrigierte Anleitung, aktualisierte Allergenliste: Datei austauschen, Code bleibt gedruckt, Plakat bleibt hängen.',
      ],
      bullets: [
        'Eine Datei pro Code, nicht ein Sammelordner',
        'Dateiname ohne Leerzeichen und ohne Umlaute, weil die Adresse sonst prozentkodiert im Code landet',
        'Keine Weiterleitung dazwischen, wenn es sich vermeiden lässt',
        'Vor dem Druck auf dem Handy öffnen, nicht nur am Rechner',
      ],
    },
    {
      title: 'Wo die Datei liegen sollte',
      body: [
        'Am haltbarsten ist ein Verzeichnis auf der eigenen Domain. Ordnerstrukturen ändern sich dort nur, wenn jemand sie ändert, und niemand kann den Zugriff abschalten. Genau das ist bei Fremdanbietern das Risiko: Ein Freigabelink aus einem Cloud-Speicher läuft ab, ändert seine Adresse oder wird gelöscht, wenn das Konto gekündigt wird.',
        'Wer eine Freigabe aus einem Cloud-Speicher nutzt, sollte zwei Dinge prüfen: Der Link hat keine Ablaufzeit, und der Zugriff ist nicht an ein Konto gebunden. Ein Link, der nach 30 Tagen aufhört zu funktionieren, ist auf einem gedruckten Etikett ein Fehler mit Ansage.',
        'Wir hosten Ihre Datei nicht. Der Code zeigt auf Ihre Adresse, damit die Datei Ihnen gehört und der Code nicht von einem Abo abhängt.',
      ],
    },
    {
      title: 'Größe, Kontrast und Beschriftung',
      body: [
        'Ein PDF-Code steht fast immer auf Papier, das in der Hand gehalten wird: Aufsteller, Aushang, Beipackzettel, Flyer. Bei 20 bis 30 Zentimetern Leseabstand reichen 2,5 Zentimeter Kantenlänge. Auf einem Schild, das aus einem Meter gelesen wird, sind es 10 bis 15 Zentimeter.',
        'Die Beschriftung entscheidet mit, ob gescannt wird. Schreiben Sie unter den Code, was passiert und was es kostet: keine Daten, keine Anmeldung, direkt die Datei. Ein Code ohne Beschriftung wird deutlich seltener gescannt, weil niemand weiß, was ihn erwartet.',
      ],
      bullets: [
        'Ruhezone von vier Modulen rundum frei halten',
        'Schwarz auf Weiß, nicht Weiß auf Schwarz',
        'Bei längeren Adressen die Kantenlänge um etwa ein Drittel erhöhen',
        'Auf dem fertigen Druck testen, nicht auf dem Monitor',
      ],
    },
    {
      title: 'Personenbezug und Zugriff',
      body: [
        'Eine PDF unter einer öffentlichen Adresse ist für jeden abrufbar, der die Adresse kennt, und Suchmaschinen finden sie in der Regel auch. Für Preislisten und Anleitungen ist das gewollt. Für Formulare mit Namen, Adressen, Kontodaten oder Gesundheitsangaben ist es ein Datenschutzproblem.',
        'Ein QR-Code kann keinen Zugriffsschutz ersetzen. Wenn das Dokument personenbezogene Daten enthält, gehört es in einen geschützten Bereich mit Anmeldung, und der Code zeigt dann auf die Anmeldeseite. Alles andere ist eine PDF, die versehentlich im Netz steht.',
      ],
    },
    {
      title: 'Wann ein PDF-Code die falsche Wahl ist',
      body: [
        'Wenn der Inhalt sich laufend ändert, ist eine Webseite besser als eine Datei. Eine Seite aktualisiert sich für alle, eine PDF muss neu erzeugt und hochgeladen werden, und alte Verlinkungen zeigen weiter auf die alte Fassung, wenn der Dateiname sich ändert.',
        'Wenn der Leser am Handy etwas ausfüllen soll, ist ein Formular besser. Lange PDFs sind auf dem Telefon mühsam zu lesen, und ein PDF-Formular auszufüllen ist auf einem kleinen Bildschirm eine Zumutung. Für alles, was zurückkommt, gehört ein Formular hinter den Code.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Preisliste im Verkaufsraum',
      text: 'Ein Aufsteller mit dem Code zur aktuellen Liste. Die Datei wird bei jeder Preisänderung ersetzt, das Schild bleibt stehen.',
    },
    {
      title: 'Montageanleitung am Produkt',
      text: 'Der Code auf dem Etikett führt zur Anleitung in der passenden Sprache. Bei Produktänderungen bleibt die Adresse, die Fassung wechselt.',
    },
    {
      title: 'Allergene und Zusatzstoffe',
      text: 'Die Karte verweist auf eine PDF mit vollständiger Allergenliste. Das entlastet die gedruckte Karte und lässt sich kurzfristig korrigieren.',
    },
    {
      title: 'Anmeldebogen für Kurse',
      text: 'Der Code am Aushang öffnet den Bogen zum Ausdrucken. Wer digital ausfüllen will, sollte eine Seite und kein PDF bekommen.',
    },
  ],
  steps: [
    'Die PDF erzeugen und so benennen, dass die Adresse lesbar bleibt: preisliste-2026.pdf statt Scan_0043.pdf.',
    'Die Datei auf die eigene Domain legen, in einen Ordner, der nicht bei der nächsten Umstellung umbenannt wird.',
    'Die vollständige Adresse kopieren und im Browser in einem privaten Fenster öffnen, also ohne Anmeldung.',
    'Typ „Webseite“ wählen, Adresse einfügen, Code erzeugen und als SVG herunterladen.',
    'Den gedruckten Code mit zwei Telefonen testen, einem iPhone und einem Android-Gerät.',
  ],
  faq: [
    {
      q: 'Muss ich die Datei bei Ihnen hochladen?',
      a: 'Nein. Es gibt keine Dateiablage und kein Konto. Der Code enthält nur die Adresse Ihrer Datei, die auf Ihrem Server oder in Ihrem Speicher liegt.',
    },
    {
      q: 'Kann ich die PDF später austauschen?',
      a: 'Ja, und das ist der übliche Weg. Solange die Adresse gleich bleibt, zeigt der gedruckte Code auf die neue Fassung. Ändert sich die Adresse, ist der Code tot.',
    },
    {
      q: 'Warum lädt die Datei auf dem Handy so langsam?',
      a: 'Meistens wegen der Dateigröße. Eine Preisliste mit Fotos kommt schnell auf mehrere Megabyte. Unter zwei Megabyte öffnet sie auch im Mobilfunknetz zügig.',
    },
    {
      q: 'Werden PDFs von Google gefunden?',
      a: 'Ja, PDF-Dateien werden indexiert. Wenn Sie das nicht wollen, etwa bei einem internen Dokument, gehört die Datei hinter eine Anmeldung und nicht hinter einen QR-Code.',
    },
    {
      q: 'Kann ich sehen, wie oft der Code gescannt wurde?',
      a: 'Bei einem statischen Code nicht, weil kein Dienst dazwischen liegt. Zählungen entstehen nur über einen Weiterleitungsdienst, und der kostet Unabhängigkeit.',
    },
  ],
  toolLinks: [
    { label: 'PDF-QR-Code erstellen', href: '/?type=url' },
    { label: 'Druckgrößen und Kontrast', href: '/qr-codes-auf' },
  ],
  blogLinks: [
    { label: 'QR-Code drucken: Kontrast, Größe, Material', href: '/blog/qr-code-drucken-kontrast-groesse' },
    { label: 'QR-Code und Datenschutz: was der Code verrät', href: '/blog/qr-code-dsgvo-datenschutz' },
  ],
};

const googleBewertung: SeoSubPage = {
  slug: 'google-bewertung',
  title: 'Google-Bewertung als QR-Code',
  metaTitle: 'Google Bewertung QR-Code: direkt zum Bewertungsformular',
  metaDescription:
    'Ein Code, der das Bewertungsformular Ihres Unternehmensprofils öffnet. Was in den Link gehört, was Google verbietet und was der Code nicht kann.',
  intro: [
    'Der Code ersetzt den Satz „Bewerten Sie uns doch bei Google" durch einen Scan. Statt zu suchen, das richtige Unternehmen zu treffen und das Formular zu finden, landet der Kunde direkt im Bewertungsfeld.',
    'Was er nicht ersetzt: die Bewertung selbst. Der Code senkt den Aufwand, er kauft keine Sterne. Und weil an dieser Stelle viel Unsinn verkauft wird, steht auf dieser Seite auch, was Google ausdrücklich nicht erlaubt.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Der Bewertungslink aus dem eigenen Unternehmensprofil. Google liefert dafür zwei brauchbare Formen: eine kurze Adresse der Art g.page/r/Kennung/review und die längere Variante search.google.com/local/writereview mit der Place-ID als Parameter. Beide öffnen das Formular, in dem der Kunde Sterne und Text erfassen kann.',
        'Die Place-ID ist der dauerhafte Teil. Sie hängt am Unternehmenseintrag, nicht an der Adresse der Filiale, und sie bleibt auch bestehen, wenn sich der Eintrag ändert. Prüfen Sie den Link trotzdem vor jedem Druck, denn Einträge werden zusammengelegt, umbenannt und gelegentlich neu angelegt.',
      ],
      bullets: [
        'Den Link im Unternehmensprofil unter „Bewertungen" erzeugen und kopieren, nicht aus dem Browser abtippen',
        'Im privaten Fenster testen, also ohne angemeldetes Google-Konto',
        'Ein Code pro Standort, nicht ein Code für eine Kette mit fünf Filialen',
        'Kurze eigene Adresse als Ziel ist bequem, macht den Code aber von einer Weiterleitung abhängig',
      ],
    },
    {
      title: 'Was Google ausdrücklich verbietet',
      body: [
        'Die Richtlinie für unzulässige und eingeschränkte Inhalte ist an dieser Stelle eindeutig. Nicht erlaubt ist, für eine Bewertung eine Gegenleistung anzubieten, also Rabatt, Gratisprodukt oder Geld, und ebenso wenig, nur zufriedene Kunden gezielt anzusprechen oder Kunden unter Druck zu setzen, direkt im Laden zu bewerten.',
        'Die Folge ist nicht nur das Löschen einzelner Bewertungen. Google kann dem Profil für einen Zeitraum das Recht entziehen, neue Bewertungen zu erhalten, vorhandene Bewertungen ausblenden und einen Hinweis anzeigen, dass Bewertungen entfernt wurden. Für einen Betrieb, der von Laufkundschaft lebt, ist das der teurere Schaden.',
        'Erlaubt ist dagegen ausdrücklich, um Bewertungen zu bitten, ohne Gegenleistung und ohne auf den Inhalt Einfluss zu nehmen. Genau das ist die Formulierung, die neben den Code gehört.',
      ],
    },
    {
      title: 'Wo der Code wirkt',
      body: [
        'Am wirksamsten ist der Moment direkt nach der Leistung: die Karteikarte des Handwerkers, der Beileger zur Rechnung, der Aufsteller an der Theke, das Schild am Ausgang der Praxis. Dort ist die Erfahrung frisch und das Telefon in der Hand.',
        'Weniger wirkt er dort, wo viele Menschen gleichzeitig warten. Ein Code im Wartezimmer wird gesehen, aber nicht gescannt, weil das Scannen eine Entscheidung ist und keine Beiläufigkeit. Ein Code auf der Rechnung erreicht dagegen genau eine Person in genau einem Moment.',
      ],
      bullets: [
        'Beschriftung mit Zeitangabe: „Bewertung abgeben, dauert etwa 30 Sekunden"',
        'Kein Hinweis auf eine Gegenleistung, weder im Text noch im Gespräch',
        'Keine Aufforderung, nur positive Bewertungen zu schreiben',
        'Bei mehreren Standorten je Standort ein eigener Code mit eigener Beschriftung',
      ],
    },
    {
      title: 'Was der Code nicht leistet',
      body: [
        'Er wählt keine Sterne vor. Er kann nicht prüfen, ob jemand bewertet hat, und er kann keine Bewertung erzwingen. Auf manchen Geräten öffnet der Link die Karte statt des Formulars, je nach installierter App und Zustand der Anmeldung.',
        'Er ersetzt auch keine Antworten auf Bewertungen. Der häufigste Grund für schlechte Wirkung ist nicht der Code, sondern ein Profil, auf dem seit Monaten niemand antwortet.',
      ],
    },
    {
      title: 'Messen ohne Selbstbetrug',
      body: [
        'Ein statischer Code zählt nichts. Wer wissen will, wie viele Scans stattgefunden haben, braucht einen Weiterleitungsdienst davor, und dann ist der Code nicht mehr statisch. Das ist eine Abwägung: Zählbarkeit gegen Unabhängigkeit.',
        'Die ehrliche Kennzahl ist ohnehin nicht die Zahl der Scans, sondern die Zahl der neuen Bewertungen im Profil, verglichen mit dem Zeitraum davor. Das ist die einzige Zahl, die Google selbst ausgibt, und sie braucht kein Tracking.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Handwerksbetrieb',
      text: 'Der Code auf der Karteikarte oder dem Rechnungsbeileger, direkt nach der abgeschlossenen Arbeit. Der Kunde ist zufrieden und hat das Telefon ohnehin in der Hand.',
    },
    {
      title: 'Gastronomie',
      text: 'Ein kleines Schild an der Theke oder am Ausgang. Nicht am Tisch, weil dort das Essen und nicht das Bewerten im Vordergrund steht.',
    },
    {
      title: 'Praxis und Studio',
      text: 'Der Code am Empfang, mit dem Hinweis auf den Zeitaufwand. Wer die Praxis verlässt, ist der Moment, in dem die Bewertung entsteht.',
    },
    {
      title: 'Mehrere Standorte',
      text: 'Je Filiale ein eigener Code mit eigener Beschriftung. Ein gemeinsamer Code für alle Filialen führt zu Bewertungen am falschen Eintrag und ist kaum zu korrigieren.',
    },
  ],
  steps: [
    'Im Unternehmensprofil den Bewertungslink erzeugen oder unter „Bewertungen" kopieren.',
    'Den Link in einem privaten Browserfenster öffnen und prüfen, ob das richtige Unternehmen und das Bewertungsformular erscheinen.',
    'Typ „Webseite" wählen, Link einfügen, Code erzeugen.',
    'Als SVG herunterladen, wenn gedruckt wird, und auf dem fertigen Druck mit zwei Geräten testen.',
    'Die Beschriftung so formulieren, dass sie um eine Bewertung bittet und nichts dafür verspricht.',
  ],
  faq: [
    {
      q: 'Darf ich einen Rabatt für eine Bewertung anbieten?',
      a: 'Nein. Google zählt das zu unzulässigen Inhalten und entfernt solche Bewertungen. Das Profil kann zusätzlich für einen Zeitraum gesperrt werden, neue Bewertungen zu erhalten.',
    },
    {
      q: 'Kann der Code nur gute Bewertungen sammeln?',
      a: 'Er kann es nicht, und er darf es auch nicht. Gezielt nur zufriedene Kunden anzusprechen ist laut Richtlinie unzulässig. Der Code führt alle zum selben Formular.',
    },
    {
      q: 'Warum öffnet sich bei mir Google Maps statt des Formulars?',
      a: 'Meistens, weil der Link ohne Place-ID oder in einer älteren Form gespeichert wurde. Prüfen Sie den Link im privaten Fenster und auf einem zweiten Gerät.',
    },
    {
      q: 'Kann ich sehen, wie viele Scans es gab?',
      a: 'Bei einem statischen Code nicht. Scans zählen nur mit einem Weiterleitungsdienst, und dann hängt der Code an einem Anbieter.',
    },
    {
      q: 'Was passiert, wenn wir umziehen?',
      a: 'Bleibt der Unternehmenseintrag bestehen, bleibt auch die Place-ID und damit der Code. Wird ein neuer Eintrag angelegt, braucht es einen neuen Code.',
    },
  ],
  sources: [
    {
      label: 'Google Business Profile Help: Prohibited and restricted content',
      href: 'https://support.google.com/business/answer/7400114',
    },
    {
      label: 'Google Business Profile Help: Tips to get more reviews',
      href: 'https://support.google.com/business/answer/3474122',
    },
    {
      label: 'Google Business Profile Help: restrictions for policy violations',
      href: 'https://support.google.com/business/answer/14114287',
    },
  ],
  toolLinks: [
    { label: 'Bewertungs-QR-Code erstellen', href: '/?type=url' },
    { label: 'Google-Bewertungen per QR-Code sammeln', href: '/blog/google-bewertungen-qr-code' },
  ],
  blogLinks: [
    { label: 'Google-Bewertungen per QR-Code sammeln', href: '/blog/google-bewertungen-qr-code' },
    { label: 'QR-Codes für Handwerk und lokale Betriebe', href: '/blog/qr-codes-handwerk-lokal' },
  ],
};

export const TYPEN_PART_FIVE = [pdf, googleBewertung];
