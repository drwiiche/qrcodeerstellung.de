/**
 * Template gallery.
 *
 * What a visitor actually wants when they land on "QR-Code Vorlage" is not a
 * blank form, it is the finished thing: the guest Wi-Fi card, the parcel note
 * on the front door, the tip jar that takes PayPal. So each template is a
 * complete prefill, including the colour, not just a type preselect.
 *
 * Two rules held throughout:
 *
 *   1. No invented facts. Placeholder business data is obviously placeholder
 *      ("Muster GmbH", the standard example IBAN), never a real-looking company
 *      that a visitor might copy into a live payment code by accident.
 *   2. Every template has to be the version that works in the wild, not the
 *      pretty version. The guest Wi-Fi template uses the guest network, the
 *      parcel template keeps the flat number out of the public field, and the
 *      Bitcoin template says in the description that a wrong address cannot be
 *      refunded.
 */
import type { QRType, QRCustomization } from '../types/qr';

export interface Template {
  id: string;
  category: TemplateCategory;
  title: string;
  /** One sentence: what it is for and, where relevant, the trap. */
  description: string;
  type: QRType;
  data: Record<string, unknown>;
  custom?: Partial<QRCustomization>;
  /** Extra search phrasing this template answers. Used for the page copy. */
  alsoKnownAs?: string;
}

export type TemplateCategory =
  | 'zuhause'
  | 'gastronomie'
  | 'handwerk'
  | 'vermietung'
  | 'verein'
  | 'bezahlen'
  | 'social';

export const CATEGORY_LABELS: Record<TemplateCategory, { label: string; lead: string }> = {
  zuhause: {
    label: 'Zuhause und Alltag',
    lead: 'Die Fälle, die jeden Monat wieder auftauchen: Gäste im WLAN, Pakete an der Tür, der Zettel für die Putzhilfe.',
  },
  gastronomie: {
    label: 'Gastronomie',
    lead: 'Gastnetz, Karte am Tisch, Trinkgeld. Alles, was auf einem Bierdeckel Platz hat, sollte auch dort stehen.',
  },
  handwerk: {
    label: 'Handwerk und Dienstleistung',
    lead: 'Betriebe, die draußen arbeiten: Fahrzeug, Baustelle, Werkstatt. Codes, die Regen und Sonne überstehen müssen.',
  },
  vermietung: {
    label: 'Vermietung und Immobilien',
    lead: 'Wohnung, Ferienhaus, Objekt. Immer mit demselben Problem: Informationen, die sich ändern, und ein Code, der das nicht tut.',
  },
  verein: {
    label: 'Verein und Veranstaltung',
    lead: 'Termine, Anmeldungen, Spenden. Ehrenamt heißt wenig Zeit, also wenig Klicks bis zur fertigen Info.',
  },
  bezahlen: {
    label: 'Bezahlen und Spenden',
    lead: 'Geld einsammeln ohne Terminal. Mit dem Hinweis, wann ein Code dafür nicht taugt.',
  },
  social: {
    label: 'Social Media',
    lead: 'Ein Profil auf Papier bringen: Schaufenster, Flyer, Visitenkarte, Schild am Stand.',
  },
};

export const TEMPLATES: Template[] = [
  // ---------------------------------------------------------------- Zuhause --
  {
    id: 'gaeste-wlan',
    category: 'zuhause',
    title: 'Gäste-WLAN für die Wohnung',
    description:
      'Für das Gastnetz des Routers, nicht für das Heimnetz. Das Passwort steht im Code im Klartext, deshalb ist die Trennung der Punkt.',
    type: 'wifi',
    alsoKnownAs: 'WLAN QR Code Vorlage, Gäste-WLAN Karte',
    data: {
      ssid: 'Gaeste-WLAN',
      password: 'kaffee-und-kuchen',
      encryption: 'WPA',
      hidden: false,
      routerPreset: 'custom',
    },
    custom: { foregroundColor: '#0b1220', dotStyle: 'rounded', cornerStyle: 'extra-rounded' },
  },
  {
    id: 'paket-abstellort',
    category: 'zuhause',
    title: 'Paket-Abstellort an der Haustür',
    description:
      'Für DHL, Hermes und Amazon. Der Ablageort steht im Klartext, deshalb gehören Wohnungsnummer und Nachname nicht in ein Schild, das von der Straße lesbar ist.',
    type: 'delivery',
    alsoKnownAs: 'Abstellgenehmigung QR Code, Paket Hinweis Vorlage',
    data: {
      recipientName: 'Muster',
      deliveryLocation: 'Hinter der blauen Tonne im Carport, trocken und von der Straße nicht sichtbar',
      parcelServices: ['DHL', 'Hermes', 'Amazon'],
      phone: '',
      specialInstructions: 'Bitte nicht klingeln, das Kind schläft. Keine Ablage bei Regen.',
    },
    custom: { foregroundColor: '#c2410c' },
  },
  {
    id: 'haushalt-putzhilfe',
    category: 'zuhause',
    title: 'Zettel für die Putzhilfe',
    description:
      'Einmal gedruckt, bleibt der Zettel an derselben Stelle: welche Mittel wo benutzt werden und was bitte nicht angefasst wird.',
    type: 'text',
    data: {
      text: 'Bad: Essigreiniger. Küche: Spülmittel, kein Scheuermittel auf der Arbeitsplatte. Boden: Wischmopp im Schrank neben der Waschmaschine. Bitte nichts auf dem Schreibtisch verschieben.',
    },
    custom: { foregroundColor: '#475569' },
  },
  {
    id: 'notfall-telefon',
    category: 'zuhause',
    title: 'Notfallnummer am Kühlschrank',
    description:
      'Eine Nummer, die auch der Babysitter findet, ohne das Handy der Eltern zu durchsuchen.',
    type: 'phone',
    data: { phoneNumber: '+49 30 12345678' },
    custom: { foregroundColor: '#4338ca' },
  },

  // ------------------------------------------------------------ Gastronomie --
  {
    id: 'speisekarte-tisch',
    category: 'gastronomie',
    title: 'Karte am Tisch',
    description:
      'Zeigt auf eine HTML-Seite, nicht auf ein PDF. Ein PDF im A4-Querformat ist auf dem Telefon der häufigste Grund, warum Gäste aufgeben.',
    type: 'url',
    alsoKnownAs: 'Speisekarte QR Code Vorlage, digitale Karte',
    data: { url: 'https://ihre-domain.de/speisekarte' },
    custom: { foregroundColor: '#a16207', frameType: 'bottom-bar', frameText: 'KARTE ANSEHEN' },
  },
  {
    id: 'gastnetz-restaurant',
    category: 'gastronomie',
    title: 'Gastnetz im Café',
    description:
      'Auf dasselbe Kärtchen wie die Karte. Ein Aufsteller mit zwei Codes wird in die Hand genommen, einer mit einem wird übersehen.',
    type: 'wifi',
    data: {
      ssid: 'Cafe-Gast',
      password: 'zuckerfrei-2026',
      encryption: 'WPA',
      hidden: false,
      routerPreset: 'custom',
    },
    custom: { foregroundColor: '#0e9f6e' },
  },
  {
    id: 'bewertung-tresen',
    category: 'gastronomie',
    title: 'Bewertungslink am Tresen',
    description:
      'Auf die Innenseite der Rechnung oder an die Kasse, nicht an den Ausgang. Wer schon draußen ist, bewertet nicht mehr.',
    type: 'url',
    data: { url: 'https://ihre-domain.de/bewertung' },
    custom: { foregroundColor: '#be185d' },
  },
  {
    id: 'trinkgeld-paypal',
    category: 'gastronomie',
    title: 'Trinkgeld per PayPal',
    description:
      'Für Straßenmusik, Theke oder den Kaffee-Krug. Funktioniert nur mit einem paypal.me-Namen, nicht mit jedem Geschäftskonto.',
    type: 'paypal',
    data: { handle: 'musterband', amount: '' },
    custom: { foregroundColor: '#1e3a8a' },
  },

  // -------------------------------------------------------------- Handwerk --
  {
    id: 'fahrzeug-betrieb',
    category: 'handwerk',
    title: 'Firmenfahrzeug mit Kontakt',
    description:
      'An die Heckscheibe oder die Beifahrertür: Wer den Wagen zugeparkt vorfindet, ruft direkt an, statt einen Zettel zu schreiben.',
    type: 'vcard',
    data: {
      firstName: 'Max',
      lastName: 'Mustermann',
      organization: 'Muster Haustechnik',
      title: 'Notdienst',
      phone: '+49 30 12345678',
      mobile: '+49 170 1234567',
      email: 'notdienst@example.de',
      street: 'Werkstraße 4',
      zip: '10115',
      city: 'Berlin',
      country: 'Deutschland',
      website: 'https://example.de',
      note: 'Erreichbar Mo bis Sa, 7 bis 19 Uhr',
    },
    custom: { foregroundColor: '#be185d' },
  },
  {
    id: 'baustelle-zutritt',
    category: 'handwerk',
    title: 'Baustellenschild mit Ansprechpartner',
    description:
      'Für die Projektbeschilderung: ein Anruf beim Bauleiter statt einer Nachricht, die niemand liest. Wetterfest drucken, nicht auf Normalpapier.',
    type: 'phone',
    data: { phoneNumber: '+49 170 1234567' },
    custom: { foregroundColor: '#c2410c' },
  },
  {
    id: 'werkstatt-standort',
    category: 'handwerk',
    title: 'Werkstatt-Anfahrt',
    description:
      'Der Standort öffnet die Karten-App statt der Webseite. Auf der Rechnung spart das jeden zweiten Anruf.',
    type: 'standort',
    alsoKnownAs: 'Anfahrt QR Code, Standort Vorlage',
    data: { latitude: '52.520008', longitude: '13.404954', label: 'Muster Haustechnik' },
    custom: { foregroundColor: '#0e7490' },
  },
  {
    id: 'youtube-kanal-handwerk',
    category: 'handwerk',
    title: 'Kanalschild für YouTube',
    description:
      'Für Betriebe, die Reparaturen filmen: Der Kanalname als Code auf Flyer und Fahrzeug. Alte /channel/-Links funktionieren auch.',
    type: 'youtube',
    data: { handle: 'kanalname' },
    custom: { foregroundColor: '#dc2626' },
  },

  // ------------------------------------------------------------ Vermietung --
  {
    id: 'ferienwohnung-wlan',
    category: 'vermietung',
    title: 'Ferienwohnung: WLAN und Hausordnung',
    description:
      'Code im Rahmen auf dem Tisch plus ein zweiter auf der Rückseite für die Hausordnung. Zwei Codes, die niemand erklären muss.',
    type: 'wifi',
    data: {
      ssid: 'Ferienwohnung-Muster',
      password: 'willkommen-im-urlaub',
      encryption: 'WPA',
      hidden: false,
      routerPreset: 'custom',
    },
    custom: { foregroundColor: '#0e9f6e' },
  },
  {
    id: 'wohnungsbesichtigung',
    category: 'vermietung',
    title: 'Besichtigung: Exposé und Kontakt',
    description:
      'Am Schild vor dem Objekt, damit Interessenten das Exposé haben, ohne nachzufragen. Die Zielseite darf sich ändern, der Code bleibt.',
    type: 'url',
    data: { url: 'https://ihre-domain.de/objekt/musterstrasse-4' },
    custom: { foregroundColor: '#1d4ed8' },
  },
  {
    id: 'zutritt-technikraum',
    category: 'vermietung',
    title: 'Zutritt Technikraum für Handwerker',
    description:
      'Wer den Keller nur ab und zu braucht, bekommt an der Tür denselben Code mit allen Angaben, statt sie sich zu merken.',
    type: 'text',
    data: {
      text: 'Technikraum Musterstraße 4. Wasser: Absperrhahn neben der Heizungsanlage. Strom: Verteiler im Flur rechts. Bitte Licht aus und Tür ziehen.',
    },
    custom: { foregroundColor: '#475569' },
  },

  // ---------------------------------------------------------------- Verein --
  {
    id: 'vereins-termin',
    category: 'verein',
    title: 'Termin ins Kalender',
    description:
      'Ein Scan, und der Termin steht im Kalender mit Ort und Uhrzeit. Für Trainingszeiten, Versammlungen und Sommerfeste.',
    type: 'event',
    alsoKnownAs: 'Termin QR Code Vorlage, Kalender Einladung',
    data: {
      title: 'Jahreshauptversammlung',
      location: 'Vereinsheim, Musterweg 2',
      startDate: '2026-11-14',
      startTime: '19:00',
      endDate: '2026-11-14',
      endTime: '21:30',
      description: 'Kassenbericht, Vorstandswahl, Planung Sommerfest.',
    },
    custom: { foregroundColor: '#a16207' },
  },
  {
    id: 'vereins-anmeldung',
    category: 'verein',
    title: 'Anmeldung per Link',
    description:
      'Zum Aushang am Vereinsheim: ein Formular statt einer E-Mail-Adresse, die niemand abschreibt.',
    type: 'url',
    data: { url: 'https://ihre-domain.de/anmeldung' },
    custom: { foregroundColor: '#1d4ed8' },
  },
  {
    id: 'spenden-bitcoin',
    category: 'verein',
    title: 'Spendenadresse Bitcoin',
    description:
      'BIP21 mit Adresse und optionalem Betrag. Ein falsches Zeichen in der Adresse lässt sich nicht zurückholen, also immer kopieren statt abtippen.',
    type: 'bitcoin',
    data: { address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '', label: 'Vereinskasse' },
    custom: { foregroundColor: '#d97706' },
  },
  {
    id: 'vereins-flyer-whatsapp',
    category: 'verein',
    title: 'WhatsApp-Gruppe beitreten',
    description:
      'Für die Gruppe, die sonst jeder einzeln weitergeleitet wird. Nummer international, ohne Leerzeichen im Code.',
    type: 'whatsapp',
    data: { phoneNumber: '491701234567', message: 'Hallo, ich möchte in die Vereinsgruppe.' },
    custom: { foregroundColor: '#047857' },
  },

  // -------------------------------------------------------------- Bezahlen --
  {
    id: 'sepa-spende',
    category: 'bezahlen',
    title: 'SEPA-Überweisung als GiroCode',
    description:
      'Echter EPC069-12-GiroCode: Name, IBAN und Betrag werden vorausgefüllt, die Überweisung muss der Zahler in seiner App noch bestätigen.',
    type: 'sepa',
    alsoKnownAs: 'GiroCode Vorlage, Überweisung QR Code',
    data: {
      name: 'Musterverein e.V.',
      iban: 'DE89 3705 0198 0000 0123 45',
      bic: '',
      amount: '25.00',
      purpose: 'Spende Jugendarbeit',
      reference: '',
    },
    custom: { foregroundColor: '#6d28d9' },
  },
  {
    id: 'pix-brasilien',
    category: 'bezahlen',
    title: 'Pix für Kunden in Brasilien',
    description:
      'BR Code nach der Vorgabe der Banco Central do Brasil. Wird von brasilianischen Bank-Apps gelesen, nicht von europäischen.',
    type: 'pix',
    data: {
      key: 'chave@example.com',
      name: 'Muster Comercio',
      city: 'Sao Paulo',
      amount: '24.90',
      txid: 'PEDIDO123',
    },
    custom: { foregroundColor: '#0891b2' },
  },
  {
    id: 'kasse-paypal',
    category: 'bezahlen',
    title: 'Fester Betrag per PayPal',
    description:
      'Für Kuchenverkauf und Sammlung: Betrag fest im Code, damit niemand nachrechnen muss.',
    type: 'paypal',
    data: { handle: 'musterverein', amount: '5.00' },
    custom: { foregroundColor: '#1e3a8a' },
  },

  // ---------------------------------------------------------------- Social --
  {
    id: 'instagram-schaufenster',
    category: 'social',
    title: 'Instagram im Schaufenster',
    description:
      'Damit aus einem Blick durch die Scheibe ein Follower wird. Punkte im Profilnamen sind erlaubt und werden übernommen.',
    type: 'instagram',
    data: { handle: 'atelier.kaffee' },
    custom: { foregroundColor: '#b8336a' },
  },
  {
    id: 'facebook-verein',
    category: 'social',
    title: 'Facebook-Seite des Vereins',
    description:
      'Für Aushänge und Flyer, auf denen die Seitenadresse sonst in Kleinschrift steht.',
    type: 'facebook',
    data: { handle: 'musterverein' },
    custom: { foregroundColor: '#1877f2' },
  },
  {
    id: 'x-account',
    category: 'social',
    title: 'X-Konto auf der Visitenkarte',
    description:
      'Alte twitter.com-Links werden erkannt, der Code führt trotzdem auf x.com.',
    type: 'twitter',
    data: { handle: 'mustermann' },
    custom: { foregroundColor: '#1f2937' },
  },
  {
    id: 'mecard-marktstand',
    category: 'social',
    title: 'MECARD am Marktstand',
    description:
      'Kurz und kompakt für Scanner, die mit vCard lange brauchen. Weniger Felder, schneller im Adressbuch.',
    type: 'mecard',
    data: {
      lastName: 'Mustermann',
      firstName: 'Max',
      organization: 'Musters Käsestand',
      phone: '+49 170 1234567',
      email: 'max@example.de',
      url: '',
      address: 'Wochenmarkt, Stand 12',
      note: 'Mittwoch und Samstag',
    },
    custom: { foregroundColor: '#0f766e' },
  },
];

export function templatesByCategory(category: TemplateCategory): Template[] {
  return TEMPLATES.filter((t) => t.category === category);
}

export const CATEGORY_ORDER: TemplateCategory[] = [
  'zuhause',
  'gastronomie',
  'handwerk',
  'vermietung',
  'verein',
  'bezahlen',
  'social',
];
