/**
 * GiroCode cluster.
 *
 * The existing /qr-code-generator/girocode page explains the format itself. These
 * five pages answer the situations the format is used in, and the boundary cases
 * where people wrongly believe a payment code does something it cannot: it is not
 * an e-invoice, it is not a direct debit, it is not a donation receipt.
 *
 * Every legal statement here is sourced in the `sources` field and hedged in the
 * copy. The pages say what the rule is, not what the reader should do about it.
 */
import type { SeoSubPage } from './seo-pages';

const USTG_14 = {
  label: '§ 14 UStG: Ausstellung von Rechnungen (gesetze-im-internet.de)',
  href: 'https://www.gesetze-im-internet.de/ustg_1980/__14.html',
};
const USTDV_33 = {
  label: '§ 33 UStDV: Rechnungen über Kleinbeträge (gesetze-im-internet.de)',
  href: 'https://www.gesetze-im-internet.de/ustdv_1980/__33.html',
};
const USTG_19 = {
  label: '§ 19 UStG: Besteuerung der Kleinunternehmer (gesetze-im-internet.de)',
  href: 'https://www.gesetze-im-internet.de/ustg_1980/__19.html',
};
const EPDV_50 = {
  label: '§ 50 EStDV: Zuwendungsbestätigung (gesetze-im-internet.de)',
  href: 'https://www.gesetze-im-internet.de/estdv_1955/__50.html',
};

const rechnung: SeoSubPage = {
  slug: 'girocode-rechnung',
  title: 'GiroCode auf der Rechnung',
  metaTitle: 'GiroCode auf der Rechnung: QR-Code zum Bezahlen',
  metaDescription:
    'Wie der GiroCode auf eine Rechnung kommt, welcher Verwendungszweck die Zuordnung rettet und warum der Code weder Pflichtangabe noch E-Rechnung ist.',
  intro: [
    'Auf einer Rechnung ist der GiroCode die letzte Meile: Der Kunde hat das Dokument ohnehin in der Hand, und statt IBAN und Verwendungszweck abzutippen, scannt er und bestätigt in der Banking-App.',
    'Was auf dieser Seite steht, ist vor allem die Abgrenzung. Der Code ist eine Zahlungshilfe und kein Rechnungsbestandteil. Wer ihn für eine E-Rechnung hält, hat ein Problem, das erst beim Prüfer auffällt.',
  ],
  sections: [
    {
      title: 'Was der Code auf der Rechnung leistet',
      body: [
        'Er füllt das Überweisungsformular in der Banking-App: Empfänger, IBAN, Betrag und Verwendungszweck. Der Kunde bestätigt mit PIN oder Fingerabdruck. Abtippen entfällt, und mit dem Abtippen entfällt die häufigste Fehlerquelle bei Überweisungen, nämlich eine vertauschte Ziffer in einer zweiundzwanzigstelligen IBAN.',
        'Der Code löst keine Zahlung aus, er bereitet sie vor. Diesen Unterschied sollte man nicht kleinreden, denn er ist der Grund, warum der Code auf einer Rechnung überhaupt zumutbar ist: Der Kunde behält die Kontrolle über jeden Vorgang.',
      ],
      bullets: [
        'Der Betrag darf im Code stehen, dann ist die Rechnung eindeutig',
        'Der Verwendungszweck sollte die Rechnungsnummer enthalten',
        'Ein Code pro Rechnung, nicht ein Code für alle Rechnungen eines Jahres',
        'Bei Teilzahlungen besser ohne Betrag, sonst muss der Kunde das Feld überschreiben',
      ],
    },
    {
      title: 'Der Verwendungszweck entscheidet über die Buchhaltung',
      body: [
        'Der GiroCode erlaubt bis zu 140 Zeichen Verwendungszweck, der Empfängername ist auf 70 Zeichen begrenzt. Beides ist reichlich, wird aber regelmäßig schlecht genutzt: Ein Feld mit „Rechnung" ist für die Zuordnung wertlos, ein Feld mit „RE-2026-0147 Müller Möbelmontage" löst den Fall beim ersten Blick.',
        'Wer mehrere Rechnungen im Monat schreibt, sollte die Rechnungsnummer an den Anfang des Verwendungszwecks setzen. Banken übernehmen den Text in der Regel vollständig, aber die Anzeige ist im Online-Banking oft abgeschnitten. Was vorne steht, sieht man auch dann noch.',
        'Ein zweiter Punkt, der Zeit kostet: der Name. Er sollte der Firma entsprechen, die auf dem Kontoauszug erwartet wird, nicht einem Kürzel. Sonst ruft der Kunde an, weil er nicht erkennt, wer da abbuchen möchte.',
      ],
    },
    {
      title: 'Der Code ist keine E-Rechnung',
      body: [
        'Das ist die Verwechslung, die in diesem Bereich am meisten Schaden anrichtet. Eine E-Rechnung ist ein strukturiertes elektronisches Format nach der Norm EN 16931, in Deutschland vor allem XRechnung und ZUGFeRD. Seit dem 1. Januar 2025 müssen Unternehmen in Deutschland solche Rechnungen empfangen können; die Pflicht, selbst welche auszustellen, greift gestaffelt ab 2027.',
        'Eine PDF mit einem QR-Code darauf ist keine E-Rechnung, auch dann nicht, wenn ein XML eingebettet ist. Der QR-Code ist kein Rechnungsbestandteil im Sinne des Formats, er ist eine Zugabe für den Menschen vor dem Papier.',
        'Wer heute Rechnungen als PDF verschickt, darf das im Übergang noch tun, sollte aber wissen, dass der bequeme Weg über den Code auf dem Ausdruck ein anderes Thema ist als die Formatfrage in der Buchhaltung. Das eine löst das andere nicht.',
      ],
    },
    {
      title: 'Was auf der Rechnung stehen muss, unabhängig vom Code',
      body: [
        'Über 250 Euro brutto verlangt § 14 Abs. 4 UStG zehn Pflichtangaben: beide Namen und Anschriften, Steuernummer oder Umsatzsteuer-Identifikationsnummer, Ausstellungsdatum, fortlaufende Rechnungsnummer, Menge und Art der Leistung, Leistungszeitpunkt, Nettoentgelt je Steuersatz, Steuersatz und Steuerbetrag sowie den Gesamtbetrag.',
        'Bis einschließlich 250 Euro brutto greift die Erleichterung für Kleinbetragsrechnungen nach § 33 UStDV. Rechnungsnummer, Empfängeranschrift und Steuernummer sind dann nicht erforderlich, Name und Anschrift des Leistenden, Datum, Leistungsbeschreibung, Bruttobetrag und Steuersatz schon.',
        'Der Code ersetzt keine dieser Angaben und ergänzt sie nicht. Er ist und bleibt eine Zahlungshilfe. Ob die Rechnung selbst vollständig ist, entscheidet sich im Text, nicht im Quadrat.',
      ],
    },
    {
      title: 'Größe und Platzierung auf dem Dokument',
      body: [
        'Ein Code auf einer Rechnung steht auf Papier, das in der Hand gehalten wird. 2,5 Zentimeter Kantenlänge sind ausreichend, 3 Zentimeter sind angenehmer, weil Rechnungen oft gefaltet oder geknickt werden und ein Code an der Knickkante nicht mehr liest.',
        'Platzieren Sie ihn nicht in der Falz, nicht über einer farbigen Fläche und nicht neben dem Lochrand eines Ordners. Ein Code, der zu einem Drittel fehlt, ist kein Code. Wenn das Layout eng ist: Der untere Rand neben dem Zahlungsziel ist die beste Stelle, weil dort ohnehin steht, wie gezahlt werden soll.',
      ],
      bullets: [
        'Nicht in die Falz drucken',
        'Kontrast prüfen, graue Schrift auf weißem Grund ist zu wenig',
        'Beim Versand als PDF: Code nicht komprimieren, sonst verwaschen die Kanten',
        'Auf dem Ausdruck testen, nicht nur auf dem Bildschirm',
      ],
    },
  ],
  useCases: [
    {
      title: 'Handwerksrechnung',
      text: 'Der Code neben dem Zahlungsziel mit Rechnungsnummer im Verwendungszweck. Der Kunde zahlt am Küchentisch, statt am Abend zur Bank zu gehen.',
    },
    {
      title: 'Vereinsbeitrag',
      text: 'Die Beitragsrechnung mit festem Betrag und der Mitgliedsnummer im Verwendungszweck. Der Kassenwart muss nichts nachfragen.',
    },
    {
      title: 'Monatliche Dienstleistung',
      text: 'Ein Code ohne Betrag, weil die Stunden schwanken. Der Kunde trägt den Rechnungsbetrag selbst ein.',
    },
    {
      title: 'Anzahlungsrechnung',
      text: 'Fester Betrag, Zweck mit Rechnungsnummer und dem Zusatz „Anzahlung". Damit ist die Restforderung später eindeutig zuordenbar.',
    },
  ],
  steps: [
    'Rechnungsnummer und Verwendungszweck festlegen, die Nummer an den Anfang.',
    'Typ GiroCode wählen, Empfänger, IBAN, Betrag und Verwendungszweck eintragen.',
    'Als SVG herunterladen und neben dem Zahlungsziel platzieren, nicht in die Falz.',
    'Eine Testrechnung drucken und mit der eigenen Banking-App scannen.',
  ],
  faq: [
    {
      q: 'Ist der GiroCode auf einer Rechnung Pflicht?',
      a: 'Nein. Weder § 14 UStG noch eine andere Vorschrift verlangt ihn. Er ist eine freiwillige Zahlungshilfe.',
    },
    {
      q: 'Ersetzt der Code die Kontodaten im Text?',
      a: 'Nein. IBAN und Empfänger gehören weiterhin lesbar auf die Rechnung, schon weil nicht jede Banking-App das Format liest.',
    },
    {
      q: 'Ist eine PDF mit QR-Code eine E-Rechnung?',
      a: 'Nein. Eine E-Rechnung ist ein strukturiertes Format nach EN 16931, etwa XRechnung oder ZUGFeRD. Ein PDF bleibt ein PDF, auch mit Code.',
    },
    {
      q: 'Was gehört in den Verwendungszweck?',
      a: 'Die Rechnungsnummer an erster Stelle, danach eine kurze Zuordnung. Maximal 140 Zeichen, und alles, was wichtig ist, gehört nach vorne.',
    },
    {
      q: 'Kann der Kunde einen anderen Betrag überweisen?',
      a: 'Ja, er kann das Betragsfeld in der App überschreiben. Bei häufigen Teilzahlungen ist ein Code ohne Betrag die bessere Wahl.',
    },
  ],
  sources: [USTG_14, USTDV_33],
  toolLinks: [
    { label: 'GiroCode für die Rechnung erstellen', href: '/?type=sepa' },
    { label: 'GiroCode: Format und Aufbau', href: '/qr-code-generator/girocode' },
  ],
  blogLinks: [
    { label: 'SEPA-GiroCode erstellen: Anleitung', href: '/blog/sepa-girocode-qr-code-erstellen' },
  ],
};

const verein: SeoSubPage = {
  slug: 'girocode-verein',
  title: 'GiroCode für Vereine',
  metaTitle: 'GiroCode für Vereine: Beiträge und Spenden per Scan',
  metaDescription:
    'Beitrag und Spende per QR-Code: warum der GiroCode keine Lastschrift ersetzt, wie die Mitgliedsnummer ins Spiel kommt und was der Kassenwart beachten muss.',
  intro: [
    'Vereine haben ein Zahlungsproblem, das keine App löst: Beiträge werden überwiesen, wenn jemand daran denkt, und die Zuordnung landet beim Kassenwart. Ein GiroCode mit Mitgliedsnummer im Verwendungszweck löst den zweiten Teil des Problems, den ersten nur halb.',
    'Diese Seite sagt auch, was er nicht löst. Wer Lastschriften gewohnt ist, wird enttäuscht: Ein GiroCode ist eine Überweisung und ein Lastschrifteinzug ist etwas anderes, mit Mandat und Widerrufsrecht.',
  ],
  sections: [
    {
      title: 'Beitrag einsammeln mit dem Code',
      body: [
        'Der übliche Weg: Der Verein verschickt einmal im Jahr eine Beitragsrechnung oder ein Erinnerungsschreiben, und darauf steht der Code mit IBAN des Vereins, festem Betrag und Mitgliedsnummer im Verwendungszweck. Wer den Brief in der Hand hat, zahlt in einer Minute.',
        'Der feste Betrag ist hier sinnvoll, weil er die Rückfrage erspart. Bei Familienbeiträgen, Ermäßigungen oder Teilbeiträgen ist er falsch, weil der Code dann einen Betrag zeigt, der nicht gilt. In dem Fall bleibt das Feld leer, und der Zahler trägt ein.',
      ],
      bullets: [
        'Mitgliedsnummer in den Verwendungszweck, an den Anfang',
        'Der Vereinsname im Feld Empfänger muss zu dem passen, was auf dem Kontoauszug erscheint',
        'Ein Code pro Beitragslauf, nicht derselbe Code für Spenden und Beiträge',
        'Für den Jahresbeitrag ein festes Datum nennen, sonst wandert die Zahlung ins nächste Jahr',
      ],
    },
    {
      title: 'Ein GiroCode ist keine Lastschrift',
      body: [
        'Ein Lastschrifteinzug braucht ein Mandat, also eine schriftliche Ermächtigung, und der Einziehende muss die Regeln des SEPA-Lastschriftverfahrens einhalten, einschließlich Ankündigung und Erstattungsrecht. Ein QR-Code kann das nicht leisten, weil er den Zahler voraussetzt, der aktiv bestätigt.',
        'In der Praxis ist das für viele Vereine ein Rückschritt: Wer jahrelang eingezogen hat, muss jetzt jährlich daran erinnern. Der Vorteil ist der geringere Aufwand bei der Einrichtung und weniger Streit, weil niemand abbucht, ohne dass der Zahler es bestätigt hat.',
      ],
    },
    {
      title: 'Spenden und Beiträge sind steuerlich zwei Dinge',
      body: [
        'Für Spenden bis einschließlich 300 Euro je Zuwendung genügt dem Spender ein vereinfachter Nachweis: der Bareinzahlungsbeleg oder die Buchungsbestätigung des Kreditinstituts, also der Kontoauszug. Bei einem Verein muss der Empfänger zusätzlich einen Beleg darüber ausstellen, dass die Zuwendung für den steuerbegünstigten Zweck bestimmt ist.',
        'Darüber hinaus ist eine Zuwendungsbestätigung nach amtlichem Muster nötig, geregelt in § 50 EStDV. Der Code erzeugt keine dieser Unterlagen. Er bewegt Geld, und der Nachweis darüber entsteht beim Kontoauszug und beim Verein.',
        'Deshalb steht im Verwendungszweck am besten ausdrücklich „Spende" oder „Beitrag". Der Kontoauszug ist der halbe Nachweis, und was dort steht, muss zur späteren Bescheinigung passen.',
      ],
    },
    {
      title: 'Der Kassenwart und die Zuordnung',
      body: [
        'Der eigentliche Gewinn liegt nicht beim Zahler, sondern im Büro. Wenn im Verwendungszweck die Mitgliedsnummer steht, ist die Buchung ohne Rückfrage zuzuordnen. Steht sie nicht dort, beginnt die Suche nach dem Namen, und bei gleichen Nachnamen im Verein endet sie beim Telefonat.',
        'Für Vereine mit vielen Mitgliedern lohnt sich ein Code pro Mitglied nicht. Ein Code für den Beitragslauf genügt, weil die Mitgliedsnummer nicht im Code steht, sondern der Zahler sie einträgt. Wer das nicht tut, erzeugt Nacharbeit, und daran ändert der Code nichts.',
      ],
      bullets: [
        'Ein Code für den Beitragslauf, gedruckt auf das Anschreiben',
        'Ein zweiter Code für Spenden ohne Betrag, auf Flyer und Plakate',
        'Zahlungsdatum und Einladungsdatum auseinanderhalten, sonst zahlt der eine früher und der andere nie',
      ],
    },
    {
      title: 'Wo der Code im Vereinsleben auftaucht',
      body: [
        'Auf dem Beitragsanschreiben, auf dem Spendenplakat am Vereinsheim, auf der Kasse beim Sommerfest, auf dem Aufsteller am Eingang bei Veranstaltungen. Der Unterschied ist jedes Mal derselbe: mit oder ohne Betrag, mit oder ohne Zweck.',
        'Für Veranstaltungen gilt die Faustregel aus dem Druckbereich: 4 bis 5 Zentimeter Kantenlänge auf einem Tresenaufsteller, 10 Zentimeter auf einem Plakat, das aus zwei Metern gelesen wird. Ein Code auf einem Plakat, das in Hüfthöhe hängt, ist zu klein geschweige denn zu niedrig.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Jahresbeitrag',
      text: 'Das Anschreiben mit eingedrucktem Code, festem Betrag und Mitgliedsnummer im Zweck. Die Zuordnung passiert beim Kontoauszug.',
    },
    {
      title: 'Spendenplakat',
      text: 'Der Code ohne Betrag am Vereinsheim, mit dem Hinweis, wofür gesammelt wird. Wer 20 Euro geben will, tut es im Vorbeigehen.',
    },
    {
      title: 'Sommerfest und Kasse',
      text: 'Der Code am Kassenstand für Kartenzahlungsskeptiker. Kein Kartenlesegerät, kein Bargeld, das abgeholt werden muss.',
    },
    {
      title: 'Jugendkasse',
      text: 'Der Code für Trikots, Fahrten und Material, mit dem Zusatz „Jugend" im Zweck, damit die Mittelverwendung nachvollziehbar bleibt.',
    },
  ],
  steps: [
    'Beitragslauf festlegen und den Verwendungszweck so formulieren, dass die Mitgliedsnummer vorn steht.',
    'Typ GiroCode wählen, IBAN des Vereins und den Betrag eintragen, oder das Feld leer lassen.',
    'Den Code auf das Beitragsanschreiben drucken, nicht als Aufkleber auf ein vorhandenes Schreiben.',
    'Im Zweck die Worte „Beitrag" oder „Spende" verwenden, damit der Kontoauszug als Nachweis taugt.',
  ],
  faq: [
    {
      q: 'Kann der GiroCode Mitgliedsbeiträge automatisch einziehen?',
      a: 'Nein. Er bereitet eine Überweisung vor. Ein Einzug braucht ein SEPA-Lastschriftmandat und ein Lastschriftverfahren.',
    },
    {
      q: 'Reicht der Code als Spendenquittung?',
      a: 'Nein. Der Code ist kein Beleg. Bis 300 Euro je Zuwendung genügt dem Spender der Kontoauszug, darüber ist eine Zuwendungsbestätigung nach amtlichem Muster nötig.',
    },
    {
      q: 'Was gehört in den Verwendungszweck?',
      a: 'Die Mitgliedsnummer zuerst, dann der Zweck, also Beitrag, Spende oder Jugend. So ist die Buchung ohne Rückfrage zuzuordnen.',
    },
    {
      q: 'Soll der Betrag im Code stehen?',
      a: 'Beim Jahresbeitrag ja, weil er eindeutig ist. Bei Ermäßigungen, Familientarifen und Spenden nein, dann trägt der Zahler den Betrag ein.',
    },
    {
      q: 'Muss der Verein für jeden ein eigenes Schreiben drucken?',
      a: 'Nein. Ein Code für den Lauf genügt; die individuelle Zuordnung passiert über den Verwendungszweck, den der Zahler einträgt.',
    },
  ],
  sources: [EPDV_50],
  toolLinks: [
    { label: 'GiroCode für den Verein erstellen', href: '/?type=sepa' },
    { label: 'GiroCode für Spenden', href: '/qr-code-generator/girocode-spende' },
  ],
  blogLinks: [
    { label: 'SEPA-GiroCode erstellen: Anleitung', href: '/blog/sepa-girocode-qr-code-erstellen' },
    { label: 'QR-Codes für Veranstaltungen', href: '/blog/qr-codes-veranstaltungen-events' },
  ],
};

const spende: SeoSubPage = {
  slug: 'girocode-spende',
  title: 'GiroCode für Spenden',
  metaTitle: 'GiroCode für Spenden: QR-Code ohne festen Betrag',
  metaDescription:
    'Spenden per QR-Code: warum der Betrag leer bleiben sollte, wie der Nachweis für den Spender entsteht und wo der Code an seine Grenzen stößt.',
  intro: [
    'Eine Spendenbox mit Code hat einen anderen Zweck als eine Rechnung mit Code. Bei der Rechnung ist der Betrag bekannt, bei der Spende entscheidet der Mensch davor. Das ist der erste Gestaltungsfehler, der hier passiert: ein fester Betrag in einem Code, der zu freien Beträgen einladen soll.',
    'Der zweite Fehler ist steuerlich. Viele glauben, der Code erzeuge einen Beleg. Er tut es nicht, und was wirklich als Nachweis gilt, steht im zweiten Abschnitt.',
  ],
  sections: [
    {
      title: 'Ohne Betrag, mit klarem Zweck',
      body: [
        'Bleibt das Betragsfeld im GiroCode leer, öffnet die Banking-App ein leeres Betragsfeld. Der Spender trägt selbst ein, was er geben will. Mit Betrag ist der Code eine Zahlungsaufforderung, und die wirkt an einer Spendenbox falsch, selbst wenn der Betrag klein ist.',
        'Der Verwendungszweck ist die eigentliche Arbeit. Er sollte sagen, wofür gesammelt wird, und zwar so, dass der Kassenwart später nicht raten muss: „Spende Jugendprojekt Halle" ist brauchbar, „Spende" allein nicht. Achtung, der Zweck ist auf 140 Zeichen begrenzt, der Empfängername auf 70.',
      ],
      bullets: [
        'Betrag leer lassen, damit der Spender entscheidet',
        'Zweck konkret benennen, nicht nur „Spende"',
        'Ein Code pro Sammelzweck, nicht einer für alle Projekte',
        'Bei mehreren Projekten getrennte Codes, damit die Mittelverwendung nachvollziehbar bleibt',
      ],
    },
    {
      title: 'Der Nachweis entsteht nicht durch den Code',
      body: [
        'Für Zuwendungen bis einschließlich 300 Euro je Spende genügt dem Spender ein vereinfachter Nachweis: der Bareinzahlungsbeleg oder die Buchungsbestätigung des Kreditinstituts, praktisch also der Kontoauszug. Bei einer Körperschaft, die als gemeinnützig anerkannt ist, muss der Empfänger zusätzlich einen Beleg darüber ausstellen, dass die Zuwendung für den steuerbegünstigten Zweck bestimmt ist.',
        'Darüber hinaus ist eine Zuwendungsbestätigung nach amtlich vorgeschriebenem Muster erforderlich; die Einzelheiten regelt § 50 EStDV. Zuständig ist der Empfänger, nicht der Code und nicht der Generator.',
        'Für den Spender heißt das: Der QR-Code beschleunigt die Zahlung, nicht den Nachweis. Wer den Nachweis braucht, braucht weiterhin den Kontoauszug und, oberhalb der Grenze, eine Bescheinigung.',
      ],
    },
    {
      title: 'Wo der Code an einer Spendenbox wirkt',
      body: [
        'Am besten dort, wo ohnehin jemand steht und die Entscheidung im Moment fällt: am Stand auf dem Markt, am Eingang einer Veranstaltung, am Kassenblech beim Vereinsheim, auf einem Plakat neben dem Sammelziel. Der Code ersetzt dort das Kleingeld, das niemand mehr dabei hat.',
        'Weniger gut wirkt er dort, wo ohnehin gespendet wird: Ein Code auf einem Spendenaufruf per Post erreicht Leute, die eher überweisen, und ein Code in einer E-Mail wird selten gescannt, weil der Empfänger am Rechner sitzt.',
      ],
      bullets: [
        'Beschriftung mit dem Zweck, nicht mit „QR-Code"',
        'Ein Satz, was mit dem Geld passiert',
        'Größe nach Abstand: 4 bis 5 Zentimeter am Stand, 10 Zentimeter am Plakat',
      ],
    },
    {
      title: 'Kontrolle und Vertrauen',
      body: [
        'Wer an einer Box scannt, sieht den Empfängernamen im Formular. Deshalb muss dort der Name stehen, den die Leute erwarten, also der Verein oder die Stiftung, nicht ein Kürzel und nicht eine Person.',
        'Ein zweiter Vertrauenspunkt ist die Bankverbindung selbst. Ein gedruckter Code auf einem Flyer, der auf ein privates Konto zeigt, ist ein Grund, nicht zu spenden. Der Code macht die IBAN unsichtbar, aber nicht unüberprüfbar, und die App zeigt sie nach dem Scan.',
      ],
    },
    {
      title: 'Was der Code nicht leistet',
      body: [
        'Er bestätigt keine Spende, er zählt keine Spenden und er stellt keinen Beleg aus. Er erzeugt auch keine Quittung, die vor dem Finanzamt gilt, und keine Sammelbestätigung für einen Verein.',
        'Und er ersetzt keine Entscheidung darüber, ob Spenden angenommen werden dürfen und wie die Mittel verwendet werden müssen. Das ist eine Frage des Vereinsrechts und des Steuerrechts, nicht des Druckformats.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Stand auf dem Markt',
      text: 'Ein Aufsteller mit Code ohne Betrag, beschriftet mit dem Sammelziel. Wer kein Kleingeld hat, scannt und gibt zwei Euro.',
    },
    {
      title: 'Spendenplakat am Vereinsheim',
      text: 'Ein Code am Plakat neben der Telefonnummer. Wetterfest, weil das Plakat länger hängt als eine Veranstaltung dauert.',
    },
    {
      title: 'Katastrophenaufruf',
      text: 'Ein Code für ein Sonderkonto, mit dem Hinweis auf den Zeitraum. Die Zuordnung übernimmt hier der Zweck, nicht der Betrag.',
    },
    {
      title: 'Projektförderung',
      text: 'Getrennte Codes je Projekt, damit die Mittelverwendung stimmt und der Kassenwart nicht raten muss, wofür das Geld kam.',
    },
  ],
  steps: [
    'Sammelzweck festlegen und in Worte fassen, die in 140 Zeichen passen und später zuordenbar sind.',
    'Typ GiroCode wählen, Empfänger und IBAN eintragen, das Betragsfeld leer lassen.',
    'Den Code mit dem Sammelzweck beschriften, nicht mit dem Wort QR-Code.',
    'Vor dem Aufstellen mit einem fremden Handy scannen und prüfen, welcher Empfängername erscheint.',
  ],
  faq: [
    {
      q: 'Soll ein fester Betrag im Spenden-Code stehen?',
      a: 'Nein. Mit Betrag wirkt der Code wie eine Rechnung. Ohne Betrag entscheidet der Spender, und das ist der Sinn einer Spende.',
    },
    {
      q: 'Bekommt der Spender einen Beleg über den Code?',
      a: 'Nein. Bis 300 Euro je Zuwendung genügt der Kontoauszug als vereinfachter Nachweis, oberhalb davon ist eine Zuwendungsbestätigung nach amtlichem Muster nötig, ausgestellt vom Empfänger.',
    },
    {
      q: 'Kann ich sehen, wie viel über den Code gespendet wurde?',
      a: 'Über den Code selbst nicht, weil ein statischer Code nichts zählt. Sichtbar ist es auf dem Konto, über den Verwendungszweck.',
    },
    {
      q: 'Was gehört in den Verwendungszweck?',
      a: 'Das Wort Spende und der konkrete Zweck, etwa „Spende Jugendprojekt". So ist die Buchung zuordenbar und passt zur späteren Bestätigung.',
    },
    {
      q: 'Darf der Code auf ein privates Konto zeigen?',
      a: 'Technisch ja, praktisch ist es ein Grund für Spender, es nicht zu tun. Der Empfängername im Formular sollte der Organisation entsprechen.',
    },
  ],
  sources: [EPDV_50],
  toolLinks: [
    { label: 'Spenden-Code erstellen', href: '/?type=sepa' },
    { label: 'GiroCode für Vereine', href: '/qr-code-generator/girocode-verein' },
  ],
  blogLinks: [
    { label: 'QR-Codes für Veranstaltungen', href: '/blog/qr-codes-veranstaltungen-events' },
  ],
};

const vergleich: SeoSubPage = {
  slug: 'girocode-oder-ueberweisungstraeger',
  title: 'GiroCode oder Überweisungsträger',
  metaTitle: 'GiroCode oder Überweisungsträger: was heute sinnvoll ist',
  metaDescription:
    'Der gedruckte Überweisungsträger gegen den GiroCode: Kosten, Fehlerquellen, Haftung und die Fälle, in denen das Papierformular weiterhin die bessere Wahl ist.',
  intro: [
    'Der Überweisungsträger war jahrzehntelang der Standard im Zahlungsverkehr mit Papier. Seit SEPA gibt es ihn weiter, aber er löst ein Problem, das die meisten Betriebe heute anders lösen: Er sammelt Daten, die der Kunde abtippen muss.',
    'Ein Vergleich lohnt trotzdem, weil der Träger zwei Vorteile hat, die der Code nicht hat, und weil die Entscheidung davon abhängt, wer die Rechnung in die Hand bekommt.',
  ],
  sections: [
    {
      title: 'Was beide tun, und wo sie sich unterscheiden',
      body: [
        'Beide erzeugen am Ende denselben Vorgang: eine SEPA-Überweisung mit Empfänger, IBAN, Betrag und Verwendungszweck. Der Unterschied liegt davor.',
        'Der Überweisungsträger ist ein Formular, das mit der Post oder am Schalter eingereicht wird und dessen Daten jemand erfassen muss, entweder der Kunde im Online-Banking oder die Bank gegen Gebühr. Der GiroCode ist eine Vorlage für die App des Kunden, die er selbst bestätigt. Beim Träger zahlt der Aussteller für das Papier und für die Erfassung. Beim Code zahlt niemand etwas außer dem Druck.',
      ],
      bullets: [
        'Träger: Papier, Versand oder Schalterweg, Erfassung durch Mensch oder Bank',
        'Code: ein Druck, ein Scan, Bestätigung im Gerät des Kunden',
        'Beide: kein Widerruf, keine Lastschrift, keine automatische Zahlung',
        'Beide: der Betrag kann falsch sein, weil der Mensch ihn eingibt oder bestätigt',
      ],
    },
    {
      title: 'Fehlerquellen im direkten Vergleich',
      body: [
        'Beim Träger entstehen Fehler beim Abtippen der IBAN, beim Übertragen des Verwendungszwecks und beim Datum. Die IBAN ist zweiundzwanzigstellig und enthält keine Prüfziffer, die ein Mensch prüfen kann.',
        'Beim Code entfallen diese drei, aber zwei andere bleiben. Der Kunde kann den Bildschirm falsch lesen und einen falschen Betrag bestätigen, und er kann den Vorgang abbrechen. Was beim Code zusätzlich schiefgehen kann, ist die Vorlage selbst: ein falscher Empfänger im gedruckten Code wird von jedem Kunden brav bestätigt. Deshalb ist die Prüfung vor dem Druck hier wichtiger als beim Formular, wo ein Fehler wenigstens beim Abtippen auffällt.',
      ],
    },
    {
      title: 'Kosten und Aufwand',
      body: [
        'Ein Überweisungsträger kostet Papier, Druck und gegebenenfalls Porto, und die Erfassung am Schalter kostet Gebühren. Bei wenigen hundert Rechnungen im Jahr ist das kein Betrag, über den man reden muss, bei mehreren tausend schon.',
        'Der GiroCode kostet einen Druck auf dem Dokument, das ohnehin gedruckt wird, und keine laufenden Kosten. Es gibt keinen Anbieter dazwischen, kein Abo und keine Zählung. Das ist gleichzeitig der Grund, warum er nicht messbar ist: Ein statischer Code zählt keine Scans.',
      ],
    },
    {
      title: 'Wann der Träger weiterhin die bessere Wahl ist',
      body: [
        'Wenn die Zielgruppe nicht mit Banking-Apps arbeitet. Das ist keine Frage des Alters, sondern der Gewohnheit: Wer seine Überweisungen am Schalter macht oder von jemandem machen lässt, braucht ein Formular, und dort ist der Träger besser als ein Code, den niemand scannt.',
        'Zweitens, wenn das Dokument ohnehin per Post verschickt wird und eine Rücksendung erwartet wird. Ein beigelegter Träger ist dann Teil des Ablaufs, ein Code ist eine zusätzliche Option, die niemand nutzt.',
        'Drittens, wenn es auf den Nachweis der Zustellung ankommt. Ein eingereichter Träger ist ein Vorgang mit Datum, ein Scan ist keiner.',
      ],
    },
    {
      title: 'Die Kombination, die in der Praxis funktioniert',
      body: [
        'Auf dieselbe Rechnung gehören beide Wege, lesbar: die IBAN als Text mit Empfänger, Betrag und Verwendungszweck, daneben der Code. Wer scannen kann, tut es, wer nicht, tippt ab. Was nicht funktioniert, ist die Variante, in der nur der Code steht, weil dann jeder ohne App zum Telefon greifen muss.',
        'Dasselbe gilt für das Zahlungsziel. Ein Code ohne Datum, bis wann gezahlt werden soll, verschiebt die Zahlung nach hinten. Das Datum gehört in den Text, nicht in den Code.',
      ],
      bullets: [
        'IBAN, Empfänger, Betrag und Zweck immer auch als Text',
        'Der Code ersetzt nichts, er beschleunigt',
        'Zahlungsziel im Text nennen, nicht im Code verstecken',
      ],
    },
  ],
  useCases: [
    {
      title: 'Rechnung an Privatkunden',
      text: 'Text und Code nebeneinander. Der Code für die App, der Text für alle anderen.',
    },
    {
      title: 'Rechnung an Geschäftskunden',
      text: 'Der Code ist hier meist unnötig, weil die Buchhaltung ohnehin im System arbeitet. Er schadet nicht, kostet aber Platz.',
    },
    {
      title: 'Spendenaufruf per Post',
      text: 'Der Träger im Umschlag ist Teil des Rituals, der Code auf dem Schreiben ist die moderne Variante. Beides zusammen erhöht die Antwortquote nicht automatisch.',
    },
    {
      title: 'Vereinsbeitrag',
      text: 'Der Code auf dem Anschreiben mit Mitgliedsnummer im Zweck, die Bankverbindung im Text. Wer nicht scannt, überweist wie bisher.',
    },
  ],
  steps: [
    'Prüfen, wie die eigene Zielgruppe zahlt: App, Schalter, Dauerauftrag oder gar nicht.',
    'Die Bankverbindung als Text auf das Dokument setzen, vollständig und lesbar.',
    'Den GiroCode daneben setzen, mit Betrag oder ohne, je nach Fall.',
    'Eine Testrechnung an sich selbst schicken und mit zwei verschiedenen Banking-Apps scannen.',
  ],
  faq: [
    {
      q: 'Ist der Überweisungsträger noch erlaubt?',
      a: 'Ja. Er ist ein normales Formular und wird weiterhin angenommen. An Bedeutung verloren hat er, weil die meisten Überweisungen inzwischen in der App entstehen.',
    },
    {
      q: 'Kann ich den Code auf einen Träger drucken?',
      a: 'Ja, aber es ist der schwächste Fall: Der Träger muss dann trotzdem eingereicht werden, und der Code spart nur das Abtippen. Sinnvoll ist er auf dem Begleitdokument, nicht auf dem Formular.',
    },
    {
      q: 'Welche Variante ist schneller bezahlt?',
      a: 'Der Code, weil zwischen Scan und Bestätigung selten mehr als eine Minute liegt. Der Träger braucht Weg, Erfassung und Buchung.',
    },
    {
      q: 'Was ist mit Lastschrift und Karte?',
      a: 'Beide sind eigene Verfahren. Lastschrift braucht ein Mandat, Kartenzahlung braucht ein Gerät oder einen Anbieter. Ein GiroCode ist und bleibt eine Überweisung.',
    },
  ],
  sources: [USTG_14],
  toolLinks: [
    { label: 'GiroCode erstellen', href: '/?type=sepa' },
    { label: 'GiroCode: Format und Aufbau', href: '/qr-code-generator/girocode' },
  ],
  blogLinks: [
    { label: 'SEPA-GiroCode erstellen: Anleitung', href: '/blog/sepa-girocode-qr-code-erstellen' },
  ],
};

const kleinunternehmer: SeoSubPage = {
  slug: 'girocode-kleinunternehmer',
  title: 'GiroCode für Kleinunternehmer',
  metaTitle: 'GiroCode für Kleinunternehmer: Rechnung mit QR-Code',
  metaDescription:
    'Was eine Rechnung nach § 19 UStG enthalten muss, was die Kleinbetragsrechnung erlaubt und warum der QR-Code weder Pflichtangabe noch E-Rechnung ist.',
  intro: [
    'Kleinunternehmerinnen und Kleinunternehmer schreiben Rechnungen, die oft knapp sind: ein Blatt, ein Betrag, eine Leistung. Da passt ein QR-Code gut ins Bild, weil er genau eine Sache tut, nämlich das Bezahlen vereinfachen.',
    'Was er nicht tut, ist eine Rechnung vollständig zu machen. Und weil nach § 19 UStG ohnehin ein Hinweis auf die Steuerbefreiung nötig ist, lohnt sich der Blick auf die Pflichtangaben, bevor über die Gestaltung gesprochen wird.',
  ],
  sections: [
    {
      title: 'Was die Rechnung enthalten muss',
      body: [
        'Wer nach § 19 UStG als Kleinunternehmer behandelt wird, weist keine Umsatzsteuer aus und muss einen Hinweis darauf auf der Rechnung tragen. Für Rechnungen über 250 Euro brutto gelten die Pflichtangaben des § 14 Abs. 4 UStG: beide Namen und Anschriften, Steuernummer oder Umsatzsteuer-Identifikationsnummer, Ausstellungsdatum, fortlaufende Rechnungsnummer, Menge und Art der Leistung, Leistungszeitpunkt, Nettoentgelt, Steuersatz und Steuerbetrag oder Hinweis auf die Steuerbefreiung.',
        'Bis einschließlich 250 Euro brutto genügt eine Kleinbetragsrechnung nach § 33 UStDV. Dafür braucht es nur Name und Anschrift des Leistenden, Ausstellungsdatum, Art und Umfang der Leistung sowie den Bruttobetrag mit Steuersatz oder dem Hinweis auf die Steuerbefreiung.',
        'Der Code gehört in keine dieser Listen. Er ist keine Pflichtangabe, und er wird nicht zur Pflichtangabe, weil ein Kunde ihn gern hätte.',
      ],
      bullets: [
        'Hinweis auf die Steuerbefreiung nach § 19 UStG nicht vergessen',
        'Fortlaufende Rechnungsnummer, auch bei kleinen Beträgen sinnvoll',
        'Bei Kleinbetragsrechnungen entfallen Empfängeranschrift, Nummer und Steuernummer',
        'Der Code kommt zusätzlich, nicht statt',
      ],
    },
    {
      title: 'Der Code ist keine E-Rechnung',
      body: [
        'Eine E-Rechnung ist ein strukturiertes Format nach EN 16931, in Deutschland vor allem XRechnung und ZUGFeRD. Eine PDF oder ein Ausdruck mit QR-Code ist keine E-Rechnung, auch wenn der Code auf eine Zahlung zeigt oder ein XML eingebettet ist.',
        'Seit dem 1. Januar 2025 müssen Unternehmen in der Lage sein, E-Rechnungen zu empfangen. Für Kleinbetragsrechnungen gibt es eine Ausnahme von der Pflicht, selbst E-Rechnungen auszustellen. Wer als Kleinunternehmer B2B arbeitet, sollte trotzdem wissen, was Kundinnen und Kunden ab 2027 erwarten werden.',
      ],
    },
    {
      title: 'Was ein GiroCode auf einer kleinen Rechnung bringt',
      body: [
        'Bei Handwerksleistungen, Nachhilfe, Fotografie, Beratung oder Kosmetik ist die Rechnung oft ein Blatt, das bei Übergabe oder per Mail kommt. Der Code darauf verkürzt die Zahlung von mehreren Tagen auf Minuten, weil das Zusammentragen von IBAN und Betrag entfällt.',
        'Der Effekt ist bei kleinen Beträgen größer als bei großen, was zunächst überrascht. Bei 5.000 Euro nimmt sich jemand die Zeit zum Abtippen, bei 38 Euro bleibt die Rechnung liegen. Der Code senkt genau diese Schwelle.',
      ],
      bullets: [
        'Betrag im Code bei festen Preisen, sonst offen lassen',
        'Rechnungsnummer in den Verwendungszweck, damit die Zuordnung ohne Rückfrage klappt',
        'Der Empfängername im Code sollte identisch mit dem auf dem Kontoauszug sein',
      ],
    },
    {
      title: 'Zwei Fehler, die häufig passieren',
      body: [
        'Der erste: Der QR-Code zeigt auf eine private Kontoverbindung, während die Rechnung eine Geschäftsadresse nennt. Das ist technisch möglich und wirkt unseriös, und bei einer Betriebsprüfung erzeugt es Fragen, die man nicht haben will.',
        'Der zweite: Der Code enthält den Betrag, die Rechnung wird aber nachträglich geändert. Dann zeigt der gedruckte Code einen anderen Betrag als das Dokument. Bei einer Korrektur gehört eine neue Rechnung mit neuem Code dazu, nicht ein korrigierter Zettel mit dem alten Aufdruck.',
      ],
    },
    {
      title: 'Größe und Ort',
      body: [
        'Auf einem A4-Blatt, das in der Hand gehalten wird, reichen 2,5 bis 3 Zentimeter. Auf einer Visitenkarte gilt dasselbe wie für jede Karte: 2,5 Zentimeter, und lieber auf der Rückseite als zwischen zwei Textzeilen.',
        'Die Stelle unter dem Zahlungsziel ist die beste, weil dort ohnehin steht, wie gezahlt werden soll. Ein Code im Kopfbereich konkurriert mit dem Logo und wird kleiner gedruckt, als er sein müsste.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Handwerk und Montage',
      text: 'Die Rechnung wird vor Ort übergeben, der Code mit festem Betrag. Der Kunde zahlt, während der Handwerker abbaut.',
    },
    {
      title: 'Nachhilfe und Kurse',
      text: 'Monatliche Rechnung mit festem Betrag und der Kursnummer im Zweck. Damit die Zuordnung auch bei gleichen Nachnamen klappt.',
    },
    {
      title: 'Fotografie und Gestaltung',
      text: 'Rechnung nach Abnahme, Code ohne Betrag, weil häufig Anzahlungen und Restbeträge anfallen.',
    },
    {
      title: 'Kosmetik und Studio',
      text: 'Die Rechnung am Tresen, der Code für alle, die kein Bargeld dabeihaben und kein Kartenlesegerät wollen.',
    },
  ],
  steps: [
    'Pflichtangaben prüfen, besonders den Hinweis auf die Steuerbefreiung nach § 19 UStG.',
    'Rechnungsnummer festlegen und im Verwendungszweck an den Anfang setzen.',
    'GiroCode erzeugen, Empfänger und IBAN aus dem Geschäftskonto, Betrag nach Fall.',
    'Testrechnung drucken und mit der eigenen Banking-App scannen, bevor die erste echte rausgeht.',
  ],
  faq: [
    {
      q: 'Muss ich als Kleinunternehmer einen QR-Code auf die Rechnung setzen?',
      a: 'Nein. Es gibt keine Pflicht dazu. Der Code ist eine freiwillige Zahlungshilfe.',
    },
    {
      q: 'Was muss auf eine Kleinunternehmer-Rechnung?',
      a: 'Ein Hinweis auf die Steuerbefreiung nach § 19 UStG ist erforderlich. Bis 250 Euro brutto genügen die Angaben der Kleinbetragsrechnung, darüber gilt der Katalog des § 14 Abs. 4 UStG.',
    },
    {
      q: 'Gilt die E-Rechnungspflicht für mich?',
      a: 'Kleinbetragsrechnungen sind von der Pflicht zur Ausstellung einer E-Rechnung ausgenommen. Empfangen können muss sie seit 2025 grundsätzlich jedes Unternehmen.',
    },
    {
      q: 'Kann der Code auf mein privates Konto zeigen?',
      a: 'Technisch ja, aber Name und Konto sollten zusammenpassen und zum Geschäft gehören. Alles andere wirkt unseriös und erzeugt Rückfragen.',
    },
    {
      q: 'Soll der Betrag im Code stehen?',
      a: 'Bei festen Preisen ja, das erspart Rückfragen. Bei schwankenden Beträgen oder Anzahlungen besser leer lassen.',
    },
  ],
  sources: [USTG_19, USTG_14, USTDV_33],
  toolLinks: [
    { label: 'GiroCode erstellen', href: '/?type=sepa' },
    { label: 'GiroCode auf der Rechnung', href: '/qr-code-generator/girocode-rechnung' },
  ],
  blogLinks: [
    { label: 'SEPA-GiroCode erstellen: Anleitung', href: '/blog/sepa-girocode-qr-code-erstellen' },
  ],
};

export const TYPEN_PART_SEVEN = [rechnung, verein, spende, vergleich, kleinunternehmer];
