/**
 * English version of one regulatory page: the wine e-label.
 *
 * Only one page of the standards cluster is translated, on purpose. The rest is
 * German law and German landlords, but the e-label obligation follows wine into
 * export markets: an importer in London or a distributor in Rotterdam has to
 * check the same label as a producer in Rheinhessen. That is the one page where
 * the audience is provably not German-speaking.
 *
 * This is not a translation of /standards/wein-e-label. It is written for a
 * different reader: someone buying or importing wine into the EU, who needs to
 * know what has to be on the bottle, what may be behind the code, and what
 * happens if a batch is printed wrong. The German page addresses the producer
 * deciding between print and digital; this one addresses the buyer checking a
 * label before it goes to market.
 *
 * Facts are the verified ones, unchanged: Regulation (EU) 2021/2117, applicable
 * from 8 December 2023, nutrition and ingredients may be electronic, energy
 * value with the "E" and the allergens must stay printed, no marketing content
 * and no personal data collection on the e-label, beer and spirits out of scope.
 */
import type { SeoSubPage } from './seo-pages';

export const WINE_ELABEL_EN: SeoSubPage = {
  slug: 'wine-e-label',
  title: 'Wine e-label: what has to be on the bottle',
  metaTitle: 'Wine e-label: QR code, nutrition and allergen rules',
  metaDescription:
    'Regulation (EU) 2021/2117 explained for importers and buyers: what stays printed, what may sit behind the QR code, and what fails a label check.',
  intro: [
    'Since 8 December 2023, wine and aromatised wine products placed on the EU market carry an ingredient list and a nutrition declaration. Both may be printed on the label or delivered electronically through a QR code. For an importer or a buyer signing off a label, that flexibility is where the mistakes happen, because the split between printed and digital is not free to choose.',
    'This page is written for the person checking a label before a batch goes to market, not for the producer deciding how to lay out a 100 mm label. The obligations are the same ones that apply to the producer in Germany; the practical questions are different.',
  ],
  sources: [
    {
      label: 'Regulation (EU) 2021/2117, consolidated text',
      href: 'https://eur-lex.europa.eu/eli/reg/2021/2117/oj',
    },
    {
      label: 'Regulation (EU) 1169/2011, Food Information to Consumers',
      href: 'https://eur-lex.europa.eu/eli/reg/2011/1169/oj',
    },
  ],
  sections: [
    {
      title: 'What must stay printed on the bottle',
      body: [
        'Two items cannot move behind the code. The energy value, marked with the letter "E", has to appear on the package, and so do the allergens, in practice the sulphites declaration. Everything else in the nutrition declaration, and the full ingredient list, may be provided electronically.',
        'For a label check this is the first thing to verify, and it is the most common defect: a batch printed with the full nutrition table on the website and no energy value on the bottle. The code resolves, the data is complete, and the label still fails.',
      ],
      bullets: [
        'Printed: energy in kJ and kcal per 100 ml, the "E", and the allergen statement',
        'May be digital: fat, saturates, carbohydrate, sugars, protein, salt, and the ingredient list',
        'Wine under 10 percent alcohol: the date of minimum durability may also be electronic',
        'The printed energy value is required even when the rest of the table is digital',
      ],
    },
    {
      title: 'What may not sit behind the code',
      body: [
        'The electronic label may not carry sales or marketing content, and it may not collect personal data from the person scanning it. A shop link, a newsletter form or an analytics pixel on the same page is a compliance risk that buys nothing.',
        'In practice this rules out most redirect services: a short link whose whole purpose is to count scans is collecting data on the page the regulation is talking about. A code that points directly at a page you control, with no counting, is the cleaner construction.',
      ],
    },
    {
      title: 'One code per wine, and the price-list exception',
      body: [
        'Each wine needs its own destination, because ingredients and values differ between wines. The regulation allows a shared code where a price list with an ordering function covers several wines, pointing at a page that carries the information for all of them. That is a narrow exception, not a shortcut for an entire range.',
        'For an importer holding several producers, this is where batches get mixed up: a shared page for a range is fine for the list, and wrong for the individual bottles.',
      ],
    },
    {
      title: 'How long the destination has to work',
      body: [
        'The information has to stay available for as long as the product is on the market. That is longer than most campaign pages live, and it is the part that fails quietly: a batch printed in 2024 scans fine in 2024 and dead in 2027.',
        'Before accepting a label, check that the destination is a permanent address you or the producer controls, without a login, without a redirect service and without an expiry. A code is only as durable as the page behind it.',
      ],
    },
    {
      title: 'Print checks before a batch runs',
      body: [
        'On a 100 mm label, 15 mm is the floor for a code and 18 mm is comfortable, with a quiet zone of at least four modules. Error correction level Q or H survives the handling a bottle gets in a cold chain.',
        'The code must be darker than its background. A light code reversed out of a dark label photographs well and fails in a cellar or a restaurant with dim lighting. Print, then scan the actual material with three devices before the run, not the PDF.',
      ],
      bullets: [
        'Minimum 15 mm, better 18 mm, on a 100 mm label',
        'Error correction Q or H, quiet zone of four modules',
        'Never inverted, no gloss varnish over the code',
        'Test on the real substrate under shop or cellar lighting',
      ],
    },
  ],
  useCases: [
    {
      title: 'Importer signing off a producer label',
      text: 'Check the two printed items first. If the energy value or the sulphite statement is missing, the batch does not need a fix to the website, it needs new labels.',
    },
    {
      title: 'Distributor listing a new wine',
      text: 'Ask for the destination address and scan it. A code pointing at a generic producer homepage is not a compliant e-label, even if the data exists somewhere on that site.',
    },
    {
      title: 'Producer selling into several markets',
      text: 'One destination per wine, in the languages of the markets it ships to, with no shop or tracking elements on the page.',
    },
    {
      title: 'Retail buyer checking an existing listing',
      text: 'Longevity matters more than design here. If nobody can say who maintains the destination page, assume it will not survive the vintage.',
    },
  ],
  steps: [
    'Confirm the printed items: energy value with the "E", and the allergen statement.',
    'Scan the code as a consumer would, on a retail device, and check the page for marketing content and any consent banner.',
    'Confirm the page carries the full nutrition declaration and the ingredient list for that specific wine.',
    'Ask who owns the destination address and what happens to it when the vintage changes.',
    'Check size, contrast and error correction on the material, then record the scan test with the batch paperwork.',
  ],
  faq: [
    {
      q: 'Is a QR code mandatory on a wine label?',
      a: 'No. The obligation is on the ingredient list and the nutrition declaration, not on the technology. Either may be printed or provided electronically, and the QR code is simply the usual way of doing the latter because the lists do not fit on a 100 mm label in several languages.',
    },
    {
      q: 'Can the energy value be moved behind the code?',
      a: 'No. The energy value, marked with the letter "E", and the allergens must remain on the package. The rest of the nutrition declaration and the ingredient list may be electronic.',
    },
    {
      q: 'May the e-label page carry a shop link or a newsletter form?',
      a: 'No. The regulation excludes sales and marketing content from the electronic label, and it excludes the collection of personal data. A page with a shop, a form or a tracking pixel is exposed.',
    },
    {
      q: 'Does the same rule apply to beer and spirits?',
      a: 'No. Regulation (EU) 2021/2117 covers wine and aromatised wine products. Other categories may provide nutrition information voluntarily, but there is no equivalent obligation.',
    },
    {
      q: 'What happens if the destination page disappears?',
      a: 'The e-label is no longer available, which leaves the batch non-compliant regardless of what was printed. Use a permanent address under your own control, and do not route it through a short-link service that can be switched off.',
    },
  ],
  translations: [
    { lang: 'de', label: 'Deutsche Fassung, für Produzenten', href: '/standards/wein-e-label' },
  ],
  toolLinks: [
    { label: 'Create the QR code for an e-label page', href: '/?type=url' },
    { label: 'Print sizes and contrast', href: '/qr-codes-auf' },
  ],
  blogLinks: [
    { label: 'Static or dynamic: what still works after printing', href: '/blog/dynamische-vs-statische-qr-codes' },
  ],
};
