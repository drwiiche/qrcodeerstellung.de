/**
 * German type pages, seventh batch: the last four noun pages from the competitor
 * analysis.
 *
 * Three of these describe something the code deliberately does not do. Google Forms
 * and Google Docs are hosted content with sharing settings, and an audio code cannot
 * hold audio. Saying so is the whole value of the pages.
 */
import type { SeoSubPage } from './seo-pages';

const googleFormular: SeoSubPage = {
  slug: 'google-formular',
  title: 'Google Formular als QR-Code',
  metaTitle: 'Google Formular QR-Code: Umfrage per Scan ausfüllen',
  metaDescription:
    'Ein Code, der ein Google-Formular öffnet: welche Freigabe nötig ist, warum der Code nichts speichert und was bei personenbezogenen Antworten zu klären ist.',
  intro: [
    'Ein Google-Formular ist der kürzeste Weg zu einer Umfrage, einer Anmeldung oder einer Rückmeldung, die als Tabelle ankommt. Der QR-Code davor beseitigt den Schritt, an dem solche Umfragen scheitern: den Link weiterschicken und hoffen.',
    'Der Code speichert dabei nichts. Er öffnet eine Seite, und alles Weitere passiert in Googles Formular. Wer das auseinanderhält, erspart sich zwei Missverständnisse: dass der Code Antworten sammelt, und dass er den Datenschutz erledigt.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Die Adresse des Formulars, so wie sie beim Teilen angeboten wird. Zwei Formen sind üblich: die Adresse auf docs.google.com/forms/.../viewform und ein Kurzlink, der auf dieselbe Seite zeigt. Beide funktionieren, die lange Adresse hat aber einen Vorteil: Sie bleibt gleich, auch wenn der Kurzlink einmal neu erzeugt wird.',
        'Wichtig ist, dass der Code auf die Ausfüllansicht zeigt und nicht auf den Bearbeitungsmodus. Im Bearbeitungsmodus sieht der Kunde die Fragen und die Antworten anderer Leute, und das ist ein Datenleck, das bei der ersten Umfrage auffällt statt beim Test.',
      ],
      bullets: [
        'Vor dem Druck im privaten Fenster prüfen, ob das Formular ohne Anmeldung ausfüllbar ist',
        'Ein Formular pro Anlass, nicht ein Formular für alles',
        'Die Ausfüllansicht verlinken, nicht die Bearbeitungsansicht',
        'Kurze eigene Adresse ist bequem, hängt aber an einer Weiterleitung',
      ],
    },
    {
      title: 'Die Freigabe ist der Punkt, an dem es scheitert',
      body: [
        'In den Einstellungen des Formulars lässt sich festlegen, ob eine Anmeldung erforderlich ist. Ist sie es, sieht der Kunde eine Anmeldemaske, und eine Umfrage am Tisch ist damit beendet. Für eine Abstimmung unter Kolleginnen und Kollegen ist die Anmeldepflicht sinnvoll, für eine Rückmeldung am Tresen ist sie ein Ausschlusskriterium.',
        'Die zweite Einstellung betrifft die Anzahl der Antworten. Ein Formular, das nur eine Antwort pro Person zulässt, verlangt eine Anmeldung. Wer das nicht will, muss Mehrfachantworten erlauben und mit ihnen leben.',
      ],
    },
    {
      title: 'Was der Code nicht leistet',
      body: [
        'Er zählt keine Antworten, er bestätigt keine Teilnahme und er schützt nicht vor doppelten Eingaben. Er zeigt nur auf das Formular. Wer Teilnahmekarten oder Gutscheine verteilen will, braucht eine Logik im Formular oder eine Person davor, nicht einen anderen Code.',
        'Er ersetzt auch nicht die Information der Teilnehmenden. Ein Formular, das Namen erhebt, ist eine Verarbeitung personenbezogener Daten, und die braucht eine Rechtsgrundlage und eine Information darüber, was mit den Antworten passiert. Bei Google als Dienstleister kommt die Frage nach dem Vertrag zur Auftragsverarbeitung dazu. Das ist eine organisatorische Frage, und der QR-Code ändert daran nichts, weder zum Guten noch zum Schlechten.',
      ],
    },
    {
      title: 'Wo das Formular am Code wirkt',
      body: [
        'Am Tisch, am Empfang, am Ausgang, auf dem Beileger zur Rechnung: überall dort, wo jemand gerade eine Erfahrung gemacht hat und in 30 Sekunden etwas dazu sagen könnte. Die Rücklaufquote hängt fast nie am Code, sondern an der Länge des Formulars. Drei Fragen werden beantwortet, fünfzehn nicht.',
        'Ein zweiter Faktor ist die Beschriftung. „Umfrage, 30 Sekunden" funktioniert, „QR-Code" nicht. Wer nicht weiß, was ihn erwartet, scannt nicht.',
      ],
      bullets: [
        'Maximal fünf Fragen, besser drei',
        'Ein Fortschrittsbalken hilft, wenn es mehr als drei Fragen sind',
        'Keine Pflichtfelder, die niemand beantworten kann',
        'Die erste Frage entscheidet, ob der Rest ausgefüllt wird',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf einem Tischaufsteller sind 4 bis 5 Zentimeter Kantenlänge bei 40 bis 60 Zentimetern Abstand richtig. Auf einem Aushang, der aus einem Meter gelesen wird, 10 Zentimeter. Auf einem Flyer in der Hand genügen 2,5 Zentimeter.',
        'Vermeiden Sie Glas mit Reflexion und Stellen mit Gegenlicht. Ein Code auf einem Tresen, der eine Fensterfront im Rücken hat, liest sich schlechter als derselbe Code zwei Meter weiter innen.',
      ],
    },
  ],
  useCases: [
    { title: 'Rückmeldung am Tresen', text: 'Drei Fragen zur Beratung, der Code steht neben der Kasse. Wer zufrieden ist, füllt aus, während er wartet.' },
    { title: 'Anmeldung zum Kurs', text: 'Der Code am Aushang öffnet das Anmeldeformular mit Name und Kursnummer. Die Liste liegt abends als Tabelle vor.' },
    { title: 'Umfrage im Verein', text: 'Der Code auf dem Vereinsheft, das Formular fragt nach Terminwünschen. Keine Diskussion in der WhatsApp-Gruppe.' },
    { title: 'Reklamation und Mängel', text: 'Der Code auf dem Lieferschein öffnet ein Formular mit Feld für die Auftragsnummer. Der Fall landet strukturiert im Postfach.' },
  ],
  steps: [
    'Das Formular bauen und in den Einstellungen prüfen, ob eine Anmeldung verlangt wird.',
    'Die Ausfüllansicht öffnen, nicht die Bearbeitungsansicht, und die Adresse daraus kopieren.',
    'Die Adresse im privaten Fenster und auf dem Handy testen.',
    'Code erzeugen, als SVG herunterladen und mit Zweck und Dauer beschriften.',
    'Den ersten Tag beobachten: Wie viele Scans, wie viele abgeschickte Antworten, wo bricht es ab.',
  ],
  faq: [
    { q: 'Speichert der QR-Code Antworten?', a: 'Nein. Die Antworten liegen im Formular bei Google. Der Code enthält nur die Adresse.' },
    { q: 'Müssen sich Teilnehmende anmelden?', a: 'Nur, wenn es in den Formulareinstellungen so eingestellt ist. Für Umfragen vor Ort ist eine Anmeldepflicht meistens ein Ausschlusskriterium.' },
    { q: 'Kann ich verhindern, dass jemand mehrfach abstimmt?', a: 'Nur mit Anmeldepflicht oder mit einer Logik im Formular. Ein anderer QR-Code löst das nicht.' },
    { q: 'Brauche ich einen Vertrag mit Google?', a: 'Wenn über das Formular personenbezogene Daten verarbeitet werden, ist die Verarbeitung zu klären, einschließlich Auftragsverarbeitung und Information der Teilnehmenden. Das ist keine Frage des Codes.' },
    { q: 'Was ist besser: Google Formular oder eigenes Formular?', a: 'Das Google-Formular ist schneller gebaut und liefert eine Tabelle. Ein eigenes Formular kostet mehr Arbeit, hält die Daten aber im eigenen Bereich.' },
  ],
  toolLinks: [
    { label: 'Formular-Code erstellen', href: '/?type=url' },
    { label: 'Anwesenheit per QR-Code erfassen', href: '/qr-code-generator/anwesenheit' },
  ],
  blogLinks: [
    { label: 'QR-Codes für Veranstaltungen', href: '/blog/qr-codes-veranstaltungen-events' },
    { label: 'QR-Code und Datenschutz', href: '/blog/qr-code-dsgvo-datenschutz' },
  ],
};

const googleDocs: SeoSubPage = {
  slug: 'google-docs',
  title: 'Google Docs als QR-Code',
  metaTitle: 'Google Docs QR-Code: Dokument per Scan öffnen',
  metaDescription:
    'Ein Code, der ein Google-Dokument öffnet: welche Freigabe trägt, warum Bearbeiten-Links auf gedruckten Codes gefährlich sind und wann eine PDF besser ist.',
  intro: [
    'Ein Google-Dokument ist praktisch, solange es im Browser gelesen wird. Der Code darauf ist eine Abkürzung dorthin, und wie bei jeder Datei entscheidet nicht der Code über den Erfolg, sondern die Freigabe.',
    'Die drei Freigabestufen sehen in der Oberfläche ähnlich aus und verhalten sich auf einem gedruckten Etikett völlig unterschiedlich. Das ist der Inhalt dieser Seite.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Die Adresse des Dokuments, in der Form docs.google.com/document/d/.../edit oder mit einem anderen Suffix. Achtung: Die Adresse, die beim Kopieren aus der Adresszeile kommt, endet oft auf /edit. Wer die so in einen Code schreibt, verschickt einen Bearbeitungslink.',
        'Richtig ist die Freigabeansicht oder ein Link, der auf die Leseansicht zeigt. Am saubersten ist eine eigene kurze Adresse auf der eigenen Domain, die auf die Leseansicht weiterleitet: Dann steht im Code etwas Lesbares, und die Freigabe lässt sich später ändern, ohne den Code neu zu drucken.',
      ],
      bullets: [
        'Nicht die Adresse mit /edit verwenden',
        'Freigabe auf „Jeder mit dem Link, Betrachter" setzen',
        'Im privaten Fenster prüfen, also ohne angemeldetes Google-Konto',
        'Bei Änderungen am Dokument bleibt die Adresse gleich, der Code gilt weiter',
      ],
    },
    {
      title: 'Die Freigabestufen und was sie auf Papier bedeuten',
      body: [
        'Betrachter: Jeder mit dem Link liest, niemand ändert. Das ist die einzige Stufe, die auf einem gedruckten Code funktioniert. Kommentator: Jeder mit dem Link kann kommentieren, was bei einem öffentlichen Dokument zu Spam führt. Bearbeiter: Jeder mit dem Link kann den Text überschreiben, löschen oder durch etwas anderes ersetzen.',
        'Der Bearbeiterlink ist der Fehler, der am seltensten auffällt und am meisten kostet. Ein Dokument an einer Pinnwand, das jeder umschreiben kann, bleibt nicht lange das Dokument, das man aufgehängt hat.',
        'Dazu kommt die Anmeldepflicht: Steht die Freigabe auf „eingeschränkt", sieht der Kunde eine Anmeldemaske statt des Inhalts. Bei einem gedruckten Code ist das die häufigste Beschwerde nach dem Druck.',
      ],
    },
    {
      title: 'Lesen am Telefon: was Google Docs gut kann und was nicht',
      body: [
        'Die Leseansicht funktioniert im mobilen Browser ohne App, und das ist der Grund, warum dieser Typ überhaupt sinnvoll ist. Ein Dokument mit Überschriften, Listen und Tabellen bleibt lesbar. Ein Dokument, das für A4 mit Rand und Fußzeile gestaltet wurde, liest sich eng, aber es liest sich.',
        'Was nicht funktioniert, ist das Ausfüllen am Telefon. Ein Dokument mit Formularfeldern oder einer Tabelle zum Eintragen ist auf einem 6-Zoll-Bildschirm eine Zumutung. Für alles, was zurückkommt, gehört ein Formular hinter den Code und kein Dokument.',
      ],
    },
    {
      title: 'Wann eine PDF die bessere Wahl ist',
      body: [
        'Wenn der Inhalt unverändert bleiben soll. Ein Google-Dokument kann jederzeit bearbeitet werden, eine PDF ist fest. Bei Aushängen, Anleitungen und Preislisten ist das ein Vorteil, weil die Fassung im Code und die Fassung auf dem Papier nicht auseinanderlaufen können.',
        'Wenn das Dokument an einem Ort ohne Netz gelesen werden muss. Ein Google-Dokument braucht eine Verbindung, eine heruntergeladene PDF nicht. Für Keller, Werkstätten und Fahrzeuge ist das der entscheidende Unterschied.',
        'Und wenn der Empfänger kein Google-Konto hat und die Freigabe trotzdem eng bleiben soll. Eine PDF auf der eigenen Domain erreicht jeder, ohne dass irgendwo ein Konto nötig ist.',
      ],
    },
    {
      title: 'Druck und Platzierung',
      body: [
        'Der Code steht meistens auf einem Aushang oder einem Beileger, also auf Papier, das in der Hand gehalten oder aus einem Meter gelesen wird: 2,5 bis 3 Zentimeter für die Hand, 10 Zentimeter für den Aushang.',
        'Beschriften Sie ihn mit dem Inhalt und nicht mit dem Format: „Speisekarte mit Allergenen" wird gescannt, „Google Docs" nicht. Und prüfen Sie die Freigabe nach jeder Änderung erneut, denn die Einstellung kann sich ändern, wenn jemand das Dokument kopiert oder in einen anderen Ordner verschiebt.',
      ],
    },
  ],
  useCases: [
    { title: 'Aushang mit Öffnungszeiten', text: 'Das Dokument wird zentral gepflegt, der Aushang bleibt. Ändert sich etwas, ist es am nächsten Tag überall aktuell.' },
    { title: 'Anleitung am Arbeitsplatz', text: 'Ein Code an der Maschine führt zur Anleitung im Browser. Bei Änderungen bleibt der Aufkleber, der Text wechselt.' },
    { title: 'Protokolle im Verein', text: 'Der Code im Vereinsheft öffnet das Protokoll der letzten Sitzung. Freigabe auf Betrachter, sonst schreibt jemand hinein.' },
    { title: 'Elternbrief und Infozettel', text: 'Statt eines Ausdrucks, der in der Schultasche verschwindet, ein Code auf die Mitteilung. Wer kein Konto hat, bekommt weiter Papier.' },
  ],
  steps: [
    'Die Freigabe auf „Jeder mit dem Link, Betrachter" stellen.',
    'Die Leseansicht öffnen und die Adresse daraus kopieren, nicht die Adresse mit /edit.',
    'Die Adresse im privaten Fenster und auf dem Handy öffnen.',
    'Code erzeugen und mit dem Inhalt beschriften, nicht mit dem Format.',
    'Nach jeder inhaltlichen Änderung die Freigabe erneut prüfen.',
  ],
  faq: [
    { q: 'Kann jeder mit dem Code das Dokument ändern?', a: 'Nur wenn die Freigabe auf Bearbeiter steht. Bei einem gedruckten Code gehört sie auf Betrachter.' },
    { q: 'Warum sehe ich eine Anmeldemaske?', a: 'Weil die Freigabe auf „eingeschränkt" steht. Bei einem öffentlichen Code muss sie auf „Jeder mit dem Link" stehen.' },
    { q: 'Funktioniert das ohne Google-Konto?', a: 'Bei der Freigabe „Jeder mit dem Link" ja, im Browser und ohne App. Ein Konto braucht nur, wer kommentieren oder bearbeiten will.' },
    { q: 'Was ist besser, Google Docs oder PDF?', a: 'Docs, wenn der Inhalt sich ändern soll. PDF, wenn er fest bleiben soll oder offline gelesen wird.' },
    { q: 'Ändert sich der Code, wenn das Dokument umbenannt wird?', a: 'Nein. Die Dokument-ID in der Adresse bleibt gleich. Der Anzeigename ändert sich, die Adresse nicht.' },
  ],
  toolLinks: [
    { label: 'Dokument-Code erstellen', href: '/?type=url' },
    { label: 'PDF als QR-Code bereitstellen', href: '/qr-code-generator/pdf' },
  ],
  blogLinks: [
    { label: 'QR-Code und Datenschutz', href: '/blog/qr-code-dsgvo-datenschutz' },
    { label: 'QR-Code drucken: Kontrast, Größe, Material', href: '/blog/qr-code-drucken-kontrast-groesse' },
  ],
};

const audio: SeoSubPage = {
  slug: 'audio',
  title: 'Audio-QR-Code erstellen',
  metaTitle: 'Audio QR-Code erstellen: Ton per Scan abspielen',
  metaDescription:
    'Ein Audio-QR-Code enthält keinen Ton, sondern einen Link auf eine Audiodatei. Was beim Abspielen schiefgeht, wie groß die Datei sein darf und wo Ton hilft.',
  intro: [
    'Der Name führt in die Irre. Ein Audio-QR-Code kann keinen Ton speichern, jedenfalls keinen, den man hören möchte: In einen QR-Code passen wenige Kilobyte, eine Minute Sprache braucht ein Vielfaches davon. Im Code steht eine Adresse, und der Ton kommt von dort.',
    'Das ist keine Einschränkung, sondern der Grund, warum dieser Typ funktioniert. Die Audiodatei lässt sich austauschen, solange die Adresse bleibt, und man kann sie ergänzen, ohne den gedruckten Code anzufassen.',
  ],
  sections: [
    {
      title: 'Was im Code steht',
      body: [
        'Ein Link auf eine Audiodatei oder auf eine Seite mit einem Abspieler. Die direkte Datei ist einfacher, hat aber einen Nachteil: Auf manchen Telefonen lädt der Browser die Datei herunter, statt sie abzuspielen. Eine kleine Seite mit einem Abspielknopf verhält sich überall gleich und lässt sich zusätzlich mit einem Titelbild und einem Transkript versehen.',
        'Für einen Audioguide im Museum, eine Kirchenführung oder eine Produktanleitung ist die Seite die bessere Wahl, weil sie auch den Text enthalten kann. Für eine Sprachnachricht an die Familie reicht die direkte Datei.',
      ],
      bullets: [
        'Ein Code pro Tonspur, nicht ein Code für ein ganzes Album',
        'Format MP3 oder M4A, beide werden von allen gängigen Browsern abgespielt',
        'Adresse ohne Leerzeichen und ohne Umlaute, sonst wird sie prozentkodiert',
        'Bei einer Seite mit Abspieler: Titel und Dauer dazuschreiben',
      ],
    },
    {
      title: 'Was beim Abspielen schiefgeht',
      body: [
        'Der erste Punkt ist das automatische Abspielen. Browser blockieren Ton, der ohne Zutun startet, und zwar zu Recht. Wer den Code scannt, muss danach noch auf Abspielen tippen. Darüber sollte die Beschriftung auf dem Schild nicht hinwegtäuschen.',
        'Der zweite Punkt ist die Umgebung. Ein Code an einer Wand in einer Kirche oder einer Halle wird ohne Kopfhörer abgespielt, und dann hört die ganze Gruppe mit. Für Orte mit mehreren Besuchern gleichzeitig braucht es eine Lösung, die ohne Ton funktioniert, also mindestens ein Transkript.',
        'Der dritte Punkt ist das Datenvolumen. Wer im Ausland scannt, zahlt für jede Minute. Eine Datei unter zwei Megabyte ist bei Sprache mit einer Spur Qualität noch gut verständlich.',
      ],
    },
    {
      title: 'Wie groß eine Audiodatei sein darf',
      body: [
        'Für gesprochene Sprache genügt eine niedrige Bitrate, weil keine Musik und keine feinen Höhen im Signal sind. Eine Minute in Mono bei 64 bis 96 kBit pro Sekunde ergibt etwa ein halbes bis ein Megabyte. Eine dreiminütige Führung liegt damit bei unter drei Megabyte und lädt im Mobilfunknetz in wenigen Sekunden.',
        'Wer Musik oder mehrere Sprecher aufnimmt, braucht mehr. Für den Anwendungsfall dieser Seite, also eine Erklärung, eine Anleitung oder eine Führung, ist die niedrige Bitrate die richtige Einstellung, und sie ist kein Qualitätsverlust, den man hört.',
      ],
      bullets: [
        'Mono statt Stereo, das halbiert die Dateigröße',
        'Sprache bei 64 bis 96 kBit/s ist ausreichend',
        'Länge kürzen statt Qualität senken, wenn die Datei zu groß wird',
        'Ein Transkript als Text auf derselben Seite kostet nichts und hilft allen',
      ],
    },
    {
      title: 'Wo ein Audio-Code wirklich etwas bringt',
      body: [
        'Überall dort, wo der erklärende Text zu lang für ein Schild und zu kurz für ein Buch ist: an einem Exponat, an einer Maschine, an einem Baudenkmal, an einer Pflanze im Garten, an einem Produkt mit komplizierter Handhabung.',
        'Und dort, wo Menschen den Text nicht lesen können oder wollen: sehbehinderte Besucher, Kinder, Menschen, die die Sprache des Schildes nicht lesen, aber die gesprochene Variante verstehen. Ein Transkript bleibt trotzdem Pflicht, denn Ton schließt niemanden aus, wenn er die Wahl hat.',
      ],
    },
    {
      title: 'Druck und Beschriftung',
      body: [
        'Ein Audio-Code steht meistens auf einem Schild, das aus einem halben bis einem Meter gelesen wird: 5 bis 10 Zentimeter Kantenlänge. Im Außenbereich, an Denkmälern und in Kirchen, hält nur Metall oder eine wetterfeste Platte. Papier hinter Glas fängt an zu vergilben, bevor die Führung neu aufgenommen wird.',
        'Was unter den Code gehört: die Dauer und ein Hinweis auf die Kopfhörer. „Hören Sie die Geschichte des Turms, 2:40, Kopfhörer empfohlen" ist eine Beschriftung, die funktioniert. „Audio" ist keine.',
      ],
    },
  ],
  useCases: [
    { title: 'Audioguide im Museum', text: 'Ein Code pro Exponat, dahinter eine Seite mit Ton und Transkript. Die Aufnahme lässt sich ersetzen, das Schild bleibt.' },
    { title: 'Kirchenführung', text: 'Der Code am Portal erklärt die Geschichte des Baus. Für Gruppen ohne Kopfhörer steht das Transkript auf derselben Seite.' },
    { title: 'Maschine und Werkstatt', text: 'Die Einweisung als Ton, während die Hände beschäftigt sind. Ein Code pro Maschine, die Datei wird bei Änderungen ersetzt.' },
    { title: 'Pflanze im Schaugarten', text: 'Der Code am Beet erzählt die Herkunft. Für Kinder kürzer als für Erwachsene, deshalb je Zielgruppe eine Spur.' },
  ],
  steps: [
    'Die Aufnahme machen und als Mono-MP3 mit 64 bis 96 kBit/s exportieren.',
    'Die Datei auf die eigene Domain legen oder eine Seite mit Abspieler und Transkript bauen.',
    'Die Adresse auf dem Handy im Mobilfunknetz öffnen und die Ladezeit prüfen.',
    'Code erzeugen, als SVG herunterladen und mit Titel, Dauer und Kopfhörerhinweis beschriften.',
    'Am fertigen Ort testen, bei realem Licht und mit realem Abstand.',
  ],
  faq: [
    { q: 'Kann der Ton im Code selbst stecken?', a: 'Praktisch nicht. In einen QR-Code passen wenige Kilobyte, der Code enthält deshalb einen Link auf die Audiodatei.' },
    { q: 'Startet die Wiedergabe von allein?', a: 'Nein. Browser blockieren Ton ohne Zutun, der Hörer tippt nach dem Scan auf Abspielen.' },
    { q: 'Welches Format soll ich nehmen?', a: 'MP3 oder M4A, Mono, 64 bis 96 kBit/s für Sprache. Das spielt jeder Browser und die Datei bleibt klein.' },
    { q: 'Wie lang darf eine Spur sein?', a: 'So lang wie nötig und so kurz wie möglich. Zwei bis drei Minuten sind für ein Exponat viel, für eine Führung normal.' },
    { q: 'Brauche ich ein Transkript?', a: 'Ja, wenn der Ort belebt ist oder Menschen mit Höreinschränkung erreicht werden sollen. Es kostet nichts und macht die Seite für alle besser.' },
  ],
  toolLinks: [
    { label: 'Audio-Code erstellen', href: '/?type=url' },
    { label: 'Google Docs als QR-Code', href: '/qr-code-generator/google-docs' },
  ],
  blogLinks: [
    { label: 'QR-Code drucken: Kontrast, Größe, Material', href: '/blog/qr-code-drucken-kontrast-groesse' },
  ],
};

const linkliste: SeoSubPage = {
  slug: 'linkliste',
  title: 'Mehrere Links in einem QR-Code',
  metaTitle: 'Mehrere Links im QR-Code: Linkliste statt Sammelcode',
  metaDescription:
    'Ein QR-Code trägt genau eine Adresse. Wie eine Linkliste daraus wird, warum die eigene Domain besser ist als ein Dienst und wann ein Link gewinnt.',
  intro: [
    'Die Anfrage klingt einfach: ein Code, mehrere Links. Technisch ist sie nicht lösbar, jedenfalls nicht so, wie sie gemeint ist. Ein QR-Code enthält eine Zeichenkette, und ein Scanner macht daraus genau eine Aktion.',
    'Was funktioniert, ist eine Seite mit mehreren Links davor. Der Code zeigt auf diese Seite, und dort wählt der Leser. Ob das sinnvoll ist, hängt davon ab, ob die Auswahl einen Zweck hat oder nur die Bequemlichkeit des Absenders.',
  ],
  sections: [
    {
      title: 'Warum ein Code nur ein Ziel hat',
      body: [
        'Ein QR-Code speichert Text. Bei einem Link ist dieser Text eine Adresse, und das Scan-Ergebnis ist immer dieselbe Aktion: diese Adresse öffnen. Es gibt keinen QR-Code mit zwei Adressen, zwischen denen das Telefon wählt, und keinen mit einem Menü.',
        'Deshalb ist jede Lösung für mehrere Links eine Zwischenseite. Entweder eine, die Sie selbst betreiben, oder eine bei einem Dienst, der Link-in-Bio-Seiten anbietet. Beides ist eine Seite, nur mit unterschiedlichem Besitzer.',
      ],
      bullets: [
        'Ein Code, eine Adresse, ein Ziel',
        'Mehrere Ziele brauchen eine Seite dazwischen',
        'Diese Seite gehört entweder Ihnen oder einem Anbieter',
      ],
    },
    {
      title: 'Die eigene Seite gegen den Dienst',
      body: [
        'Eine einfache Seite auf der eigenen Domain ist in einer Stunde gebaut und hat drei Vorteile: Sie gehört Ihnen, sie verschwindet nicht mit einem Abonnement, und sie erhebt keine Daten über die Klicks. Der Nachteil ist die Pflege, denn Links ändern sich und müssen von Hand nachgezogen werden.',
        'Ein Link-in-Bio-Dienst ist in fünf Minuten eingerichtet und bietet Auswertungen. Der Preis ist die Abhängigkeit: Der Dienst sieht jeden Klick, kann sein Geschäftsmodell ändern oder den Betrieb einstellen, und der gedruckte Code zeigt dann auf eine Seite, die nicht mehr existiert. Bei einem Code auf einer Speisekarte oder einem Fahrzeug ist das ein reales Risiko, bei einem Instagram-Profil ein kleines.',
      ],
    },
    {
      title: 'Wann eine Linkliste die richtige Antwort ist',
      body: [
        'Wenn ein physisches Objekt mehrere Bedürfnisse bedient. Ein Fahrzeug: Werkstatt, Notruf, Zulassung. Ein Messestand: Programm, Anfahrt, Kontakt. Ein Exponat: Ton, Text, Quelle. Hier ist die Auswahl ein Teil des Nutzens, und niemand käme auf die Idee, drei Codes nebeneinander zu drucken.',
        'Und wenn sich das Ziel ändert, das Objekt aber bleibt. Eine Speisekarte hat montags andere Inhalte als samstags, ein Kursprogramm ändert sich jedes Halbjahr. Eine feste Seite mit aktuellen Links ist dann besser als ein gedruckter Link auf ein saisonales Ziel.',
      ],
    },
    {
      title: 'Wann ein einzelner Link gewinnt',
      body: [
        'Wenn es nur ein Ziel gibt, das die Leute wirklich brauchen. Die meisten Linklisten sind länger als nötig, und jede zusätzliche Zeile senkt die Wahrscheinlichkeit, dass die erste angetippt wird. Ein Code auf einem Flyer, der direkt auf die Anmeldeseite führt, ist besser als derselbe Code, der auf eine Seite mit acht Möglichkeiten führt.',
        'Auch bei Zeitdruck gewinnt der einzelne Link. An einer Kasse, an einer Tür, im Vorbeigehen braucht niemand eine Auswahl. Auswahl ist etwas für Leute, die Zeit haben, und die haben sie an diesen Orten nicht.',
      ],
      bullets: [
        'Höchstens fünf Ziele, besser drei',
        'Das wichtigste Ziel steht oben, groß, mit Abstand',
        'Keine Kategorien, keine Untermenüs, keine Animation',
        'Jeder Link mit einem Satz, was dahinter ist',
      ],
    },
    {
      title: 'Aufbau der Seite und Druck des Codes',
      body: [
        'Die Seite muss auf dem Telefon in einer Sekunde erfassbar sein: ein Titel, der zum Objekt passt, darunter die Links als große Schaltflächen mit je einer Zeile Text. Kein Cookie-Banner, kein Video, kein Newsletter-Fenster. Wer nach zwei Sekunden nicht sieht, wohin er tippen soll, hat schon verloren.',
        'Der Code selbst braucht 4 bis 5 Zentimeter auf einem Aufsteller und 10 Zentimeter auf einem Aushang. Beschriften Sie ihn mit dem, was dahinter liegt: „Alle Links zum Stand" oder „Programm, Anfahrt, Kontakt". Ein Code mit dem Wort „QR-Code" daneben ist ein ungeöffneter Umschlag.',
      ],
    },
  ],
  useCases: [
    { title: 'Fahrzeug', text: 'Werkstatt, Notruf, Zulassung und Hinweis auf die eigene Seite. Ein Code an der Heckscheibe, drei Ziele auf einer Seite.' },
    { title: 'Messestand', text: 'Programm, Anfahrt, Kontakt und der Kalenderlink. Wer vorbeigeht, findet alles an einer Stelle.' },
    { title: 'Speisekarte', text: 'Die Karte, die Allergene und die Öffnungszeiten. Alle drei auf einer Seite, die sich wöchentlich ändern lässt.' },
    { title: 'Vereinsheim', text: 'Trainingszeiten, Beitrittsformular, Spendenlink. Ein Aushang, der über Jahre alles beantwortet.' },
  ],
  steps: [
    'Ehrlich prüfen, ob es mehr als ein Ziel braucht. Meistens reicht eins.',
    'Die Ziele nach Wichtigkeit sortieren, das wichtigste nach oben.',
    'Die Seite auf der eigenen Domain bauen, mobil gedacht, ohne Ablenkung.',
    'Die Adresse im Generator eintragen und als SVG herunterladen.',
    'Nach vier Wochen aufräumen: Was wird nicht angetippt, fliegt raus.',
  ],
  faq: [
    { q: 'Kann ein QR-Code mehrere Links enthalten?', a: 'Nein. Er enthält eine Adresse. Mehrere Ziele entstehen durch eine Seite dazwischen.' },
    { q: 'Brauche ich dafür einen Dienst?', a: 'Nein. Eine Seite auf der eigenen Domain leistet dasselbe, gehört Ihnen und erhebt keine Klickdaten.' },
    { q: 'Was passiert, wenn der Dienst schließt?', a: 'Der gedruckte Code zeigt ins Leere. Bei Codes auf Fahrzeugen, Schildern und Karten ist das ein Grund, die eigene Domain zu nehmen.' },
    { q: 'Wie viele Links sind sinnvoll?', a: 'Drei, höchstens fünf. Jede weitere Zeile senkt die Wahrscheinlichkeit, dass das wichtigste Ziel angetippt wird.' },
    { q: 'Kann ich sehen, welche Links benutzt werden?', a: 'Nur mit Auswertung, also über einen Dienst oder eine eigene Statistik. Ein statischer Code selbst zählt nichts.' },
  ],
  toolLinks: [
    { label: 'Linkliste-Code erstellen', href: '/?type=url' },
    { label: 'QR-Code für einen Link', href: '/qr-code-generator/link' },
  ],
  blogLinks: [
    { label: 'QR-Code und Datenschutz', href: '/blog/qr-code-dsgvo-datenschutz' },
  ],
};

export const TYPEN_PART_EIGHT = [googleFormular, googleDocs, audio, linkliste];
