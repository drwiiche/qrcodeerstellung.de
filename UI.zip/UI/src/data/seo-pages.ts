/**
 * Use-case content for /qr-codes-fuer/… and /qr-codes-auf/….
 *
 * Restructured 2026-10-29. The site previously carried 19 near-identical
 * subpages averaging about 200 words, which is the shape Google's scaled
 * content abuse policy describes. Now:
 *
 *   - six hub pages carry the material, each about one distinct workflow,
 *   - six subpages stay because each answers a genuinely different question,
 *   - the other thirteen URLs are 301-redirected to the hub that absorbed
 *     them (see next.config.mjs).
 *
 * Every page here has to earn its URL: specific situations, real German
 * products (Fritz!Box, DHL, EPC069-12), real constraints. Nothing here is
 * an interchangeable paragraph about "the benefits of QR codes".
 */

export interface SeoSource {
  label: string;
  href: string;
}

export interface SeoSection {
  title: string;
  body: string[];
  bullets?: string[];
}

export interface SeoSubPage {
  slug: string;
  title: string;
  metaTitle: string;
  metaDescription: string;
  intro: string[];
  sections: SeoSection[];
  useCases: { title: string; text: string }[];
  steps: string[];
  faq: { q: string; a: string }[];
  /** Primary sources for claims made on the page. */
  sources?: SeoSource[];
  /**
   * Other language versions of this exact page. Only set where a genuinely
   * written counterpart exists; the rest of this cluster is German only.
   */
  translations?: { lang: string; label: string; href: string }[];
  toolLinks: { label: string; href: string }[];
  blogLinks: { label: string; href: string }[];
}

export interface SeoHub {
  slug: string;
  /** URL prefix when the hub does not live under /qr-codes-fuer or /qr-codes-auf. */
  basePath?: string;
  label: string;
  title: string;
  metaTitle: string;
  metaDescription: string;
  intro: string[];
  sections: SeoSection[];
  faq: { q: string; a: string }[];
  /** Primary sources for the legal or technical claims made on this page. */
  sources?: SeoSource[];
  /**
   * Pages outside this hub that answer an adjacent question. Rendered on the hub
   * only, because a sub page already has its own tool and blog links.
   */
  relatedLinks?: SeoSource[];
  /** Standalone pages that live below this hub and answer their own question. */
  subs: SeoSubPage[];
  /** Former URLs now served by this hub. Kept as a record of the merge. */
  consolidated: string[];
}

const HUBS_BASE: SeoHub[] = [
  {
    slug: 'unternehmen',
    label: 'Für Unternehmen',
    title: 'QR-Codes für Unternehmen',
    metaTitle: 'QR-Codes für Unternehmen: Speisekarte, Rechnung, Werkstatt',
    metaDescription:
      'Wo Betriebe QR-Codes wirklich einsetzen: Speisekarte am Tisch, Bewertungslink auf der Rechnung, Aufstellort am Fahrzeug. Mit Druckgrößen.',
    intro: [
      'Ein Betrieb hat selten ein QR-Code-Problem. Er hat ein Problem mit dem Zettel, den niemand liest, dem Aushang, der veraltet, oder der Rückfrage, die jeden Tag dreimal kommt. Der Code ist nur der kürzeste Weg zwischen dem Gegenstand und der Antwort.',
      'Diese Seite bündelt die Fälle, in denen das in Deutschland funktioniert: Gastronomie, Handwerk, Einzelhandel, Hotellerie, Friseure und Studios. Jeweils mit dem, was gedruckt hält und was in der Praxis scheitert.',
    ],
    sections: [
      {
        title: 'Welche QR-Codes nutzen Gastronomiebetriebe?',
        body: [
          'Die Tischkarte mit Code führt auf eine Seite, die Sie selbst aktualisieren. Gerichte und Preise ändern sich, die gedruckte Karte bleibt gültig. Der zweite Code auf der Rechnung führt zur Bewertungsseite; er wirkt nur, wenn er im Moment der Bezahlung sichtbar ist, nicht auf einem Aushang neben der Toilette.',
          'Wichtig ist die Zielseite hinter dem Code: eine Karte als PDF im Querformat zoomt der Gast am Telefon nicht. Eine normale, mobil bedienbare Seite mit Ankern pro Gang ist die Arbeit, die den Unterschied macht.',
        ],
        bullets: [
          'Tischkarte: Code mindestens 3 cm, matt gedruckt, nie hinter Glas mit Reflexion',
          'Rechnung: 2 cm genügen, Code direkt neben dem Betrag platzieren',
          'Theke oder Fenster: ab 1 m Leseabstand mindestens 10 cm',
        ],
      },
      {
        title: 'Was bringt ein QR-Code auf dem Handwerkerfahrzeug?',
        body: [
          'Handwerksbetriebe verlieren Zeit an dieselbe Rückfrage: Wie erreiche ich euch, was kostet das, wann kommt jemand. Ein Code auf dem Baustellenschild, dem Fahrzeugheck und der Rechnung führt auf ein Formular, das diese Frage in einem Schritt beantwortet. Der Interessent tippt nicht, er scannt.',
          'Auf dem Fahrzeug ist die Platzierung entscheidend: Der Code gehört auf Achshöhe an eine Fläche, die auch bei Regen trocken bleibt. Auf die Heckscheibe geklebt ist er nach zwei Wintern unlesbar.',
        ],
        bullets: [
          'Baustellenschild: ab 15 cm, sonst liest ihn niemand von der Straße',
          'Fahrzeug: mindestens 10 cm, nie auf die Scheibe, nie auf Schmutzfänger',
          'Rechnung: 2 cm, verlinkt auf Terminanfrage oder Ersatzteilformular',
        ],
      },
      {
        title: 'Wo helfen QR-Codes im Laden, im Hotel und im Studio?',
        body: [
          'Im Laden trägt der Code eine Aufgabe, die das Personal sonst erklärt: Größenberatung, Pflegehinweise, Verfügbarkeit einer Größe in einer anderen Filiale. Im Hotel übernimmt er den Check-in-Hinweis, das Gäste-WLAN und die Frühstückszeiten, ohne dass jemand an der Rezeption anstehen muss.',
          'In Studios und Salons ist der Code auf der Spiegelfolie oder am Gerät sinnvoll, weil er genau dort gelesen wird, wo die Frage entsteht. Ein Code am Empfang wird ignoriert.',
        ],
      },
      {
        title: 'Warum wird ein QR-Code unlesbar?',
        body: [
          'Vier Ursachen decken fast alle Fehler ab, die uns gemeldet werden: zu klein gedruckt, zu wenig Kontrast (hellgrau auf weiß, oder Logo über dem Muster), zu wenig Ruhezone am Rand, oder eine Folie, die spiegelt. Statische Codes veralten nicht, aber sie verzeihen nichts.',
          'Wenn Sie unsicher sind: Der Scan-Test im Generator prüft Kontrast und Motiv, bevor Sie in die Druckerei gehen.',
        ],
      },
    ],
    faq: [
      {
        q: 'Darf ich einen QR-Code auf die Rechnung setzen?',
        a: 'Ja. Wenn der Code bezahlte Leistungen oder eigene Angebote verlinkt, ist er unproblematisch. Für Fremdwerbung gelten die Regeln des Werbewiderspruchs nach § 7 UWG, das betrifft aber die Werbung, nicht den Code.',
      },
      {
        q: 'Brauche ich für jeden Tisch einen eigenen Code?',
        a: 'Nein, solange alle auf dieselbe Karte zeigen. Eigene Codes pro Tisch lohnen sich erst, wenn Sie auswerten wollen, wo Gäste sitzen, und dafür brauchen Sie einen Weiterleitungsdienst statt eines statischen Codes.',
      },
      {
        q: 'Kann ich das Muster nachträglich ändern, ohne neu zu drucken?',
        a: 'Nicht bei einem statischen Code. Wenn sich das Ziel ändern soll, brauchen Sie einen Kurzlink-Dienst dazwischen; dann hängt die Gültigkeit aber an dessen Vertragslaufzeit.',
      },
      {
        q: 'Wie prüfe ich, ob der gedruckte Code funktioniert?',
        a: 'Nach dem ersten Druck mit zwei Geräten testen: einem älteren Telefon und einem aktuellen. Wenn es auf beiden bei normalem Licht klappt, hält es auch im Alltag.',
      },
    ],
    subs: [],
    consolidated: [
      'einzelhandel',
      'hotellerie',
      'friseure-wellness',
    ],
  },

  {
    slug: 'schulen',
    label: 'Für Schulen und Bildung',
    title: 'QR-Codes für Schulen und Bildung',
    metaTitle: 'QR-Codes für Schulen: Elternbriefe, Arbeitsblätter, Campus',
    metaDescription:
      'QR-Codes in Schule und Kita ohne Zettelwirtschaft: Anmeldung per Elternbrief, Material am Arbeitsblatt, Orientierung auf dem Campus.',
    intro: [
      'Schulen haben ein Verteilungsproblem: dieselbe Information muss zu 600 Eltern, und zwar so, dass sie ankommt. Der Aushang hängt im Flur, der Brief bleibt im Ranzen, die E-Mail liest die Hälfte. Ein Code auf dem Blatt ersetzt keine Kommunikation, aber er verkürzt den Weg zum Formular auf einen Scan.',
      'Diese Seite beschreibt die drei Stellen, an denen sich das im Schul- und Kita-Alltag bewährt hat, und was rechtlich zu beachten ist, wenn Schüler mit privaten Telefonen scannen.',
    ],
    sections: [
      {
        title: 'Wie funktioniert der Elternbrief per QR-Code?',
        body: [
          'Der häufigste Fall: Der Brief kündigt einen Elternabend an, der Termin soll aber im Kalender landen. Ein Termin-Code (iCal) legt ihn mit einem Scan an, inklusive Erinnerung. Für die Anmeldung zum Schulanfang oder zum Kita-Platz führt ein zweiter Code direkt ins Formular.',
          'Der Code gehört auf die erste Seite, nicht auf die Rückseite und nicht in die Fußzeile. Eine kurze Zeile darunter erklärt, was passiert: "Scannen Sie hier für den Termin im Kalender." Ohne diese Zeile wird nur ein Teil der Eltern scannen.',
        ],
        bullets: [
          'Brief, kopiert in Schwarzweiß: mindestens 2,5 cm, sonst bricht der Laserdruck das Muster auf',
          'Aushang im Flur: ab 10 cm, weil aus 1 bis 2 m Entfernung gescannt wird',
          'Nie hinter Glas oder in eine Folie mit Reflexion',
        ],
      },
      {
        title: 'Welche QR-Codes gehören auf Arbeitsblätter?',
        body: [
          'Ein Code am Arbeitsblatt bringt Hörbeispiel, Video oder Lösungsweg auf das Display, ohne dass jemand eine Adresse abtippt. Bei jüngeren Klassen funktioniert das nur, wenn die Lehrkraft den Code begleitet und ein Gerät pro Gruppe bereitsteht.',
          'Praktisch für Stationenarbeit: Jede Station hat ihren eigenen Code auf einem laminierten Kärtchen. Das Material bleibt nutzbar, wenn das Arbeitsblatt neu gedruckt wird.',
        ],
      },
      {
        title: 'Wie hilft ein QR-Code bei Räumen und Vertretungsplan?',
        body: [
          'Auf dem Gelände ersetzt der Code den Wegweiser, der niemanden interessiert: Aula, Sekretariat, Mensa, Fachräume. Wichtig ist die Aktualität: Ein Raum-Code, der auf einen alten Plan zeigt, ist schlimmer als kein Code.',
          'Für Vertretungspläne gilt dasselbe. Wenn Sie statische Codes drucken, muss der Plan unter einer stabilen Adresse liegen, die Sie selbst aktualisieren.',
        ],
      },
      {
        title: 'Was ist bei Datenschutz und Schulgeräten zu beachten?',
        body: [
          'Der Code selbst speichert nichts und überträgt nichts, bis jemand scannt. Die Datenschutzfrage entsteht an der Zielseite: Wenn dort ein Formular für Elternkontaktdaten liegt, braucht dieses Formular eine Rechtsgrundlage und muss auf einem Server in Ihrem Verantwortungsbereich laufen.',
          'Für Schülergeräte gilt die Hausordnung. Der Code setzt keine App voraus, jede Kamera liest ihn.',
        ],
      },
    ],
    faq: [
      {
        q: 'Funktionieren die Codes auf Kopierern zuverlässig?',
        a: 'Ja, wenn der Code mindestens 2,5 cm groß ist und echtes Schwarz auf Weiß verwendet wird. Farbige Codes oder helle Grautöne überstehen den Schulkopierer oft nicht.',
      },
      {
        q: 'Was passiert, wenn die Zielseite umzieht?',
        a: 'Dann verliert der gedruckte Code sein Ziel. Halten Sie die Adresse stabil oder nutzen Sie für diesen Fall einen Weiterleitungsdienst.',
      },
      {
        q: 'Dürfen Lehrkräfte private Geräte einsetzen lassen?',
        a: 'Das regelt die Schule über ihre Hausordnung. Der Code ist dabei kein zusätzliches Risiko, weil er nichts überträgt, solange niemand ihn scannt.',
      },
    ],
    subs: [],
    consolidated: ['lehrmittel', 'elternkommunikation', 'campus'],
  },

  {
    slug: 'veranstaltungen',
    label: 'Für Veranstaltungen',
    title: 'QR-Codes für Veranstaltungen',
    metaTitle: 'QR-Codes für Veranstaltungen: Programm, Einlass, Einladung',
    metaDescription:
      'Von der Einladung mit Rückmeldung bis zum Einlass per Code: wo QR-Codes bei Veranstaltungen Zeit sparen, und warum das Programm ein Plakat braucht, keinen Zettel.',
    intro: [
      'Bei Veranstaltungen entscheidet der Moment vor dem Eingang, ob der Abend gut beginnt. Wer 300 Menschen eine Liste abgleichen lässt, steht dort 40 Minuten. Ein Code auf der Karte oder dem Etikett verkürzt das auf einen Scan.',
      'Diese Seite beschreibt Programm, Einladung mit Rückmeldung, Einlass und die Fälle, in denen ein Code am falschen Ort alles schlimmer macht.',
    ],
    sections: [
      {
        title: 'Wie ersetzt der QR-Code das Programmheft?',
        body: [
          'Ein Programm ändert sich noch am Nachmittag der Veranstaltung. Darum gehört es nicht in den Druck, sondern hinter den Code. Auf dem Plakat steht der Zeitplan in Grundzügen, der Code führt auf die aktuelle Fassung.',
          'Bewährt hat sich ein Hinweis in der Form "Änderungen: siehe Programm", statt das ganze Heft neu zu drucken.',
        ],
        bullets: [
          'Plakat: ab 10 cm, mit Schriftzug direkt unter dem Code',
          'Programmheft innen: ab 3 cm, mattes Papier',
          'Tischaufsteller: 5 cm, damit er auch in gedämpftem Licht liest',
        ],
      },
      {
        title: 'Wie kommen Zusagen über den QR-Code zurück?',
        body: [
          'Die Einladung mit einem Code für die Zusage spart den Rückruf: Der Gast trägt seinen Namen selbst ein, Begleitpersonen inklusive. Für Hochzeiten und Familienfeiern ist das der Fall, der am häufigsten nachgefragt wird, deshalb steht er auf einer eigenen Seite.',
          'Wichtig ist die Formulierung am Code: Ein reines "Hier scannen" führt zu weniger Zusagen als "Zusage bis 12. Mai".',
        ],
      },
      {
        title: 'Wie beschleunigt ein QR-Code den Einlass?',
        body: [
          'Ein Code auf dem Ticket ersetzt die gedruckte Liste nur, wenn vor Ort jemand mit einem Lesegerät steht. Für Vereinsfeste mit 200 Gästen reicht ein Telefon und ein Formular, das die Anmeldung als Liste anzeigt.',
          'Achtung bei personalisierten Tickets: Wenn jeder Gast einen eigenen Code bekommt, ist das bereits eine Datenbank. Prüfen Sie vorher, wer diese Daten für welchen Zeitraum aufbewahrt.',
        ],
      },
      {
        title: 'Welcher Fehler passiert am Eingang am häufigsten?',
        body: [
          'Codes werden dort aufgeklebt, wo sie gut aussehen, nicht dort, wo gelesen wird. Einlass: Der Code gehört auf Augenhöhe und wird angestrahlt oder beleuchtet. Am Boden oder unterhalb der Hüfte scannen Gäste im Dunkeln nicht.',
        ],
      },
    ],
    faq: [
      {
        q: 'Reicht ein Code als Ticket?',
        a: 'Nur wenn Sie ihn prüfen können. Ein statischer Code speichert keine Person und keinen Zeitpunkt, er ist damit fälschbar. Für echten Einlass mit Nummernkreis brauchen Sie ein System, das Tickets erzeugt und entwertet.',
      },
      {
        q: 'Wie fange ich Zusagen für eine Feier ein?',
        a: 'Mit einem Code, der auf ein einfaches Formular führt. Eine Zeile mit Frist daneben erhöht die Rückmeldungen deutlich gegenüber einem nur dekorativen Code.',
      },
      {
        q: 'Was taugt ein Code im Festzelt?',
        a: 'Wenig, wenn das Netz dort schlecht ist. Der Code öffnet eine Adresse und braucht dafür Datenverbindung. Drucken Sie den Zeitplan zusätzlich, nicht nur den Code.',
      },
    ],
    subs: [],
    consolidated: ['einladungen-rsvp', 'programm', 'tickets-check-in'],
  },

  {
    slug: 'immobilien',
    label: 'Für Immobilien',
    title: 'QR-Codes für Immobilien',
    metaTitle: 'QR-Codes für Immobilien: Exposé am Objekt, Besichtigung',
    metaDescription:
      'QR-Codes in der Immobilienbranche: Exposé am Objekt, Terminvergabe für Besichtigungen, Hinweise für Mieter im Treppenhaus. Mit dem, was im Freien hält.',
    intro: [
      'Ein Objekt steht, das Exposé liegt im Büro. Der Interessent fährt vorbei, ruft nicht an, und Sie erfahren nicht, dass er da war. Ein Code am Objekt schließt genau diese Lücke, aber nur wenn er Wind, Regen und Sonne übersteht.',
      'Diese Seite beschreibt die drei Stellen, an denen Codes in der Immobilienwirtschaft Arbeit abnehmen, und das Material, das im Außenbereich tatsächlich hält.',
    ],
    sections: [
      {
        title: 'Warum ein Exposé am Objekt statt im Schaufenster?',
        body: [
          'Ein Code auf dem Schild neben der Fassade führt auf das Exposé mit Grundriss, Preis und Ansprechpartner. Der Interessent sieht Details in dem Moment, in dem er davorsteht, und kann sich selbst orientieren: Richtung, Lärmquelle, Abstand zur Straße.',
          'Bewährt ist eine eigene, kurze Adresse pro Objekt, die nach dem Verkauf erreichbar bleibt. Wenn Sie den Code bei jedem Objekt neu erzeugen, kostet das eine Minute, ersetzt aber jede Verwechslung.',
        ],
        bullets: [
          'Außenschild: ab 15 cm, wetterfeste Folie, nicht unter der Balkonkante',
          'Am Fenster: nicht auf Glas kleben, sondern auf eine von innen sichtbare Platte',
          'Auf dem Boden/Abstand: mindestens 1,2 m Höhe, sonst scannt niemand',
        ],
      },
      {
        title: 'Wie lassen sich Besichtigungen per QR-Code takten?',
        body: [
          'Der Code auf dem Ausdruck oder der Anzeige führt auf einen Terminkalender statt auf eine Telefonnummer. Wer mehrere Objekte betreut, gibt Interessenten damit ein Formular, das Objekt und Person bereits verknüpft.',
          'Was nicht funktioniert: ein Code, der auf die Startseite der Website führt und dort die Suche erwartet.',
        ],
      },
      {
        title: 'Wie erreicht die Verwaltung Mieter ohne Zettel?',
        body: [
          'Im Treppenhaus und in der Wohnung übernimmt der Code Aufgaben, die sonst Aushänge mit abgerissenen Zetteln lösen: Müllabfuhrtermine, Heizungswartung, Schadensmeldung, Hausordnung. Ein Code pro Treppenhaus, hinterlegt auf eine Seite, die Sie selbst ändern.',
          'Für Handwerker im Haus ist der Code des Zählers oder Geräts nützlich: Modell, Baujahr, letzte Wartung, Ansprechpartner. Das ersetzt die Suche nach der Mappe im Keller.',
        ],
      },
    ],
    faq: [
      {
        q: 'Hält ein bedruckter Code auf einem Außenschild dem Wetter stand?',
        a: 'Nur unter Folie oder auf Aluverbund. Ausgedrucktes Papier ist nach einem Winter unlesbar. Für Außenanwendungen drucken lassen, nicht laminiert mit dem Bürolaminator.',
      },
      {
        q: 'Darf ich im Treppenhaus Codes anbringen?',
        a: 'Als Mieter brauchen Sie das Einverständnis des Eigentümers. Als Verwaltung ist es Teil der Mieterkommunikation und mit der Ankündigung im Haus zu machen.',
      },
      {
        q: 'Führt der Code auf das Exposé oder auf die Anzeige?',
        a: 'Auf das Exposé in Ihrer eigenen Struktur. Anzeigenportale ändern ihre Adressen und Umleitungen, gedruckte Codes bleiben fix.',
      },
    ],
    subs: [],
    consolidated: ['besichtigungen', 'verwaltung'],
  },

  {
    slug: 'gesundheit',
    label: 'Gesundheit und Fitness',
    title: 'QR-Codes für Gesundheit und Fitness',
    metaTitle: 'QR-Codes für Praxen, Therapie und Fitnessstudios',
    metaDescription:
      'QR-Codes in Praxen, Physiotherapie und Studios: Terminbestätigung, Übungsanleitungen am Gerät, Check-in. Mit den Datenschutzfragen, die vorher zu klären sind.',
    intro: [
      'In Praxen und Studios entstehen die meisten Rückfragen zu denselben drei Themen: Wann ist der Termin, was soll ich üben, wie melde ich mich an. Ein Code an der richtigen Stelle beantwortet sie leiser als jeder Aushang.',
      'Gesundheitsdaten sind besondere Kategorien nach DSGVO. Das bestimmt, was hinter einem Code liegen darf und was nicht.',
    ],
    sections: [
      {
        title: 'Wie funktionieren Termin und Anfahrt per QR-Code?',
        body: [
          'Der Termin-Code auf der Karte ergänzt die Praxis ohne Rückruf: Adresse, Anfahrt, wer im Notfall zu erreichen ist. Er enthält keine Diagnose und ist damit unkritisch.',
          'Für Patienten, die den Weg zum ersten Mal fahren: Die Adresse allein reicht nicht, Parkplatz und Eingang sind die Fragen, die im Telefon landen.',
        ],
        bullets: [
          'Terminkarte: ab 2,5 cm, keine Farbflächen dahinter',
          'Aushang am Empfang: 6 bis 8 cm',
          'An der Praxis: kein Code außen, wenn er unter Dachrinnen hängt',
        ],
      },
      {
        title: 'Warum Anleitungen am Gerät statt auf Papier?',
        body: [
          'In der Physiotherapie und im Studio wirkt der Code direkt am Gerät, wenn er auf eine Anleitung führt, die den Übungsteil, Wiederholungszahl und Hinweise zur Ausführung zeigt. Diese Seiten sind kein Geheimwissen und dürfen öffentlich sein.',
          'Was hier inhaltlich trägt: kurze Videos, aber auch die Textvariante mit Bildern. Wer sein Telefon nicht zum Gerät nimmt, braucht die Karte am Gerät gedruckt.',
        ],
      },
      {
        title: 'Wie läuft der Check-in in der Praxis?',
        body: [
          'Der Check-in im Studio bleibt eine Personal- und Systemfrage, ein statischer Code hilft nur, wenn ihn eine Anwendung prüft. Eine geprüfte Kette ist mehr Arbeit, als die meisten Studios erwarten, meist bleibt es beim Code auf der Mitgliedskarte für den Eingang.',
          'Für die Technik ist der Code am Kessel oder Gerät praktisch: Baujahr, letzte Wartung, Wartungsfirma. Das gehört an den Prüfaufkleber, nicht in ein Formular mit Patientendaten.',
        ],
      },
      {
        title: 'Was ist datenschutzrechtlich heikel?',
        body: [
          'Kein Code darf ungeschützt auf Befunde, Diagnosen oder Therapiepläne führen. Ein Link zu einem PDF mit Patientennamen per statischem Code ist eine Offenlegung, sobald jemand den Code fotografiert.',
          'In der Praxis heißt das: Was gescannt wird, ist öffentlich oder inhaltsfrei. Individuelle Daten gehören hinter eine Anmeldung, nicht hinter ein Muster.',
        ],
      },
    ],
    faq: [
      {
        q: 'Dürfen Übungsanleitungen öffentlich verlinkt werden?',
        a: 'Ja, solange sie keine personenbezogenen Daten enthalten. Standardübungen sind Anleitungen, kein Gesundheitsdatensatz.',
      },
      {
        q: 'Ist ein QR-Code für die Terminanfrage DSGVO-konform?',
        a: 'Der Code selbst ja. Das Formular dahinter ist der Verantwortungsbereich Ihrer Praxis und braucht Datenschutzhinweis, Zweckbindung und Löschfrist.',
      },
      {
        q: 'Kann der Code bei der Hygiene helfen?',
        a: 'Indirekt: Ein Code auf dem Händedesinfektionsspender sollte nicht mit Handschuhen angefasst werden. Tests mit Desinfektionsmitteln haben gedruckte Codesangegriffen, deshalb gibt es Formulierungshinweise.',
      },
    ],
    subs: [],
    consolidated: ['arztpraxen', 'therapeuten', 'sport-fitness'],
  },
];

/**
 * Standalone pages. Each answers a question that deserves its own URL and does
 * not repeat the hub text above it.
 */
const DEPTH_PAGES: Record<string, SeoSubPage[]> = {
  unternehmen: [
    {
      slug: 'gastronomie',
      title: 'QR-Codes für die Gastronomie: Speisekarten, Bewertungen und Bestellungen',
      metaTitle: 'Digitale Speisekarte mit QR-Code: Anleitung für Restaurants',
      metaDescription:
        'Wie Gastronomen Karte, Bewertungslink und Vorbestellung per QR-Code lösen: Platzierung, Papierversion, Update-Falle und Druckgrößen.',
      intro: [
        'Die digitale Speisekarte hat sich in deutschen Restaurants durchgesetzt, aber selten gut: Meist hängt ein Code an der Theke, der auf ein PDF im Querformat führt. Der Gast zoomt, gibt auf und fragt den Service.',
        'Diese Seite beschreibt, wie die Karte funktioniert, worauf die Platzierung ankommt und was nach dem Gerichtswechsel passiert.',
      ],
      sections: [
        {
          title: 'Warum gehört die Karte auf eine Seite und nicht als PDF?',
          body: [
            'Das PDF ist der Grund, warum Gäste die Karte verfluchen. Nutzen Sie eine normal aufgebaute Seite mit einer Überschrift pro Gang. Sie können sie selbst pflegen, sie zoomt auf dem Telefon nicht, und Lesbarkeit heißt hier nicht, 12 pt Serif in Beton zu verwandeln.',
            'Die Papierkarte bleibt im Betrieb, sie ist die Rückfallebene, wenn das Netz im Kellerloch verschwindet. Der Code ersetzt sie nicht, er bedient den Gast, der die Karte lieber hell liest.',
          ],
        },
        {
          title: 'Wo liegt der Code am Tisch, an der Theke und am Fenster?',
          body: [
            'Der Aufsteller auf dem Tisch ist der einzige Ort, an dem der Gast sicher eine Hand frei hat. Er gehört auf die dem Gast zugewandte Seite, nicht auf die Seite mit dem Logo, die zum Gang zeigt.',
            'Am Fenster ist die Reflexion der Feind: von innen durch Glas gelesen, in der Sonne, funktioniert fast kein Code. Wer im Außenbereich eine Karte anbieten will, klebt eine wetterfeste Folie mit Code und nicht eine bedruckte Papierkarte.',
          ],
        },
        {
          title: 'Wann ist der richtige Moment für den Bewertungslink?',
          body: [
            'Der zweite Code auf der Rechnung wirkt nur im Moment der Bezahlung. Gäste bewerten, wenn sie die Rechnung sehen, nicht drei Meter weiter am Ausgang. Und nur, wenn auf der Rechnung außerdem klar ist, warum sie scannen sollen: "Ihre Meinung entscheidet, was auf der nächsten Karte steht."',
            'Viel mehr als das Bewertungsziel ändern, können Sie ohne Weiterleitungsdienst nicht. Ein statischer Code zeigt auf eine feste Adresse, deshalb muss die Bewertungsseite stabil erreichbar bleiben.',
          ],
        },
        {
          title: 'Was gilt für Vorbestellung und Allergene?',
          body: [
            'Für Vorbestellung im Außenbereich oder bei Stoßzeiten führt ein Code zu einem Formular mit Warenkorb; das ist ein eigener Aufbau, kein QR-Code-Thema. Häufiger gefragt wird die Allergenliste: Ein Code auf die Liste am Tisch entlastet den Service und ist rechtlich zulässig, solange die Angaben aktuell sind (§ 14 Abs. 1 Nr. 13 LMIV).',
          ],
        },
      ],
      useCases: [
        {
          title: 'Digitale Speisekarte am Tisch',
          text: 'Ein Aufsteller pro Tisch führt auf die aktuelle Karte. Preise und Gerichte ändern Sie zentral, die Aufsteller bleiben.',
        },
        {
          title: 'Bewertungen sammeln',
          text: 'Auf der Rechnung, neben dem Betrag, mit einer Zeile Begründung. Nicht auf dem Ausgangsschild.',
        },
        {
          title: 'Allergene und Zusatzstoffe',
          text: 'Code neben der Karte führt auf die Allergenliste. Änderungen bleiben in Ihrer Hand.',
        },
        {
          title: 'WLAN für Gäste',
          text: 'Ein Code spart das Passworttippen: Gäste scannen, das Telefon verbindet sich.',
        },
      ],
      steps: [
        'Kartenseite erstellen und auf dem Telefon testen: Lesbarkeit ohne Zoom.',
        'Code mit der Zieladresse erzeugen, mindestens 3 cm für den Tischaufsteller.',
        'Aufsteller drucken lassen, matt, mit einem Satz Erklärung unter dem Code.',
        'Nach dem Umbau der Karte: prüfen, ob die Adresse gleich geblieben ist.',
      ],
      faq: [
        {
          q: 'Brauche ich einen eigenen Code pro Tisch?',
          a: 'Nur wenn Sie auswerten wollen, wo Gäste sitzen. Für die Karte reicht derselbe Code überall.',
        },
        {
          q: 'Was passiert bei Geruchswechsel, wenn der Code gedruckt ist?',
          a: 'Nichts, solange die Adresse gleich bleibt. Darum ist die Karte eine Seite und kein PDF, das Sie umbenennen müssten.',
        },
        {
          q: 'Wie groß muss der Aufsteller sein?',
          a: 'Mindestens 3 cm Kantenlänge für 30 cm Leseabstand. Bei 1 m, etwa am Fenster, ab 10 cm.',
        },
      ],
      toolLinks: [
        { label: 'Webseite-Code für die Karte erstellen', href: '/?type=url' },
        { label: 'WLAN-Code erzeugen', href: '/?type=wifi' },
      ],
      blogLinks: [
        { label: 'Speisekarten und QR: was Gastronomen wissen müssen', href: '/blog/qr-codes-speisekarten-gastronomie' },
        { label: 'Bewertungscode richtig platzieren', href: '/blog/google-bewertungen-qr-code' },
      ],
    },
    {
      slug: 'handwerk',
      title: 'QR-Codes für Handwerksbetriebe',
      metaTitle: 'QR-Codes für Handwerker: Fahrzeug, Baustelle, Angebot',
      metaDescription:
        'QR-Codes im Handwerk sinnvoll einsetzen: Angebotsformular am Fahrzeug, Terminanfrage am Baustellenschild, Ersatzteile am Gerät. Inklusive Materialwahl für draußen.',
      intro: [
        'Im Handwerk bringt ein Code am wenigsten, wenn er im Flyer steht. Er wirkt dort, wo der Betrieb ohnehin ist: auf dem Fahrzeug, am Gerüst, auf der Rechnung.',
        'Was draußen hält und was nach zwei Wintern abfällt, ist der eigentliche Teil dieser Seite.',
      ],
      sections: [
        {
          title: 'Warum gehört der Code ans Heck und nicht auf die Scheibe?',
          body: [
            'Ein Code auf der Hecktür wird an jeder Ampel gescannt, wenn er lesbar bleibt. Auf Achshöhe, mindestens 10 cm groß, auf unlackierter Fläche oder auf einer Folie, die nicht hinter der Radkappe hängt. Nie auf die Heckscheibe: Erstens spiegelt sie bei Regen, zweitens überlebt Kleber dort selten.',
            'Was nichts bringt: Kleingedruckte Adressen zu entfernen und dafür zwei Linien Fließtext lesbar zu machen. Wer den Code scannt, will keine Selbstbeschreibung, sondern das Formular.',
          ],
        },
        {
          title: 'Was leistet der Code auf Bauschild und in der Werkstatt?',
          body: [
            'Am Bauschild wirkt der Code nur, wenn das Schild plausibel zur Baustelle gehört und der Interessent anhält. Also eher bei Sanierungen im Bestand als an der Autobahnbehelfsbrücke, an der niemand hält.',
            'In der Werkstatt ist der Code am Ersatzteil oder Kessel wertvoller: Modell, Ansprechpartner, letzte Wartung. Das ersetzt die Suche nach der Mappe im Keller.',
          ],
        },
        {
          title: 'Welches Material hält im Freien?',
          body: [
            'Ausgedrucktes Papier hält draußen keinen Winter, auch nicht laminiert. Chemische UV-Stabilisierung und Kleber sind hier der Unterschied, den wir von einer Druckerei hören.',
            'Für Fahrzeuge und Schilder: Druck auf Folie oder Aluverbund, mit Klarlack über dem Muster. Für innen reicht Papier, wenn es nicht im Sonnenlicht hängt.',
          ],
          bullets: [
            'Fahrzeug und Schild: Folie oder Aluverbund, Klarlack gegen UV',
            'Innen: Papier, mindestens 3 cm',
            'Nie: Ausdruck im Bürolaminator im Außeneinsatz',
          ],
        },
      ],
      useCases: [
        {
          title: 'Angebotsanfrage am Fahrzeug',
          text: 'Der Code am Heck führt auf ein kurzes Formular mit Foto-Upload für die Anfrage.',
        },
        {
          title: 'Terminanfrage am Bauschild',
          text: 'Wer anhält, hat eine konkrete Frage. Der Code führt auf den Rückruf-Termin, nicht auf eine Liste.',
        },
        {
          title: 'Gerätedaten in der Werkstatt',
          text: 'Modell, Baujahr und Wartungsdaten direkt am Gerät, ohne Mappe.',
        },
        {
          title: 'Rechnung',
          text: 'Code neben dem Betrag für Ersatzteilbestellung oder Terminanfrage.',
        },
      ],
      steps: [
        'Ziel festlegen: Angebotsformular, Terminanfrage oder Gerätedaten.',
        'Code mit der stabilen Zieladresse erzeugen.',
        'Für den Außeneinsatz in der Druckerei auf Folie drucken lassen.',
        'Nach dem ersten Fahrzeug mit dem ältesten Telefon im Betrieb testen.',
      ],
      faq: [
        {
          q: 'Wie bekomme ich den Code auf das Fahrzeug, ohne den Lack zu beschädigen?',
          a: 'Mit einer Kfz-Klebefolie auf unlackiertem Kunststoff oder einer Seite, die die Werkstatt ohnehin beklebt. Nicht auf Klarlack und nicht auf die Scheibe.',
        },
        {
          q: 'Lohnt sich ein Code am Bauschild?',
          a: 'Ja bei Umbauten, die Monate dauern und Passanten sehen. Bei kurzlebigen Baustellen ist der Aufwand größer als der Nutzen.',
        },
        {
          q: 'Kann ich den Code auf dem Handy meines Kollegen nachdrucken?',
          a: 'Ja, mit der SVG-Datei bleibt das Muster verlustfrei, auch bei großen Formaten. Deshalb SVG und nicht PNG für alles, was gedruckt wird.',
        },
      ],
      toolLinks: [
        { label: 'Website-Formular verlinken', href: '/?type=url' },
        { label: 'Telefon-Code für Notdienst', href: '/?type=phone' },
      ],
      blogLinks: [
        { label: 'QR-Codes für Handwerk und lokale Betriebe', href: '/blog/qr-codes-handwerk-lokal' },
        { label: 'Drucken: Kontrast und Größe', href: '/blog/qr-code-drucken-kontrast-groesse' },
      ],
    },
  ],

  schulen: [
    {
      slug: 'kitas',
      title: 'QR-Codes in Kitas: Elternkommunikation ohne Zettel',
      metaTitle: 'QR-Codes in der Kita: Elternbriefe und Anmeldungen',
      metaDescription:
        'Kita-Alltag mit QR-Codes organisieren: Anmeldung, Krankmeldung, Termine und Infos am Gruppenraum. Mit Größen für Aushang und Elternbrief.',
      intro: [
        'In der Kita kommen Informationen bei 60 Familien an, und die Hälfte davon liest den Zettel am Montag. Ein Code auf dem Brief hilft, weil er nicht die Information ersetzt, sondern die Rückmeldung.',
        'Diese Seite ist bewusst der einzige Kita-Text auf dieser Website; er beschreibt, was funktioniert und wo die Betreuungs-Software anfängt.',
      ],
      sections: [
        {
          title: 'Wie läuft die Anmeldung per QR-Code?',
          body: [
            'Die Anmeldung zum Kita-Platz läuft in den meisten Kommunen über ein zentrales Portal oder einen Träger-Verfahren. Ein Code auf dem Infoblatt dorthin ist der einfachste Fall: Sie müssen keine Daten davorschalten, der Code zeigt auf eine Adresse, die die Kommune pflegt.',
            'Was Sie vermeiden: ein eigenes Formular mit Kindesnamen parallel zum offiziellen Weg. Das wäre doppelte Datenhaltung ohne Rechtsgrundlage.',
          ],
        },
        {
          title: 'Wie funktioniert die Krankmeldung?',
          body: [
            'Die Krankmeldung ist der häufigste Anruf. Ein Code auf dem Elternbrief oder im Eingangsbereich führt auf eine Seite mit dem Ablauf: Wen rufen, bis wann, was tun. Ohne Formular, nur als Ablaufbeschreibung, ist das datenschutzrechtlich unkritisch und trotzdem nützlich.',
            'Für Termine, Ausflüge und Feste arbeitet der Termin-Code: Scannen legt den Termin mit Uhrzeit im Kalender ab und erinnert zuverlässiger als jede Parent-App.',
          ],
        },
        {
          title: 'Warum halten Aushänge mit Code länger?',
          body: [
            'Der Zettel am Gruppenraum erledigt sich selbst: Der Code auf einer laminierten Karte hält und zeigt auf den aktuellen Stand.',
          ],
          bullets: [
            'Gruppenraum: 3 cm, laminiert, auf Augenhöhe der Erwachsenen',
            'Eingangsbereich: 10 cm, nicht unterhalb der Kniehöhe',
            'Elternbrief: 2,5 cm in Schwarzweiß, in den Fließtext eingebunden',
          ],
        },
      ],
      useCases: [
        {
          title: 'Termine im Kalender',
          text: 'Elternabend, Laternenfest, Sommerfest: ein Scan legt den Termin mit Erinnerung an.',
        },
        {
          title: 'Ablauf der Krankmeldung',
          text: 'Wer rufen, bis wann, was passiert mit dem Essensgeld. Eine Seite, die die Fragen vorwegnimmt.',
        },
        {
          title: 'Infoblatt zur Anmeldung',
          text: 'Code führt zum offiziellen Portal der Kommune oder des Trägers.',
        },
      ],
      steps: [
        'Ablauftext für die häufigsten Fragen auf eine eigene Seite legen.',
        'Code mit dieser Adresse erzeugen, 3 cm für den Aushang.',
        'Laminiert an der Gruppentür anbringen, mit einem Satz Erklärung.',
        'Nach drei Monaten nachsehen, ob die Adresse noch gleich ist.',
      ],
      faq: [
        {
          q: 'Darf eine Kita Anmeldungen über ein eigenes Formular sammeln?',
          a: 'Für den offiziellen Platz nicht, das läuft über Kommune oder Träger. Für freiwillige Helferlisten oder Festplanung brauchen Sie eine Rechtsgrundlage und eine kurze Datenschutzhinweis-Seite.',
        },
        {
          q: 'Ist das Laminat an der Gruppentür nicht zu klein?',
          a: 'Bei 3 cm und 30 cm Leseabstand reicht es. Beim Ausdruck darunter wird es unzuverlässig.',
        },
        {
          q: 'Wie halte ich den Ablauf aktuell?',
          a: 'Indem die Adresse gleich bleibt und sich nur der Inhalt der Seite ändert. Das ist der Grund, keinen Code pro Infozettel zu drucken.',
        },
      ],
      toolLinks: [
        { label: 'Termin-Code erstellen', href: '/?type=event' },
        { label: 'Website-Code erstellen', href: '/?type=url' },
      ],
      blogLinks: [
        { label: 'QR-Codes in der Bildung: Praxisbeispiele', href: '/blog/qr-codes-schulen-bildung' },
      ],
    },
  ],

  veranstaltungen: [
    {
      slug: 'hochzeiten',
      title: 'QR-Code für Hochzeitseinladungen und Zusagen',
      metaTitle: 'Hochzeitseinladung mit QR-Code: Zusagen und Ablauf',
      metaDescription:
        'Einladung, Zusagen, Programm, Anfahrtsweg: wie Hochzeitspaare mit einem QR-Code auf der Karte Rückmeldungen und Tagesablauf organisieren, ohne Papier nachzudrucken.',
      intro: [
        'Der häufigste Fall ist der: 80 Karten gehen raus, 42 Zusagen kommen zurück, zwei Wochen später ändert sich der Ablauf, und das gedruckte Programm stimmt nicht mehr. Der Code löst nicht die Zusagen, aber er nimmt den Nachdruck aus der Gleichung.',
        'Was funktioniert, hängt an zwei Entscheidungen: Wo steht der Code, und wohin führt er.',
      ],
      sections: [
        {
          title: 'Wo steht der Code auf der Einladung?',
          body: [
            'Die Rückseite der Karte ist der richtige Ort, nicht die Vorderseite über dem Namen. Vorn liest man die Information, hinten sucht man die praktischen Details: Zusagen, Anfahrt, Hotel, Geschenkwunsch.',
            'Ein Code pro Karte kann für Nummernkreise nützlich sein, ist aber schon eine Datenbank mit Personenbezug. Für die meisten Hochzeiten reicht derselbe Code auf allen Karten.',
          ],
          bullets: [
            'Karte: ab 2,5 cm, mit zwei Zeilen Erklärung darunter',
            'Tischkarte: 3 cm, falls der Ablauf dort nachgelesen wird',
            'Beim Dinner: Aushang ab 8 cm, mit Licht dabei haben',
          ],
        },
        {
          title: 'Wie kommen Zusagen über ein Formular zurück?',
          body: [
            'Das Formular fragt nach Namen, Begleitpersonen, Allergien und manchmal Übernachtung. Eine Frist direkt daneben erhöht die Rückmeldungen: "Zusage bis 12. Mai" hat messbar mehr Antworten als ein Code ohne Satz.',
            'Die Antworten landen dort, wo sie bearbeitet werden: eine Tabelle, die ihr Pflege. Wer keine Tabelle pflegen will, gibt eine Adresse an und bittet um eine E-Mail, dann ist der Code nur ein Kürzel bis zum Postfach.',
          ],
        },
        {
          title: 'Wie kommuniziert man Ablauf, Anfahrt und Übernachtung?',
          body: [
            'Der Ablauf ändert sich bis zuletzt. Eine Seite mit Zeitplan, Anfahrt, Parken, Übernachtung und Kontaktperson hält das zusammen, und dieselbe Adresse darf davor und danach funktionieren.',
            'Für die Anfahrt ist der Standort-Code die kürzeste Form: Koordinaten einmal setzen, Gäste scannen in der Einfahrt.',
          ],
        },
      ],
      useCases: [
        {
          title: 'Zusagen mit Frist',
          text: 'Ein Formular, das Namen und Begleitpersonen aufnimmt, verlinkt auf der Rückseite der Karte.',
        },
        {
          title: 'Ablauf und Zeitplan',
          text: 'Eine Seite, die Sie am Vortag noch ändern können, statt neu zu drucken.',
        },
        {
          title: 'Anfahrt und Parken',
          text: 'Koordinaten oder Adresse, ohne dass jemand die Hausnummer im Navi suchen muss.',
        },
        {
          title: 'Geschenkwunsch',
          text: 'Statt fünf schiefer Absätze auf der Karte: eine Seite, die auch nach der Feier noch erreichbar ist.',
        },
      ],
      steps: [
        'Entscheiden, wo die Zusagen landen: Tabelle, Postfach oder Formular.',
        'Eine Seitenadresse anlegen, die nach der Hochzeit nicht verschwindet.',
        'Code erzeugen, mindestens 2,5 cm für die Karte.',
        'Zwei Probeexemplare drucken und mit zwei Telefonen testen.',
      ],
      faq: [
        {
          q: 'Wie viele Zusagen bekomme ich realistisch?',
          a: 'Mit Frist und Formular kommen die Rückmeldungen zuverlässiger als per Telefon oder WhatsApp-Gruppe. Die Zahl hängt an Ihrer Einladung, nicht am Code.',
        },
        {
          q: 'Muss ich für die Zusagen eine App benutzen?',
          a: 'Nein. Ein normales Formular reicht; die Zusagen müssen nirgends zusätzlich installiert werden.',
        },
        {
          q: 'Was ist mit Gästen, die nicht scannen wollen?',
          a: 'Rechnen Sie damit. Eine Alternative muss auf der Karte stehen: E-Mail-Adresse oder Telefonnummer, gedruckt, nicht hinter dem Code.',
        },
      ],
      toolLinks: [
        { label: 'Standort-Code für die Anfahrt', href: '/?type=standort' },
        { label: 'Termin-Code für den Ablauf', href: '/?type=event' },
        { label: 'Website-Code für Zusagen', href: '/?type=url' },
      ],
      blogLinks: [
        { label: 'QR-Codes für Veranstaltungen und Events', href: '/blog/qr-codes-veranstaltungen-events' },
      ],
    },
  ],

  immobilien: [
    {
      slug: 'objekte',
      title: 'QR-Codes am Objekt: Exposé und Außenwerbung',
      metaTitle: 'QR-Code am Objekt: Exposé für Vorbeifahrer anbinden',
      metaDescription:
        'Exposé per QR-Code direkt am Objekt: welke Materialien im Außenbereich halten, welche Größe ab Straße nötig ist und warum die Adresse pro Objekt stabil bleiben muss.',
      intro: [
        'Der Interessent fährt vorbei, sieht kein Preisschild und fährt weiter. Ein Code am Objekt ist die einzige Werbeform, die im richtigen Moment antwortet.',
        'Die Frage ist nicht der Code, sondern das Material und die Größe. Daran scheitern die meisten Außenschilder.',
      ],
      sections: [
        {
          title: 'Welches Material hält am Objekt draußen?',
          body: [
            'Papier im Klemmbrett hält keine Saison. Verwenden Sie eine bedruckte Folie oder Aluverbund mit Klarlack, auch in der Größe DIN A5 schon bezahlbar. Alles, was unter der Dachkante hängt, leidet zusätzlich unter Feuchtigkeit.',
            'Wenn das Objekt leer steht und das Schild wochenlang hängt, ist UV-Stabilität der entscheidende Punkt. Ohne Klarlack bleicht Schwarz zu Grau, und grauer Code heißt kein Scan.',
          ],
        },
        {
          title: 'Wie groß und in welcher Höhe hängt der Code?',
          body: [
            'Die Faustregel aus der Druckpraxis: Abstand in Metern geteilt durch 10 ergibt die Kantenlänge. Bei 5 m Abstand zum Gehweg sind das 50 cm, für eine 15 cm große Fläche auf 1,5 m.',
          ],
          bullets: [
            'Am Gehweg, 1 bis 2 m: 15 bis 20 cm',
            'Aus dem Auto, 5 m und mehr: 50 cm oder am Boden sparen',
            'In der Wohnung, in der Hand: 3 cm',
          ],
        },
        {
          title: 'Die stabile Adresse pro Objekt',
          body: [
            'Ein Code pro Objekt lohnt, weil Sie damit zurückverfolgen können, welches Schild wirkt. Voraussetzung ist eine Adresse, die auch nach Monaten noch funktioniert und für sich allein verständlich ist, etwa die Objektnummer statt einer Portal-Anzeige.',
            'Nach dem Verkauf bleibt die Adresse erreichbar, mit Hinweis auf den Abschluss. Ein toter Link auf einem Schild ist die unschönste Form von Werbung.',
          ],
        },
      ],
      useCases: [
        {
          title: 'Exposé am Objekt',
          text: 'Grundriss, Preis und Ansprechpartner direkt vor der Tür, ohne Anruf.',
        },
        {
          title: 'Besichtigungstermin',
          text: 'Der Code am Ausdruck oder der Anzeige führt auf einen Kalender statt auf eine Telefonnummer.',
        },
        {
          title: 'Gewerbeobjekte',
          text: 'Bei leerstehenden Flächen ersetzt der Code das Plakat und bleibt aktuell.',
        },
      ],
      steps: [
        'Pro Objekt eine kurze, eigene Adresse anlegen.',
        'Code erzeugen und in 50 cm für den Gehweg oder 15 cm für die Hauswand drucken lassen.',
        'Auf Aluverbund oder Folie mit Klarlack, nicht auf Papier.',
        'Nach zwei Wochen testen: mit einem älteren Telefon bei Sonne.',
      ],
      faq: [
        {
          q: 'Reicht ein gedrucktes Schild in der Fensterauslage?',
          a: 'Nur von innen, dann aber hinter Glas. Der Code muss durch die Scheibe lesbar bleiben; bei Sonne funktioniert das selten. Besser: eine Platte von innen, die nicht spiegelt.',
        },
        {
          q: 'Wie oft sollte ich die Adresse wechseln?',
          a: 'Nie. Wechseln Sie den Inhalt der Seite, nicht die Adresse. Sonst müssen Sie das Schild neu drucken.',
        },
        {
          q: 'Was passiert nach dem Verkauf?',
          a: 'Die Adresse bleibt bestehen, mit einem Satz zum Abschluss. Alles andere hinterlässt einen toten Link.',
        },
      ],
      toolLinks: [
        { label: 'Website-Code für das Exposé', href: '/?type=url' },
        { label: 'Standort-Code für den Treffpunkt', href: '/?type=standort' },
      ],
      blogLinks: [
        { label: 'QR-Codes drucken: Kontrast und Größe', href: '/blog/qr-code-drucken-kontrast-groesse' },
      ],
    },
  ],

  gesundheit: [],

  auf: [
    {
      slug: 'visitenkarten',
      title: 'QR-Code auf der Visitenkarte: vCard statt Buchstaben',
      metaTitle: 'Visitenkarte mit QR-Code: vCard richtig einsetzen',
      metaDescription:
        'Warum der QR-Code auf der Visitenkarte eine vCard enthalten sollte, welche Größe auf 85 × 55 mm funktioniert und welche Felder gespeichert werden.',
      intro: [
        'Auf einer Visitenkarte steht der Name einmal, und danach tippt ihn jemand ab. Der Code auf der Karte überträgt dieselben Daten in das Adressbuch, ohne Tippfehler.',
        'Ob das gelingt, hängt an zwei Dingen: dem Format (vCard, nicht URL) und der Größe. Auf einer 85 × 55 mm Karte ist das eng.',
      ],
    sections: [
        {
          title: 'Warum vCard und nicht die Website?',
          body: [
            'Ein Code, der auf die Firmenwebsite führt, ist kein Visitenkarten-Code. Er speichert niemanden. Das Format vCard enthält Name, Firma, Telefon, Mobil, E-Mail, Anschrift und Notiz, und das Telefon bietet nach dem Scan direkt "Kontakt anlegen" an.',
            'Halten Sie die vCard knapp: alles, was in Feldern steht, landet im Adressbuch des Gegenübers. Eine Notiz mit dem ganzen Leistungsspektrum wird als Notiz gespeichert und nie wieder gelesen.',
          ],
        },
        {
          title: 'Wie groß darf der Code auf der Karte sein?',
          body: [
            '2,5 cm ist die Untergrenze für einen zuverlässigen Scan mit älteren Geräten. Auf einer Standardkarte bleibt dafür Platz in einer Ecke, aber nicht mehr viel. Wer kleiner setzt, spart Layout und verliert Scans.',
            'Der Code gehört nicht auf die Rückseite über den Claim, sondern auf die Seite mit den Kontaktdaten, meist unten rechts. Er ist ein Werkzeug, keine Illustration.',
          ],
          bullets: [
            'Mindestens 2,5 cm, besser 3 cm Kantenlänge',
            'Ruhezone von 2 mm um das Muster frei halten',
            'Nie mit Folie kaschieren, die spiegelt',
          ],
        },
        {
          title: 'Welche Daten landen im Adressbuch?',
          body: [
            'Eine vCard ist statisch. Ändert sich die Telefonnummer, ist der Code auf 500 gedruckten Karten falsch. Das ist der Preis für eine Lösung ohne Dienstleister.',
            'Wenn sich Kontaktdaten häufig ändern, ist der Code auf der Website die ehrlichere Variante, auch wenn er den Namen nicht speichert.',
          ],
        },
      ],
      useCases: [
        {
          title: 'Lohnt sich der Code auf der Vertriebskarte?',
          text: 'Kontakt per Scan statt Abtippen, auch bei Messegetriebe mit wenig Zeit.',
        },
        {
          title: 'Schild am Büro',
          text: 'Am Türschild mit vCard: Anruf oder Kontakt speichern ohne Nummernsuche.',
        },
        {
          title: 'Anhänger am Messestand',
          text: 'Ein Code, den Interessenten scannen und der den Kontakt speichert, statt einer Broschüre, die im Koffer landet.',
        },
      ],
      steps: [
        'vCard-Code im Generator über den Typ "Visitenkarte" anlegen.',
        'Nur die Felder füllen, die im Adressbuch stehen sollen.',
        'Als SVG exportieren, damit die Druckerei die Größe frei skalieren kann.',
        'Auf 2,5 cm setzen, Ruhezone freihalten, mit einem alten Telefon gegenprüfen.',
      ],
      faq: [
        {
          q: 'Funktioniert eine vCard auf Android und iPhone gleich?',
          a: 'Ja, beide erkennen vCard 3.0. Die Darstellung des Dialogs unterscheidet sich, gespeichert wird derselbe Inhalt.',
        },
        {
          q: 'Kann ich ein Foto in die vCard legen?',
          a: 'Technisch ja, praktisch selten: Das Foto bläht die Datenmenge auf und macht das Muster dichter, was den Scan bei kleiner Fläche erschwert.',
        },
        {
          q: 'Warum nicht einfach ein Kurzlink auf das Profil?',
          a: 'Weil ein Kurzlink den Kontakt nicht speichert und von der Laufzeit des Dienstes abhängt. Für Visitenkarten ist die vCard die robustere Wahl.',
        },
      ],
      toolLinks: [
        { label: 'Visitenkarten-Code (vCard) erstellen', href: '/?type=vcard' },
        { label: 'Telefon-Code erstellen', href: '/?type=phone' },
      ],
      blogLinks: [
        { label: 'vCard-QR-Codes: Felder und Format', href: '/blog/vcard-qr-code-visitenkarte' },
      ],
    },
  ],
};

export const HUBS: SeoHub[] = HUBS_BASE.map((hub) => ({
  ...hub,
  subs: DEPTH_PAGES[hub.slug] ?? [],
}));

export const MATERIALS_HUB: SeoHub = {
  slug: 'auf',
  label: 'Auf Druckerzeugnissen',
  title: 'QR-Codes auf Druckerzeugnissen',
  metaTitle: 'QR-Codes drucken: Größe, Kontrast und Platzierung',
  metaDescription:
    'Welche Kantenlänge bei welchem Leseabstand zählt, warum Kontrast mehr wiegt als Farbe und wo der Code auf Flyer und Verpackung hingehört.',
  intro: [
    'Die meisten Fehler entstehen nicht im Generator, sondern in der Druckerei und am Klebstoff. Ein Code, der auf dem Bildschirm perfekt aussieht, ist auf dem Flyer tot, wenn er zu klein, zu hell oder zu glänzend ist.',
    'Diese Seite ist die Nachschlagehilfe dazu: Größen, Kontrast, Ruhezone, Material.',
  ],
  sources: [
    {
      label: 'ISO/IEC 18004: QR-Code-Symbologie (Modulgröße, Ruhezone)',
      href: 'https://www.iso.org/standard/62021.html',
    },
    {
      label: 'DIN 476: Papierformate A4 und A5',
      href: 'https://www.din.de/de/mitwirken/normenausschuesse/nhrs',
    },
  ],

  sections: [
    {
      title: 'Wie groß muss ein QR-Code sein?',
      body: [
        'Die Faustregel: Kantenlänge in Zentimetern gleich Leseabstand in Metern geteilt durch 10, mindestens aber 2,5 cm. Sie stammt aus der Druckpraxis und hat sich als Untergrenze bewährt, nicht als Optimum. Wer Platz hat, setzt größer.',
        'Bei bewegten Zielen, etwa einem Fahrzeug im Vorbeifahren, funktioniert der Code nur im Stand. Rechnen Sie für den flüchtigen Kontakt nicht mit Scans.',
      ],
      bullets: [
        'Hand, 20 bis 30 cm: 2,5 bis 3 cm',
        'Tischaufsteller, 50 cm: 4 bis 5 cm',
        'Aushang, 1 bis 2 m: 10 bis 15 cm',
        'Plakat und Fahrzeug, ab 5 m: 50 cm',
      ],
    },
    {
      title: 'Warum ist Kontrast wichtiger als Farbe?',
      body: [
        'Dunkles Muster auf hellem Grund. Umgekehrt funktioniert nur, wenn der Grund wirklich hell bleibt und nicht in Grau abfällt. Ein hellgrauer Code auf Weiß hat formal Kontrast, aber nicht genug für eine Handykamera bei 60 Prozent Bildschirmhelligkeit.',
        'Farbige Muster sind erlaubt, solange der Kontrast zum Hintergrund groß bleibt. Kräftiges Schwarz, Dunkelblau und Dunkelrot auf Weiß arbeiten zuverlässig; Gelb und Hellgrün nicht.',
      ],
    },
    {
      title: 'Wie viel Rand braucht ein QR-Code?',
      body: [
        'Um das Muster gehört ein Rand frei von Text und Grafik, mindestens vier Module breit. Wer den Code in ein Bild legt, verliert genau dort die Erkennung.',
        'Ein Logo in der Mitte geht, kostet aber Korrekturkapazität. Deshalb schaltet der Generator in diesem Fall automatisch auf Fehlerkorrektur H. Kleiner als 20 Prozent der Fläche sollte das Logo nicht sein, größer nicht.',
      ],
    },
    {
      title: 'Welches Material hält den Code lesbar?',
      body: [
        'Auf glänzendem Papier spiegelt der Code beim Scannen, auf Recyclingpapier franst der Punktdruck aus. Matt und weiß ist die sichere Wahl.',
        'Im Außenbereich hält nur bedruckte Folie oder Aluverbund mit Klarlack. Ein Ausdruck unter Bürofolie ist nach einem Winter unlesbar.',
      ],
    },
  ],
  faq: [
    {
      q: 'Wie klein darf ein QR-Code auf einem Flyer sein?',
      a: '2,5 cm als Untergrenze bei 25 bis 30 cm Leseabstand. Unter 2 cm steigen die Fehlscans bei älteren Telefonen deutlich.',
    },
    {
      q: 'Geht ein QR-Code in Farbe?',
      a: 'Ja, mit dunklem Muster auf sehr hellem Grund. Der Kontrast entscheidet, nicht die Farbe. Ein Generator-Scan-Test zeigt vorher, ob es reicht.',
    },
    {
      q: 'Warum brauche ich eine Ruhezone?',
      a: 'Weil die Kamera den Rand braucht, um das Muster als Code zu erkennen. Text oder Grafik direkt am Muster führt zu Fehlscans, auch wenn der Code selbst korrekt ist.',
    },
    {
      q: 'Was ist besser: PNG oder SVG?',
      a: 'Für alles, was gedruckt wird, SVG. Es skaliert verlustfrei auf jede Größe. PNG ist für Bildschirm und schnelle Aushänge gedacht.',
    },
    {
      q: 'Überlebt ein Code den Laserdrucker im Büro?',
      a: 'Ab 2,5 cm und in Schwarzweiß meistens. Vermeiden Sie Farbdruck auf Normalpapier für kleine Codes, die Farbpunkte verlaufen.',
    },
  ],
  subs: DEPTH_PAGES.auf,
  consolidated: ['flyer', 'plakate', 'verpackungen', 'tickets-einladungen'],
};

export const ALL_HUBS: SeoHub[] = [...HUBS, MATERIALS_HUB];

export function findHub(slug: string): SeoHub | undefined {
  return ALL_HUBS.find((h) => h.slug === slug);
}

export function findSub(hub: SeoHub, subSlug: string): SeoSubPage | undefined {
  return hub.subs.find((s) => s.slug === subSlug);
}

/** Every former subpage URL that is now a 301, keyed by old path. */
export const CONSOLIDATED_PATHS: { from: string; to: string }[] = ALL_HUBS.flatMap(
  (hub) => {
    const base = hub.slug === 'auf' ? '/qr-codes-auf' : `/qr-codes-fuer/${hub.slug}`;
    return hub.consolidated.map((slug) => ({ from: `${base}/${slug}`, to: base }));
  }
);
