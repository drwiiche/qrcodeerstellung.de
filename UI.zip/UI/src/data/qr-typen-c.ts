/**
 * Wave 2 of the type pages: the platform targets and the dense contact format.
 *
 * These are the pages the competitor set has and we did not: facebook, youtube,
 * x, paypal, mecard. Each is a type the generator actually produces, so each can
 * be honest about the payload instead of writing generic "social media" copy.
 *
 * Three integrations I looked at and dropped, with reasons, because padding the
 * family with pages nobody searches would be the exact pattern these pages are
 * meant to beat:
 *   - Fritz!Box: already the opening case of the Wi-Fi guide (/wlan-qr-code).
 *   - Google Bewertungen: already a blog post (/blog/google-bewertungen-qr-code).
 *   - DATEV: no defensible search demand in Germany, and inventing one would be
 *     a page written for a keyword tool rather than for a person.
 */
import type { SeoSubPage } from './seo-pages';

const facebook: SeoSubPage = {
  slug: 'facebook',
  title: 'Facebook-QR-Code erstellen',
  metaTitle: 'Facebook QR-Code erstellen: Seite oder Profil verlinken',
  metaDescription:
    'Ein Code, der eine Facebook-Seite öffnet. Warum die Seitenadresse besser ist als der In-App-Code, was der Slug darf und wo der Code wirkt.',
  intro: [
    'Ein Facebook-Code führt auf eine Seite oder ein Profil, ohne dass jemand den Namen suchen muss. Für lokale Betriebe ist das der Weg von einem Aufsteller zu einer Bewertung oder zu den Öffnungszeiten, die dort gepflegt sind.',
    'Wie bei Instagram gilt: Gedruckt wird die Adresse, nicht das Muster aus der App.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Eine Adresse der Form https://www.facebook.com/seitenname. Der Seitenname ist der Teil, den Facebook als Nutzername vergibt. Er bleibt stabil, solange ihn niemand ändert, und das ist die einzige Bedingung für einen gedruckten Code.',
        'Der Generator akzeptiert entweder den Namen oder eine vollständig eingefügte Adresse. Eine Adresse wird nur übernommen, wenn der Host wirklich zu Facebook gehört, damit ein Instagram-Link nicht versehentlich als Facebook-Adresse gedruckt wird.',
      ],
      bullets: [
        'Seitenname ohne @ und ohne Schrägstrich am Ende',
        'Keine Weiterleitung auf eine Kurzdomain dazwischen',
        'Bei Gruppen: der Einladungslink der Gruppe, nicht der Name',
        'Bei Veranstaltungen: die Ereignis-Adresse, sie verfällt aber nach dem Termin',
      ],
    },
    {
      title: 'Seite, Profil oder Gruppe',
      body: [
        'Für Betriebe ist die Seite richtig, weil sie ohne Freundschaftsanfrage erreichbar ist, Statistiken liefert und Bewertungen sammeln kann. Ein Profil kann nur mit Freundschaftsanfrage folgen, das ist für Kundschaft die falsche Hürde.',
        'Gruppen sind nur sinnvoll, wenn eine bestehende Community gepflegt wird. Ein gedruckter Gruppenlink ist riskant, weil Gruppen ihre Sichtbarkeit ändern können und der Code dann auf eine Beitrittsseite führt.',
      ],
    },
    {
      title: 'Der In-App-Code und warum er nicht gedruckt wird',
      body: [
        'Facebook erzeugt in der App ebenfalls ein Codebild, das die Facebook-Kamera liest. Für den Bildschirm ist das praktisch, für Papier nicht: Der Code lässt sich in der App neu erzeugen, und fremde Kamera-Apps erkennen ihn nicht zuverlässig.',
        'Die Adresse als gewöhnlicher QR-Code ist dagegen ein Text, den jede Kamera versteht. Das ist der kleinere technische Weg und der haltbarere.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Am Tresen 3 Zentimeter, auf Flyern 2,5 Zentimeter, auf Schildern im Außenbereich 10 Zentimeter. Immer mit einer Zeile daneben, die den Grund nennt: „Öffnungszeiten und Bewertungen" funktioniert, „Facebook" allein nicht.',
        'Wer Bewertungen will, sollte den Code nicht auf die Bewertungsseite führen, sondern auf die Seite mit sichtbarem Bewertungsbereich. Ein direkter Bewertungslink ist bei Facebook nicht dauerhaft stabil.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Gastronomie am Tisch',
      text: 'Aufsteller mit Code zur Seite, dort stehen Öffnungszeiten und die aktuelle Karte. Änderungen sind sofort sichtbar, ohne neuen Druck.',
    },
    {
      title: 'Handwerk und Dienstleistung',
      text: 'Der Code auf dem Fahrzeug führt zur Seite mit Referenzen. Wer eine Bewertung hinterlassen will, findet den Weg dorthin in zwei Schritten.',
    },
    {
      title: 'Veranstaltung',
      text: 'Der Code auf dem Programmheft führt zur Veranstaltungsseite mit Fotos. Nach dem Termin sollte er auf die Seite des Veranstalters zeigen, nicht ins Leere.',
    },
  ],
  steps: [
    'Seitennamen aus der Adresszeile kopieren, nicht aus dem Anzeigenamen.',
    'Prüfen, ob die Seite ohne Anmeldung erreichbar ist. Wenn nicht, den Code nicht drucken.',
    'Typ „Facebook" wählen und Namen oder Adresse eintragen.',
    'Code erzeugen und mit einer Zeile drucken, die sagt, was dort zu finden ist.',
    'Auf einem Gerät ohne Facebook-Konto scannen, um die Anmeldemaske zu sehen.',
  ],
  faq: [
    {
      q: 'Warum nicht der Code aus der Facebook-App?',
      a: 'Weil er sich in der App neu erzeugen lässt und fremde Kamera-Apps ihn nicht zuverlässig lesen. Die Seitenadresse als QR-Code ist dauerhaft und universell lesbar.',
    },
    {
      q: 'Kann der Code auf eine Bewertung führen?',
      a: 'Ein direkter Bewertungslink ist bei Facebook nicht stabil. Besser ist die Seite mit sichtbarem Bewertungsbereich, dort findet der Gast den Weg in zwei Schritten.',
    },
    {
      q: 'Was passiert, wenn der Seitenname geändert wird?',
      a: 'Alte Adressen werden oft weitergeleitet, aber nicht garantiert und nicht dauerhaft. Wer den Namen ändert, sollte die gedruckten Codes austauschen.',
    },
  ],
  toolLinks: [
    { label: 'Facebook-QR-Code erstellen', href: '/?type=facebook' },
    { label: 'Instagram-QR-Code erstellen', href: '/qr-code-generator/instagram' },
  ],
  blogLinks: [{ label: 'QR-Codes für Bewertungen und Rezensionen', href: '/blog/google-bewertungen-qr-code' }],
};

const youtube: SeoSubPage = {
  slug: 'youtube',
  title: 'YouTube-QR-Code erstellen',
  metaTitle: 'YouTube QR-Code: Kanal oder Video per Scan öffnen',
  metaDescription:
    'Kanal-Code oder Video-Code: was der Unterschied ist, warum der Kanal auf Papier länger hält und wie Sie die Adresse ohne Kanalnamen finden.',
  intro: [
    'Ein YouTube-Code öffnet den Kanal oder ein einzelnes Video. Der Unterschied ist größer, als er klingt: Ein Kanal bleibt, ein Video kann verschwinden.',
    'Für alles Gedruckte ist der Kanal in der Regel die bessere Wahl, für eine konkrete Anleitung das Video.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Beim Kanal eine Adresse der Form https://www.youtube.com/@kanalname. Der Kanalname mit @ ist die stabile Kennung; der angezeigte Name darf sich ändern, die Kennung nicht.',
        'Beim Video die Adresse https://www.youtube.com/watch?v= oder die Kurzform https://youtu.be/. Beide funktionieren, die Kurzform ist etwa 30 Zeichen kürzer und ergibt dadurch ein weniger dichtes Muster.',
      ],
      bullets: [
        'Kanalname mit @, keine Leerzeichen, keine Groß- und Kleinschreibung mischen',
        'Video-ID ist der Wert nach v= oder nach youtu.be/',
        'Keine Playlist-Adresse mit Sitzungszeichenketten, die verfallen',
        'Kein Link auf einen Kanal, der noch keine Videos hat',
      ],
    },
    {
      title: 'Kanal oder Video: die Entscheidung',
      body: [
        'Der Kanal überlebt Produktwechsel und Kampagnen. Wer eine Broschüre für zwei Jahre druckt, ist mit dem Kanal besser bedient, weil dort immer das Aktuelle steht.',
        'Das Video ist richtig, wenn es um genau eine Sache geht: die Montageanleitung für dieses eine Gerät, die Einweisung in dieses eine Formular. Dann ist der Inhalt der Grund für den Scan.',
      ],
    },
    {
      title: 'Was den Scan scheitern lässt',
      body: [
        'Ein privates oder nicht gelistetes Video. Nicht gelistet heißt: nur mit dem Link erreichbar, was funktioniert, aber wenn das Video gelöscht wird, ist der Code tot. Privat ist immer falsch, weil der Scan dann eine Fehlermeldung zeigt.',
        'Altersbeschränkungen. Videos mit Altersfreigabe verlangen eine Anmeldung. Auf einem Flyer für Jugendliche ist das eine Hürde, die den Scan entwertet.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf Montageanleitungen 2,5 bis 3 Zentimeter, auf Verpackungen 2 Zentimeter mit sehr gutem Kontrast, auf Schildern 8 bis 10 Zentimeter.',
        'Bei Verpackungen zählt die Fläche: Ein Code auf einer gewölbten Flasche wird selten gut gescannt. Besser eine plane Fläche oder ein Etikett mit geradem Untergrund.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Montageanleitung',
      text: 'Der Code auf dem Beipackzettel führt zum Video. Wer nicht gern liest, hat den Aufbau in zwei Minuten gesehen.',
    },
    {
      title: 'Betrieb mit Erklärvideos',
      text: 'Der Kanal-Code auf der Visitenkarte, für alle, die vorher sehen wollen, wie gearbeitet wird. Das ersetzt Referenzen in Textform.',
    },
    {
      title: 'Verein und Bildung',
      text: 'Der Code auf dem Kursblatt führt zur Aufzeichnung. Wichtig ist der Hinweis, ob das Video dauerhaft stehen bleibt.',
    },
  ],
  steps: [
    'Kanalnamen über „Kanal teilen" kopieren, nicht aus dem Browsertab.',
    'Prüfen, ob der Kanal auch im ausgeloggten Zustand Videos zeigt.',
    'Typ „YouTube" wählen und Namen oder Adresse eintragen.',
    'Code erzeugen, mit dem Hinweis „Video ansehen" drucken.',
    'Mit einem Gerät ohne YouTube-App scannen, um den Browserpfad zu prüfen.',
  ],
  faq: [
    {
      q: 'Funktioniert der Code, wenn YouTube nicht installiert ist?',
      a: 'Ja. Der Browser öffnet die Seite. YouTube zeigt auf Mobilgeräten häufig einen Hinweis auf die App, das Video bleibt aber erreichbar.',
    },
    {
      q: 'Kann ich eine Playlist verlinken?',
      a: 'Ja, aber Playlist-Adressen enthalten oft Sitzungsparameter. Prüfen Sie, ob die Adresse ohne diese Zeichenkette funktioniert, sonst veraltet der Code.',
    },
    {
      q: 'Warum ist der Kanal-Code langlebiger?',
      a: 'Weil die Kanaladresse bleibt, auch wenn einzelne Videos ersetzt werden. Ein Video-Code stirbt mit dem Video.',
    },
  ],
  toolLinks: [
    { label: 'YouTube-QR-Code erstellen', href: '/?type=youtube' },
    { label: 'Allgemeiner Link-QR-Code', href: '/qr-code-generator/link' },
  ],
  blogLinks: [{ label: 'QR-Codes auf Verpackungen und Druckerzeugnissen', href: '/blog/qr-codes-flyer-plakate-drucksachen' }],
};

const x: SeoSubPage = {
  slug: 'x',
  title: 'X-QR-Code (Twitter) erstellen',
  metaTitle: 'X QR-Code erstellen: Profil per Code öffnen',
  metaDescription:
    'Ein Code, der ein X-Profil öffnet. Warum gedruckte Handles fragil sind, was bei Umbenennungen passiert und wann der Code trotzdem sinnvoll ist.',
  intro: [
    'Ein X-Code, früher Twitter-Code, führt auf ein Profil. Technisch ist es eine gewöhnliche Adresse, inhaltlich eine Wette auf die Beständigkeit eines Namens.',
    'Diese Seite sagt, wann die Wette sinnvoll ist und wann Sie besser auf etwas anderes verweisen.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Eine Adresse der Form https://x.com/handlename. Der Handle ist der Name mit @, im Code ohne das Zeichen. Groß- und Kleinschreibung spielt bei X keine Rolle, gedruckt wird trotzdem die Schreibweise des Profils.',
        'Adressen mit twitter.com werden von X weitergeleitet. Für neue Codes ist x.com die richtige Form, weil die alte Domain irgendwann verschwinden kann.',
      ],
      bullets: [
        'Handle ohne @ und ohne Leerzeichen',
        'Keine Adresse eines einzelnen Beitrags, die altert schnell',
        'Keine Profil-Adresse mit angehängten Parametern aus der App',
        'Handle vor dem Druck auf Tippfehler prüfen, ein falscher Handle führt zu einem fremden Profil',
      ],
    },
    {
      title: 'Warum ein gedruckter Handle fragil ist',
      body: [
        'Handles sind bei X einseitig änderbar. Wer den Namen ändert, macht jeden gedruckten Code wertlos, und alte Handles können von anderen übernommen werden. Das ist kein theoretisches Risiko, sondern bei bekannten Konten mehrfach passiert.',
        'Daraus folgt keine Absage, sondern eine Reihenfolge: Wer den Code druckt, sollte den Handle als dauerhaft behandeln. Wenn das nicht gesichert ist, ist der Link-Code auf eine eigene Seite die robustere Wahl.',
      ],
    },
    {
      title: 'Wann sich der Code trotzdem lohnt',
      body: [
        'Bei Veranstaltungen mit kurzer Lebensdauer, auf Bühnenfolien, in Programmheften und auf Presseunterlagen. Dort ist der Aufdruck zeitlich begrenzt und der Handle muss nur Monate halten.',
        'Für dauerhafte Flächen wie Fahrzeugbeschriftung oder Schilder ist eine eigene Seite mit eingebettetem Feed die bessere Bauform, weil sie unabhängig vom Handle bleibt.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf Programmheften und Folien 2,5 bis 3 Zentimeter, auf Aufstellern 4 Zentimeter. Bei Präsentationen auf Bildschirm gilt: Der Code muss mindestens ein Drittel der Bildschirmhöhe haben, sonst scannt ihn aus dem Raum niemand.',
        'Für Folien zusätzlich den Handle in Klarschrift daneben. Wer nicht scannen will, findet so den Weg.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Konferenz und Bühne',
      text: 'Der Code auf der letzten Folie führt zum Profil des Vortragenden. Kurzlebig, aber in dem Moment wirksam.',
    },
    {
      title: 'Presse und Medien',
      text: 'Der Code im Pressematerial für den direkten Draht. Wichtig ist, dass der Handle aktuell ist.',
    },
    {
      title: 'Lokaler Betrieb',
      text: 'Nur sinnvoll, wenn dort wirklich regelmäßig etwas erscheint. Ein Profil ohne Beiträge seit einem Jahr wirkt schlechter als kein Verweis.',
    },
  ],
  steps: [
    'Handle im Profil prüfen und kopieren, ohne @.',
    'Entscheiden, ob die Fläche langlebig ist. Wenn ja, stattdessen eine eigene Seite verlinken.',
    'Typ „X" wählen und den Handle eintragen.',
    'Code erzeugen und mit dem Handle in Klarschrift daneben drucken.',
    'Selbst scannen und prüfen, dass das richtige Profil erscheint.',
  ],
  faq: [
    {
      q: 'Soll ich twitter.com oder x.com verwenden?',
      a: 'x.com. Die alte Domain wird derzeit weitergeleitet, aber neue Codes sollten die aktuelle Form tragen, damit sie nicht von einer künftigen Umstellung abhängen.',
    },
    {
      q: 'Was passiert bei einer Namensänderung?',
      a: 'Der gedruckte Code zeigt auf den alten Handle. Je nachdem, ob ihn jemand übernimmt, landet man auf einem falschen Profil oder auf einer Fehlermeldung.',
    },
    {
      q: 'Gibt es ein eigenes X-QR-Format?',
      a: 'Nein. X-Profile werden als gewöhnliche Adresse kodiert, es gibt kein besonderes Format wie bei WLAN oder vCard.',
    },
  ],
  toolLinks: [
    { label: 'X-QR-Code erstellen', href: '/?type=twitter' },
    { label: 'Link-QR-Code für eine eigene Seite', href: '/qr-code-generator/link' },
  ],
  blogLinks: [],
};

const paypal: SeoSubPage = {
  slug: 'paypal',
  title: 'PayPal-QR-Code erstellen',
  metaTitle: 'PayPal QR-Code erstellen: Geld per Scan senden',
  metaDescription:
    'Ein Code auf paypal.me, optional mit Betrag. Was der Link kann, was er nicht kann, welche Gebühren anfallen und warum kein Beleg entsteht.',
  intro: [
    'Ein PayPal-Code führt auf eine Zahlungsseite mit vorausgefülltem Empfänger, auf Wunsch mit Betrag. Der Zahler muss keine Adresse suchen und tippt sich nicht in der Empfängerliste fest.',
    'Für Trinkgeld, Vereinsbeiträge und kleine Rechnungen ist das schnell. Für alles, was einen Beleg braucht, ist es der falsche Weg.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Eine Adresse der Form https://www.paypal.me/handle, optional mit Betrag als letztem Teil, also https://www.paypal.me/handle/25. Der Betrag wird als Zahl ohne Währungszeichen eingetragen, die Währung ergibt sich aus dem Konto des Empfängers.',
        'Der Handle ist der Teil nach paypal.me/ im eigenen Profil. Eine vollständig eingefügte Adresse wird auf diesen Handle reduziert, damit keine doppelten Pfade entstehen.',
      ],
      bullets: [
        'Handle ohne @, ohne Leerzeichen',
        'Betrag mit Punkt als Dezimaltrenner, nicht mit Komma',
        'Kein Betrag, wenn der Zahler selbst entscheiden soll',
        'Währung nicht im Link, sie hängt am Empfängerkonto',
      ],
    },
    {
      title: 'Was dabei nicht entsteht',
      body: [
        'Kein Beleg im Sinne der Buchhaltung. Für eine Betriebsausgabe braucht es eine Rechnung mit den Pflichtangaben, ein PayPal-Vorgang allein genügt nicht. Wer den Code auf eine Rechnung setzt, sollte trotzdem eine ordentliche Rechnung ausstellen.',
        'Auch keine Zahlungsgarantie. Der Link öffnet eine Zahlungsseite, ob gezahlt wird, entscheidet der Gegenüber.',
      ],
    },
    {
      title: 'Gebühren und Adressaten',
      body: [
        'Zwischen Freunden und Familie ist das Senden in der Regel kostenlos, für geschäftliche Zahlungen fallen Gebühren an. Wer geschäftlich Geld einsammelt, sollte den Code auf ein Geschäftskonto legen, nicht auf ein privates.',
        'Wichtig für Vereine: Spenden über PayPal sind möglich, aber Spendenquittungen verlangen eine Zuordnung. Ohne Verwendungszweck im Zahlungsvorgang ist die Zuordnung Handarbeit.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf einem Aufsteller am Tresen 4 Zentimeter, auf Flyern 2,5 Zentimeter, auf Spendendosen 3 Zentimeter mit klarem Hinweis auf den Zweck.',
        'Immer mit einer Zeile, die den Zweck nennt. Ein PayPal-Code ohne Beschriftung wird nicht gescannt, weil niemand weiß, wohin das Geld geht.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Trinkgeld im Laden',
      text: 'Aufsteller an der Kasse, Betrag leer. Der Gast entscheidet, und niemand muss Münzen suchen.',
    },
    {
      title: 'Verein und Spendenbox',
      text: 'Code auf der Spendenbox, mit dem Hinweis, wofür gesammelt wird. Ohne diesen Hinweis sinkt die Bereitschaft deutlich.',
    },
    {
      title: 'Kleine Rechnung',
      text: 'Der Code auf der Rechnung, Betrag vorbelegt. Der Kunde zahlt in zwei Schritten, die Buchhaltung erhält trotzdem eine Rechnung.',
    },
  ],
  steps: [
    'Handle aus dem eigenen PayPal-Profil kopieren, nicht aus einer alten Adresse.',
    'Entscheiden, ob ein Betrag festgelegt wird.',
    'Typ „PayPal" wählen, Handle und Betrag eintragen.',
    'Code erzeugen und mit Beschriftung drucken, die den Zweck nennt.',
    'Selbst scannen und prüfen, dass der richtige Empfänger erscheint, bevor Sie den Code veröffentlichen.',
  ],
  faq: [
    {
      q: 'Kann der Zahler den Betrag ändern?',
      a: 'Ja, der Betrag ist vorausgefüllt und editierbar. Bei festen Forderungen sollte der Betrag im Code stehen, weil es Rückfragen erspart.',
    },
    {
      q: 'Ist der PayPal-Code eine Rechnung?',
      a: 'Nein. Für Betriebsausgaben braucht es eine Rechnung mit den Pflichtangaben nach § 14 UStG. Der Code löst nur die Zahlung aus.',
    },
    {
      q: 'Warum funktioniert der Code mit Komma nicht?',
      a: 'Der Link erwartet einen Punkt als Dezimaltrenner. Mit Komma entsteht ein ungültiger Betrag, und die Zahlungsseite öffnet ohne Betrag.',
    },
  ],
  toolLinks: [
    { label: 'PayPal-QR-Code erstellen', href: '/?type=paypal' },
    { label: 'Rechnungen: was ein Code dort darf', href: '/standards/erechnung' },
  ],
  blogLinks: [],
};

const mecard: SeoSubPage = {
  slug: 'mecard',
  title: 'MECARD-QR-Code erstellen',
  metaTitle: 'MECARD QR-Code: kompakter Kontakt für kleine Etiketten',
  metaDescription:
    'MECARD statt vCard: was das Format enthält, wie Sonderzeichen maskiert werden und wann der kürzere Kontakt-Code die bessere Wahl ist.',
  intro: [
    'MECARD ist das ältere Kontaktformat im QR-Code. Es ist deutlich kürzer als vCard, kennt weniger Felder, und genau deshalb passt es auf Flächen, auf denen vCard zu dicht wird.',
    'Wer nur Name, Nummer und E-Mail braucht, ist damit gut bedient. Wer Titel, Abteilung und Adresse braucht, nimmt vCard.',
  ],
  sections: [
    {
      title: 'Was steht im Code?',
      body: [
        'Eine Zeile der Form MECARD:N:Nachname,Vorname;ORG:Firma;TEL:Nummer;EMAIL:Adresse;; Die Felder sind durch Semikolon getrennt, und die Zeile endet mit zwei Semikola.',
        'Die Maskierung ist hier der Knackpunkt: Enthält ein Wert selbst ein Semikolon, einen Doppelpunkt, ein Komma oder einen Backslash, muss dieses Zeichen mit einem Backslash davor geschrieben werden. Sonst endet das Feld an der falschen Stelle.',
      ],
      bullets: [
        'Felder: N, ORG, TEL, EMAIL, ADR, URL, NOTE',
        'Name im Feld N als Nachname,Vorname',
        'Semikolon, Doppelpunkt, Komma und Backslash werden maskiert',
        'Abschluss mit doppeltem Semikolon, sonst gilt der Block als unvollständig',
      ],
    },
    {
      title: 'MECARD oder vCard',
      body: [
        'MECARD ist um etwa die Hälfte kürzer. Das klingt nach einem Detail, ist aber der Grund für seine Existenz: Auf einem 20-Millimeter-Feld auf einer Visitenkarte entscheidet die Datenmenge darüber, ob der Code lesbar bleibt.',
        'vCard hat mehr Felder, ist besser spezifiziert und wird von praktisch jeder Adressbuch-App vollständig ausgewertet. Wenn Platz keine Rolle spielt, ist vCard die erste Wahl.',
      ],
    },
    {
      title: 'Wann MECARD die richtige Wahl ist',
      body: [
        'Auf kleinen Etiketten, auf Inventaraufklebern mit Kontakt für Rückfragen, auf Werkzeugkisten, auf Schlüsselanhängern. Überall, wo nur wenige Angaben gebraucht werden und die Fläche knapp ist.',
        'Nicht geeignet für Firmenkarten mit Titel und Abteilung. Wer diese Angaben dort unterbringt, bekommt einen Code, der auf dem Kartenformat nicht mehr sauber zu scannen ist.',
      ],
    },
    {
      title: 'Größe und Platzierung',
      body: [
        'Auf einem Etikett von 20 Millimetern geht MECARD mit Name und Nummer, vCard an derselben Stelle wäre bereits grenzwertig. Auf der Visitenkarte sind 20 bis 25 Millimeter die Untergrenze.',
        'Wie bei jedem Kontaktformat gilt: dunkel auf hell, vier Module Ruhezone, matt drucken. Ein glänzend laminiertes Etikett spiegelt bei schrägem Licht und lässt den Scan scheitern.',
      ],
    },
  ],
  useCases: [
    {
      title: 'Inventar und Werkzeug',
      text: 'Ein Etikett mit Name und Nummer des Verantwortlichen. Wer ein Gerät findet, ruft an, statt eine Mail zu schreiben.',
    },
    {
      title: 'Schlüsselanhänger',
      text: 'Kontakt für den Rückgabe-Fall. Wenige Felder, kleine Fläche, hoher Nutzen, wenn der Schlüssel verloren geht.',
    },
    {
      title: 'Messe und Aushang',
      text: 'Auf Aushängen, auf denen nur die Durchwahl stehen soll. Alles Weitere ist auf der Fläche ohnehin nicht lesbar.',
    },
  ],
  steps: [
    'Überlegen, welche Felder wirklich gebraucht werden. Weniger ist hier buchstäblich besser.',
    'Typ „MECARD" wählen und die Felder füllen, Telefonnummern international.',
    'Prüfen, ob Sonderzeichen im Firmennamen vorkommen. Der Generator maskiert sie, im Zweifel den Code testen.',
    'Code erzeugen und auf dem echten Etikett scannen, nicht am Bildschirm.',
  ],
  faq: [
    {
      q: 'Warum wird mein MECARD-Code nicht erkannt?',
      a: 'Meistens wegen eines nicht maskierten Sonderzeichens oder eines fehlenden doppelten Semikolons am Ende. Beides bricht die Struktur, und der Scanner zeigt dann nur Text an.',
    },
    {
      q: 'Unterstützen alle Telefone MECARD?',
      a: 'Die meisten Adressbuch-Apps erkennen es, aber nicht alle zeigen jedes Feld an. Für maximale Kompatibilität ist vCard die sichere Wahl.',
    },
    {
      q: 'Kann ich MECARD später auf vCard umstellen?',
      a: 'Nur mit einem neuen Code. Der Inhalt ist im Muster eingebrannt, ein Formatwechsel verlangt einen neuen Druck.',
    },
  ],
  toolLinks: [
    { label: 'MECARD-QR-Code erstellen', href: '/?type=mecard' },
    { label: 'vCard für die Visitenkarte', href: '/qr-code-generator/vcard' },
  ],
  blogLinks: [{ label: 'vCard-QR-Code: Felder, Format, Fehler', href: '/blog/vcard-qr-code-visitenkarte' }],
};

export const TYPEN_PART_THREE = [facebook, youtube, x, paypal, mecard];
