/**
 * Two German authority hubs built from measured query demand.
 *
 * Both blocks of queries were the largest uncovered themes in the German
 * autocomplete harvest (research/de-autocomplete.json):
 *
 *   - legal / compliance: 96 queries ("qr code auf rechnung pflicht",
 *     "impressum qr code", "qr code datenschutz", "girocode")
 *   - troubleshooting:    37 queries ("qr code wird nicht erkannt",
 *     "qr code funktioniert nicht iphone", "qr code zu klein")
 *
 * Neither theme was covered anywhere on the site. These are the pages that
 * answer a question the tool itself cannot answer, which is why they are
 * worth their own URL rather than a paragraph on an existing hub.
 *
 * Legal care: nothing here states a legal requirement that does not exist,
 * and the pages say plainly that they are not legal advice. Several of the
 * most-searched German phrasings assume an obligation that is not in the
 * statute, and correcting that is most of the value.
 */
import type { SeoHub } from './seo-pages';

export const RECHT_HUB: SeoHub = {
  slug: 'qr-code-recht',
  basePath: '/qr-code-recht',
  label: 'Recht & Compliance',
  title: 'QR-Codes und Recht: Rechnung, Impressum, Datenschutz',
  metaTitle: 'QR-Code und Recht: Rechnung, Impressum, DSGVO',
  metaDescription:
    'Muss ein QR-Code auf die Rechnung? Was darf hinter dem Code im Impressum stehen? Wo Datenschutz anfängt, wenn ein Code gescannt wird.',
  intro: [
    'Rund um QR-Codes hält sich in Deutschland eine Reihe von Annahmen, die sich nicht im Gesetz wiederfinden. Die häufigste: Auf einer Rechnung müsse ein QR-Code stehen. Das ist nicht der Fall.',
    'Diese Seite sortiert die Fragen, die tatsächlich häufig gestellt werden: Rechnung, Impressum, Datenschutz beim Scannen, Werbung mit Code, Speisekarte in der Gastronomie. Sie ersetzt keine Rechtsberatung, sie ordnet nur ein, was der Gesetzgeber verlangt und was nicht.',
  ],
  sources: [
    {
      label: '§ 14 UStG: Pflichtangaben in der Rechnung',
      href: 'https://www.gesetze-im-internet.de/ustg_1980/__14.html',
    },
    {
      label: '§ 33 UStDV: Angaben in der Rechnung',
      href: 'https://www.gesetze-im-internet.de/ustdv_1980/__33.html',
    },
    {
      label: '§ 5 DDG: Anbieterkennzeichnung im Impressum',
      href: 'https://www.gesetze-im-internet.de/ddg/__5.html',
    },
    {
      label: '§ 5a UWG: Irreführung, getarnte Werbung',
      href: 'https://www.gesetze-im-internet.de/uwg_2004/__5a.html',
    },
    {
      label: '§ 25 TDDDG: Einwilligung für Endgeräte-Speicherung',
      href: 'https://www.gesetze-im-internet.de/ttdsg/__25.html',
    },
    {
      label: 'Art. 6 DSGVO: Rechtmäßigkeit der Verarbeitung',
      href: 'https://eur-lex.europa.eu/eli/reg/2016/679/oj',
    },
  ],
  sections: [
    {
      title: 'Gibt es eine Pflicht zum QR-Code auf der Rechnung?',
      body: [
        'Nein. Für Rechnungen an Unternehmen und Verbraucher in Deutschland gelten die Pflichtangaben nach § 14 UStG und § 33 UStDV. Ein QR-Code gehört nicht dazu. Die Pflichtangaben lassen sich vollständig in Textform erbringen.',
        'Etwas anderes gilt nur, wenn eine Rechnung elektronisch als E-Rechnung im Sinne der EU-Norm EN 16931 ausgestellt wird. Dort werden strukturierte Daten übertragen, und ein QR-Code kann als Träger dienen. Das ist aber kein eigener QR-Code, sondern die Darstellung eines Datensatzes, der ohnehin maschinenlesbar vorliegen muss.',
        'Wer freiwillig einen Code auf die Rechnung setzt, ist daran nicht gehindert. Der Code sollte dann zu den eigenen Leistungen führen: Terminbuchung, Produktdatenblatt, Bedienungsanleitung. Er darf aber keine Pflichtangaben ersetzen, die in Textform zu erscheinen haben.',
      ],
      bullets: [
        'Pflichtangaben nach § 14 UStG bleiben Pflicht, unabhängig vom Code',
        'Ein Code auf der Rechnung ist eine freiwillige Zusatzleistung',
        'Bei E-Rechnungen trägt der Code strukturierte Daten, nicht ein PDF',
        'Der QR-Code auf einem Kassenbon ist etwas anderes als der auf einer Rechnung',
      ],
    },
    {
      title: 'Muss ein QR-Code ins Impressum?',
      body: [
        'Die Anbieterkennzeichnung nach § 5 DDG muss leicht erkennbar, unmittelbar erreichbar und ständig verfügbar sein. Ein QR-Code im Impressum ist zulässig, er erfüllt aber nur dann seinen Zweck, wenn er auf die Impressumsseite selbst zeigt und nicht auf ein PDF.',
        'Der Grund ist praktisch: Ein PDF wird selten aktualisiert und oft nicht indexiert. Wenn sich die Anschrift ändert, bleibt der alte Stand im PDF stehen, während die Seite längst korrigiert ist. Wer einen Code setzt, sollte ihn deshalb auf eine HTML-Seite richten und diese Seite ist die, die auch ohne Code erreichbar ist.',
      ],
      bullets: [
        'Der Code ist eine Abkürzung, nicht der einzige Zugang zu den Angaben',
        'Ziel sollte eine HTML-Seite sein, kein PDF',
        'Nach einer Änderung der Anschrift prüfen, ob der Code noch auf den aktuellen Stand zeigt',
      ],
    },
    {
      title: 'Datenschutz: Was passiert beim Scan?',
      body: [
        'Ein statischer QR-Code, wie ihn dieses Werkzeug erzeugt, enthält nur den Zieltext. Beim Scannen wird nichts an einen Server übertragen, weil es keinen gibt. Es entstehen keine Zugriffsprotokolle, keine Gerätekennungen und keine Standortdaten.',
        'Anders ist es bei Codes, die auf eine Weiterleitung zeigen. Dort wird der Scan technisch über einen Dienst geleitet, damit die Zieladresse austauschbar bleibt. Dieser Dienst sieht das Gerät, die Zeit und die IP-Adresse. Das ist eine Verarbeitung personenbezogener Daten und braucht eine Rechtsgrundlage, in der Regel Art. 6 Abs. 1 lit. f DSGVO für das berechtigte Interesse an der Auswertung.',
        'Wer solche Codes einsetzt, muss das in der Datenschutzerklärung abbilden. Für die Frage, ob das interoperabel mit der DSGVO funktioniert, ist wichtig, wer als Verantwortlicher auftritt: Der Anbieter des Code-Dienstes handelt als Auftragsverarbeiter, verantwortlich bleibt die Stelle, die den Code verantwortet.',
      ],
      bullets: [
        'Statischer Code: keine Übertragung, kein Dritter, nichts zu erklären',
        'Weiterleitungscode: Scan wird über einen Dienst geleitet und dort protokolliert',
        'Bei Weiterleitungscodes gehört ein Abschnitt in die Datenschutzerklärung',
        'Für Formulare hinter dem Code braucht es einen eigenen Datenschutzhinweis',
      ],
    },
    {
      title: 'Wann ist Werbung hinter einem QR-Code unzulässig?',
      body: [
        'Wird über einen Code eine Werbung ausgelöst, die beim Öffnen nicht als solche erkennbar ist, kann das nach § 5a UWG unzulässig sein. Das gilt für getarnte Werbeangebote genauso wie für bezahlte Inhalte, die wie eine redaktionelle Empfehlung aussehen.',
        'Praktisch betrifft das vor allem Codes, die auf Affiliate-Links zeigen, ohne dass der Empfänger den kommerziellen Charakter erkennt. Ein Code auf einem Plakat, der zu einer Produktseite führt, ist offensichtlich Werbung. Ein Code in einem redaktionellen Bericht, der zu einem Anbieter führt, ist es nicht.',
      ],
    },
    {
      title: 'Braucht die Speisekarte in der Gastronomie einen QR-Code?',
      body: [
        'Die coronabedingte Pflicht zur digitalen Speisekarte ist ausgelaufen. Auch die Preisangabenverordnung verlangt nicht, dass die Karte über einen Code abrufbar ist.',
        'Wenn eine Speisekarte über einen Code angeboten wird, dann zusätzlich zur Karte in Papierform, gilt weiter, was auch sonst gilt: Die Preise müssen vollständig und korrekt sein, Allergenkennzeichnungen werden nach LMIV benötigt, und die Seite muss mit einem Telefon ohne zusätzliche App lesbar sein.',
      ],
      bullets: [
        'Keine Pflicht zu Speisekarte per QR-Code in Deutschland',
        'Preise und Allergene auf der digitalen Karte müssen vollständig sein',
        'Die Karte sollte ohne App und ohne Anmeldung erreichbar sein',
      ],
    },
  ],
  faq: [
    {
      q: 'Muss ein QR-Code auf der Rechnung stehen?',
      a: 'Nein. § 14 UStG und § 33 UStDV nennen die Pflichtangaben einer Rechnung, ein QR-Code ist nicht darunter. Er darf freiwillig gesetzt werden, ersetzt aber keine Angabe in Textform.',
    },
    {
      q: 'Ist ein QR-Code im Impressum erlaubt?',
      a: 'Ja, die Anbieterkennzeichnung darf zusätzlich per Code erreichbar sein. Der Code sollte auf die Impressumsseite zeigen und nicht auf ein PDF, das nicht mitgepflegt wird. Die Angaben müssen auch ohne den Code auffindbar bleiben.',
    },
    {
      q: 'Werden Scans personenbezogen gespeichert?',
      a: 'Bei einem statischen Code nicht, weil nichts übertragen wird. Bei einem Weiterleitungscode werden Gerät, Zeitpunkt und IP-Adresse technisch verarbeitet, damit die Zieladresse austauschbar bleibt. Das gehört in die Datenschutzerklärung.',
    },
    {
      q: 'Brauche ich eine Einwilligung für einen QR-Code?',
      a: 'Für einen statischen Code nicht, er verarbeitet keine Daten. Für ein Formular, ein Tracking-Pixel oder einen Newsletter hinter dem Code ist eine Rechtsgrundlage erforderlich, je nach Zweck Einwilligung oder berechtigtes Interesse.',
    },
    {
      q: 'Ist der QR-Code auf dem Kassenbon Pflicht?',
      a: 'Nein. Die Belegausgabe nach § 6 KassenSichV verlangt einen Beleg, keinen QR-Code. In der Praxis dient der Code auf dem Bon häufig dazu, den Bon digital nachzuladen.',
    },
    {
      q: 'Darf ich einen fremden QR-Code nachdrucken?',
      a: 'Nur mit Berechtigung. Der Code selbst ist ein technisches Muster, aber das Ziel und der verbundene Inhalt können urheberrechtlich oder markenrechtlich geschützt sein. Bei einem fremden Code ist das Ziel zudem oft nicht erkennbar, daher nie ungeprüft übernehmen.',
    },
  ],
  subs: [],
  consolidated: [],
};

export const HILFE_HUB: SeoHub = {
  slug: 'qr-code-funktioniert-nicht',
  basePath: '/qr-code-funktioniert-nicht',
  label: 'Fehlersuche',
  title: 'QR-Code wird nicht erkannt: Ursachen und Abhilfe',
  metaTitle: 'QR-Code wird nicht erkannt: Ursachen und Lösungen',
  metaDescription:
    'Der QR-Code wird nicht gescannt? Vier Ursachen erklären fast jeden Fall: Größe, Kontrast, Rand, Oberfläche. Mit Prüfreihenfolge und Druckmaßen.',
  intro: [
    'Wenn ein QR-Code nicht gelesen wird, liegt es selten am Scanner und fast immer am Aufdruck. Die Reihenfolge der Prüfung ist entscheidend, weil sich die häufigsten Ursachen an einer Stelle beheben lassen und die seltenen an einer anderen.',
    'Diese Seite arbeitet die vier häufigen Ursachen in der Reihenfolge ab, in der sie sich prüfen lassen: Kantenlänge, Kontrast, Ruhezone und Oberfläche. Dazu die Fälle, in denen das Telefon selbst die Ursache ist.',
  ],
  sources: [
    {
      label: 'ISO/IEC 18004: QR-Code-Symbologie (Modulgröße, Ruhezone)',
      href: 'https://www.iso.org/standard/62021.html',
    },
  ],
  sections: [
    {
      title: 'Ursache 1: der Code ist zu klein',
      body: [
        'Ein QR-Code besteht aus Modulen. Die Kamera muss jedes einzelne Modul auflösen können, deshalb wächst die nötige Kantenlänge mit dem Leseabstand. Die Faustregel lautet: Abstand in Metern geteilt durch 10, mindestens aber 2,5 Zentimeter.',
        'Auf einer Visitenkarte liest man aus etwa 30 Zentimetern, damit reichen 2,5 bis 3 Zentimeter. Ein Aushang an der Haustür wird aus ein bis zwei Metern gelesen, dort braucht es 10 bis 20 Zentimeter. Ein Plakat, das aus fünf Metern gelesen wird, braucht rund 50 Zentimeter.',
        'Ein zweiter Faktor kommt bei dichten Inhalten dazu: Je mehr Zeichen im Code stehen, desto mehr Module hat er, und desto größer muss er bei gleichem Abstand sein. Eine lange URL mit Kampagnenparametern braucht deshalb mehr Fläche als eine kurze Adresse.',
      ],
      bullets: [
        '30 cm Leseabstand: mindestens 3 cm Kantenlänge',
        '1 m Leseabstand: etwa 10 cm',
        '5 m Leseabstand: etwa 50 cm',
        'Lange Links brauchen mehr Fläche als kurze',
      ],
    },
    {
      title: 'Ursache 2: zu wenig Kontrast',
      body: [
        'Der Scanner erwartet dunkle Module auf hellem Grund. Der Kontrast zwischen beiden muss ausreichen, damit die Bildverarbeitung eine Schwelle ziehen kann. Grau auf Weiß ist der häufigste Fehler, danach kommt Gelb auf Weiß.',
        'Für den Kontrast gibt es keine gesetzliche Vorgabe, aber eine brauchbare Praxis: Der Helligkeitsunterschied sollte mindestens 40 Prozent betragen, gerechnet nach WCAG. Ein mittleres Grau auf Weiß erreicht das nicht. Zusätzlich darf der Code im Druck nicht zu dunkel hinterlegt werden, sonst verliert er beim Kopieren die Schwelle.',
      ],
      bullets: [
        'Dunkle Module auf hellem Grund, nicht umgekehrt',
        'Kein Grau und kein Gelb als Modulfarbe auf weißem Papier',
        'Beim Kopieren prüfen, ob der Kontrast erhalten bleibt',
        'Ein Farbcode ist zulässig, solange der Helligkeitsunterschied bleibt',
      ],
    },
    {
      title: 'Ursache 3: fehlende Ruhezone',
      body: [
        'Die Ruhezone ist der leere Rand um das Muster. Ohne sie findet die Software den Rand des Codes nicht und rechnet nicht los. Der Standard verlangt vier Module Rand auf allen Seiten.',
        'In der Praxis entsteht das Problem, wenn ein Code freigestellt wird, ein Rahmen direkt am Muster klebt oder das Layout den Code bis an die Kante beschneidet. Ein Rahmen mit ein bis zwei Zentimetern Abstand ist unproblematisch, ein Rahmen direkt auf dem Muster nicht.',
      ],
      bullets: [
        'Vier Module Rand rundherum, bei 3 cm Codegröße etwa 5 mm',
        'Ein dekorativer Rahmen darf das Muster nicht berühren',
        'Der Code darf nicht über eine Papierkante laufen',
      ],
    },
    {
      title: 'Ursache 4: die Oberfläche',
      body: [
        'Glänzendes Papier, Laminat, Glas und Displayspiegelungen zerstören den Kontrast dort, wo das Licht reflektiert. Unter einer Glasscheibe funktioniert ein Code bei direktem Licht oft nicht, obwohl er im Schatten einwandfrei gelesen wird.',
        'Bei Außenaufstellungen kommt Verwitterung dazu. Tintenstrahldruck auf Normalpapier ist nach einem Winter nicht mehr lesbar. Für dauerhafte Aufstellung gehört der Code auf mattes Material, idealerweise als Druck auf Aluminium oder Kunststoff, oder unter einer matten Scheibe.',
      ],
      bullets: [
        'Matter Druck statt Hochglanz',
        'Kein Code unter Glas mit direktem Lichteinfall',
        'Im Außenbereich mattes, wetterfestes Material',
        'Auf Displays Bildschirmhelligkeit erhöhen statt Code zu vergrößern',
      ],
    },
    {
      title: 'Warum liest das Telefon den Code nicht?',
      body: [
        'Auf dem iPhone liest die Kamera QR-Codes ab iOS 11 direkt im Sucher, ohne Zusatz-App. Wird nichts erkannt, liegt es häufig an einer verschmutzten Linse, an der Zoomstufe oder daran, dass der Code nicht im Sucherrahmen zentriert ist. Ein Neustart der Kamera-App behebt hängende Sitzungen.',
        'Unter Android gibt es je nach Hersteller unterschiedliche Wege. Bei Google Pixel und den meisten Samsung-Geräten ist die Erkennung in der Kamera-App integriert und muss in den Einstellungen aktiviert sein. Fehlt die Funktion, hilft die Google-App über die Lupe oder eine Scanner-App.',
        'In beiden Fällen gilt: Erst näher herangehen, dann die Ebene wechseln. Ein Code auf einem Bildschirm sollte fotografiert und dann aus der Galerie gescannt werden, weil die Kamera sonst zwischen Flimmern und Muster unterscheiden muss.',
      ],
    },
    {
      title: 'Warum führt der Code auf die falsche Seite?',
      body: [
        'Wenn der Scanner den Code erkennt, das Ziel aber nicht aufgeht, liegt es an der Adresse und nicht am Muster. Häufige Ursachen sind ein fehlendes https, ein Tippfehler in der Domain und eine Weiterleitung, deren Ziel nicht mehr existiert.',
        'Bei einem statischen Code lässt sich der Inhalt nicht nachträglich ändern. Wer die Adresse korrigieren will, muss einen neuen Code erzeugen und den alten austauschen. Das ist der Preis dafür, dass kein Dienst dazwischen liegen muss.',
      ],
      bullets: [
        'Zieladresse auf Tippfehler prüfen, besonders bei kurzen Domains',
        'https statt http verwenden',
        'Weiterleitungen prüfen, wenn die Adresse geändert wurde',
        'Ein falscher Code bleibt falsch, er lässt sich nicht umschreiben',
      ],
    },
  ],
  faq: [
    {
      q: 'Warum wird mein QR-Code nicht erkannt?',
      a: 'In den meisten Fällen ist der Aufdruck zu klein, hat zu wenig Kontrast, hat keinen freien Rand, ist glänzend oder liegt hinter Glas. Prüfe in dieser Reihenfolge: Kantenlänge mindestens 3 cm, dunkel auf hell, vier Module Rand, matte Oberfläche ohne Spiegelung.',
    },
    {
      q: 'Wie klein darf ein QR-Code sein?',
      a: 'Nicht kleiner als 2,5 cm Kantenlänge für Inhalte, die aus 30 cm gelesen werden. Bei mehr Inhalt oder größerem Abstand muss er deutlich größer sein. Die Faustregel ist Abstand in Metern geteilt durch 10.',
    },
    {
      q: 'Kann ein QR-Code nachträglich geändert werden?',
      a: 'Ein statischer Code nicht, weil der Inhalt im Muster steckt. Änderbar sind nur Weiterleitungscodes, deren Ziel auf einem fremden Server liegt. Dann liegt die Erreichbarkeit aber in der Hand dieses Anbieters.',
    },
    {
      q: 'Funktioniert ein QR-Code auf dem Handy-Display?',
      a: 'Ja, aber nur mit erhöhter Helligkeit und ohne Reflexion. Bei Problemen hilft es, den Code zu fotografieren und dann aus der Galerie zu scannen, weil dann kein Flimmern mehr im Bild ist.',
    },
    {
      q: 'Brauche ich eine App zum Scannen?',
      a: 'Auf dem iPhone nicht, die Kamera liest Codes seit iOS 11. Bei Android ist die Funktion je nach Hersteller in der Kamera-App vorhanden oder muss aktiviert werden. Eine zusätzliche App ist meist nicht nötig.',
    },
    {
      q: 'Warum funktioniert der Code im Druck, aber nicht auf dem Bildschirm?',
      a: 'Auf einem Bildschirm kommen Flimmern und Spiegelung dazu. Verkleinere den Code nicht, sondern erhöhe die Helligkeit, entferne Reflexe und vermeide eine Skalierung, bei der einzelne Module ungleich breit abgebildet werden.',
    },
  ],
  subs: [],
  consolidated: [],
};
