/**
 * hreflang and canonical helpers.
 *
 * Generated from the locale registry rather than hand-written, so a page can
 * never ship a one-way hreflang (the classic mistake that makes Google ignore
 * the whole cluster).
 */
import type { Metadata } from 'next';
import { SITE_URL, ogImageUrl } from '@/src/lib/site';
import { DEFAULT_LOCALE, LOCALES, localeMeta, localePath, type Locale } from './config';

/**
 * Absolute URL for a locale-neutral path.
 *
 * The root is written *without* a trailing slash, and the same string is used
 * for the canonical, the hreflang alternates and the sitemap `<loc>`. Before
 * this, `'/'` was resolved by Next in three different places and came out as
 * `https://…de/` in the sitemap but `https://…de` in the page head, so the
 * German homepage was declared two ways depending on which surface you read.
 */
export function absoluteUrl(path: string): string {
  if (path.startsWith('http')) return path;
  const clean = path.startsWith('/') ? path : `/${path}`;
  return clean === '/' ? SITE_URL : `${SITE_URL}${clean}`;
}

/**
 * `alternates.languages` for a route, given the path *without* a locale prefix.
 * Every locale points at its own version of the same route, plus x-default.
 */
export function languageAlternates(path = '/'): Record<string, string> {
  const languages: Record<string, string> = {};
  for (const l of LOCALES) {
    languages[l.hreflang] = absoluteUrl(localePath(l.code, path));
  }
  languages['x-default'] = absoluteUrl(localePath(DEFAULT_LOCALE, path));
  return languages;
}

/** Canonical + hreflang + og:locale for one localized page. */
export function localeMetadata({
  locale,
  path,
  title,
  description,
}: {
  locale: Locale;
  path: string;
  title: string;
  description: string;
}): Metadata {
  const meta = localeMeta(locale);
  const canonical = absoluteUrl(localePath(locale, path));
  return {
    title,
    description,
    alternates: {
      canonical,
      languages: languageAlternates(path),
    },
    openGraph: {
      /* English kicker on every locale card, because the card travels outside
         the page's own language context more often than inside it. */
      images: [
        {
          url: ogImageUrl({ title, kicker: 'QR-Generator', colour: 'url' }),
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
      type: 'website',
      title,
      description,
      url: canonical,
      siteName: 'QR-Generator Deutschland',
      /* og:locale wants language_TERRITORY, and htmlLang alone is often just
         the language ('pl'), which Facebook reads as unknown. hreflang carries
         the region, so that is what gets converted. */
      locale: meta.hreflang.replace('-', '_'),
    },
  };
}

/** `lang` and `dir` attributes for <html>. */
export function htmlAttrs(locale: Locale): { lang: string; dir: 'ltr' | 'rtl' } {
  const m = localeMeta(locale);
  return { lang: m.htmlLang, dir: m.dir };
}
