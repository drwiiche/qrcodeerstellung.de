/**
 * Per-locale copy.
 *
 * Written per locale from that locale's own autocomplete data (see TASKS.md),
 * not translated from German. The `local` block is the locale-specific block
 * that makes the page worth its URL: Paczkomat for Polish, Pix for Portuguese,
 * Честный знак for Russian, menu for French and Italian, troubleshooting for
 * Spanish, and so on. Nothing here is a machine translation of a German
 * sentence, and no paragraph is shared between locales.
 *
 * Known limitation, recorded honestly: de/en/fr/es/it/pt/tr/pl/ru were written
 * with high confidence; id/he/ar need a native review before launch.
 */
import type { Locale } from './config';

export interface LocaleDict {
  meta: { title: string; description: string };
  nav: { generator: string; howItWorks: string; faq: string; why: string; language: string; menu: string };
  hero: {
    eyebrow: string;
    titleTop: string;
    titleAccent: string;
    lead: string;
    cta: string;
    facts: { term: string; desc: string }[];
  };
  types: { title: string; lead: string };
  typeNames: Record<string, string>;
  how: { title: string; lead: string; steps: { title: string; text: string }[] };
  why: { title: string; lead: string; items: { title: string; text: string }[] };
  local: { eyebrow: string; title: string; body: string[]; points: string[] };
  faq: { title: string; items: { q: string; a: string }[] };
  cta: { title: string; lead: string; button: string; hint: string };
  footer: {
    tagline: string;
    note: string;
    tools: string;
    legal: string;
    /*
     * The legal pages (Impressum, Datenschutz, AGB) exist only in German
     * because they are the version that binds. This line says so in the
     * reader's language instead of dropping a German-only link with no
     * explanation.
     */
    legalNote: string;
  };
}

const de: LocaleDict = {
  meta: {
    title: 'QR-Code erstellen: kostenlos, ohne Konto, ohne Ablaufdatum',
    description:
      'QR-Codes im Browser erzeugen: WLAN für Fritz!Box, SEPA GiroCode, Visitenkarte, Paket-Abstellort. Als SVG für den Druck oder PNG bis 2048 px, ohne Anmeldung.',
  },
  nav: { generator: 'Generator', howItWorks: 'Ablauf', faq: 'Fragen', why: 'Warum', language: 'Sprache', menu: 'Menü' },
  hero: {
    eyebrow: 'Kostenlos, ohne Konto, ohne Ablaufdatum',
    titleTop: 'QR-Code erstellen.',
    titleAccent: 'Fertig in einer Minute.',
    lead:
      'Gäste-WLAN für Fritz!Box und Speedport, GiroCode für Überweisungen, Abstellort für Pakete, Visitenkarte fürs Telefon. Der Code entsteht in Ihrem Browser, die Eingaben bleiben auf Ihrem Gerät.',
    cta: 'Code erstellen',
    facts: [
      { term: 'Ohne Konto', desc: 'keine Anmeldung' },
      { term: 'Im Browser', desc: 'kein Upload' },
      { term: 'SVG und PNG', desc: 'bis 2048 px' },
    ],
  },
  types: {
    title: 'Was soll der Code öffnen?',
    lead: 'Zwölf Typen, jeder mit eigener Farbe. Wählen Sie den Typ, das Formular fragt nur, was dafür nötig ist.',
  },
  typeNames: {
    url: 'Webseite',
    wifi: 'WLAN',
    sepa: 'SEPA GiroCode',
    vcard: 'Visitenkarte',
    delivery: 'Paket-Abstellort',
    standort: 'Standort',
    event: 'Termin',
    phone: 'Telefonnummer',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'E-Mail',
    text: 'Freitext',
  },
  how: {
    title: 'Vier Schritte, kein Konto.',
    lead: 'Der ganze Ablauf spielt sich auf einer Seite ab. Typ wechseln ist jederzeit möglich, die Eingaben bleiben erhalten.',
    steps: [
      { title: 'Typ wählen', text: 'WLAN, GiroCode, Visitenkarte, Paket, Standort, SMS. Der Typ bestimmt das Formular.' },
      { title: 'Daten eintragen', text: 'Nur die Felder, die dieser Typ braucht. Die Vorschau folgt beim Tippen.' },
      { title: 'Aussehen prüfen', text: 'Farben, Ecken und Rahmen anpassen. Der Scan-Test warnt, bevor Sie drucken.' },
      { title: 'Herunterladen', text: 'SVG für die Druckerei, PNG bis 2048 px für Aushang und Bildschirm.' },
    ],
  },
  why: {
    title: 'Was dieses Werkzeug anders macht',
    lead: 'Kein Konto, kein Ablaufdatum, keine Weiterleitung dazwischen.',
    items: [
      { title: 'Der Code entsteht lokal', text: 'Die Eingaben werden in Ihrem Browser verarbeitet. Passwort, IBAN und Netzname gehen nicht an einen Server.' },
      { title: 'Statisch heißt dauerhaft', text: 'Der Inhalt steckt im Muster selbst. Kein Dienst dazwischen, der abgeschaltet werden kann, keine Scan-Grenze.' },
      { title: 'Für Papier gebaut', text: 'SVG skaliert verlustfrei auf jede Größe. Dazu die Faustregeln für Kantenlänge, Ruhezone und Kontrast.' },
    ],
  },
  local: {
    eyebrow: 'In Deutschland',
    title: 'Rechtliches, das oft gefragt wird',
    body: [
      'Sehr viele Anfragen drehen sich um dieselbe Frage: Muss ein QR-Code auf der Rechnung oder im Impressum stehen, und was muss dann dahinterliegen?',
      'Die kurze Antwort: Eine gesetzliche Pflicht, einen QR-Code auf Rechnungen abzubilden, gibt es in Deutschland nicht. Wer ihn freiwillig setzt, muss aber die Ziele einhalten, die das UWG und die DSGVO an Werbung und Datenerhebung stellen.',
    ],
    points: [
      'Auf der Rechnung: freiwillig, aber der Link muss zu eigenen Leistungen oder Angeboten führen',
      'Im Impressum: der Code darf auf die Impressumsseite führen, nicht auf ein PDF mit veralteten Angaben',
      'Bei Formularen hinter dem Code: Datenschutzhinweis und Rechtsgrundlage sind Ihre Aufgabe, nicht die des Werkzeugs',
    ],
  },
  faq: {
    title: 'Fragen, die bleiben.',
    items: [
      { q: 'Landen mein WLAN-Passwort oder meine IBAN auf einem Server?', a: 'Nein. Der Code wird in Ihrem Browser berechnet, die Formulardaten werden nicht an einen Server geschickt. Es gibt keine Anmeldung und kein Konto, in dem die Eingaben liegen könnten.' },
      { q: 'Verfallen die Codes oder gibt es Scan-Limits?', a: 'Nein. Es sind statische Codes: Der Inhalt steht im Muster selbst. Sie funktionieren unbegrenzt oft und ändern sich nicht, solange Sie den Code nicht neu erzeugen.' },
      { q: 'Wie groß muss der Code für die Haustür sein?', a: 'Mindestens 3 cm Kantenlänge bei 30 cm Leseabstand, etwa 10 cm bei einem Meter. Als Faustregel gilt: Abstand in Metern geteilt durch 10, mindestens aber 2,5 cm.' },
      { q: 'Was kostet die Nutzung?', a: 'Nichts. Keine Wasserzeichen, keine Begrenzung der Anzahl, kein Tarif. Werbeplätze auf der Seite laden nur mit Ihrer Zustimmung.' },
    ],
  },
  cta: {
    title: 'Der Generator',
    lead: 'Zwölf Typen, Live-Vorschau, Export als SVG und PNG.',
    button: 'Zum Generator',
    hint: 'Die Werkzeugsprache ist derzeit Deutsch.',
  },
  footer: {
    tagline: 'Ein kostenloses Werkzeug für QR-Codes, die im Alltag gebraucht werden.',
    note: 'Codes werden lokal im Browser erzeugt.',
    tools: 'Werkzeug',
    legal: 'Rechtliches',
    legalNote: 'Rechtstexte nur auf Deutsch, verbindlich ist die deutsche Fassung.',
  },
};

const en: LocaleDict = {
  meta: {
    title: 'Free QR code generator: no account, no expiry date',
    description:
      'Make QR codes in your browser: guest Wi-Fi, SEPA transfer codes, vCards, parcel drop-off notes. Vector SVG for print or PNG up to 2048 px, no sign-up.',
  },
  nav: { generator: 'Generator', howItWorks: 'How it works', faq: 'Questions', why: 'Why this one', language: 'Language', menu: 'Menu' },
  hero: {
    eyebrow: 'Free, no account, no expiry date',
    titleTop: 'Make a QR code.',
    titleAccent: 'Done in a minute.',
    lead:
      'Guest Wi-Fi for your router, a payment code for your bank app, a drop-off note for parcels, a contact card for your phone. The code is generated in your browser and your input stays on your device.',
    cta: 'Open the generator',
    facts: [
      { term: 'No account', desc: 'no sign-up' },
      { term: 'In your browser', desc: 'nothing uploaded' },
      { term: 'SVG and PNG', desc: 'up to 2048 px' },
    ],
  },
  types: {
    title: 'What should the code open?',
    lead: 'Twelve types, each with its own colour. Pick one and the form only asks for what that type needs.',
  },
  typeNames: {
    url: 'Website',
    wifi: 'Wi-Fi',
    sepa: 'SEPA transfer',
    vcard: 'Contact card',
    delivery: 'Parcel drop-off',
    standort: 'Location',
    event: 'Calendar event',
    phone: 'Phone number',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'Email',
    text: 'Plain text',
  },
  how: {
    title: 'Four steps, no account.',
    lead: 'The whole flow happens on one page. You can switch type at any point and your input is kept.',
    steps: [
      { title: 'Pick a type', text: 'Wi-Fi, transfer, contact card, parcel, location, SMS. The type decides the form.' },
      { title: 'Enter the details', text: 'Only the fields that type actually needs. The preview follows as you type.' },
      { title: 'Check how it looks', text: 'Adjust colours, corners and frame. The scan test warns you before you print.' },
      { title: 'Download', text: 'SVG for a print shop, PNG up to 2048 px for a screen or a notice board.' },
    ],
  },
  why: {
    title: 'What is different here',
    lead: 'No account, no expiry date, no redirect service in between.',
    items: [
      { title: 'The code is generated locally', text: 'Your input is processed in your browser. Passwords, IBANs and network names never reach a server.' },
      { title: 'Static means permanent', text: 'The content lives inside the pattern itself. No service that can be switched off, and no scan limit.' },
      { title: 'Built for paper', text: 'SVG scales losslessly to any size, plus the rules for edge length, quiet zone and contrast.' },
    ],
  },
  local: {
    eyebrow: 'Practical notes',
    title: 'Print size, and the "no expiry" question',
    body: [
      'The two questions that come up most often are how large a code has to be and whether a free code stops working after a while.',
      'Both have concrete answers. Size follows viewing distance, not taste. And a static code has no expiry because there is no service behind it to expire.',
    ],
    points: [
      'Shortcut for size: distance in metres divided by 10, never below 2.5 cm',
      'A business card needs 2.5 to 3 cm, a poster read from 5 m needs about 50 cm',
      'Dynamic codes from paid services can expire; static codes generated here cannot',
    ],
  },
  faq: {
    title: 'Questions people actually ask',
    items: [
      { q: 'Does my Wi-Fi password leave the browser?', a: 'No. The pattern is computed on your device. There is no account where the data could be stored, and nothing is uploaded.' },
      { q: 'Is there a scan limit or an expiry date?', a: 'Neither. A static code carries its content in the pattern itself, so it keeps working for as long as the printed surface lasts.' },
      { q: 'How big does the code need to be for print?', a: 'At least 2.5 cm for something held in the hand, around 10 cm for a notice read from a metre away, and about 50 cm for a poster at 5 m.' },
      { q: 'Can I use the files commercially?', a: 'Yes. The exported files are yours to use on menus, invoices, vehicles, posters and packaging without attribution.' },
    ],
  },
  cta: {
    title: 'The generator',
    lead: 'Twelve types, live preview, SVG and PNG export.',
    button: 'Open the generator',
    hint: 'The tool interface is currently in German.',
  },
  footer: {
    tagline: 'A free tool for QR codes that get used in real life.',
    note: 'Codes are generated locally in your browser.',
    tools: 'Tool',
    legal: 'Legal',
    legalNote: 'Legal pages are in German, and the German version is the binding one.',
  },
};

const fr: LocaleDict = {
  meta: {
    title: 'Générateur de QR code gratuit : sans compte, sans expiration',
    description:
      'Créez un QR code dans votre navigateur : Wi-Fi invité, virement SEPA, carte de visite, consigne de colis. SVG vectoriel, sans inscription.',
  },
  nav: { generator: 'Générateur', howItWorks: 'Étapes', faq: 'Questions', why: 'Pourquoi', language: 'Langue', menu: 'Menu' },
  hero: {
    eyebrow: 'Gratuit, sans compte, sans date d’expiration',
    titleTop: 'Créez votre QR code.',
    titleAccent: 'Prêt en une minute.',
    lead:
      'Wi-Fi invité pour la box, virement pour l’application bancaire, consigne de colis, carte de visite pour le téléphone. Le code est calculé dans votre navigateur, vos données restent sur votre appareil.',
    cta: 'Ouvrir le générateur',
    facts: [
      { term: 'Sans compte', desc: 'aucune inscription' },
      { term: 'Dans le navigateur', desc: 'aucun envoi' },
      { term: 'SVG et PNG', desc: 'jusqu’à 2048 px' },
    ],
  },
  types: {
    title: 'Que doit ouvrir le code ?',
    lead: 'Douze types, chacun avec sa couleur. Choisissez-en un : le formulaire ne demande que les champs nécessaires.',
  },
  typeNames: {
    url: 'Site web',
    wifi: 'Wi-Fi',
    sepa: 'Virement SEPA',
    vcard: 'Carte de visite',
    delivery: 'Consigne colis',
    standort: 'Lieu',
    event: 'Rendez-vous',
    phone: 'Téléphone',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'E-mail',
    text: 'Texte',
  },
  how: {
    title: 'Quatre étapes, sans compte.',
    lead: 'Tout se passe sur une seule page. Vous pouvez changer de type à tout moment, vos saisies sont conservées.',
    steps: [
      { title: 'Choisir le type', text: 'Wi-Fi, virement, carte de visite, colis, lieu, SMS. Le type détermine le formulaire.' },
      { title: 'Saisir les données', text: 'Uniquement les champs utiles. L’aperçu se met à jour pendant la saisie.' },
      { title: 'Vérifier le rendu', text: 'Couleurs, coins et cadre. Le test de lecture prévient avant l’impression.' },
      { title: 'Télécharger', text: 'SVG pour l’imprimeur, PNG jusqu’à 2048 px pour un écran ou un affichage.' },
    ],
  },
  why: {
    title: 'Ce qui change ici',
    lead: 'Pas de compte, pas d’expiration, pas de service de redirection entre les deux.',
    items: [
      { title: 'Le code est calculé localement', text: 'Les données sont traitées dans votre navigateur. Mot de passe, IBAN et nom du réseau ne partent pas sur un serveur.' },
      { title: 'Statique veut dire durable', text: 'Le contenu est dans le motif lui-même. Aucun service à couper, aucune limite de scans.' },
      { title: 'Conçu pour le papier', text: 'Le SVG monte en taille sans perte, avec les règles de taille, de zone de silence et de contraste.' },
    ],
  },
  local: {
    eyebrow: 'Côté restaurant',
    title: 'Le menu à table : ce qui marche vraiment',
    body: [
      'En restauration, la question du menu par QR code revient sans arrêt. Le problème n’est presque jamais le code, c’est la page derrière : un PDF en paysage que personne ne peut lire sur un téléphone.',
      'La solution est une page normale, avec un titre par service, mise à jour par le restaurant. La carte papier reste à table comme solution de repli quand le réseau ne passe pas.',
    ],
    points: [
      'Un chevalet par table suffit, un code différent par table n’apporte rien sans outil de suivi',
      'Compter au moins 3 cm de côté pour une lecture à 30 cm',
      'Éviter le code derrière une vitre : le reflet empêche la lecture en terrasse',
    ],
  },
  faq: {
    title: 'Les questions qui reviennent',
    items: [
      { q: 'Mes données passent-elles par un serveur ?', a: 'Non. Le motif est calculé dans votre navigateur. Il n’y a ni compte ni stockage côté serveur, et rien n’est envoyé.' },
      { q: 'Le code expire-t-il ?', a: 'Non. Un code statique contient l’information dans le motif. Il fonctionne indéfiniment, sans limite de scans.' },
      { q: 'Quelle taille pour une table de restaurant ?', a: 'Comptez 3 cm minimum pour une lecture à 30 cm, et 5 cm pour un chevalet lu depuis un peu plus loin.' },
      { q: 'Puis-je l’utiliser à titre professionnel ?', a: 'Oui. Les fichiers exportés vous appartiennent : carte, addition, vitrine, flyer ou plaque.' },
    ],
  },
  cta: {
    title: 'Le générateur',
    lead: 'Douze types, aperçu en direct, export SVG et PNG.',
    button: 'Ouvrir le générateur',
    hint: 'L’interface de l’outil est actuellement en allemand.',
  },
  footer: {
    tagline: 'Un outil gratuit pour les QR codes qui servent vraiment.',
    note: 'Les codes sont générés localement dans le navigateur.',
    tools: 'Outil',
    legal: 'Mentions légales',
    legalNote: 'Les pages juridiques sont en allemand, seule la version allemande fait foi.',
  },
};

const es: LocaleDict = {
  meta: {
    title: 'Generador de código QR gratis: sin cuenta y sin caducidad',
    description:
      'Crea códigos QR en el navegador: wifi para invitados, transferencia SEPA, tarjeta de visita, aviso para el repartidor. SVG o PNG hasta 2048 px.',
  },
  nav: { generator: 'Generador', howItWorks: 'Cómo funciona', faq: 'Preguntas', why: 'Por qué este', language: 'Idioma', menu: 'Menú' },
  hero: {
    eyebrow: 'Gratis, sin cuenta, sin caducidad',
    titleTop: 'Crea tu código QR.',
    titleAccent: 'Listo en un minuto.',
    lead:
      'Wifi de invitados para el router, transferencia para la app del banco, aviso de entrega para el repartidor, tarjeta de contacto para el móvil. El código se genera en tu navegador y los datos se quedan en tu dispositivo.',
    cta: 'Abrir el generador',
    facts: [
      { term: 'Sin cuenta', desc: 'sin registro' },
      { term: 'En tu navegador', desc: 'nada se sube' },
      { term: 'SVG y PNG', desc: 'hasta 2048 px' },
    ],
  },
  types: {
    title: '¿Qué debe abrir el código?',
    lead: 'Doce tipos, cada uno con su color. Elige uno y el formulario solo pedirá lo necesario.',
  },
  typeNames: {
    url: 'Sitio web',
    wifi: 'Wifi',
    sepa: 'Transferencia SEPA',
    vcard: 'Tarjeta de visita',
    delivery: 'Aviso de entrega',
    standort: 'Ubicación',
    event: 'Cita',
    phone: 'Teléfono',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'Correo',
    text: 'Texto',
  },
  how: {
    title: 'Cuatro pasos, sin cuenta.',
    lead: 'Todo ocurre en una sola página. Puedes cambiar de tipo cuando quieras sin perder lo escrito.',
    steps: [
      { title: 'Elegir el tipo', text: 'Wifi, transferencia, tarjeta, paquete, ubicación, SMS. El tipo decide el formulario.' },
      { title: 'Rellenar los datos', text: 'Solo los campos que ese tipo necesita. La vista previa se actualiza al escribir.' },
      { title: 'Revisar el aspecto', text: 'Colores, esquinas y marco. La prueba de escaneo avisa antes de imprimir.' },
      { title: 'Descargar', text: 'SVG para imprenta, PNG hasta 2048 px para pantalla o cartel.' },
    ],
  },
  why: {
    title: 'Qué cambia aquí',
    lead: 'Sin cuenta, sin caducidad y sin servicio de redirección en medio.',
    items: [
      { title: 'El código se genera en local', text: 'Los datos se procesan en tu navegador. Contraseñas, IBAN y nombres de red no salen de tu equipo.' },
      { title: 'Estático significa permanente', text: 'El contenido está dentro del propio patrón. No hay servicio que se pueda cerrar ni límite de escaneos.' },
      { title: 'Pensado para papel', text: 'El SVG escala sin pérdida, con reglas de tamaño, zona de silencio y contraste.' },
    ],
  },
  local: {
    eyebrow: 'Si no funciona',
    title: 'El código no se lee: por dónde empezar',
    body: [
      'En español la búsqueda más habitual después de "crear" es la de solución de problemas: el código está impreso, pero el móvil no lo abre.',
      'Casi siempre son cuatro causas: demasiado pequeño, poco contraste, sin margen alrededor del patrón, o una superficie que refleja. Se comprueban en ese orden y en dos minutos.',
    ],
    points: [
      'Tamaño: menos de 2,5 cm falla con cámaras antiguas; súbelo antes de tocar nada más',
      'Contraste: patrón oscuro sobre fondo muy claro; el gris claro sobre blanco es el error más común',
      'Reflejo: papel brillante o cristal delante del código rompen la lectura con luz directa',
      'Margen: deja libre el equivalente a cuatro módulos alrededor del patrón',
    ],
  },
  faq: {
    title: 'Preguntas frecuentes',
    items: [
      { q: '¿Mis datos se envían a un servidor?', a: 'No. El patrón se calcula en tu navegador. No hay cuenta ni almacenamiento en servidor, y no se sube nada.' },
      { q: '¿El código caduca?', a: 'No. Un código estático lleva la información en el patrón, así que funciona indefinidamente y sin límite de escaneos.' },
      { q: '¿Qué tamaño necesito para imprimir?', a: '2,5 cm como mínimo para algo que se tiene en la mano, unos 10 cm para un cartel leído a un metro y unos 50 cm para un cartel a 5 m.' },
      { q: '¿Puedo usarlo en un negocio?', a: 'Sí. Los archivos son tuyos: carta, factura, vehículo, escaparate o envase.' },
    ],
  },
  cta: {
    title: 'El generador',
    lead: 'Doce tipos, vista previa en directo y exportación SVG y PNG.',
    button: 'Abrir el generador',
    hint: 'La interfaz de la herramienta está por ahora en alemán.',
  },
  footer: {
    tagline: 'Una herramienta gratuita para códigos QR que se usan de verdad.',
    note: 'Los códigos se generan en local, en tu navegador.',
    tools: 'Herramienta',
    legal: 'Aviso legal',
    legalNote: 'Las páginas legales están en alemán y la versión alemana es la que vincula.',
  },
};

const it: LocaleDict = {
  meta: {
    title: 'Generatore di QR code gratis: senza account, senza scadenza',
    description:
      'Crea QR code nel browser: Wi-Fi per gli ospiti, bonifico SEPA, biglietto da visita, nota per il corriere. SVG vettoriale per la stampa o PNG fino a 2048 px.',
  },
  nav: { generator: 'Generatore', howItWorks: 'Come funziona', faq: 'Domande', why: 'Perché questo', language: 'Lingua', menu: 'Menu' },
  hero: {
    eyebrow: 'Gratis, senza account, senza scadenza',
    titleTop: 'Crea il tuo QR code.',
    titleAccent: 'Pronto in un minuto.',
    lead:
      'Wi-Fi ospiti per il router, bonifico per l’app della banca, nota di consegna per il corriere, biglietto da visita per il telefono. Il codice viene calcolato nel browser e i dati restano sul tuo dispositivo.',
    cta: 'Apri il generatore',
    facts: [
      { term: 'Nessun account', desc: 'nessuna registrazione' },
      { term: 'Nel browser', desc: 'niente caricamenti' },
      { term: 'SVG e PNG', desc: 'fino a 2048 px' },
    ],
  },
  types: {
    title: 'Cosa deve aprire il codice?',
    lead: 'Dodici tipi, ognuno con il suo colore. Scegli il tipo e il modulo chiede solo i campi necessari.',
  },
  typeNames: {
    url: 'Sito web',
    wifi: 'Wi-Fi',
    sepa: 'Bonifico SEPA',
    vcard: 'Biglietto da visita',
    delivery: 'Nota di consegna',
    standort: 'Posizione',
    event: 'Appuntamento',
    phone: 'Telefono',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'Email',
    text: 'Testo',
  },
  how: {
    title: 'Quattro passaggi, senza account.',
    lead: 'Tutto avviene su una sola pagina. Puoi cambiare tipo in qualsiasi momento e i dati restano.',
    steps: [
      { title: 'Scegli il tipo', text: 'Wi-Fi, bonifico, biglietto, pacco, posizione, SMS. Il tipo determina il modulo.' },
      { title: 'Inserisci i dati', text: 'Solo i campi necessari. L’anteprima si aggiorna mentre scrivi.' },
      { title: 'Controlla l’aspetto', text: 'Colori, angoli e cornice. Il test di lettura avvisa prima di stampare.' },
      { title: 'Scarica', text: 'SVG per la tipografia, PNG fino a 2048 px per schermo o cartello.' },
    ],
  },
  why: {
    title: 'Cosa cambia qui',
    lead: 'Nessun account, nessuna scadenza, nessun servizio di reindirizzamento in mezzo.',
    items: [
      { title: 'Il codice nasce in locale', text: 'I dati sono elaborati nel browser. Password, IBAN e nome della rete non arrivano a un server.' },
      { title: 'Statico vuol dire permanente', text: 'Il contenuto sta nel motivo stesso. Nessun servizio che può chiudere, nessun limite di scansioni.' },
      { title: 'Pensato per la carta', text: 'SVG scala senza perdita, con le regole di dimensione, zona di silenzio e contrasto.' },
    ],
  },
  local: {
    eyebrow: 'Ristorazione',
    title: 'Il menù al tavolo: cosa funziona davvero',
    body: [
      'In Italia il QR code per il menù è ormai normale, ma spesso male: un PDF orizzontale che sul telefono nessuno riesce a leggere.',
      'La parte che funziona è una pagina normale, con un titolo per portata, aggiornata dal ristorante. Il menù di carta resta al tavolo come riserva quando la rete non prende.',
    ],
    points: [
      'Un segnaposto per tavolo basta: un codice diverso per tavolo non serve senza strumenti di analisi',
      'Almeno 3 cm di lato per una lettura a 30 cm',
      'Mai dietro il vetro: il riflesso blocca la lettura in terrazza',
      'Il codice per le recensioni va sullo scontrino, non sull’uscita',
    ],
  },
  faq: {
    title: 'Le domande che tornano',
    items: [
      { q: 'I miei dati passano da un server?', a: 'No. Il motivo è calcolato nel browser. Non ci sono account né archivio sul server, e nulla viene caricato.' },
      { q: 'Il codice scade?', a: 'No. Un codice statico contiene l’informazione nel motivo, quindi funziona senza scadenza e senza limite di scansioni.' },
      { q: 'Che dimensione serve per il menù?', a: 'Almeno 3 cm per un segnaposto letto da 30 cm, 5 cm se il tavolo è più grande o la luce è bassa.' },
      { q: 'Posso usarlo per lavoro?', a: 'Sì. I file esportati sono tuoi: menù, scontrino, vetrina, volantino, targa.' },
    ],
  },
  cta: {
    title: 'Il generatore',
    lead: 'Dodici tipi, anteprima dal vivo, esportazione SVG e PNG.',
    button: 'Apri il generatore',
    hint: 'L’interfaccia dello strumento è per ora in tedesco.',
  },
  footer: {
    tagline: 'Uno strumento gratuito per QR code che si usano davvero.',
    note: 'I codici sono generati in locale nel browser.',
    tools: 'Strumento',
    legal: 'Note legali',
    legalNote: 'Le pagine legali sono in tedesco e fa fede la versione tedesca.',
  },
};

const pt: LocaleDict = {
  meta: {
    title: 'Gerador de QR code grátis: sem conta e sem validade',
    description:
      'Crie QR codes no navegador: Wi-Fi para visitantes, transferência, cartão de visita, aviso para o entregador. SVG vetorial para impressão ou PNG até 2048 px.',
  },
  nav: { generator: 'Gerador', howItWorks: 'Como funciona', faq: 'Dúvidas', why: 'Por que este', language: 'Idioma', menu: 'Menu' },
  hero: {
    eyebrow: 'Grátis, sem conta, sem validade',
    titleTop: 'Crie seu QR code.',
    titleAccent: 'Pronto em um minuto.',
    lead:
      'Wi-Fi para visitantes, transferência para o app do banco, aviso de entrega para o entregador, cartão de contato para o celular. O código é gerado no navegador e os dados ficam no seu aparelho.',
    cta: 'Abrir o gerador',
    facts: [
      { term: 'Sem conta', desc: 'sem cadastro' },
      { term: 'No navegador', desc: 'nada é enviado' },
      { term: 'SVG e PNG', desc: 'até 2048 px' },
    ],
  },
  types: {
    title: 'O que o código deve abrir?',
    lead: 'Doze tipos, cada um com sua cor. Escolha um e o formulário pede só o necessário.',
  },
  typeNames: {
    url: 'Site',
    wifi: 'Wi-Fi',
    sepa: 'Transferência',
    vcard: 'Cartão de visita',
    delivery: 'Aviso de entrega',
    standort: 'Localização',
    event: 'Compromisso',
    phone: 'Telefone',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'E-mail',
    text: 'Texto',
  },
  how: {
    title: 'Quatro passos, sem conta.',
    lead: 'Tudo acontece em uma página. Você pode trocar de tipo a qualquer momento sem perder o que digitou.',
    steps: [
      { title: 'Escolher o tipo', text: 'Wi-Fi, transferência, cartão, encomenda, localização, SMS. O tipo define o formulário.' },
      { title: 'Preencher os dados', text: 'Somente os campos necessários. A prévia acompanha a digitação.' },
      { title: 'Conferir o visual', text: 'Cores, cantos e moldura. O teste de leitura avisa antes da impressão.' },
      { title: 'Baixar', text: 'SVG para gráfica, PNG até 2048 px para tela ou cartaz.' },
    ],
  },
  why: {
    title: 'O que muda aqui',
    lead: 'Sem conta, sem validade e sem serviço de redirecionamento no meio.',
    items: [
      { title: 'O código é gerado localmente', text: 'Os dados são processados no navegador. Senhas, IBAN e nome da rede não vão para um servidor.' },
      { title: 'Estático é permanente', text: 'O conteúdo está no próprio padrão. Não há serviço que possa ser desligado nem limite de leituras.' },
      { title: 'Feito para papel', text: 'O SVG escala sem perda, com as regras de tamanho, zona de silêncio e contraste.' },
    ],
  },
  local: {
    eyebrow: 'Pagamentos',
    title: 'QR code do Pix e códigos de pagamento',
    body: [
      'No Brasil, a busca por QR code quase sempre está ligada a pagamento: Pix, boleto, maquininha. É um caso diferente do código de Wi-Fi ou de cardápio, e vale entender a diferença antes de gerar qualquer coisa.',
      'Um código Pix é um padrão do Banco Central (BR Code), com chave, valor e identificador. Este gerador cria códigos de conteúdo genérico e não substitui o aplicativo do seu banco para emitir cobranças Pix.',
    ],
    points: [
      'Para cobrar com Pix, gere o código no app ou no PSP, que assina o padrão BR Code',
      'Um QR de texto ou link não processa pagamento, apenas abre uma página',
      'Para o cardápio, um QR que abre a página do restaurante é o caminho correto',
      'Impressão: no mínimo 2,5 cm, com contraste alto e sem brilho',
    ],
  },
  faq: {
    title: 'Dúvidas frequentes',
    items: [
      { q: 'Meus dados passam por um servidor?', a: 'Não. O padrão é calculado no navegador. Não existe conta nem armazenamento no servidor, e nada é enviado.' },
      { q: 'O código expira?', a: 'Não. Um código estático carrega a informação no padrão, então funciona sem prazo e sem limite de leituras.' },
      { q: 'Qual tamanho usar na impressão?', a: '2,5 cm no mínimo para uso na mão, cerca de 10 cm para um cartaz lido a um metro, e uns 50 cm para cartaz a 5 m.' },
      { q: 'Serve para o cardápio do restaurante?', a: 'Sim, desde que o código abra uma página normal, com títulos por prato, e não um PDF em paisagem.' },
    ],
  },
  cta: {
    title: 'O gerador',
    lead: 'Doze tipos, prévia ao vivo, exportação SVG e PNG.',
    button: 'Abrir o gerador',
    hint: 'A interface da ferramenta está em alemão por enquanto.',
  },
  footer: {
    tagline: 'Uma ferramenta gratuita para QR codes usados de verdade.',
    note: 'Os códigos são gerados localmente no navegador.',
    tools: 'Ferramenta',
    legal: 'Avisos legais',
    legalNote: 'As páginas legais estão em alemão e a versão alemã é a vinculativa.',
  },
};

const tr: LocaleDict = {
  meta: {
    title: 'Ücretsiz QR kod oluşturucu: hesap yok, son kullanma tarihi yok',
    description:
      'Tarayıcıda QR kod oluşturun: misafir Wi-Fi, SEPA havalesi, kartvizit, kurye notu. Baskı için SVG veya 2048 px’e kadar PNG, kayıt gerekmez.',
  },
  nav: { generator: 'Oluşturucu', howItWorks: 'Nasıl çalışır', faq: 'Sorular', why: 'Neden bu', language: 'Dil', menu: 'Menü' },
  hero: {
    eyebrow: 'Ücretsiz, hesap yok, son kullanma tarihi yok',
    titleTop: 'QR kodunu oluşturun.',
    titleAccent: 'Bir dakikada hazır.',
    lead:
      'Modem için misafir Wi-Fi, banka uygulaması için havale kodu, kurye için teslim notu, telefon için kartvizit. Kod tarayıcınızda üretilir, girdiler cihazınızda kalır.',
    cta: 'Oluşturucuyu aç',
    facts: [
      { term: 'Hesap yok', desc: 'kayıt gerekmez' },
      { term: 'Tarayıcıda', desc: 'sunucuya gitmez' },
      { term: 'SVG ve PNG', desc: '2048 px’e kadar' },
    ],
  },
  types: {
    title: 'Kod ne açsın?',
    lead: 'On iki tür, her birinin kendi rengi var. Türü seçin, form yalnızca gereken alanları sorar.',
  },
  typeNames: {
    url: 'Web sitesi',
    wifi: 'Wi-Fi',
    sepa: 'SEPA havalesi',
    vcard: 'Kartvizit',
    delivery: 'Kurye notu',
    standort: 'Konum',
    event: 'Randevu',
    phone: 'Telefon',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'E-posta',
    text: 'Metin',
  },
  how: {
    title: 'Dört adım, hesap yok.',
    lead: 'Tüm akış tek sayfada. Türü istediğiniz an değiştirebilirsiniz, girdiler korunur.',
    steps: [
      { title: 'Türü seçin', text: 'Wi-Fi, havale, kartvizit, kargo, konum, SMS. Tür formu belirler.' },
      { title: 'Bilgileri girin', text: 'Yalnızca o tür için gereken alanlar. Önizleme yazarken güncellenir.' },
      { title: 'Görünümü denetleyin', text: 'Renkler, köşeler ve çerçeve. Tarama testi yazdırmadan önce uyarır.' },
      { title: 'İndirin', text: 'Matbaa için SVG, ekran veya afiş için 2048 px’e kadar PNG.' },
    ],
  },
  why: {
    title: 'Burada ne farklı',
    lead: 'Hesap yok, son kullanma tarihi yok, arada yönlendirme servisi yok.',
    items: [
      { title: 'Kod yerelde üretilir', text: 'Girdiler tarayıcınızda işlenir. Şifre, IBAN ve ağ adı sunucuya gitmez.' },
      { title: 'Statik, kalıcı demektir', text: 'İçerik desenin kendisinde durur. Kapatılabilecek bir servis ya da tarama sınırı yok.' },
      { title: 'Kâğıt için tasarlandı', text: 'SVG kayıpsız büyür; boyut, sessiz alan ve kontrast kurallarıyla birlikte.' },
    ],
  },
  local: {
    eyebrow: 'Restoran ve kafe',
    title: 'Masada menü: Türkiye’de ne işe yarıyor',
    body: [
      'Türkçe aramalarda Wi-Fi’den sonra en güçlü ikinci niyet menü: masadaki QR kodun karta götürmesi bekleniyor.',
      'İşe yarayan çözüm kod değil, arkasındaki sayfa. Yatay PDF telefonda okunmuyor; başlıkları kategori olan normal bir sayfa gerekiyor. Kâğıt menü de masada kalmalı, çünkü internet her zaman çekmiyor.',
    ],
    points: [
      'Masa başına tek kod yeterli; masa bazlı ayrım ancak analiz aracıyla anlam kazanır',
      '30 cm mesafeden okuma için en az 3 cm kenar uzunluğu',
      'Cam arkasına koymayın: yansıma teras ve bahçede okumayı bozar',
      'Değerlendirme kodu hesap fişine, çıkışa değil',
    ],
  },
  faq: {
    title: 'Sık sorulanlar',
    items: [
      { q: 'Wi-Fi şifrem sunucuya gidiyor mu?', a: 'Hayır. Desen tarayıcınızda hesaplanır. Verinin tutulacağı bir hesap yok ve hiçbir şey yüklenmez.' },
      { q: 'Kodun süresi doluyor mu?', a: 'Hayır. Statik kod bilgiyi desenin içinde taşır; süre sınırı ve tarama sınırı yoktur.' },
      { q: 'Baskı için hangi boyut?', a: 'Elde tutulan için en az 2,5 cm, bir metreden okunan afiş için yaklaşık 10 cm, 5 metreden okunan için 50 cm.' },
      { q: 'Ticari olarak kullanabilir miyim?', a: 'Evet. Dışa aktarılan dosyalar sizindir; menü, fiş, araç, vitrin ve ambalajda kullanabilirsiniz.' },
      { q: 'Kodu sonradan değiştirebilir miyim?', a: 'Statik kod içeriği desenin içinde taşır, bu yüzden sonradan değiştirilemez. Değişmesi gereken bir adres için kodu bir kez oluşturup arkasındaki sayfayı güncellemek doğru yol.' },
      { q: 'Kod taranmıyorsa ilk nereye bakılır?', a: 'Kontrast ve sessiz alana. Koyu desen açık zemin üzerinde olmalı, çevresinde en az dört modül boşluk kalmalı ve kod ışığı yansıtan yüzeye basılmamalı.' },
    ],
  },
  cta: {
    title: 'Oluşturucu',
    lead: 'On iki tür, canlı önizleme, SVG ve PNG dışa aktarma.',
    button: 'Oluşturucuyu aç',
    hint: 'Aracın arayüzü şu anda Almanca.',
  },
  footer: {
    tagline: 'Gerçekten kullanılan QR kodlar için ücretsiz bir araç.',
    note: 'Kodlar tarayıcıda yerel olarak üretilir.',
    tools: 'Araç',
    legal: 'Yasal',
    legalNote: 'Hukuki sayfalar Almancadır, bağlayıcı olan Almanca metindir.',
  },
};

const pl: LocaleDict = {
  meta: {
    title: 'Darmowy generator kodów QR: bez konta i bez terminu ważności',
    description:
      'Twórz kody QR w przeglądarce: Wi-Fi dla gości, przelew SEPA, wizytówka, informacja dla kuriera. SVG do druku lub PNG do 2048 px, bez rejestracji.',
  },
  nav: { generator: 'Generator', howItWorks: 'Jak działa', faq: 'Pytania', why: 'Dlaczego ten', language: 'Język', menu: 'Menu' },
  hero: {
    eyebrow: 'Bezpłatnie, bez konta, bez terminu ważności',
    titleTop: 'Wygeneruj kod QR.',
    titleAccent: 'Gotowe w minutę.',
    lead:
      'Wi-Fi dla gości, przelew dla aplikacji banku, informacja dla kuriera, wizytówka do telefonu. Kod powstaje w przeglądarce, a dane zostają na Twoim urządzeniu.',
    cta: 'Otwórz generator',
    facts: [
      { term: 'Bez konta', desc: 'bez rejestracji' },
      { term: 'W przeglądarce', desc: 'nic nie jest wysyłane' },
      { term: 'SVG i PNG', desc: 'do 2048 px' },
    ],
  },
  types: {
    title: 'Co ma otwierać kod?',
    lead: 'Dwanaście typów, każdy w swoim kolorze. Wybierz typ, a formularz zapyta tylko o potrzebne pola.',
  },
  typeNames: {
    url: 'Strona www',
    wifi: 'Wi-Fi',
    sepa: 'Przelew SEPA',
    vcard: 'Wizytówka',
    delivery: 'Informacja dla kuriera',
    standort: 'Lokalizacja',
    event: 'Termin',
    phone: 'Telefon',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'E-mail',
    text: 'Tekst',
  },
  how: {
    title: 'Cztery kroki, bez konta.',
    lead: 'Cały proces na jednej stronie. Typ możesz zmienić w każdej chwili, wpisane dane zostają.',
    steps: [
      { title: 'Wybierz typ', text: 'Wi-Fi, przelew, wizytówka, paczka, lokalizacja, SMS. Typ decyduje o formularzu.' },
      { title: 'Wpisz dane', text: 'Tylko potrzebne pola. Podgląd aktualizuje się podczas pisania.' },
      { title: 'Sprawdź wygląd', text: 'Kolory, narożniki i ramka. Test skanowania ostrzega przed drukiem.' },
      { title: 'Pobierz', text: 'SVG dla drukarni, PNG do 2048 px na ekran lub tablicę.' },
    ],
  },
  why: {
    title: 'Co tu jest inaczej',
    lead: 'Bez konta, bez terminu ważności i bez usługi przekierowania pośrodku.',
    items: [
      { title: 'Kod powstaje lokalnie', text: 'Dane są przetwarzane w przeglądarce. Hasło, IBAN i nazwa sieci nie trafiają na serwer.' },
      { title: 'Statyczny znaczy trwały', text: 'Treść jest w samym wzorze. Nie ma usługi, którą można wyłączyć, ani limitu skanowań.' },
      { title: 'Zrobiony pod papier', text: 'SVG skaluje się bezstratnie, wraz z zasadami rozmiaru, strefy ciszy i kontrastu.' },
    ],
  },
  local: {
    eyebrow: 'Paczkomaty',
    title: 'Kod QR na przesyłce i w Paczkomacie',
    body: [
      'W polskich wyszukiwaniach obok Wi-Fi mocno pojawia się wątek paczek: InPost, Paczkomat, odbiór. To inny przypadek niż kod na wizytówce.',
      'Kod odbioru w aplikacji InPost jest generowany przez operatora i nie da się go zastąpić własnym kodem. Możesz natomiast zrobić własny kod z instrukcją dla kuriera, numerem mieszkania i miejscem zostawienia paczki.',
    ],
    points: [
      'Kod odbioru Paczkomatu pochodzi z aplikacji InPost, nie z generatora',
      'Własny kod dla kuriera: piętro, kod do klatki, miejsce zostawienia paczki',
      'Na drzwiach minimum 3 cm, na tabliczce przy furtce 10 cm',
      'Nie drukuj na zwykłym papierze na zewnątrz; po jednej zimie jest nieczytelny',
    ],
  },
  faq: {
    title: 'Częste pytania',
    items: [
      { q: 'Czy moje dane trafiają na serwer?', a: 'Nie. Wzór jest liczony w przeglądarce. Nie ma konta ani przechowywania na serwerze, nic nie jest wysyłane.' },
      { q: 'Czy kod traci ważność?', a: 'Nie. Kod statyczny ma treść w samym wzorze, więc działa bezterminowo i bez limitu skanowań.' },
      { q: 'Jaki rozmiar do druku?', a: 'Co najmniej 2,5 cm do trzymania w ręce, około 10 cm na tabliczkę czytaną z metra, a 50 cm na plakat z 5 m.' },
      { q: 'Czy mogę użyć komercyjnie?', a: 'Tak. Wyeksportowane pliki są Twoje: menu, faktura, auto, witryna, opakowanie.' },
      { q: 'Czy treść kodu można zmienić później?', a: 'Kod statyczny trzyma treść we własnym wzorze, więc nie da się jej podmienić. Jeśli adres ma się zmieniać, lepiej raz utworzyć kod prowadzący do strony, którą aktualizujesz.' },
    ],
  },
  cta: {
    title: 'Generator',
    lead: 'Dwanaście typów, podgląd na żywo, eksport SVG i PNG.',
    button: 'Otwórz generator',
    hint: 'Interfejs narzędzia jest obecnie po niemiecku.',
  },
  footer: {
    tagline: 'Darmowe narzędzie do kodów QR, które naprawdę się przydają.',
    note: 'Kody są generowane lokalnie w przeglądarce.',
    tools: 'Narzędzie',
    legal: 'Informacje prawne',
    legalNote: 'Strony prawne są po niemiecku, wiążąca jest wersja niemiecka.',
  },
};

const ru: LocaleDict = {
  meta: {
    title: 'Бесплатный генератор QR-кодов: без аккаунта',
    description:
      'Создайте QR-код в браузере: гостевой Wi-Fi, перевод SEPA, визитка, записка для курьера. SVG для печати или PNG до 2048 px, без регистрации.',
  },
  nav: { generator: 'Генератор', howItWorks: 'Как работает', faq: 'Вопросы', why: 'Почему этот', language: 'Язык', menu: 'Меню' },
  hero: {
    eyebrow: 'Бесплатно, без аккаунта, без срока действия',
    titleTop: 'Создайте QR-код.',
    titleAccent: 'Готово за минуту.',
    lead:
      'Гостевой Wi-Fi для роутера, перевод для банковского приложения, записка для курьера, визитка для телефона. Код создаётся в браузере, данные остаются на вашем устройстве.',
    cta: 'Открыть генератор',
    facts: [
      { term: 'Без аккаунта', desc: 'без регистрации' },
      { term: 'В браузере', desc: 'ничего не уходит' },
      { term: 'SVG и PNG', desc: 'до 2048 px' },
    ],
  },
  types: {
    title: 'Что должен открывать код?',
    lead: 'Двенадцать типов, у каждого свой цвет. Выберите тип, и форма спросит только нужные поля.',
  },
  typeNames: {
    url: 'Сайт',
    wifi: 'Wi-Fi',
    sepa: 'Перевод SEPA',
    vcard: 'Визитка',
    delivery: 'Записка курьеру',
    standort: 'Местоположение',
    event: 'Встреча',
    phone: 'Телефон',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'E-mail',
    text: 'Текст',
  },
  how: {
    title: 'Четыре шага, без аккаунта.',
    lead: 'Весь процесс на одной странице. Тип можно сменить в любой момент, введённые данные сохраняются.',
    steps: [
      { title: 'Выберите тип', text: 'Wi-Fi, перевод, визитка, посылка, место, SMS. Тип определяет форму.' },
      { title: 'Введите данные', text: 'Только нужные поля. Предпросмотр обновляется при вводе.' },
      { title: 'Проверьте вид', text: 'Цвета, углы и рамка. Тест сканирования предупредит до печати.' },
      { title: 'Скачайте', text: 'SVG для типографии, PNG до 2048 px для экрана или объявления.' },
    ],
  },
  why: {
    title: 'Что здесь иначе',
    lead: 'Без аккаунта, без срока действия и без сервиса-посредника.',
    items: [
      { title: 'Код создаётся локально', text: 'Данные обрабатываются в браузере. Пароль, IBAN и имя сети не попадают на сервер.' },
      { title: 'Статический значит постоянный', text: 'Содержимое хранится в самом узоре. Нет сервиса, который можно отключить, и нет лимита сканирований.' },
      { title: 'Сделано для печати', text: 'SVG масштабируется без потерь, вместе с правилами размера, тихой зоны и контраста.' },
    ],
  },
  local: {
    eyebrow: 'Маркировка',
    title: 'QR-код и «Честный знак»',
    body: [
      'В русскоязычных запросах рядом с Wi-Fi часто встречается «Честный знак»: маркировка товаров. Это отдельная система, и её коды не создаются в сторонних генераторах.',
      'Коды маркировки выдаёт ЦРПТ через личный кабинет и оборудование. Обычный генератор подходит для других задач: ссылка на инструкцию, визитка, гостевой Wi-Fi.',
    ],
    points: [
      'Коды Data Matrix для «Честного знака» выдаёт оператор ЦРПТ, генератор их не заменяет',
      'Обычный QR подойдёт для инструкции, меню, визитки или Wi-Fi',
      'На этикетке размер имеет значение: от 2,5 см, контраст тёмный на светлом',
      'Глянцевая плёнка даёт блик, поэтому на витрине лучше матовый материал',
    ],
  },
  faq: {
    title: 'Частые вопросы',
    items: [
      { q: 'Данные уходят на сервер?', a: 'Нет. Узор вычисляется в браузере. Нет аккаунта и серверного хранения, ничего не загружается.' },
      { q: 'Код истекает?', a: 'Нет. Статический код хранит содержимое в узоре, поэтому работает бессрочно и без лимита сканирований.' },
      { q: 'Какой размер нужен для печати?', a: 'Не меньше 2,5 см для использования в руке, около 10 см для объявления с метра и 50 см для плаката с 5 м.' },
      { q: 'Можно использовать в бизнесе?', a: 'Да. Файлы ваши: меню, счёт, машина, витрина, упаковка.' },
      { q: 'Можно ли изменить содержимое кода позже?', a: 'Статический код хранит данные в самом узоре, поэтому заменить их нельзя. Если содержимое должно меняться, создайте код один раз и ведите его на страницу, которую обновляете.' },
      { q: 'Код не считывается, с чего начать?', a: 'С контраста и свободного поля. Тёмный узор на светлом фоне, не меньше четырёх модулей по краям и никакого глянца, который отражает свет.' },
    ],
  },
  cta: {
    title: 'Генератор',
    lead: 'Двенадцать типов, живой предпросмотр, экспорт SVG и PNG.',
    button: 'Открыть генератор',
    hint: 'Интерфейс инструмента пока на немецком.',
  },
  footer: {
    tagline: 'Бесплатный инструмент для QR-кодов, которыми действительно пользуются.',
    note: 'Коды создаются локально в браузере.',
    tools: 'Инструмент',
    legal: 'Правовая информация',
    legalNote: 'Юридические страницы на немецком, обязательна немецкая версия.',
  },
};

const id: LocaleDict = {
  meta: {
    title: 'Pembuat QR code gratis: tanpa akun, tanpa masa berlaku',
    description:
      'Buat QR code di browser: Wi-Fi tamu, transfer SEPA, kartu nama, catatan untuk kurir. SVG untuk cetak atau PNG hingga 2048 px, tanpa pendaftaran.',
  },
  nav: { generator: 'Pembuat', howItWorks: 'Cara kerja', faq: 'Pertanyaan', why: 'Kenapa ini', language: 'Bahasa', menu: 'Menu' },
  hero: {
    eyebrow: 'Gratis, tanpa akun, tanpa masa berlaku',
    titleTop: 'Buat QR code.',
    titleAccent: 'Selesai dalam satu menit.',
    lead:
      'Wi-Fi tamu untuk router, kode transfer untuk aplikasi bank, catatan untuk kurir, kartu nama untuk ponsel. Kode dibuat di browser dan data tetap di perangkat Anda.',
    cta: 'Buka pembuat',
    facts: [
      { term: 'Tanpa akun', desc: 'tanpa pendaftaran' },
      { term: 'Di browser', desc: 'tidak diunggah' },
      { term: 'SVG dan PNG', desc: 'hingga 2048 px' },
    ],
  },
  types: {
    title: 'Kode harus membuka apa?',
    lead: 'Dua belas jenis, masing-masing punya warna sendiri. Pilih satu, formulir hanya menanyakan yang perlu.',
  },
  typeNames: {
    url: 'Situs web',
    wifi: 'Wi-Fi',
    sepa: 'Transfer SEPA',
    vcard: 'Kartu nama',
    delivery: 'Catatan kurir',
    standort: 'Lokasi',
    event: 'Janji',
    phone: 'Telepon',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'Email',
    text: 'Teks',
  },
  how: {
    title: 'Empat langkah, tanpa akun.',
    lead: 'Semua terjadi di satu halaman. Jenis bisa diganti kapan saja dan data tetap tersimpan.',
    steps: [
      { title: 'Pilih jenis', text: 'Wi-Fi, transfer, kartu nama, paket, lokasi, SMS. Jenis menentukan formulir.' },
      { title: 'Isi data', text: 'Hanya kolom yang diperlukan. Pratinjau ikut berubah saat mengetik.' },
      { title: 'Periksa tampilan', text: 'Warna, sudut, dan bingkai. Uji pindai memberi peringatan sebelum dicetak.' },
      { title: 'Unduh', text: 'SVG untuk percetakan, PNG hingga 2048 px untuk layar atau papan pengumuman.' },
    ],
  },
  why: {
    title: 'Apa yang berbeda',
    lead: 'Tanpa akun, tanpa masa berlaku, dan tanpa layanan pengalihan di tengah.',
    items: [
      { title: 'Kode dibuat lokal', text: 'Data diproses di browser. Kata sandi, IBAN, dan nama jaringan tidak dikirim ke server.' },
      { title: 'Statis berarti permanen', text: 'Isi tersimpan di dalam pola. Tidak ada layanan yang bisa dimatikan dan tidak ada batas pindai.' },
      { title: 'Dibuat untuk cetak', text: 'SVG diskalakan tanpa kehilangan kualitas, lengkap dengan aturan ukuran, zona hening, dan kontras.' },
    ],
  },
  local: {
    eyebrow: 'Warung dan restoran',
    title: 'QR code menu: yang benar-benar dipakai',
    body: [
      'Di Indonesia, setelah Wi-Fi, pencarian terbanyak adalah menu dan cetak. QR code menu sudah biasa di warung dan kafe, tetapi sering bermasalah karena isinya PDF mendatar yang tidak terbaca di ponsel.',
      'Yang bekerja adalah halaman biasa dengan judul per kategori, diperbarui pemilik. Menu kertas tetap di meja karena sinyal belum selalu bagus.',
    ],
    points: [
      'Satu kode per meja cukup; kode berbeda per meja baru berguna bila ada alat analitik',
      'Minimal 3 cm sisi untuk dibaca dari 30 cm',
      'Jangan menempel di kaca: pantulan membuat kode gagal dibaca di area terbuka',
      'Untuk ulasan, taruh kode di struk, bukan di pintu keluar',
    ],
  },
  faq: {
    title: 'Pertanyaan yang sering muncul',
    items: [
      { q: 'Apakah data saya dikirim ke server?', a: 'Tidak. Pola dihitung di browser. Tidak ada akun atau penyimpanan di server, dan tidak ada yang diunggah.' },
      { q: 'Apakah kode kedaluwarsa?', a: 'Tidak. Kode statis menyimpan isi di polanya, jadi berlaku tanpa batas waktu dan tanpa batas pindai.' },
      { q: 'Ukuran berapa untuk cetak?', a: 'Minimal 2,5 cm untuk dipegang tangan, sekitar 10 cm untuk papan dibaca dari satu meter, dan 50 cm untuk poster dari 5 m.' },
      { q: 'Boleh untuk usaha?', a: 'Boleh. File hasil ekspor milik Anda: menu, struk, kendaraan, etalase, kemasan.' },
    ],
  },
  cta: {
    title: 'Pembuat QR',
    lead: 'Dua belas jenis, pratinjau langsung, ekspor SVG dan PNG.',
    button: 'Buka pembuat',
    hint: 'Antarmuka alat masih dalam bahasa Jerman.',
  },
  footer: {
    tagline: 'Alat gratis untuk QR code yang benar-benar dipakai.',
    note: 'Kode dibuat lokal di browser.',
    tools: 'Alat',
    legal: 'Informasi hukum',
    legalNote: 'Halaman hukum tersedia dalam bahasa Jerman dan versi Jerman yang mengikat.',
  },
};

const he: LocaleDict = {
  meta: {
    title: 'מחולל קוד QR בחינם: בלי חשבון ובלי תאריך תפוגה',
    description:
      'יוצרים קוד QR בדפדפן: Wi-Fi לאורחים, העברה בנקאית, כרטיס ביקור, פתק לשליח. SVG להדפסה או PNG עד 2048 px, בלי הרשמה.',
  },
  nav: { generator: 'מחולל', howItWorks: 'איך זה עובד', faq: 'שאלות', why: 'למה דווקא זה', language: 'שפה', menu: 'תפריט' },
  hero: {
    eyebrow: 'בחינם, בלי חשבון, בלי תאריך תפוגה',
    titleTop: 'יוצרים קוד QR',
    titleAccent: 'מוכן בתוך דקה.',
    lead:
      'Wi-Fi לאורחים בשביל הראוטר, קוד העברה לאפליקציית הבנק, פתק לשליח, כרטיס ביקור לטלפון. הקוד נוצר בדפדפן והנתונים נשארים במכשיר שלכם.',
    cta: 'פתיחת המחולל',
    facts: [
      { term: 'בלי חשבון', desc: 'בלי הרשמה' },
      { term: 'בדפדפן', desc: 'שום דבר לא נשלח' },
      { term: 'SVG ו-PNG', desc: 'עד 2048 px' },
    ],
  },
  types: {
    title: 'מה הקוד צריך לפתוח?',
    lead: 'שנים עשר סוגים, לכל אחד צבע משלו. בוחרים סוג, והטופס מבקש רק את מה שנדרש.',
  },
  typeNames: {
    url: 'אתר',
    wifi: 'Wi-Fi',
    sepa: 'העברה SEPA',
    vcard: 'כרטיס ביקור',
    delivery: 'פתק לשליח',
    standort: 'מיקום',
    event: 'פגישה',
    phone: 'טלפון',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    email: 'אימייל',
    text: 'טקסט',
  },
  how: {
    title: 'ארבעה שלבים, בלי חשבון.',
    lead: 'כל התהליך בעמוד אחד. אפשר להחליף סוג בכל רגע והנתונים נשמרים.',
    steps: [
      { title: 'בוחרים סוג', text: 'Wi-Fi, העברה, כרטיס ביקור, חבילה, מיקום, SMS. הסוג קובע את הטופס.' },
      { title: 'מזינים נתונים', text: 'רק השדות שנדרשים. התצוגה המקדימה מתעדכנת תוך כדי הקלדה.' },
      { title: 'בודקים מראה', text: 'צבעים, פינות ומסגרת. בדיקת הסריקה מתריעה לפני ההדפסה.' },
      { title: 'מורידים', text: 'SVG לבית דפוס, PNG עד 2048 px למסך או לשלט.' },
    ],
  },
  why: {
    title: 'מה שונה כאן',
    lead: 'בלי חשבון, בלי תאריך תפוגה ובלי שירות הפניה באמצע.',
    items: [
      { title: 'הקוד נוצר מקומית', text: 'הנתונים מעובדים בדפדפן. סיסמה, IBAN ושם הרשת לא נשלחים לשרת.' },
      { title: 'סטטי פירושו קבוע', text: 'התוכן נמצא בתבנית עצמה. אין שירות שאפשר לכבות ואין מגבלת סריקות.' },
      { title: 'בנוי לנייר', text: 'SVG מוגדל בלי אובדן איכות, יחד עם כללי גודל, שוליים לבנים וניגודיות.' },
    ],
  },
  local: {
    eyebrow: 'Wi-Fi',
    title: 'קוד Wi-Fi: הדבר שהכי מחפשים',
    body: [
      'כמעט מחצית מהחיפושים בעברית על קודי QR קשורים ל-Wi-Fi. זה הגיוני: להקליד סיסמה של עשרים תווים בטלפון זו הטרחה שהקוד פותר.',
      'הדפוס הסטנדרטי נקרא WIFI: והוא מוכר לכל מצלמה בטלפון. אחרי סריקה הטלפון מציע להתחבר לרשת, בלי להקליד כלום.',
    ],
    points: [
      'רשת אורחים היא הבחירה הנכונה: לא חושפת את הסיסמה הראשית',
      'אפשר להסתיר את שם הרשת (SSID מוסתר) והקוד עדיין יעבוד',
      'גודל לאורחים: 3 ס"מ על שולחן, 10 ס"מ על קיר בכניסה',
      'אם החלפתם סיסמה, חייבים להדפיס קוד חדש: הקוד סטטי',
    ],
  },
  faq: {
    title: 'שאלות נפוצות',
    items: [
      { q: 'הנתונים שלי נשלחים לשרת?', a: 'לא. התבנית מחושבת בדפדפן. אין חשבון ואין אחסון בשרת, ושום דבר לא מועלה.' },
      { q: 'הקוד פג תוקף?', a: 'לא. קוד סטטי נושא את התוכן בתבנית עצמה, ולכן עובד בלי הגבלת זמן ובלי הגבלת סריקות.' },
      { q: 'איזה גודל להדפסה?', a: 'לפחות 2.5 ס"מ לשימוש ביד, כ-10 ס"מ לשלט שנקרא ממטר, וכ-50 ס"מ לפוסטר מ-5 מטר.' },
      { q: 'אפשר להשתמש עסקית?', a: 'כן. הקבצים שיוצאים הם שלכם: תפריט, חשבונית, רכב, חלון ראווה, אריזה.' },
      { q: 'אפשר לשנות את תוכן הקוד אחר כך?', a: 'קוד סטטי נושא את התוכן בתוך הדפוס עצמו, ולכן אי אפשר להחליף אותו. אם התוכן אמור להשתנות, צרו את הקוד פעם אחת והפנו אותו לדף שאתם מעדכנים.' },
      { q: 'הקוד לא נקרא, מה בודקים קודם?', a: 'ניגודיות ושוליים פנויים. דפוס כהה על רקע בהיר, ארבעה מודולים לפחות מסביב, ובלי ניילון מבריק שמחזיר אור.' },
      { q: 'באיזה קובץ להשתמש להדפסה?', a: 'להדפסה בבית מספיק PNG ברזולוציה גבוהה, ובבית דפוס עדיף SVG, כי הוא וקטורי ונשאר חד בכל גודל שבו מדפיסים אותו.' },
    ],
  },
  cta: {
    title: 'המחולל',
    lead: 'שנים עשר סוגים, תצוגה מקדימה חיה, ייצוא SVG ו-PNG.',
    button: 'פתיחת המחולל',
    hint: 'ממשק הכלי הוא כרגע בגרמנית.',
  },
  footer: {
    tagline: 'כלי חינמי לקודי QR שבאמת משתמשים בהם.',
    note: 'הקודים נוצרים מקומית בדפדפן.',
    tools: 'כלי',
    legal: 'מידע משפטי',
    legalNote: 'העמודים המשפטיים בגרמנית, והנוסח המחייב הוא הגרמני.',
  },
};

const ar: LocaleDict = {
  meta: {
    title: 'مولد رمز QR مجاني: بدون حساب وبدون تاريخ انتهاء',
    description:
      'أنشئ رمز QR في المتصفح: واي فاي للضيوف، تحويل بنكي، بطاقة عمل، ملاحظة للمندوب. ملف SVG للطباعة أو PNG حتى 2048 px، بدون تسجيل.',
  },
  nav: { generator: 'المولد', howItWorks: 'كيف يعمل', faq: 'أسئلة', why: 'لماذا هذا', language: 'اللغة', menu: 'القائمة' },
  hero: {
    eyebrow: 'مجاناً، بدون حساب، وبدون تاريخ انتهاء',
    titleTop: 'أنشئ رمز QR',
    titleAccent: 'جاهز في دقيقة.',
    lead:
      'واي فاي للضيوف، رمز تحويل لتطبيق البنك، ملاحظة للمندوب، بطاقة عمل للهاتف. يُنشأ الرمز داخل المتصفح وتبقى بياناتك على جهازك.',
    cta: 'فتح المولد',
    facts: [
      { term: 'بدون حساب', desc: 'بدون تسجيل' },
      { term: 'داخل المتصفح', desc: 'لا يُرفع شيء' },
      { term: 'SVG و PNG', desc: 'حتى 2048 px' },
    ],
  },
  types: {
    title: 'ماذا يفتح الرمز؟',
    lead: 'اثنا عشر نوعاً، ولكل نوع لونه. اختر النوع ولا يسألك النموذج إلا عن الحقول اللازمة.',
  },
  typeNames: {
    url: 'موقع إلكتروني',
    wifi: 'واي فاي',
    sepa: 'تحويل SEPA',
    vcard: 'بطاقة عمل',
    delivery: 'ملاحظة للمندوب',
    standort: 'الموقع',
    event: 'موعد',
    phone: 'هاتف',
    sms: 'رسالة نصية',
    whatsapp: 'واتساب',
    email: 'بريد إلكتروني',
    text: 'نص',
  },
  how: {
    title: 'أربع خطوات، بدون حساب.',
    lead: 'كل شيء في صفحة واحدة. يمكنك تغيير النوع في أي وقت وتظل البيانات محفوظة.',
    steps: [
      { title: 'اختر النوع', text: 'واي فاي، تحويل، بطاقة عمل، طرد، موقع، رسالة. النوع يحدد النموذج.' },
      { title: 'أدخل البيانات', text: 'الحقول اللازمة فقط. تتحدث المعاينة أثناء الكتابة.' },
      { title: 'راجع الشكل', text: 'الألوان والزوايا والإطار. اختبار المسح ينبهك قبل الطباعة.' },
      { title: 'حمّل الملف', text: 'SVG للمطبعة، أو PNG حتى 2048 px للشاشة واللوحات.' },
    ],
  },
  why: {
    title: 'ما المختلف هنا',
    lead: 'بدون حساب، وبدون تاريخ انتهاء، وبدون خدمة إعادة توجيه في المنتصف.',
    items: [
      { title: 'الرمز يُنشأ محلياً', text: 'تُعالج البيانات داخل متصفحك. كلمة المرور والآيبان واسم الشبكة لا تصل إلى أي خادم.' },
      { title: 'الثابت يعني الدائم', text: 'المحتوى داخل النمط نفسه. لا خدمة يمكن إغلاقها ولا حد لعدد مرات المسح.' },
      { title: 'مصمم للورق', text: 'ملف SVG يكبّر دون فقدان جودة، مع قواعد المقاس والهامش الأبيض والتباين.' },
    ],
  },
  local: {
    eyebrow: 'الاستخدام اليومي',
    title: 'لماذا يبحث الناس عن مولد مجاني',
    body: [
      'معظم البحث العربي عن رموز QR يبدأ بكلمة «مجاني». السبب عملي: كثير من المواقع تطلب حساباً أو تضع علامة مائية أو توقف الرمز بعد فترة تجريبية.',
      'هذه الأداة تعمل بالعكس: الرمز يُنشأ في متصفحك، بلا حساب ولا علامة مائية، ويبقى صالحاً لأن المحتوى مخزّن في النمط نفسه وليس في خدمة خارجية.',
    ],
    points: [
      'لا علامة مائية على الملف المُصدَّر',
      'لا حاجة إلى بريد إلكتروني أو تسجيل',
      'بدون حد لعدد الرموز التي تنشئها',
      'الرموز الثابتة لا تتوقف عن العمل بعد فترة',
    ],
  },
  faq: {
    title: 'أسئلة متكررة',
    items: [
      { q: 'هل تُرسل بياناتي إلى خادم؟', a: 'لا. يُحسب النمط داخل المتصفح، ولا يوجد حساب أو تخزين على الخادم، ولا يُرفع أي شيء.' },
      { q: 'هل ينتهي صلاحية الرمز؟', a: 'لا. الرمز الثابت يحمل محتواه في النمط نفسه، لذلك يعمل بلا حد زمني وبلا حد للمسح.' },
      { q: 'ما المقاس المناسب للطباعة؟', a: '٢٫٥ سم على الأقل للاستخدام باليد، وحوالي ١٠ سم للوحة تُقرأ من متر، و٥٠ سم لملصق من خمسة أمتار.' },
      { q: 'هل يمكن استخدامه تجارياً؟', a: 'نعم. الملفات المُصدَّرة ملكك: قائمة طعام، فاتورة، سيارة، واجهة متجر، تغليف.' },
      { q: 'هل يمكن تغيير محتوى الرمز لاحقاً؟', a: 'الرمز الثابت يحمل المحتوى داخل النقش نفسه، ولذلك لا يمكن استبداله. وإذا كان المحتوى سيتغير فأنشئ الرمز مرة واحدة ووجّهه إلى صفحة تحدّثها أنت.' },
      { q: 'الرمز لا يُقرأ، ما أول ما يُفحص؟', a: 'التباين والهامش الفارغ. نقش غامق على خلفية فاتحة، وأربع وحدات فارغة على الأقل حول الرمز، وبلا غلاف لامع يعكس الضوء.' },
    ],
  },
  cta: {
    title: 'المولد',
    lead: 'اثنا عشر نوعاً، معاينة مباشرة، وتصدير SVG و PNG.',
    button: 'فتح المولد',
    hint: 'واجهة الأداة باللغة الألمانية حالياً.',
  },
  footer: {
    tagline: 'أداة مجانية لرموز QR تُستخدم فعلاً.',
    note: 'تُنشأ الرموز محلياً داخل المتصفح.',
    tools: 'الأداة',
    legal: 'معلومات قانونية',
    legalNote: 'الصفحات القانونية بالألمانية، والنسخة الألمانية هي الملزمة.',
  },
};

/**
 * Names of the second-wave types, for the type list on the locale pages.
 *
 * Facebook, Instagram, YouTube, X, PayPal, Bitcoin, Pix and MECARD are brand or
 * format names and are not translated anywhere. Only MECARD needs a word for
 * what it does, and that word is per locale.
 */
const BRAND_TYPES: Record<Locale, Record<string, string>> = {
  de: { mecard: 'Kontakt (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  en: { mecard: 'Contact (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  fr: { mecard: 'Contact (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  es: { mecard: 'Contacto (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  it: { mecard: 'Contatto (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  pt: { mecard: 'Contato (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  tr: { mecard: 'Kişi (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  pl: { mecard: 'Kontakt (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  ru: { mecard: 'Контакт (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  id: { mecard: 'Kontak (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  he: { mecard: 'איש קשר (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
  ar: { mecard: 'جهة اتصال (MECARD)', facebook: 'Facebook', twitter: 'X', youtube: 'YouTube', instagram: 'Instagram', bitcoin: 'Bitcoin', paypal: 'PayPal', pix: 'Pix' },
};

/** The full type list a locale page shows, original twelve plus second wave. */
export function allTypeNames(locale: Locale): Record<string, string> {
  return { ...dict(locale).typeNames, ...BRAND_TYPES[locale] };
}

export const DICTIONARIES: Record<Locale, LocaleDict> = {
  de, en, fr, es, it, pt, tr, pl, ru, id, he, ar,
};

export function dict(locale: Locale): LocaleDict {
  return DICTIONARIES[locale] ?? DICTIONARIES.de;
}
