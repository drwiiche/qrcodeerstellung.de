/**
 * Locale registry.
 *
 * German lives at the site root (`/`, `/blog`, …) so the existing URLs keep
 * their accumulated signals. Every other locale is prefixed (`/en`, `/tr`, …).
 * Nothing in the codebase hard-codes a locale list; everything reads this file,
 * so adding a language is one entry here plus a dictionary.
 */

export type Locale =
  | 'de' | 'en' | 'fr' | 'es' | 'it' | 'pt'
  | 'tr' | 'pl' | 'ru' | 'id' | 'he' | 'ar';

export interface LocaleMeta {
  code: Locale;
  /** Name in the language itself, for the switcher. */
  nativeName: string;
  /** English name, for aria labels and the audit report. */
  englishName: string;
  /** Value for <html lang>. */
  htmlLang: string;
  dir: 'ltr' | 'rtl';
  /** BCP-47 for hreflang. */
  hreflang: string;
  /**
   * The intent this locale's query data actually shows, used by the landing
   * page and recorded so content decisions stay traceable.
   */
  primaryIntent: string;
}

export const DEFAULT_LOCALE: Locale = 'de';

export const LOCALES: LocaleMeta[] = [
  { code: 'de', nativeName: 'Deutsch', englishName: 'German', htmlLang: 'de', dir: 'ltr', hreflang: 'de-DE', primaryIntent: 'qr code erstellen (Generikum) + WLAN + rechtliche Pflichtangaben' },
  { code: 'en', nativeName: 'English', englishName: 'English', htmlLang: 'en', dir: 'ltr', hreflang: 'en', primaryIntent: 'free generator, no expiration; wifi; print size' },
  { code: 'fr', nativeName: 'Français', englishName: 'French', htmlLang: 'fr', dir: 'ltr', hreflang: 'fr-FR', primaryIntent: 'générateur gratuit + wifi + menu de restaurant' },
  { code: 'es', nativeName: 'Español', englishName: 'Spanish', htmlLang: 'es', dir: 'ltr', hreflang: 'es-ES', primaryIntent: 'generador gratis + wifi + "no funciona" (Fehlersuche)' },
  { code: 'it', nativeName: 'Italiano', englishName: 'Italian', htmlLang: 'it', dir: 'ltr', hreflang: 'it-IT', primaryIntent: 'generatore gratis per sempre + wifi + menu' },
  { code: 'pt', nativeName: 'Português', englishName: 'Portuguese', htmlLang: 'pt', dir: 'ltr', hreflang: 'pt-BR', primaryIntent: 'gerador gratuito + wifi + Pix' },
  { code: 'tr', nativeName: 'Türkçe', englishName: 'Turkish', htmlLang: 'tr', dir: 'ltr', hreflang: 'tr-TR', primaryIntent: 'qr kod oluştur + wifi + menü' },
  { code: 'pl', nativeName: 'Polski', englishName: 'Polish', htmlLang: 'pl', dir: 'ltr', hreflang: 'pl-PL', primaryIntent: 'generator kodów qr + wifi + Paczkomat/InPost' },
  { code: 'ru', nativeName: 'Русский', englishName: 'Russian', htmlLang: 'ru', dir: 'ltr', hreflang: 'ru-RU', primaryIntent: 'генератор qr + wifi + Честный знак' },
  { code: 'id', nativeName: 'Bahasa Indonesia', englishName: 'Indonesian', htmlLang: 'id', dir: 'ltr', hreflang: 'id-ID', primaryIntent: 'buat qr code gratis + wifi + menu + cetak' },
  { code: 'he', nativeName: 'עברית', englishName: 'Hebrew', htmlLang: 'he', dir: 'rtl', hreflang: 'he-IL', primaryIntent: 'מחולל qr + wifi (45 % aller Queries)' },
  { code: 'ar', nativeName: 'العربية', englishName: 'Arabic', htmlLang: 'ar', dir: 'rtl', hreflang: 'ar', primaryIntent: 'مولد رمز qr مجاني (fast ausschließlich "kostenlos")' },
];

export const LOCALE_CODES = LOCALES.map((l) => l.code);

export function isLocale(value: string): value is Locale {
  return (LOCALE_CODES as string[]).includes(value);
}

export function localeMeta(code: Locale): LocaleMeta {
  return LOCALES.find((l) => l.code === code) ?? LOCALES[0];
}

/**
 * Path for a locale. German keeps the unprefixed root, everything else gets a
 * prefix, so `path('de', '/blog')` is `/blog` and `path('fr', '/blog')` is
 * `/fr/blog`.
 */
export function localePath(code: Locale, path = '/'): string {
  const clean = path.startsWith('/') ? path : `/${path}`;
  if (code === DEFAULT_LOCALE) return clean;
  return clean === '/' ? `/${code}` : `/${code}${clean}`;
}

/** Route strings that exist for every locale (the localized landing set). */
/**
 * Routes that exist in every locale.
 *
 * Only paths listed here may be linked across locales or get an hreflang
 * alternate. Declaring hreflang for a URL that returns 404 is worse than
 * declaring none: Google reads it as a broken cluster and drops the whole set.
 * Grow this list as localized hubs are added, and check the build output
 * against it.
 */
export const LOCALIZED_ROUTES: readonly string[] = ['/'];

/** True when `path` (locale-neutral) has a version in every locale. */
export function isLocalizedRoute(path: string): boolean {
  const clean = path === '' ? '/' : path.replace(/\/+$/, '') || '/';
  return LOCALIZED_ROUTES.includes(clean);
}

/**
 * Where a visitor should land in `locale` when leaving `path`.
 *
 * Falls back to that locale's homepage rather than building a URL that does
 * not exist, so switching language is never a 404.
 */
export function swapLocale(locale: Locale, path: string): string {
  return isLocalizedRoute(path) ? localePath(locale, path) : localePath(locale, '/');
}

export const SHARED_ROUTES = ['/', '/wlan', '/menu', '/drucken', '/fehlersuche'] as const;
export type SharedRoute = (typeof SHARED_ROUTES)[number];
