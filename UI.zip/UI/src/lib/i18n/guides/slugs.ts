/**
 * Guide slug map, kept separate from the content on purpose.
 *
 * The language switcher is a client component. Importing the full guide
 * registry there would pull every locale's guide text into the browser
 * bundle, roughly 60 kB of prose for the sake of twelve links. So the slugs
 * live here as a small standalone map.
 *
 * The map is asserted against the real registry in `guides/slugs.test.mjs`,
 * so it cannot silently drift from the content: if a slug changes in the
 * guides and not here, `npm test` fails.
 */
import type { Locale } from '../config';

export const GUIDE_SLUGS: Record<string, Partial<Record<Locale, string>>> = {
  /* Type pages. German lives at /qr-code-generator/<typ> and is not part of the
     locale routing, so it is absent here and resolved through
     GERMAN_COUNTERPART instead. */
  'type-link': { en: 'link-qr-code', es: 'codigo-qr-enlace', fr: 'qr-code-lien', it: 'qr-code-link', pt: 'qr-code-link', pl: 'kod-qr-link', tr: 'link-qr-kod', ru: 'qr-kod-ssylka', id: 'qr-code-tautan', he: 'qr-code-kishur', ar: 'ramz-qr-rabt' },
  'type-vcard': { en: 'vcard-qr-code', es: 'codigo-qr-vcard', fr: 'qr-code-vcard', it: 'qr-code-vcard', pt: 'qr-code-vcard', pl: 'kod-qr-vcard', tr: 'vcard-qr-kod', ru: 'qr-kod-vcard', id: 'qr-code-vcard', he: 'qr-code-vcard', ar: 'ramz-qr-vcard' },
  'type-girocode': { en: 'girocode-qr-code', es: 'codigo-qr-girocode', fr: 'qr-code-girocode', it: 'qr-code-girocode', pt: 'qr-code-girocode', pl: 'kod-qr-girocode', tr: 'girocode-qr-kod', ru: 'qr-kod-girocode', id: 'qr-code-girocode', he: 'qr-code-girocode', ar: 'ramz-qr-girocode' },
  'type-whatsapp': { en: 'whatsapp-qr-code', es: 'codigo-qr-whatsapp', fr: 'qr-code-whatsapp', it: 'qr-code-whatsapp', pt: 'qr-code-whatsapp', pl: 'kod-qr-whatsapp', tr: 'whatsapp-qr-kod', ru: 'qr-kod-whatsapp', id: 'qr-code-whatsapp', he: 'qr-code-whatsapp', ar: 'ramz-qr-whatsapp' },
  'type-instagram': { en: 'instagram-qr-code', es: 'codigo-qr-instagram', fr: 'qr-code-instagram', it: 'qr-code-instagram', pt: 'qr-code-instagram', pl: 'kod-qr-instagram', tr: 'instagram-qr-kod', ru: 'qr-kod-instagram', id: 'qr-code-instagram', he: 'qr-code-instagram', ar: 'ramz-qr-instagram' },
  'type-email': { en: 'email-qr-code', es: 'codigo-qr-correo', fr: 'qr-code-email', it: 'qr-code-email', pt: 'qr-code-email', pl: 'kod-qr-email', tr: 'e-posta-qr-kod', ru: 'qr-kod-email', id: 'qr-code-email', he: 'qr-code-email', ar: 'ramz-qr-barid' },
  'type-telefon': { en: 'phone-qr-code', es: 'codigo-qr-telefono', fr: 'qr-code-telephone', it: 'qr-code-telefono', pt: 'qr-code-telefone', pl: 'kod-qr-telefon', tr: 'telefon-qr-kod', ru: 'qr-kod-telefon', id: 'qr-code-telepon', he: 'qr-code-telefon', ar: 'ramz-qr-hatif' },
  'type-standort': { en: 'location-qr-code', es: 'codigo-qr-ubicacion', fr: 'qr-code-localisation', it: 'qr-code-posizione', pt: 'qr-code-localizacao', pl: 'kod-qr-lokalizacja', tr: 'konum-qr-kod', ru: 'qr-kod-mestopolozhenie', id: 'qr-code-lokasi', he: 'qr-code-mikom', ar: 'ramz-qr-mawqi' },
  'type-sms': { en: 'sms-qr-code', es: 'codigo-qr-sms', fr: 'qr-code-sms', it: 'qr-code-sms', pt: 'qr-code-sms', pl: 'kod-qr-sms', tr: 'sms-qr-kod', ru: 'qr-kod-sms', id: 'qr-code-sms', he: 'qr-code-sms', ar: 'ramz-qr-sms' },
  'type-termin': { en: 'event-qr-code', es: 'codigo-qr-cita', fr: 'qr-code-evenement', it: 'qr-code-evento', pt: 'qr-code-evento', pl: 'kod-qr-wydarzenie', tr: 'etkinlik-qr-kod', ru: 'qr-kod-sobytie', id: 'qr-code-acara', he: 'qr-code-erua', ar: 'ramz-qr-hadath' },
  'type-text': { en: 'text-qr-code', es: 'codigo-qr-texto', fr: 'qr-code-texte', it: 'qr-code-testo', pt: 'qr-code-texto', pl: 'kod-qr-tekst', tr: 'metin-qr-kod', ru: 'qr-kod-tekst', id: 'qr-code-teks', he: 'qr-code-text', ar: 'ramz-qr-nass' },
  'type-paketabstellort': { en: 'parcel-drop-qr-code', es: 'codigo-qr-punto-recogida', fr: 'qr-code-point-relais', it: 'qr-code-punto-di-ritiro', pt: 'qr-code-ponto-de-retirada', pl: 'kod-qr-paczkomat', tr: 'kargo-qr-kod', ru: 'qr-kod-postamat', id: 'qr-code-titik-ambil-paket', he: 'qr-code-nakudat-mishloach', ar: 'ramz-qr-tawsil' },
  'type-facebook': { en: 'facebook-qr-code', es: 'codigo-qr-facebook', fr: 'qr-code-facebook', it: 'qr-code-facebook', pt: 'qr-code-facebook', pl: 'kod-qr-facebook', tr: 'facebook-qr-kod', ru: 'qr-kod-facebook', id: 'qr-code-facebook', he: 'qr-code-facebook', ar: 'ramz-qr-facebook' },
  'type-youtube': { en: 'youtube-qr-code', es: 'codigo-qr-youtube', fr: 'qr-code-youtube', it: 'qr-code-youtube', pt: 'qr-code-youtube', pl: 'kod-qr-youtube', tr: 'youtube-qr-kod', ru: 'qr-kod-youtube', id: 'qr-code-youtube', he: 'qr-code-youtube', ar: 'ramz-qr-youtube' },
  'type-x': { en: 'x-qr-code', es: 'codigo-qr-x', fr: 'qr-code-x', it: 'qr-code-x', pt: 'qr-code-x', pl: 'kod-qr-x', tr: 'x-qr-kod', ru: 'qr-kod-x', id: 'qr-code-x', he: 'qr-code-x', ar: 'ramz-qr-x' },
  'type-paypal': { en: 'paypal-qr-code', es: 'codigo-qr-paypal', fr: 'qr-code-paypal', it: 'qr-code-paypal', pt: 'qr-code-paypal', pl: 'kod-qr-paypal', tr: 'paypal-qr-kod', ru: 'qr-kod-paypal', id: 'qr-code-paypal', he: 'qr-code-paypal', ar: 'ramz-qr-paypal' },
  'type-mecard': { en: 'mecard-qr-code', es: 'codigo-qr-mecard', fr: 'qr-code-mecard', it: 'qr-code-mecard', pt: 'qr-code-mecard', pl: 'kod-qr-mecard', tr: 'mecard-qr-kod', ru: 'qr-kod-mecard', id: 'qr-code-mecard', he: 'qr-code-mecard', ar: 'ramz-qr-mecard' },
  'type-kostenlos': { en: 'free-qr-code-generator', es: 'generador-codigo-qr-gratis', fr: 'generateur-qr-code-gratuit', it: 'generatore-qr-code-gratis', pt: 'gerador-qr-code-gratis', pl: 'darmowy-generator-kodow-qr', tr: 'ucretsiz-qr-kod', ru: 'besplatnyj-qr-kod', id: 'qr-code-gratis', he: 'qr-code-chinam', ar: 'ramz-qr-majani' },
  'type-vergleich': { en: 'qr-code-comparison', es: 'comparativa-codigo-qr', fr: 'comparatif-qr-code', it: 'confronto-qr-code', pt: 'comparativo-qr-code', pl: 'porownanie-kodow-qr', tr: 'qr-kod-karsilastirma', ru: 'sravnenie-qr-kodov', id: 'perbandingan-qr-code', he: 'hashvaat-qr-code', ar: 'muqaranat-ramz-qr' },
  'type-bester-qr-code-generator': { en: 'best-qr-code-generator', es: 'mejor-generador-codigo-qr', fr: 'meilleur-generateur-qr-code', it: 'miglior-generatore-qr-code', pt: 'melhor-gerador-qr-code', pl: 'najlepszy-generator-kodow-qr', tr: 'en-iyi-qr-kod-olusturucu', ru: 'luchshij-generator-qr-kodov', id: 'qr-code-terbaik', he: 'hameytar-har-qr-code', ar: 'afdal-muwallid-ramz-qr' },
  wifi: {
    de: 'wlan-qr-code',
    en: 'wifi-qr-code',
    fr: 'qr-code-wifi',
    es: 'codigo-qr-wifi',
    it: 'qr-code-wifi',
    pt: 'qr-code-wifi',
    tr: 'wifi-qr-kod',
    pl: 'kod-qr-wifi',
    ru: 'qr-kod-wifi',
    id: 'qr-code-wifi',
    he: 'qr-code-wifi',
    ar: 'qr-code-wifi',
  },
  menu: {
    de: 'speisekarte-qr-code',
    en: 'menu-qr-code',
    fr: 'qr-code-menu-restaurant',
    es: 'codigo-qr-carta-restaurante',
    it: 'qr-code-menu',
    pt: 'qr-code-cardapio',
    tr: 'qr-menu-kod',
    pl: 'kod-qr-menu',
    ru: 'qr-kod-menyu',
    id: 'qr-code-menu',
    he: 'qr-code-tafrit',
    ar: 'ramz-qr-qaimat-taam',
  },
};

/**
 * If `slug` is a guide in `locale`, return the same guide's slug in every
 * locale. Otherwise null, and the caller falls back to the homepage mapping.
 */
export function guideSlugsFor(
  locale: Locale,
  slug: string
): Partial<Record<Locale, string>> | null {
  for (const cluster of Object.values(GUIDE_SLUGS)) {
    if (cluster[locale] === slug) return cluster;
  }
  return null;
}

/**
 * Which type page covers a generator screen.
 *
 * The generator uses twenty type codes (url, sepa, phone...), the type pages
 * use twenty keys (link, girocode, telefon...). They are not the same strings,
 * and several keys share one screen, so the mapping is written out rather than
 * guessed. Used by the locale landing page to send a reader to the written page
 * instead of back into the tool when one exists.
 */
export const TYPE_CODE_TO_KEY: Record<string, string> = {
  url: 'link',
  vcard: 'vcard',
  sepa: 'girocode',
  whatsapp: 'whatsapp',
  instagram: 'instagram',
  email: 'email',
  phone: 'telefon',
  sms: 'sms',
  standort: 'standort',
  event: 'termin',
  text: 'text',
  delivery: 'paketabstellort',
  facebook: 'facebook',
  youtube: 'youtube',
  twitter: 'x',
  paypal: 'paypal',
  mecard: 'mecard',
};

/** Slug of the written page for a generator screen, if one exists. */
export function typeGuideSlug(locale: Locale, typeCode: string): string | undefined {
  const key = TYPE_CODE_TO_KEY[typeCode];
  if (!key) return undefined;
  return GUIDE_SLUGS[`type-${key}`]?.[locale];
}
