/**
 * Readability wording.
 *
 * The score itself is computed in `utils/qrScore`, which returns a grade and a
 * list of issue codes. The sentences live here, in the same dictionary as the
 * rest of the instrument, so a warning on a Spanish page is in Spanish.
 */
import type { UiStrings } from './de';
import type { QrIssueCode } from '../../../utils/qrScore';

export function gradeLabel(u: UiStrings, grade: 'sehr-gut' | 'gut' | 'ausreichend' | 'kritisch'): string {
  switch (grade) {
    case 'sehr-gut':
      return u['pv.gradeExcellent'];
    case 'gut':
      return u['pv.gradeGood'];
    case 'ausreichend':
      return u['pv.gradeFair'];
    default:
      return u['pv.gradeCritical'];
  }
}

const ISSUE_KEY: Record<QrIssueCode, keyof UiStrings> = {
  inverted: 'sc.issueInverted',
  gradient: 'sc.issueGradient',
  logoTooBig: 'sc.issueLogoBig',
  logoEcc: 'sc.issueLogoEcc',
  eccL: 'sc.issueEccL',
  bgDark: 'sc.issueBgDark',
  opacity: 'sc.issueOpacity',
  transparent: 'sc.issueTransparent',
  contrastLow: 'sc.issueContrastLow',
  contrastCritical: 'sc.issueContrastCritical',
};

export function issueText(u: UiStrings, code: QrIssueCode): string {
  return u[ISSUE_KEY[code]];
}
