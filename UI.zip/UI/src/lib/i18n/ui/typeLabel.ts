/**
 * Type chip label.
 *
 * Twelve QR types have a translated name; the other eight are brands (Facebook,
 * X, YouTube, Instagram, Bitcoin, PayPal, Pix) or a standard name (MECARD) that
 * is not translated in any language. Those keep the label from QR_TYPE_LABELS.
 */
import type { UiStrings } from './de';
import { QR_TYPE_LABELS } from '../../../utils/translations';

export function typeLabel(u: UiStrings, id: string): string {
  const key = `type.${id}`;
  const translated = (u as Record<string, string>)[key];
  return translated ?? QR_TYPE_LABELS[id] ?? id;
}
