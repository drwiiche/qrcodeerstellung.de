/**
 * Generator UI strings, German (canonical).
 *
 * This is the source file for the whole generator interface. Every string that
 * used to be hard-coded inside QRForm, QRCustomizer, QRPreviewCard, HomeView,
 * HistoryDrawer and ScanTestModal lives here under a stable key, and the other
 * eleven locales provide the same keys. Components read them through the
 * `useUi()` hook, which falls back to this object, so German keeps rendering
 * even if a provider is missing.
 *
 * Keys are flat and dotted on purpose: a missing key shows up as one diff line
 * rather than a broken nested object, and a test can compare the key sets of
 * all twelve locales field by field.
 */
export const uiDe = {
  'm.lead': 'WLAN, GiroCode, Visitenkarte, Paket-Abstellort, Termin. Der Code entsteht in Ihrem Browser, die Eingaben bleiben auf Ihrem Gerät.',
  'wifi.info': 'Gäste scannen den Code mit der Handykamera und sind sofort online. Es wird keine App benötigt.',
  'cz.tabShapes': 'Formen',
  'cz.tabColors': 'Farben',
  'cz.tabIcons': 'Icons',
  'cz.tabFrame': 'Rahmen',
  'pv.gradeExcellent': 'Sehr gut scannbar',
  'pv.gradeGood': 'Gut scannbar',
  'pv.gradeFair': 'Ausreichend, optimierbar',
  'pv.gradeCritical': 'Kritisch, nur eingeschränkt scannbar',
  'sc.issueInverted': 'Invertierte Darstellung (helle Module auf dunklem Grund) wird von alten Scannern oft abgelehnt.',
  'sc.issueGradient': 'Der Verlaufs-Ausgang liegt zu hell auf dem Hintergrund.',
  'sc.issueLogoBig': 'Logo-Fläche über 30 Prozent, deutlich verkleinern (max. 25 empfohlen).',
  'sc.issueLogoEcc': 'Logo-Fläche über 25 Prozent, Fehlerkorrektur H verwenden oder Logo verkleinern.',
  'sc.issueEccL': 'Fehlerkorrektur L mit Logo, auf H stellen.',
  'sc.issueBgDark': 'Das Hintergrundbild ist relativ dunkel, Deckkraft reduzieren oder helles Motiv wählen.',
  'sc.issueOpacity': 'Deckkraft des Hintergrundbildes hoch, unter 50 Prozent empfohlen.',
  'sc.issueContrastLow': 'Niedriger Farbkontrast, dunklere Module oder helleren Hintergrund wählen.',
  'sc.issueContrastCritical': 'Kritisch geringer Kontrast, so scannen viele Kameras nicht mehr.',
  'sc.issueTransparent': 'Transparenter Hintergrund: beim Druck immer einen hellen Untergrund wählen.',

  /* Toasts. These are the only messages the instrument speaks back, so they
     carry the same weight as a label and are translated like one. */
  'tst.pngOk': 'PNG gespeichert ({size} px).',
  'tst.pngBlocked':
    'Der Browser hat den Download blockiert. Seite in einem eigenen Tab öffnen oder das Bild über die rechte Maustaste speichern.',
  'tst.svgImage': 'Bild-Designs stecken nur im PNG. Für SVG das Hintergrundbild entfernen.',
  'tst.svgOk': 'SVG gespeichert.',
  'tst.svgFail': 'SVG-Export fehlgeschlagen.',
  'tst.imgCopied': 'Bild kopiert.',
  'tst.txtCopied': 'Code-Inhalt als Text kopiert.',
  'tst.copyBlocked': 'Kopieren ist in diesem Browser gesperrt.',
  'tst.iconRemoved': 'Icon entfernt.',
  'tst.drawing': 'Der Code wird noch gezeichnet, bitte kurz warten.',
  'tst.historySaved': 'QR-Code im Verlauf gespeichert.',
  'tst.historyLoaded': 'Geladen:',
  'tst.historyCleared': 'Verlauf geleert.',
  'tst.templateLoaded': 'Vorlage geladen.',

  /* Consent banner. The long legal paragraph stays German on the legal pages
     themselves; the banner says in the reader's language what it is about and
     where the German text is. */
  'ck.title': 'Ihre Privatsphäre (DSGVO und TDDDG)',
  'ck.body':
    'Nur technisch notwendige Speicherung für Ihre Einstellungen. Mit Ihrer Erlaubnis anonyme Nutzungsstatistik. Die Codes entstehen in Ihrem Browser, es gehen keine Eingaben an einen Server.',
  'ck.essential': 'Nur notwendige',
  'ck.accept': 'Alle akzeptieren',
  'ck.settings': 'Einstellungen anpassen',
  'ck.less': 'Weniger Details',

  /* Type chips. Brand types (Facebook, X, YouTube, Instagram, Bitcoin, PayPal,
     Pix, MECARD) keep their names in every language and live in
     QR_TYPE_LABELS; these twelve are the ones that need translating. */
  'type.url': 'Webseite',
  'type.wifi': 'WLAN',
  'type.sepa': 'SEPA',
  'type.vcard': 'Visitenkarte',
  'type.delivery': 'Paket',
  'type.text': 'Freitext',
  'type.email': 'E-Mail',
  'type.whatsapp': 'WhatsApp',
  'type.sms': 'SMS',
  'type.standort': 'Standort',
  'type.phone': 'Telefon',
  'type.event': 'Termin',

  /* Masthead and instrument headings */
  'm.kicker': 'Kostenlos · ohne Konto · ohne Ablaufdatum',
  'm.h1': 'QR-Code erstellen',
  'm.formTitle': 'Daten für den Code',
  'm.previewHint': 'Vorschau aktualisiert beim Tippen',
  'm.scanTest': 'Scan-Test',
  'm.download': 'Herunterladen',
  'm.quickActions': 'Schnellaktionen',
  'm.scanCheck': 'QR-Code auf Lesbarkeit prüfen',
  'm.altSmall': 'Aktueller QR-Code in klein',
  'm.saveHistory': 'Im Verlauf speichern',
  'm.threeFacts1': 'SVG für den Druck, PNG bis 2048 px',
  'm.threeFacts2': 'Statischer Code, kein Weiterleitungsdienst',
  'm.threeFacts3': 'Eingaben verlassen den Browser nicht',

  /* Type selector */
  't.heading': 'Was soll der Code öffnen?',
  't.aria': 'QR-Code-Typ wählen',
  't.count': '20 Typen',

  /* URL */
  'url.label': 'Webseiten-URL oder Link *',
  'url.hint': 'Geben Sie eine vollständige Web-Adresse mit https:// ein.',
  'url.ph': 'https://ihre-website.de oder Notizen',
  'url.templatesHead': 'Beliebte Schnell-Vorlagen für Zuhause:',
  'url.compat': 'Fritz!Box & Speedport kompatibel',
  'url.routerLabel': 'Router Vorlage:',
  'url.fritz': 'AVM Fritz!Box',
  'url.speedport': 'Telekom Speedport',

  /* Wi-Fi */
  'wifi.ssid': 'WLAN-Name (SSID) *',
  'wifi.pass': 'WLAN-Passwort (WPA-Schlüssel)',
  'wifi.enc': 'Verschlüsselung',
  'wifi.wpa': 'WPA / WPA2 / WPA3 (Standard)',
  'wifi.wep': 'WEP (Veraltet)',
  'wifi.open': 'Offenes WLAN (Ohne Passwort)',
  'wifi.hidden': 'Versteckte SSID (Hidden Network)',
  'wifi.ssidPh': 'z.B. Mein-WLAN oder FRITZ!Box Gastzugang',
  'wifi.passPh': 'Passwort Ihres Heimnetzwerks',

  /* SEPA */
  'sepa.official': 'Offizieller EPC SEPA GiroCode Standard',
  'sepa.templatesHead': 'Deutsche Überweisungsvorlagen:',
  'sepa.name': 'Empfängername (Name / Firma) *',
  'sepa.namePh': 'z.B. Max Mustermann oder Hausverwaltung',
  'sepa.amount': 'Betrag in EUR (€) (Optional)',
  'sepa.amountPh': 'z.B. 45.00',
  'sepa.iban': 'IBAN (Deutsche IBAN) *',
  'sepa.ibanPh': 'DE89 3705 0198 0000 0123 45',
  'sepa.bic': 'BIC (Optional in DE)',
  'sepa.bicPh': 'z.B. DRESDEFF500',
  'sepa.reference': 'Verwendungszweck (Max. 140 Zeichen)',
  'sepa.referencePh': 'z.B. Miete Oktober, Kundennummer 8829, Rechnung 104',

  /* vCard */
  'vcard.first': 'Vorname *',
  'vcard.firstPh': 'Max',
  'vcard.last': 'Nachname *',
  'vcard.lastPh': 'Mustermann',
  'vcard.mobile': 'Mobilnummer *',
  'vcard.mobilePh': '+49 170 1234567',
  'vcard.email': 'E-Mail Adresse *',
  'vcard.emailPh': 'max.mustermann@mail.de',
  'vcard.company': 'Unternehmen / Organisation',
  'vcard.companyPh': 'Firma oder Freelance',
  'vcard.job': 'Position / Beruf',
  'vcard.jobPh': 'z.B. Software Entwickler / Architekt',
  'vcard.street': 'Straße & Hausnummer',
  'vcard.streetPh': 'Hauptstraße 12',
  'vcard.city': 'PLZ & Ort',
  'vcard.cityPh': '10115 Berlin',

  /* Delivery */
  'delivery.head': 'Haustür-Abstellhinweis für Paketboten',
  'delivery.name': 'Name des Empfängers (an der Klingel)',
  'delivery.namePh': 'z.B. Familie Schmidt (2. OG rechts)',
  'delivery.place': 'Gewünschter Abstellort',
  'delivery.placePh': 'z.B. Hinter der blauen Papiertonne im Carport',
  'delivery.phone': 'Telefon für Rückfragen (Optional)',
  'delivery.phonePh': '+49 176 12345678',
  'delivery.carriers': 'Gilt für Paketdienste',
  'delivery.note': 'Zusätzliche Anweisung für den Boten',
  'delivery.notePh': 'z.B. Bitte kurz klingeln nach dem Abstellen. Herzlichen Dank!',

  /* WhatsApp */
  'whatsapp.number': 'WhatsApp Telefonnummer (Mit Ländervorwahl)',
  'whatsapp.numberPh': '491701234567 (z.B. für Deutschland 49...)',
  'whatsapp.hint': 'Bitte ohne führende Nullen oder Plus eingeben (z.B. 49 für Deutschland).',
  'whatsapp.message': 'Vorausgefüllte Chat-Nachricht (Optional)',
  'whatsapp.messagePh': 'Hallo! Ich scanne den QR-Code von deiner Visitenkarte...',

  /* SMS */
  'sms.number': 'Empfänger (Mit Ländervorwahl)',
  'sms.numberPh': '+49 170 1234567',
  'sms.hint': 'Deutschland: +49 statt 0 am Anfang – z. B. +491701234567.',
  'sms.message': 'Vorausgefüllte Nachricht (Optional)',
  'sms.messagePh': 'Hallo, ich interessiere mich für Ihr Angebot.',

  /* Standort */
  'standort.label': 'Beschriftung (Optional)',
  'standort.labelPh': 'Treffpunkt am Haupteingang, Ladenlokal, Ferienhaus …',
  'standort.lat': 'Breitengrad',
  'standort.latPh': '52.520008',
  'standort.lon': 'Längengrad',
  'standort.lonPh': '13.404954',
  'standort.hint': 'Bitte gültige Koordinaten eingeben (z. B. 52.520008 / 13.404954).',

  /* Text */
  'text.label': 'Freier Text / Notiz',
  'text.ph':
    'Geben Sie beliebigen Text ein (z.B. Kartoninhalt für den Keller, Willkommenstext für die Gästewohnung...)',
  'text.hint': 'Scanbar mit jedem QR-Code Scanner',
  'text.templatesHead': 'Haushalt & Vorratsspeicher Vorlagen:',

  /* E-Mail */
  'email.to': 'E-Mail Empfänger *',
  'email.toPh': 'kontakt@beispiel.de',
  'email.subject': 'Betreffzeile',
  'email.subjectPh': 'Anfrage über QR-Code',
  'email.body': 'Nachrichtentext',
  'email.bodyPh': 'Sehr geehrte Damen und Herren,...',

  /* Telefon */
  'phone.number': 'Telefonnummer zum Anrufen',
  'phone.numberPh': '+49 30 12345678',
  'phone.hint':
    'Beim Scannen öffnet sich die Telefon-App des Smartphones direkt mit dieser Rufnummer.',

  /* Termin */
  'event.title': 'Titel des Events / Termins *',
  'event.titlePh': 'z.B. Eigentümerversammlung, Sommerfest, Grillen',
  'event.start': 'Startdatum',
  'event.time': 'Startzeit',
  'event.location': 'Ort / Adresse',
  'event.locationPh': 'Gemeinschaftsraum, Innenhof oder Adresse',

  /* Preview card */
  'pv.live': 'Live-Vorschau',
  'pv.drawing': 'Wird gezeichnet',
  'pv.readability': 'Lesbarkeit',
  'pv.contrastOk': 'Kontrast, Logo und Hintergrund in Ordnung.',
  'pv.remove': 'Entfernen',
  'pv.pngWorking': 'PNG wird erstellt',
  'pv.png': 'PNG herunterladen',
  'pv.print': 'Drucken',
  'pv.scanTest': 'Scan-Test',
  'pv.history': 'Verlauf',
  'pv.pixels': 'Pixel',
  'pv.alt': 'Vorschau des erzeugten QR-Codes',
  'pv.ariaBusy': 'QR-Code wird erzeugt',
  'pv.titleSvg': 'Vektor-SVG für Druckereien',
  'pv.titleCopy': 'Bild in die Zwischenablage kopieren',
  'pv.titlePrint': 'Druckvorlage auf DIN A4',
  'pv.ariaSize': 'Auflösung wählen',
  'pv.svgLocked': 'SVG gesperrt',
  'pv.svg': 'SVG',
  'pv.copied': 'Kopiert',
  'pv.copy': 'Kopieren',

  /* Customizer */
  'cz.pixelStyle': 'Punkte- und Modulmuster (Pixel-Stil)',
  'cz.finder': 'Erkennungsecken (Finder Pattern)',
  'cz.ecc': 'Fehlerkorrektur-Level',
  'cz.palette': 'Farbpalette',
  'cz.colorPresets': 'Farb-Vorlagen',
  'cz.fg': 'Vordergrundfarbe',
  'cz.bg': 'Hintergrundfarbe',
  'cz.bgImage': 'Hintergrundbild (unter den Modulen)',
  'cz.none': 'Keins',
  'cz.removal': 'Entfernen',
  'cz.opacity': 'Deckkraft des Bildes',
  'cz.imageOnly': 'Das Bild liegt nur',
  'cz.frameImage': 'Rahmenbild (Design rund um den Code)',
  'cz.frameImageHint': 'Das Bild bildet nur den',
  'cz.noIcon': 'Ohne Icon',
  'cz.iconSize': 'Icon-Größe:',
  'cz.iconBrowse': 'Icon-Kollektionen durchsuchen',
  'cz.iconPick': 'Wählen Sie eine Sammlung für Vorschau',
  'cz.iconClick': 'Klicken Sie auf ein Icon, um es direkt im Zentrum des QR-Codes zu platzieren.',
  'cz.logo': 'Eigenes Logo hochladen',
  'cz.logoHint': 'Unterstützt PNG, SVG und JPG (Transparenter Hintergrund empfohlen)',
  'cz.logoPick': 'Datei vom Gerät auswählen',
  'cz.frameStyle': 'Rahmenstil',
  'cz.frameText': 'Rahmentext (Call-to-Action)',
  'cz.frameColor': 'Rahmenfarbe',
  'cz.textColor': 'Textfarbe',

  /* History */
  'hi.empty': 'Noch keine QR-Codes im Verlauf.',
  'hi.load': 'Laden',
  'hi.local': 'Lokal in Ihrem Browser gespeichert (DSGVO)',
  'hi.clear': 'Verlauf leeren',
  'hi.close': 'Verlauf schließen',
  'hi.restore': 'Wiederherstellen',
  'hi.delete': 'Löschen',

  /* Scan test */
  'sc.title': 'Smartphone-Scan Simulator',
  'sc.success': 'Erfolgreich erkannt (iOS & Android)',
  'sc.payload': 'Rohdaten im QR-Code (Payload):',
  'sc.done': 'Fertig / Weiter gestalten',
  'sc.close': 'Modal schließen',
  'sc.alt': 'QR-Code zur Simulation des Smartphone-Kamera-Scans',
  'sc.copied': 'Kopiert',
  'sc.copy': 'Kopieren',

  /* Printable A4 card (rendered hidden, printed by the browser). */
  'pr.cut': 'Hier ausschneiden oder aufhängen',
  'pr.wifiTitle': 'Gäste-WLAN',
  'pr.wifiLead': 'Scannen Sie den QR-Code mit Ihrem Smartphone, um sich sofort mit dem Internet zu verbinden.',
  'pr.sepaLead': 'Öffnen Sie Ihre Banking-App und scannen Sie diesen Code für eine fehlerfreie Überweisung.',
  'pr.deliveryTitle': 'Paket-Abstellhinweis',
  'pr.deliveryLead': 'Hinweis für DHL, Hermes, Amazon, DPD und GLS Zusteller.',
  'pr.scanTitle': 'Hier scannen',
  'pr.scanLead': 'Halten Sie Ihre Smartphone-Kamera auf den QR-Code.',
  'pr.alt': 'Druckfertiger hochauflösender QR-Code für A4-Aushang',
  'pr.ssid': 'Netzwerk (SSID):',
  'pr.password': 'Passwort:',
  'pr.security': 'Sicherheit:',
  'pr.guestNetwork': 'Gastzugang',
  'pr.recipient': 'Empfänger:',
  'pr.iban': 'IBAN:',
  'pr.amount': 'Betrag:',
  'pr.purpose': 'Verwendungszweck:',
  'pr.place': 'Abstellort:',
  'pr.note': 'Zusatzhinweis:',
  'pr.privacy': 'DSGVO-konform ohne Tracking erstellt',
  'pr.validity': 'Dauerhaft gültig ohne Ablaufdatum',
} as const;

export type UiKey = keyof typeof uiDe;
export type UiStrings = Record<UiKey, string>;
