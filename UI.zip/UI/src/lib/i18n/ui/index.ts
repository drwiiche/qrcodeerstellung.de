/**
 * Generator UI strings by locale.
 *
 * There is no fallback to German here on purpose: a locale that is missing from
 * this map would render German labels inside a Spanish page, which is the exact
 * failure this module was written to end. `keys.test.ts` asserts that all twelve
 * locales carry the same key set as `de.ts`.
 */
import type { Locale } from '../config';
import { uiDe, type UiStrings } from './de';
import { uiEn } from './en';
import { uiFr } from './fr';
import { uiEs } from './es';
import { uiIt } from './it';
import { uiPt } from './pt';
import { uiTr } from './tr';
import { uiPl } from './pl';
import { uiRu } from './ru';
import { uiId } from './id';
import { uiHe } from './he';
import { uiAr } from './ar';

export const UI: Record<Locale, UiStrings> = {
  de: uiDe,
  en: uiEn,
  fr: uiFr,
  es: uiEs,
  it: uiIt,
  pt: uiPt,
  tr: uiTr,
  pl: uiPl,
  ru: uiRu,
  id: uiId,
  he: uiHe,
  ar: uiAr,
};

export function uiStrings(locale: Locale): UiStrings {
  return UI[locale] ?? uiDe;
}

export { uiDe };
export type { UiKey, UiStrings } from './de';
