/**
 * Locale guide pages: the type definitions and the routing helpers.
 *
 * A guide is a depth page that exists in more than one locale. The internal
 * key ("wifi") is shared so the cluster can be reasoned about; the public slug
 * is per locale, because a German searches for "wlan qr code" and a Pole for
 * "kod qr wifi". Localized slugs cost a little routing complexity and buy the
 * exact-match URL in every market.
 */
import type { Locale } from './config';
import { localePath } from './config';

export interface GuideSection {
  h2: string;
  body: string[];
  bullets?: string[];
}

export interface GuideTable {
  caption: string;
  head: string[];
  rows: string[][];
}

export interface Guide {
  /** Internal key, shared across locales. Never appears in a URL. */
  key: string;
  /** Public slug for this locale. */
  slug: string;
  /** Deep link target inside the generator. */
  toolType: string;
  metaTitle: string;
  metaDescription: string;
  h1: string;
  lead: string;
  /**
   * Answer-first summary: one or two sentences that answer the page's main
   * question outright, rendered in a box above the intro and used as the
   * HowTo/AEO payload. Assistants quote this, so it has to stand alone without
   * the rest of the page.
   */
  answer?: { label: string; text: string };
  intro: string[];
  sections: GuideSection[];
  table?: GuideTable;
  faq: { q: string; a: string }[];
  cta: { label: string; hint: string };
  /** Localized labels for the page furniture. */
  ui: {
    contents: string;
    faq: string;
    related: string;
    back: string;
    updated: string;
    tableCaption: string;
  };
}

/**
 * A guide cluster. Not every guide is published in every locale: a menu page
 * in Hebrew would be inventing demand the harvest did not show. The type is
 * therefore partial, and every helper here iterates over whatever locales are
 * actually present.
 */
export type GuideCluster = Partial<Record<Locale, Guide>>;

/** Every slug a guide is published under, keyed by locale. */
export function guideSlugs(guides: GuideCluster): Partial<Record<Locale, string>> {
  return Object.fromEntries(
    (Object.entries(guides) as [Locale, Guide][]).map(([l, g]) => [l, g.slug])
  ) as Partial<Record<Locale, string>>;
}

/**
 * hreflang map for a guide cluster.
 *
 * Every locale in the cluster points at every other one, including itself, and
 * x-default points at German. Only call this for a guide that really is
 * published in all listed locales.
 */
export function guideAlternates(guides: GuideCluster): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [locale, guide] of Object.entries(guides) as [Locale, Guide][]) {
    out[hreflangOf(locale)] = localePath(locale, `/${guide.slug}`);
  }
  /* x-default belongs to the lead language when that language is in the
     cluster. For a cluster without German it is omitted rather than pointing
     at a page that does not exist. */
  if (guides.de) out['x-default'] = localePath('de', `/${guides.de.slug}`);
  return out;
}

const HREFLANG: Record<Locale, string> = {
  de: 'de-DE',
  en: 'en',
  fr: 'fr-FR',
  es: 'es-ES',
  it: 'it-IT',
  pt: 'pt-BR',
  tr: 'tr-TR',
  pl: 'pl-PL',
  ru: 'ru-RU',
  id: 'id-ID',
  he: 'he-IL',
  ar: 'ar',
};

export function hreflangOf(l: Locale): string {
  return HREFLANG[l];
}
