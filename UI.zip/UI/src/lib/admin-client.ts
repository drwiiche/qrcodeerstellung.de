/**
 * Admin client helpers.
 *
 * The dashboard normally authenticates with the HttpOnly session cookie. That
 * cookie is silently discarded in one common case: the app is opened inside a
 * sandboxed preview iframe, where the browser refuses to store cookies for the
 * embedded document. The login POST still succeeds, the follow-up request then
 * comes back 401, and the UI bounces the user back to an empty form with no
 * message — indistinguishable from "nothing happened".
 *
 * So the session token is also kept client-side and sent as a bearer header.
 * The server accepts either; the cookie stays the primary, HttpOnly path.
 */
const KEY = 'qr_admin_token';

let memoryToken: string | null = null;

export function setAdminToken(token: string | null): void {
  memoryToken = token;
  try {
    if (token) sessionStorage.setItem(KEY, token);
    else sessionStorage.removeItem(KEY);
  } catch {
    /* storage blocked — the in-memory copy covers this page view */
  }
}

export function getAdminToken(): string | null {
  if (memoryToken) return memoryToken;
  try {
    memoryToken = sessionStorage.getItem(KEY);
  } catch {
    memoryToken = null;
  }
  return memoryToken;
}

/** `fetch` for admin endpoints: adds the bearer token and JSON content type. */
export async function adminFetch(input: string, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers);
  const token = getAdminToken();
  if (token) headers.set('Authorization', `Bearer ${token}`);
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  return fetch(input, { ...init, headers });
}
