/**
 * Declarative field schema for the schema-driven QR types.
 *
 * The twelve original types each have a hand-written form branch in QRForm.tsx
 * with its own props drilled from the shell. Repeating that pattern for eight
 * more types would have meant sixteen more props and eight more JSX blocks.
 * These types are simple enough to describe as data instead: a list of fields
 * with a label, a placeholder and a hint, and one generic form component that
 * renders whichever list it is given.
 *
 * The benefit is not only brevity: the public API can read the same schema, so
 * a field cannot exist in the form and be missing from the API.
 */
import type { AdvancedType } from '../utils/payloads';

export interface TypeField {
  /** Key in the flat value map, and the query parameter name in the API. */
  id: string;
  label: string;
  placeholder: string;
  /** Short explanation under the field. Says why, not just what. */
  hint?: string;
  type?: 'text' | 'email' | 'tel' | 'url' | 'number';
  inputMode?: 'text' | 'numeric' | 'email' | 'tel' | 'url' | 'decimal';
  required?: boolean;
  maxLength?: number;
  /** Placeholder for the next field in a two-column row. */
  half?: boolean;
}

export interface TypeSchema {
  label: string;
  /** One line under the form heading, in German like the rest of the tool. */
  intro: string;
  fields: TypeField[];
}

export const ADVANCED_SCHEMA: Record<AdvancedType, TypeSchema> = {
  mecard: {
    label: 'MECARD',
    intro:
      'Kompaktes Kontaktformat. Viele Scanner zeigen MECARD schneller an als vCard, dafür gibt es weniger Felder.',
    fields: [
      {
        id: 'lastName',
        label: 'Nachname',
        placeholder: 'Mustermann',
        half: true,
        maxLength: 60,
      },
      { id: 'firstName', label: 'Vorname', placeholder: 'Max', half: true, maxLength: 60 },
      {
        id: 'organization',
        label: 'Firma',
        placeholder: 'Werkstatt Nord',
        maxLength: 80,
      },
      {
        id: 'phone',
        label: 'Telefon',
        placeholder: '+49 30 12345678',
        type: 'tel',
        inputMode: 'tel',
        hint: 'Wird beim Scannen als wählbare Nummer angezeigt.',
        half: true,
      },
      {
        id: 'email',
        label: 'E-Mail',
        placeholder: 'max@example.de',
        type: 'email',
        inputMode: 'email',
        half: true,
      },
      { id: 'url', label: 'Webseite', placeholder: 'https://example.de', type: 'url' },
      { id: 'address', label: 'Adresse', placeholder: 'Hauptstraße 1, 10115 Berlin' },
      { id: 'note', label: 'Notiz', placeholder: 'Öffnungszeiten, Hinweis', maxLength: 100 },
    ],
  },

  facebook: {
    label: 'Facebook',
    intro: 'Profilname oder ganze Profil-URL. Beides wird zu einem Link auf das Profil.',
    fields: [
      {
        id: 'handle',
        label: 'Profilname oder URL',
        placeholder: 'mustermann oder https://facebook.com/mustermann',
        hint: 'Der Name hinter facebook.com/. Das @ davor ist optional.',
        maxLength: 200,
      },
    ],
  },

  twitter: {
    label: 'X',
    intro: 'Profilname oder URL. Alte twitter.com-Links werden erkannt und übernommen.',
    fields: [
      {
        id: 'handle',
        label: 'Profilname oder URL',
        placeholder: 'mustermann oder https://x.com/mustermann',
        hint: 'Führt auf x.com, dem heutigen Namen des Dienstes.',
        maxLength: 200,
      },
    ],
  },

  youtube: {
    label: 'YouTube',
    intro: 'Kanalname oder Kanal-URL. Kanäle mit @ werden direkt übernommen.',
    fields: [
      {
        id: 'handle',
        label: 'Kanalname oder URL',
        placeholder: 'kanalname oder https://youtube.com/@kanalname',
        hint: 'Bei alten Kanal-URLs mit /channel/ die ganze URL einfügen.',
        maxLength: 200,
      },
    ],
  },

  instagram: {
    label: 'Instagram',
    intro: 'Profilname oder Profil-URL. Punkte im Namen sind erlaubt.',
    fields: [
      {
        id: 'handle',
        label: 'Profilname oder URL',
        placeholder: 'atelier.kaffee',
        hint: 'Der Name hinter instagram.com/.',
        maxLength: 200,
      },
    ],
  },

  bitcoin: {
    label: 'Bitcoin',
    intro:
      'BIP21: Adresse plus optionaler Betrag. Der Betrag ist in BTC, nicht in Euro, und wird unverändert übernommen.',
    fields: [
      {
        id: 'address',
        label: 'Bitcoin-Adresse',
        placeholder: 'bc1q…',
        hint: 'Adresse aus der Wallet kopieren, nicht abtippen. Ein falsches Zeichen führt zu einem Verlust, der nicht rückgängig zu machen ist.',
        required: true,
        maxLength: 120,
      },
      {
        id: 'amount',
        label: 'Betrag in BTC',
        placeholder: '0.001',
        inputMode: 'decimal',
        hint: 'Leer lassen, wenn der Zahler den Betrag selbst eintragen soll.',
        half: true,
        maxLength: 20,
      },
      {
        id: 'label',
        label: 'Empfänger',
        placeholder: 'Kaffeekasse',
        half: true,
        maxLength: 60,
      },
    ],
  },

  paypal: {
    label: 'PayPal',
    intro:
      'paypal.me-Link. Funktioniert für private Konten mit aktivem paypal.me-Profil, nicht für klassische Geschäftskonten ohne.me-Namen.',
    fields: [
      {
        id: 'handle',
        label: 'paypal.me-Name',
        placeholder: 'mustermann oder https://paypal.me/mustermann',
        hint: 'Der Teil hinter paypal.me/.',
        required: true,
        maxLength: 200,
      },
      {
        id: 'amount',
        label: 'Betrag',
        placeholder: '12.50',
        inputMode: 'decimal',
        hint: 'Ohne Währung, übernommen wird die Währung des Empfängerkontos.',
        half: true,
        maxLength: 12,
      },
    ],
  },

  pix: {
    label: 'Pix',
    intro:
      'BR Code nach der Vorgabe der Banco Central do Brasil. Der Code wird von Bank-Apps in Brasilien gelesen, nicht von europäischen Apps.',
    fields: [
      {
        id: 'key',
        label: 'Pix-Schlüssel',
        placeholder: 'max@example.com oder Telefonnummer',
        hint: 'Schlüssel kann E-Mail, Telefon, CPF/CNPJ oder eine zufällige UUID sein.',
        required: true,
        maxLength: 77,
      },
      {
        id: 'name',
        label: 'Empfänger',
        placeholder: 'Max Mustermann',
        hint: 'Bis 25 Zeichen, wird in Großbuchstaben ohne Akzente übertragen.',
        half: true,
        maxLength: 25,
      },
      {
        id: 'city',
        label: 'Ort',
        placeholder: 'Sao Paulo',
        half: true,
        maxLength: 15,
      },
      {
        id: 'amount',
        label: 'Betrag in BRL',
        placeholder: '24.90',
        inputMode: 'decimal',
        hint: 'Leer lassen für einen offenen Betrag.',
        half: true,
        maxLength: 12,
      },
      {
        id: 'txid',
        label: 'Referenz',
        placeholder: 'PEDIDO123',
        hint: 'Bis 25 Zeichen, nur Buchstaben und Ziffern. Leer bedeutet ***, also jedes Mal eine neue Referenz.',
        half: true,
        maxLength: 25,
      },
    ],
  },
};

/** Default values so the live preview has something to draw per type. */
export const ADVANCED_DEFAULTS: Record<AdvancedType, Record<string, string>> = {
  mecard: {
    lastName: 'Mustermann',
    firstName: 'Max',
    organization: 'Werkstatt Nord',
    phone: '+49 30 12345678',
    email: 'max@example.de',
    url: '',
    address: '',
    note: '',
  },
  facebook: { handle: 'mustermann' },
  twitter: { handle: 'mustermann' },
  youtube: { handle: 'kanalname' },
  instagram: { handle: 'atelier.kaffee' },
  bitcoin: { address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '', label: '' },
  paypal: { handle: 'mustermann', amount: '' },
  pix: { key: 'max@example.de', name: 'Max Mustermann', city: 'Sao Paulo', amount: '', txid: '' },
};

export function isAdvancedType(t: string): t is AdvancedType {
  return Object.prototype.hasOwnProperty.call(ADVANCED_SCHEMA, t);
}
