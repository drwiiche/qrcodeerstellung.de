/** Canonical production origin — single source of truth for SEO URLs. */
export const SITE_URL = 'https://qr-generator-deutschland.de';

/**
 * Open Graph image used across the site.
 *
 * Next.js replaces the whole `openGraph` object when a page defines its own,
 * it does not merge it with the root layout. So a page that sets title and
 * description also has to repeat the image, otherwise it ships without one.
 */
export const OG_IMAGE = [
  {
    url: '/og-image.png',
    width: 1200,
    height: 630,
    alt: 'QR-Generator Deutschland: QR-Code in Sekunden erstellen',
  },
];

/**
 * Date the guide copy was last fact-checked. Used for `dateModified`, which is
 * a real signal to search and answer engines that a page is maintained. Update
 * it when the content is genuinely reviewed, not on every deploy.
 */
export const CONTENT_UPDATED = '2026-10-29';

/**
 * Per-page Open Graph image.
 *
 * Falls back to the static file if the dynamic route is ever unavailable, but
 * the route only needs a title, so in practice every page gets its own card.
 */
export function ogImageUrl(opts: { title: string; kicker?: string; colour?: string }) {
  const params = new URLSearchParams({ t: opts.title });
  if (opts.kicker) params.set('k', opts.kicker);
  if (opts.colour) params.set('c', opts.colour);
  return `${SITE_URL}/og?${params.toString()}`;
}
