/**
 * Per-type colour coding — the one system that makes this interface colourful.
 *
 * Each QR type owns a single hue (see DESIGN.md). The hue appears in exactly
 * four places: the active type chip, the top rule of the form card, the frame
 * of the live preview, and the primary download button. Anywhere else it would
 * stop being a system and start being decoration.
 */
import type { QRType } from '../types/qr';

export interface TypeColor {
  /** Vivid hue: rules, spectrum bars, swatches. Safe because no text sits on it. */
  hex: string;
  /** Fill for chips and buttons that carry white text (>= 4.5:1 against #fff). */
  deep: string;
  /** Ink that sits legibly on top of `hex` for filled chips and buttons. */
  on: string;
  /** Very light wash of the hue for backgrounds on paper. */
  wash: string;
}

export const TYPE_COLORS: Record<QRType, TypeColor> = {
  url: { hex: '#1d4ed8', deep: '#1d4ed8', on: '#ffffff', wash: '#e8eeff' },
  wifi: { hex: '#0e9f6e', deep: '#0a7350', on: '#ffffff', wash: '#e2f7ee' },
  sepa: { hex: '#6d28d9', deep: '#6d28d9', on: '#ffffff', wash: '#efe8ff' },
  vcard: { hex: '#be185d', deep: '#be185d', on: '#ffffff', wash: '#fdeaf3' },
  delivery: { hex: '#c2410c', deep: '#c2410c', on: '#ffffff', wash: '#fdeee5' },
  standort: { hex: '#0e7490', deep: '#0e7490', on: '#ffffff', wash: '#e2f5fa' },
  event: { hex: '#a16207', deep: '#a16207', on: '#ffffff', wash: '#fbf1da' },
  phone: { hex: '#4338ca', deep: '#4338ca', on: '#ffffff', wash: '#eae8ff' },
  sms: { hex: '#15803d', deep: '#15803d', on: '#ffffff', wash: '#e4f6e9' },
  whatsapp: { hex: '#047857', deep: '#047857', on: '#ffffff', wash: '#e0f5ef' },
  email: { hex: '#be123c', deep: '#be123c', on: '#ffffff', wash: '#fde8ed' },
  text: { hex: '#475569', deep: '#475569', on: '#ffffff', wash: '#e9edf3' },

  /* Second wave. Hues picked to stay distinguishable from the twelve above and
     from each other at chip size. */
  mecard: { hex: '#0f766e', deep: '#0f766e', on: '#ffffff', wash: '#e0f4f1' },
  facebook: { hex: '#1877f2', deep: '#1866cc', on: '#ffffff', wash: '#e4effd' },
  twitter: { hex: '#1f2937', deep: '#111827', on: '#ffffff', wash: '#e8eaee' },
  youtube: { hex: '#dc2626', deep: '#b91c1c', on: '#ffffff', wash: '#fde8e8' },
  instagram: { hex: '#b8336a', deep: '#9d2a58', on: '#ffffff', wash: '#fbe7ef' },
  bitcoin: { hex: '#d97706', deep: '#b45309', on: '#ffffff', wash: '#fdf0dc' },
  paypal: { hex: '#1e3a8a', deep: '#1e3a8a', on: '#ffffff', wash: '#e5eaf8' },
  pix: { hex: '#0891b2', deep: '#0e7490', on: '#ffffff', wash: '#e0f5fa' },
};

export function typeColor(type: QRType): TypeColor {
  return TYPE_COLORS[type] ?? TYPE_COLORS.text;
}
