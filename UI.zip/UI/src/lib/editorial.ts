/**
 * Editorial accountability.
 *
 * What this module exists for: every article on the site was attributed to the
 * Organization node and nothing else, so an answer engine had no accountable
 * publisher behind the advice. This adds the missing layer honestly.
 *
 * What it deliberately does NOT do: invent a person. A named author with a
 * biography and credentials is the strongest E-E-A-T signal there is, and it
 * is also the easiest thing to fake. The site owner has not supplied a name, so
 * the byline reads "Redaktion" and points at a published editorial policy:
 * who publishes, how content is researched and checked, how corrections are
 * handled, and what the site refuses to claim.
 *
 * To upgrade later, set EDITOR.name. The byline, the Article author, the
 * Person node and the /redaktion page all read from here, so the change is one
 * line and it stays consistent everywhere.
 */
import type { Locale } from './i18n/config';

export const EDITORIAL_PATH = '/redaktion';

export const EDITOR = {
  /** Leave empty until a real, named person owns the content. */
  name: '',
  /** Short credential line shown next to the name when set. */
  role: '',
};

/** Label triplets, so the byline reads naturally in each language. */
const BYLINE: Record<Locale, { by: string; reviewed: string; standards: string }> = {
  de: { by: 'Redaktion', reviewed: 'Zuletzt geprüft', standards: 'Redaktionelle Richtlinien' },
  en: { by: 'Editorial team', reviewed: 'Last reviewed', standards: 'Editorial standards' },
  fr: { by: 'Rédaction', reviewed: 'Vérifié le', standards: 'Charte éditoriale' },
  es: { by: 'Redacción', reviewed: 'Revisado el', standards: 'Criterios editoriales' },
  it: { by: 'Redazione', reviewed: 'Verificato il', standards: 'Linee guida editoriali' },
  pt: { by: 'Redação', reviewed: 'Revisado em', standards: 'Diretrizes editoriais' },
  tr: { by: 'Editoryal ekip', reviewed: 'Son kontrol', standards: 'Editoryal ilkeler' },
  pl: { by: 'Redakcja', reviewed: 'Ostatnia weryfikacja', standards: 'Zasady redakcyjne' },
  ru: { by: 'Редакция', reviewed: 'Проверено', standards: 'Редакционные правила' },
  id: { by: 'Tim editorial', reviewed: 'Terakhir ditinjau', standards: 'Pedoman editorial' },
  he: { by: 'מערכת', reviewed: 'נבדק לאחרונה', standards: 'קווים מנחים מערכתיים' },
  ar: { by: 'فريق التحرير', reviewed: 'آخر مراجعة', standards: 'المعايير التحريرية' },
};

export function bylineLabel(locale: Locale) {
  return BYLINE[locale] ?? BYLINE.de;
}

/** The visible publisher name, which is the Editor when there is one. */
export function authorName(locale: Locale) {
  return EDITOR.name || bylineLabel(locale).by;
}

/** Human readable date, per language, for the reviewed-on line. */
export function reviewedDate(locale: Locale, iso: string) {
  const d = new Date(`${iso}T00:00:00Z`);
  const tag = locale === 'de' ? 'de-DE' : locale === 'en' ? 'en-GB' : locale;
  try {
    return d.toLocaleDateString(tag, { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
  } catch {
    return iso;
  }
}
