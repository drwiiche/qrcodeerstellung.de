/**
 * Public QR API — payload builders and validation.
 *
 * Deliberately reuses the same formatters the browser UI uses
 * (formatWifiPayload, formatSepaPayload, formatVCardPayload), so an API caller
 * and a visitor who fills in the form get byte-identical QR content. If the
 * formatters were reimplemented here they would drift within a month.
 */
import { formatWifiPayload } from '@/src/utils/wifi';
import { formatSepaPayload } from '@/src/utils/sepa';
import { formatVCardPayload } from '@/src/utils/vcard';
import { sanitizeUrl } from '@/src/utils/security';
import { formatAdvancedPayload, type AdvancedType } from '@/src/utils/payloads';

/** Second-wave types are delegated wholesale to the shared builders. */
const ADVANCED: AdvancedType[] = [
  'mecard',
  'facebook',
  'twitter',
  'youtube',
  'instagram',
  'bitcoin',
  'paypal',
  'pix',
];

export type ApiType =
  | AdvancedType
  | 'url'
  | 'text'
  | 'wifi'
  | 'sepa'
  | 'vcard'
  | 'email'
  | 'phone'
  | 'sms'
  | 'whatsapp'
  | 'standort';

export const API_TYPES: ApiType[] = [
  'mecard',
  'facebook',
  'twitter',
  'youtube',
  'instagram',
  'bitcoin',
  'paypal',
  'pix',
  'url',
  'text',
  'wifi',
  'sepa',
  'vcard',
  'email',
  'phone',
  'sms',
  'whatsapp',
  'standort',
];

export class ApiError extends Error {
  constructor(
    message: string,
    public status = 400
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

function need(params: URLSearchParams, key: string, label = key): string {
  const v = (params.get(key) ?? '').trim();
  if (!v) throw new ApiError(`Parameter "${key}" (${label}) is required for this type.`);
  return v;
}

/** Hard cap. A QR symbol above ~2953 bytes cannot be encoded at all. */
const MAX_PAYLOAD = 2000;

export function buildPayload(type: string, params: URLSearchParams): string {
  let payload: string;

  switch (type as ApiType) {
    case 'url': {
      const raw = need(params, 'url', 'target address');
      /* Check the raw input first. sanitizeUrl() substitutes a fallback for
         unsafe schemes, which is right for a form field the visitor can see,
         and wrong for an API: the caller would get a valid QR pointing at a
         domain they never asked for. */
      if (!/^https?:\/\//i.test(raw.trim())) {
        throw new ApiError('Parameter "url" must start with http:// or https://');
      }
      payload = sanitizeUrl(raw);
      break;
    }

    case 'text':
      payload = need(params, 'text', 'plain text');
      break;

    case 'wifi': {
      const encryption = (params.get('encryption') ?? 'WPA').toUpperCase();
      if (!['WPA', 'WEP', 'NOPASS'].includes(encryption)) {
        throw new ApiError('Parameter "encryption" must be one of WPA, WEP, nopass.');
      }
      payload = formatWifiPayload({
        ssid: need(params, 'ssid', 'network name'),
        password: encryption === 'NOPASS' ? '' : (params.get('password') ?? ''),
        encryption: (encryption === 'NOPASS' ? 'nopass' : encryption) as 'WPA' | 'WEP' | 'nopass',
        hidden: ['1', 'true', 'yes'].includes((params.get('hidden') ?? '').toLowerCase()),
      });
      break;
    }

    case 'sepa': {
      const iban = need(params, 'iban', 'IBAN').replace(/\s+/g, '');
      if (!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/i.test(iban)) {
        throw new ApiError('Parameter "iban" is not a plausible IBAN.');
      }
      payload = formatSepaPayload({
        name: need(params, 'name', 'account holder'),
        iban,
        bic: params.get('bic') ?? '',
        amount: params.get('amount') ?? '',
        purpose: '',
        reference: params.get('reference') ?? '',
      });
      break;
    }

    case 'vcard': {
      const firstName = params.get('firstName') ?? '';
      const lastName = params.get('lastName') ?? '';
      if (!firstName && !lastName && !(params.get('organization') ?? '')) {
        throw new ApiError(
          'Provide at least "firstName", "lastName" or "organization" for a vCard.'
        );
      }
      payload = formatVCardPayload({
        firstName,
        lastName,
        organization: params.get('organization') ?? '',
        title: params.get('title') ?? '',
        phone: params.get('phone') ?? '',
        mobile: params.get('mobile') ?? '',
        email: params.get('email') ?? '',
        street: params.get('street') ?? '',
        zip: params.get('zip') ?? '',
        city: params.get('city') ?? '',
        country: params.get('country') ?? '',
        website: params.get('website') ?? '',
        note: params.get('note') ?? '',
      });
      break;
    }

    case 'email': {
      const to = need(params, 'to', 'recipient address');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) {
        throw new ApiError('Parameter "to" is not a valid email address.');
      }
      const subject = params.get('subject') ?? '';
      const body = params.get('body') ?? '';
      const q = [
        subject ? `subject=${encodeURIComponent(subject)}` : '',
        body ? `body=${encodeURIComponent(body)}` : '',
      ]
        .filter(Boolean)
        .join('&');
      payload = `mailto:${to}${q ? '?' + q : ''}`;
      break;
    }

    case 'phone':
      payload = `tel:${need(params, 'number', 'phone number').replace(/[^\d+]/g, '')}`;
      break;

    case 'sms': {
      const number = need(params, 'number', 'phone number').replace(/[^\d+]/g, '');
      const message = params.get('message') ?? '';
      payload = `SMSTO:${number}${message ? ':' + message : ''}`;
      break;
    }

    case 'whatsapp': {
      const number = need(params, 'number', 'phone number').replace(/[^\d]/g, '');
      const message = params.get('message') ?? '';
      payload = `https://wa.me/${number}${message ? '?text=' + encodeURIComponent(message) : ''}`;
      break;
    }

    case 'standort': {
      const lat = Number(params.get('lat'));
      const lon = Number(params.get('lon'));
      if (!isFinite(lat) || Math.abs(lat) > 90) {
        throw new ApiError('Parameter "lat" must be a number between -90 and 90.');
      }
      if (!isFinite(lon) || Math.abs(lon) > 180) {
        throw new ApiError('Parameter "lon" must be a number between -180 and 180.');
      }
      payload = `geo:${lat},${lon}`;
      break;
    }

    default:
      if ((ADVANCED as string[]).includes(type)) {
        /* Every field of the schema-driven types arrives as a plain query
           parameter, so the value map is just the search params. */
        const values: Record<string, string> = {};
        for (const key of params.keys()) {
          if (key !== 'type' && key !== 'format' && key !== 'size' && key !== 'margin') {
            values[key] = params.get(key) ?? '';
          }
        }
        payload = formatAdvancedPayload(type as AdvancedType, values);
        if (!payload) {
          throw new ApiError(
            `Type "${type}" needs more parameters. See ${'/qr-api'} for the fields of this type.`
          );
        }
        break;
      }
      throw new ApiError(
        `Unknown type "${type}". Supported: ${API_TYPES.join(', ')}.`,
        400
      );
  }

  if (payload.length > MAX_PAYLOAD) {
    throw new ApiError(
      `Payload is ${payload.length} characters, the limit is ${MAX_PAYLOAD}. Shorten the input.`
    );
  }
  return payload;
}

/** Options shared by both output formats. */
export interface RenderOptions {
  format: 'svg' | 'png' | 'json';
  size: number;
  margin: number;
  dark: string;
  light: string;
  ecc: 'L' | 'M' | 'Q' | 'H';
}

const HEX = /^#[0-9a-f]{6}$/i;

export function parseOptions(params: URLSearchParams): RenderOptions {
  const format = (params.get('format') ?? 'svg').toLowerCase();
  if (format !== 'svg' && format !== 'png' && format !== 'json') {
    throw new ApiError('Parameter "format" must be "svg", "png" or "json".');
  }

  /* Clamp instead of rejecting: a caller asking for 4000 px should get the
     largest allowed size, not an error that breaks their build. */
  const rawSize = Number(params.get('size') ?? 512);
  const size = Math.min(2048, Math.max(128, isFinite(rawSize) ? Math.round(rawSize) : 512));

  const rawMargin = Number(params.get('margin') ?? 4);
  const margin = Math.min(16, Math.max(0, isFinite(rawMargin) ? Math.round(rawMargin) : 4));

  const dark = params.get('dark') ?? '#000000';
  const light = params.get('light') ?? '#ffffff';
  if (!HEX.test(dark) || !HEX.test(light)) {
    throw new ApiError('Parameters "dark" and "light" must be 6-digit hex colours like #0b1220.');
  }

  const ecc = ((params.get('ecc') ?? 'M').toUpperCase() as RenderOptions['ecc']);
  if (!['L', 'M', 'Q', 'H'].includes(ecc)) {
    throw new ApiError('Parameter "ecc" must be one of L, M, Q, H.');
  }

  return { format: format as 'svg' | 'png' | 'json', size, margin, dark, light, ecc };
}
