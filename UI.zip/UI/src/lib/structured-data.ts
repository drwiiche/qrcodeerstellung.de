/**
 * Structured-data builders shared by every page that emits JSON-LD.
 *
 * The reason this is centralised: JSON-LD is invisible. A typo in a property
 * name or a stray field does not break the build, does not throw in the
 * browser and does not look wrong on screen. It just quietly stops being
 * eligible for rich results. So the shapes live in one place, the pages pass
 * data in, and `structured-data.test.ts` walks every emitted object looking
 * for the mistakes that actually happen.
 *
 * What is deliberately NOT generated: aggregateRating, review counts, price
 * ranges and similar. Nothing on this site collects ratings, so marking them
 * up would be fabricated data, which is both a Google policy violation and a
 * lie. There is no builder for it here on purpose.
 */
import { SITE_URL } from './site';

/*
 * The publisher node, now with the two properties that make it accountable
 * rather than anonymous: `publishingPrinciples` and `correctionsPolicy` both
 * point at /redaktion, which describes how the site researches, checks and
 * corrects its content. This is the honest version of an author byline. A real
 * named person would be stronger, and the moment there is one the byline, the
 * page and this node change together.
 */
const ORG = {
  '@type': 'Organization',
  '@id': `${SITE_URL}/#organization`,
  name: 'QR-Generator Deutschland',
  url: SITE_URL,
  publishingPrinciples: `${SITE_URL}/redaktion`,
  correctionsPolicy: `${SITE_URL}/redaktion`,
} as const;

/** Article, for guides, hubs and blog posts. */
/**
 * Speakable points a voice assistant at the one paragraph that answers the
 * page's question, so it can be read aloud instead of having the whole page
 * summarised badly. It is scoped to `.answer-block`, which is the box every
 * guide renders directly under its h1 and which contains the same sentence the
 * HowTo first step repeats.
 */
function speakable() {
  return {
    '@type': 'SpeakableSpecification',
    cssSelector: ['.answer-block'],
  };
}

export function articleSchema(input: {
  headline: string;
  description: string;
  lang: string;
  path: string;
  datePublished?: string;
  dateModified?: string;
  /** Set only on pages that actually render the .answer-block paragraph. */
  withSpeakable?: boolean;
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: input.headline,
    description: input.description,
    inLanguage: input.lang,
    url: `${SITE_URL}${input.path}`,
    mainEntityOfPage: { '@type': 'WebPage', '@id': `${SITE_URL}${input.path}` },
    ...(input.datePublished ? { datePublished: input.datePublished } : {}),
    ...(input.dateModified ? { dateModified: input.dateModified } : {}),
    author: ORG,
    publisher: ORG,
    isAccessibleForFree: true,
    ...(input.withSpeakable ? { speakable: speakable() } : {}),
  };
}

/** FAQPage, from a list of question and answer pairs. */
export function faqSchema(items: { q: string; a: string }[], lang: string) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    inLanguage: lang,
    mainEntity: items.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };
}

/**
 * HowTo. Only use this when the page really is a numbered procedure with a
 * result, which the guides are. Marking a marketing page as HowTo to chase a
 * rich result is the kind of thing that gets a manual action rather than a
 * rich result.
 */
export function howToSchema(input: {
  name: string;
  description: string;
  lang: string;
  steps: { name: string; text: string }[];
  totalTime?: string;
  tool?: string[];
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'HowTo',
    name: input.name,
    description: input.description,
    inLanguage: input.lang,
    ...(input.totalTime ? { totalTime: input.totalTime } : {}),
    ...(input.tool ? { tool: input.tool.map((t) => ({ '@type': 'HowToTool', name: t })) } : {}),
    step: input.steps.map((s, i) => ({
      '@type': 'HowToStep',
      position: i + 1,
      name: s.name,
      text: s.text,
      url: `${SITE_URL}#${i + 1}`,
    })),
  };
}

/** WebApplication, for the tool itself and its localized copies. */
export function appSchema(input: {
  name: string;
  description: string;
  lang: string;
  path: string;
  features: string[];
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: input.name,
    description: input.description,
    url: `${SITE_URL}${input.path}`,
    applicationCategory: 'UtilitiesApplication',
    operatingSystem: 'Any',
    browserRequirements: 'Requires JavaScript',
    inLanguage: input.lang,
    isAccessibleForFree: true,
    offers: { '@type': 'Offer', price: '0', priceCurrency: 'EUR' },
    featureList: input.features,
    publisher: ORG,
  };
}

/** BreadcrumbList. Pass the trail in order, starting at the home page. */
export function breadcrumbSchema(trail: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: trail.map((t, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: t.name,
      item: `${SITE_URL}${t.path}`,
    })),
  };
}

/** ItemList, for the template gallery and any other enumerated page. */
export function itemListSchema(name: string, items: { name: string; description: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name,
    numberOfItems: items.length,
    itemListElement: items.map((it, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: it.name,
      description: it.description,
    })),
  };
}
