'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Home, Wifi, CreditCard, Mail, Search, FileQuestion } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  const router = useRouter();
  const onNavigateHome = () => router.push('/');
  const onSelectType = (type: string) => router.push(`/?type=${type}`);

  return (
    <div className="max-w-3xl mx-auto px-4 py-12 sm:py-16 text-center">
      <div className="w-14 h-14 rounded-none bg-paper-2 border border-rule text-ink flex items-center justify-center mx-auto mb-6">
        <FileQuestion className="w-7 h-7 stroke-[1.6]" />
      </div>

      <p className="text-xs font-semibold text-accent mb-3">Fehler 404</p>

      <h1 className="text-3xl sm:text-4xl font-semibold text-ink tracking-tight mb-3">
        Diese Seite existiert leider nicht
      </h1>

      <p className="text-sm sm:text-base text-ink/60 max-w-xl mx-auto leading-relaxed mb-8">
        Die von Ihnen aufgerufene Adresse konnte auf unserem Server nicht gefunden werden. Eventuell wurde der Link verschoben oder die URL fehlerhaft eingegeben.
      </p>

      {/* Primary CTAs */}
      <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
        <button
          type="button"
          onClick={onNavigateHome}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-none bg-black hover:bg-paper-2 text-white font-semibold text-sm transition cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>Zurück zum QR-Generator</span>
        </button>

        <button
          type="button"
          onClick={() => window.history.back()}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-none bg-paper hover:bg-paper-2 text-ink font-semibold text-sm border border-rule transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Vorherige Seite</span>
        </button>
      </div>

      {/* Helpful Quick Links */}
      <div className="bg-paper rounded-none border border-rule p-6 text-left max-w-xl mx-auto">
        <h2 className="text-xs font-bold uppercase tracking-wider text-ink/60 mb-3 flex items-center gap-2">
          <Search className="w-3.5 h-3.5" />
          Häufig gesuchte QR-Code Vorlagen
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onSelectType('wifi')}
            className="flex items-center gap-2.5 p-3 rounded-none bg-paper-2 hover:bg-paper-2 border border-rule text-ink text-xs font-semibold transition cursor-pointer text-left"
          >
            <Wifi className="w-4 h-4 flex-shrink-0" />
            <span>Fritz!Box Gäste-WLAN</span>
          </button>

          <button
            type="button"
            onClick={() => onSelectType('sepa')}
            className="flex items-center gap-2.5 p-3 rounded-none bg-paper-2 hover:bg-paper-2 border border-rule text-ink text-xs font-semibold transition cursor-pointer text-left"
          >
            <CreditCard className="w-4 h-4 flex-shrink-0" />
            <span>SEPA GiroCode Überweisung</span>
          </button>
        </div>
      </div>
    </div>
  );
};
