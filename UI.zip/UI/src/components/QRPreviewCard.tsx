/**
 * Live preview and export panel.
 *
 * A pale sheet on pale paper, separated only by a hairline and the active
 * type's colour along the top edge. Everything inside is a plain readout:
 * score, size, export. No inverted panel, no gradient CTA, no capsule badges.
 */
import React, { useMemo, useState } from 'react';
import {
  Download,
  Copy,
  Printer,
  Smartphone,
  Check,
  AlertTriangle,
  FileCode,
  BookmarkPlus,
  XCircle,
  Image as ImageIcon,
  Loader2,
} from 'lucide-react';
import { QRCustomization } from '../types/qr';
import { generateQRSvg } from '../utils/qrRenderer';
import { computeQrScore } from '../utils/qrScore';
import { trackEvent } from '../utils/analytics';
import { ICON_LABELS } from '../utils/translations';
import { useUi } from './i18n/UiProvider';
import { gradeLabel, issueText } from '../lib/i18n/ui/score';

interface QRPreviewCardProps {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  qrImageUrl: string;
  payload: string;
  customization: QRCustomization;
  setCustomization: React.Dispatch<React.SetStateAction<QRCustomization>>;
  onOpenScanTest: () => void;
  onSaveToHistory?: () => void;
  /** `tone` was added so a blocked download can be styled as an error instead
   *  of looking like a success message. */
  onNotify?: (text: string, tone?: 'success' | 'error' | 'info') => void;
  onNavigateThankYou?: () => void;
  isRendering?: boolean;
  /** Hue of the active QR type, from TYPE_COLORS. */
  accentColor?: string;
  /** Vivid hue for the frame; accentColor is the text-safe variant. */
  accentVivid?: string;
  /** Human label of the active type, shown in the panel header. */
  typeLabel?: string;
}

export const QRPreviewCard: React.FC<QRPreviewCardProps> = ({
  canvasRef,
  qrImageUrl,
  payload,
  customization,
  setCustomization,
  onOpenScanTest,
  onSaveToHistory,
  onNotify,
  onNavigateThankYou,
  isRendering = false,
  accentColor = '#0b1220',
  accentVivid,
  typeLabel,
}) => {
  const u = useUi();
  const [copied, setCopied] = useState(false);
  const [downloadingPng, setDownloadingPng] = useState(false);
  const [downloadingSvg, setDownloadingSvg] = useState(false);

  const score = useMemo(() => computeQrScore(customization), [customization]);
  const hasDesignImage = Boolean(
    customization.backgroundImageUrl || customization.borderImageUrl
  );
  /*
   * The readout used to sit on an ink panel, so the score colours only had to
   * work as fills. It sits on paper now, which means the label is text and needs
   * 4.5:1. These variants measure 5.03, 5.96 and 6.88 on the paper token.
   */
  const scoreTone =
    score.grade === 'sehr-gut' || score.grade === 'gut'
      ? { bar: '#0b7a56', text: '#0b7a56' }
      : score.grade === 'ausreichend'
        ? { bar: '#8a5305', text: '#8a5305' }
        : { bar: '#9a3412', text: '#9a3412' };

  /**
   * Save the rendered canvas as a PNG.
   *
   * Two robustness changes over the data-URL version:
   *
   * 1. `toBlob` + an object URL instead of `toDataURL`. A data URL carries the
   *    whole image in the URL itself, which Safari refuses above a certain
   *    length and iOS often ignores from an anchor click. A Blob URL is a
   *    normal download.
   * 2. When the page is embedded in an iframe without `allow-downloads` (which
   *    is exactly how the site preview inside a dashboard behaves), the click
   *    is silently refused by the browser: no exception, no file, and a
   *    "saved" message that is a lie. That case is detected and answered with
   *    the real instruction instead of a success toast.
   */
  const handleDownloadPng = async () => {
    const canvas = canvasRef.current;
    if (!canvas || downloadingPng) return;
    setDownloadingPng(true);

    const embedded = window.self !== window.top;
    const size = customization.size;

    const save = (href: string, revoke: () => void) => {
      const link = document.createElement('a');
      link.download = `qr-code-${Date.now()}.png`;
      link.href = href;
      link.rel = 'noopener';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      revoke();
      trackEvent('qr_download_png', { size });
      onNotify?.(u['tst.pngOk'].replace('{size}', String(size)));
    };

    try {
      if (embedded) {
        /* Still try: some embeds do allow it. But never promise a file we
           cannot deliver without a saving dialog. */
        const dataUrl = canvas.toDataURL('image/png', 1.0);
        const w = window.open(dataUrl, '_blank');
        if (!w) {
          onNotify?.(u['tst.pngBlocked'], 'error');
          return;
        }
        trackEvent('qr_download_png', { size });
        return;
      }

      await new Promise<void>((resolve) => {
        if (typeof canvas.toBlob !== 'function') {
          save(canvas.toDataURL('image/png', 1.0), () => {});
          resolve();
          return;
        }
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              try {
                save(canvas.toDataURL('image/png', 1.0), () => {});
              } catch {
                onNotify?.(u['tst.pngBlocked'], 'error');
              }
              resolve();
              return;
            }
            const url = URL.createObjectURL(blob);
            save(url, () => setTimeout(() => URL.revokeObjectURL(url), 1000));
            resolve();
          },
          'image/png',
          1.0
        );
      });
    } catch {
      onNotify?.(u['tst.pngBlocked'], 'error');
    } finally {
      setTimeout(() => setDownloadingPng(false), 500);
    }
  };

  const handleDownloadSvg = async () => {
    if (downloadingSvg) return;
    if (hasDesignImage) {
      onNotify?.(u['tst.svgImage'], 'info');
      return;
    }
    setDownloadingSvg(true);
    try {
      const svgData = await generateQRSvg(payload, customization);
      const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.download = `qr-code-deutschland-${Date.now()}.svg`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);

      trackEvent('qr_download_svg');
      onNotify?.(u['tst.svgOk']);
    } catch (e) {
      console.error(e);
      onNotify?.(u['tst.svgFail'], 'error');
    } finally {
      setDownloadingSvg(false);
    }
  };

  const handleCopyToClipboard = async () => {
    if (!canvasRef.current) return;
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) return;
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
        setCopied(true);
        trackEvent('qr_copy_payload');
        onNotify?.(u['tst.imgCopied']);
        setTimeout(() => setCopied(false), 2500);
      });
    } catch (err) {
      console.error('Clipboard copy error', err);
      try {
        await navigator.clipboard.writeText(payload);
        setCopied(true);
        onNotify?.(u['tst.txtCopied']);
        setTimeout(() => setCopied(false), 2000);
      } catch {
        onNotify?.(u['tst.copyBlocked'], 'error');
      }
    }
  };

  const handlePrint = () => {
    trackEvent('qr_print');
    window.print();
  };

  const secondaryBtn =
    'inline-flex items-center justify-center gap-1.5 h-9 border border-rule text-ink text-[12px] font-medium transition-colors hover:border-ink hover:bg-paper-2 disabled:opacity-50';

  return (
    <section
      aria-labelledby="preview-heading"
      className="bg-paper text-ink border border-rule"
      style={{ borderTopWidth: 2, borderTopColor: accentVivid || accentColor }}
    >
      <div className="px-4 sm:px-5 py-4">
        <div className="flex items-baseline justify-between gap-3 mb-3">
          <h2 id="preview-heading" className="text-[13px] font-semibold">{u['pv.live']}</h2>
          {typeLabel && <span className="spec text-[9px] text-ink/40">{typeLabel}</span>}
        </div>

        <canvas ref={canvasRef} className="hidden" />

        {/* The code itself on white, because a QR code needs its contrast */}
        <div
          className="relative w-full max-w-[240px] sm:max-w-[280px] mx-auto aspect-square bg-white border border-rule grid place-items-center p-4"
        >
          {isRendering && (
            <div className="absolute inset-0 bg-white/85 z-10 grid place-items-center">
              <span className="spec text-[10px] text-ink/60">{u['pv.drawing']}</span>
            </div>
          )}

          {qrImageUrl ? (
            <img
              src={qrImageUrl}
              alt={u['pv.alt']}
              width={280}
              height={280}
              className="w-full h-full object-contain"
            />
          ) : (
            <div
              className="w-8 h-8 border-2 border-t-transparent animate-spin"
              style={{ borderColor: accentColor, borderTopColor: 'transparent' }}
              role="status"
              aria-label={u['pv.ariaBusy']}
            />
          )}
        </div>

        {/* Readability check: a measurement, stated like one */}
        <div className="mt-3" aria-live="polite">
          <div className="flex items-baseline justify-between gap-3 mb-1.5">
            <span className="spec text-[9px] text-ink/45">{u['pv.readability']}</span>
            <span className="spec text-[10px] tabular-nums" style={{ color: scoreTone.bar }}>
              {score.score}/100 {gradeLabel(u, score.grade)}
            </span>
          </div>
          <div
            className="h-1 w-full bg-rule"
            role="img"
            aria-label={`${u['pv.readability']} ${score.score}/100`}
          >
            <div
              className="h-full transition-[width] duration-200"
              style={{ width: `${score.score}%`, backgroundColor: scoreTone.bar }}
            />
          </div>

          {score.issueCodes.length > 0 ? (
            <ul className="mt-2 space-y-1">
              {score.issueCodes.slice(0, 3).map((code) => (
                <li key={code} className="flex items-start gap-1.5 text-[11px] leading-snug text-ink/65">
                  <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0 text-[#f0b429]" aria-hidden="true" />
                  {issueText(u, code)}
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-2 text-[11px] leading-snug text-ink/50">{u['pv.contrastOk']}</p>
          )}
        </div>

        {customization.logoType !== 'none' || customization.customLogoUrl ? (
          <div className="mt-3 flex items-center justify-between gap-2 text-[11px] border-t border-rule pt-2.5">
            <span className="flex items-center gap-1.5 text-ink/65">
              <ImageIcon className="w-3.5 h-3.5" aria-hidden="true" />
              Icon:{' '}
              <strong className="text-ink font-semibold">
                {customization.customLogoUrl
                  ? 'eigenes Bild'
                  : ICON_LABELS[customization.logoType] || customization.logoType}
              </strong>
            </span>
            <button
              type="button"
              onClick={() => {
                setCustomization({ ...customization, logoType: 'none', customLogoUrl: undefined });
                onNotify?.(u['tst.iconRemoved']);
              }}
              className="inline-flex items-center gap-1 text-ink/50 hover:text-ink transition-colors"
            >
              <XCircle className="w-3.5 h-3.5" aria-hidden="true" />{u['pv.remove']}</button>
          </div>
        ) : null}

        {/* Export: primary action in the type's own colour */}
        <div className="mt-4 space-y-2">
          <button
            type="button"
            onClick={handleDownloadPng}
            disabled={downloadingPng}
            className="w-full h-11 px-4 font-bold text-[13px] inline-flex items-center justify-center gap-2 transition-opacity hover:opacity-90 disabled:opacity-60"
            style={{ backgroundColor: accentColor, color: '#ffffff' }}
          >
            {downloadingPng ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />{u['pv.pngWorking']}</>
            ) : (
              <>
                <Download className="w-4 h-4" strokeWidth={2.4} aria-hidden="true" />{u['pv.png']}</>
            )}
          </button>

          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={handleDownloadSvg}
              disabled={downloadingSvg}
              className={secondaryBtn}
              title={u['pv.titleSvg']}
            >
              {downloadingSvg ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
              ) : (
                <FileCode className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {hasDesignImage ? u['pv.svgLocked'] : u['pv.svg']}
            </button>

            <button
              type="button"
              onClick={handleCopyToClipboard}
              className={`${secondaryBtn} ${copied ? 'bg-ink text-paper border-ink' : ''}`}
              title={u['pv.titleCopy']}
            >
              {copied ? (
                <Check className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <Copy className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              {copied ? u['pv.copied'] : u['pv.copy']}
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className={secondaryBtn}
              title={u['pv.titlePrint']}
            >
              <Printer className="w-3.5 h-3.5" aria-hidden="true" />{u['pv.print']}</button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={onOpenScanTest} className={secondaryBtn}>
              <Smartphone className="w-3.5 h-3.5" aria-hidden="true" />{u['m.scanTest']}</button>

            {onSaveToHistory && (
              <button type="button" onClick={onSaveToHistory} className={secondaryBtn}>
                <BookmarkPlus className="w-3.5 h-3.5" aria-hidden="true" />{u['pv.history']}</button>
            )}
          </div>
        </div>

        {/* Export size: a segmented control, hairline only */}
        <div className="mt-3 pt-3 border-t border-rule flex items-center justify-between gap-3">
          <span className="spec text-[9px] text-ink/45">{u['pv.pixels']}</span>
          <div className="inline-flex border border-rule" role="group" aria-label={u['pv.ariaSize']}>
            {[512, 1024, 2048].map((sz) => (
              <button
                key={sz}
                type="button"
                onClick={() => setCustomization({ ...customization, size: sz })}
                aria-pressed={customization.size === sz}
                className={`px-2.5 h-7 text-[11px] tabular-nums border-r border-rule last:border-r-0 transition-colors ${
                  customization.size === sz
                    ? 'bg-ink text-paper font-semibold'
                    : 'text-ink/60 hover:text-ink'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
