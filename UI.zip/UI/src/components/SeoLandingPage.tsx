/**
 * Renderer for the use-case pages (/qr-codes-fuer/… and /qr-codes-auf/…).
 *
 * Each hub owns a colour from the same system as the generator's QR types, so a
 * visitor arriving here already knows which hue belongs to the work they do.
 * Layout is a printed sheet: ink header band, hairline sections, one accent.
 */
import Link from 'next/link';
import type { SeoHub, SeoSubPage } from '../data/seo-pages';
import { AdSlot } from './AdSlot';
import { JsonLd } from './JsonLd';
import {
  breadcrumbSchema,
  faqSchema as faqLd,
  itemListSchema,
} from '../lib/structured-data';

/**
 * UI strings for the renderer. The German set is the default, so the existing
 * German hubs do not change. A non-German page passes its own set rather than
 * shipping a German frame around English content.
 */
export interface SeoUiLabels {
  home: string;
  breadcrumbLabel: string;
  openGenerator: string;
  detail: string;
  cases: string;
  steps: string;
  tools: string;
  furtherReading: string;
  faq: string;
  sources: string;
  moreCases: (hubLabel: string) => string;
  related: string;
  noticeTitle: string;
  noticeBody: string;
}

export const SEO_LABELS_DE: SeoUiLabels = {
  home: 'Startseite',
  breadcrumbLabel: 'Brotkrumen',
  openGenerator: 'Generator öffnen',
  detail: 'Im Einzelnen',
  cases: 'Typische Fälle',
  steps: 'So entsteht der Code',
  tools: 'Direkt zum passenden Generator',
  furtherReading: 'Zum Weiterlesen',
  faq: 'Häufige Fragen zu diesem Fall',
  sources: 'Quellen',
  moreCases: (hubLabel) => `Weitere Fälle: ${hubLabel}`,
  related: 'Ebenfalls hilfreich',
  noticeTitle: 'Hinweis',
  noticeBody:
    'Diese Seite ordnet die genannten Vorschriften ein und verlinkt die Primärquellen. Sie ist keine Rechtsberatung. Ob eine Pflicht auf Ihren Fall zutrifft, hängt von Betriebsgröße, Produkt, Gebäude und Vertrag ab und gehört zu einer Anwältin, einem Anwalt oder einer zuständigen Behörde.',
};

export const SEO_LABELS_EN: SeoUiLabels = {
  home: 'Home',
  breadcrumbLabel: 'Breadcrumb',
  openGenerator: 'Open the generator',
  detail: 'In detail',
  cases: 'Typical cases',
  steps: 'How the code is built',
  tools: 'Go straight to the generator',
  furtherReading: 'Further reading',
  faq: 'Frequently asked questions',
  sources: 'Sources',
  moreCases: (hubLabel) => `More on ${hubLabel}`,
  related: 'Also useful',
  noticeTitle: 'Note',
  noticeBody:
    'This page summarises the rules named above and links the primary sources. It is not legal advice. Whether an obligation applies to your case depends on your company size, the product, the building and the contract, and that question belongs to a lawyer or a competent authority.',
};

interface Props {
  hub: SeoHub;
  sub?: SeoSubPage;
  /** Defaults to German. Pass SEO_LABELS_EN for an English page. */
  labels?: SeoUiLabels;
  /**
   * Where "home" and the generator button point. German pages are unprefixed and
   * the tool lives at "/", a localized type page lives under /<locale> and its
   * generator sits on that locale's homepage, so both are passed in.
   */
  homeHref?: string;
  generatorHref?: string;
  /** BCP-47 tag for the JSON-LD. Defaults to German. */
  lang?: string;
}

const HUB_COLORS: Record<string, string> = {
  unternehmen: '#be185d',
  schulen: '#1d4ed8',
  veranstaltungen: '#a16207',
  immobilien: '#0e7490',
  gesundheit: '#0e9f6e',
  auf: '#c2410c',
  standards: '#3f5a52',
  'qr-code-generator': '#1d4ed8',
};

function SourceList({
  sources,
  labels = SEO_LABELS_DE,
}: {
  sources?: { label: string; href: string }[];
  labels?: SeoUiLabels;
}) {
  if (!sources?.length) return null;
  return (
    <section className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 pb-12">
      <h2 className="spec text-[9px] text-ink/45">{labels.sources}</h2>
      <ul className="mt-2 space-y-1.5">
        {sources.map((src) => (
          <li key={src.href}>
            <a
              href={src.href}
              rel="noopener"
              target="_blank"
              className="text-[13.5px] text-ink/70 underline underline-offset-2 hover:text-ink transition-colors"
            >
              {src.label}
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}

function hubBasePath(hub: SeoHub) {
  if (hub.basePath) return hub.basePath;
  return hub.slug === 'auf' ? '/qr-codes-auf' : `/qr-codes-fuer/${hub.slug}`;
}

/**
 * Regulatory pages make claims about statutes. A reader who acts on them without
 * checking their own case needs to be told, in the flow of the page and not in a
 * footer, that this is an overview and not advice.
 */
function LegalNotice({ labels }: { labels: SeoUiLabels }) {
  return (
    <section
      aria-labelledby="keine-rechtsberatung"
      className="mt-12 border border-rule bg-paper-2 px-5 py-4"
    >
      <h2 id="keine-rechtsberatung" className="spec text-[9px] text-ink/45">
        {labels.noticeTitle}
      </h2>
      <p className="text-[13px] leading-relaxed text-ink/75 mt-2 max-w-2xl">
        {labels.noticeBody}
      </p>
    </section>
  );
}

export function SeoLandingPage({
  hub,
  sub,
  labels = SEO_LABELS_DE,
  homeHref = '/',
  generatorHref = '/',
  lang = 'de-DE',
}: Props) {
  const home = homeHref;
  const cta = generatorHref;
  const isHub = !sub;
  const hue = HUB_COLORS[hub.slug] ?? '#1d4ed8';
  const basePath = hubBasePath(hub);

  const crumbs = (
    <nav aria-label={labels.breadcrumbLabel} className="flex flex-wrap items-center gap-2 spec text-[9px]">
      <Link href={home} className="text-ink/50 hover:text-ink transition-colors">
        {labels.home}
      </Link>
      <span className="text-ink/25" aria-hidden="true">/</span>
      {isHub ? (
        <span className="text-ink/80">{hub.label}</span>
      ) : (
        <>
          <Link href={basePath} className="text-ink/50 hover:text-ink transition-colors">
            {hub.label}
          </Link>
          <span className="text-ink/25" aria-hidden="true">/</span>
          <span className="text-ink/80">{sub.title.split(':')[0]}</span>
        </>
      )}
    </nav>
  );

  if (isHub) {
    /* The hub branch used to return before any structured data was emitted, so
     * all eight hub pages shipped with an empty graph while their child pages
     * were fully marked up. A hub is a list of children, so it gets a
     * CollectionPage-flavoured ItemList alongside the trail and its own FAQ. */
    const hubSchemas = [
      itemListSchema(
        hub.title,
        hub.subs.map((s) => ({ name: s.metaTitle, description: s.metaDescription })),
      ),
      faqLd(hub.faq, lang),
      breadcrumbSchema([
        { name: labels.home, path: '/' },
        { name: hub.label, path: basePath },
      ]),
    ];
    return (
      <>
        {hubSchemas.map((schema, i) => (
          <JsonLd key={i} data={schema} />
        ))}
        <header className="bg-ink text-paper on-ink border-b-2" style={{ borderColor: hue }}>
          <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 pt-5 pb-9 sm:pb-10">
            <div className="[&_a]:text-paper/50 [&_a:hover]:text-paper [&_span]:text-paper/70">
              {crumbs}
            </div>
            <h1 className="display text-[clamp(1.7rem,3.6vw,2.5rem)] mt-5 max-w-3xl text-paper">
              {hub.title}
            </h1>
            <div className="mt-6 max-w-2xl space-y-3">
              {hub.intro.map((p, i) => (
                <p key={i} className="text-[15px] leading-relaxed text-paper/70">
                  {p}
                </p>
              ))}
            </div>
            <Link
              href={cta}
              className="inline-flex items-center h-11 px-5 mt-7 bg-acid text-ink text-[13px] font-bold hover:bg-paper transition-colors"
            >
              {labels.openGenerator}
            </Link>
          </div>
        </header>

        <div className="max-w-[1100px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <AdSlot position="below-hero" />

          {/* Substantive material: one section per real workflow */}
          <div className="max-w-3xl">
            {hub.sections.map((sec) => (
              <section key={sec.title} className="pt-2 pb-6 border-b border-rule last:border-b-0">
                <h2 className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mb-3">{sec.title}</h2>
                {sec.body.map((par, i) => (
                  <p key={i} className="text-[15px] leading-relaxed text-ink/80 mt-3 first:mt-0 break-words">
                    {par}
                  </p>
                ))}
                {sec.bullets && (
                  <ul className="mt-4 border-l-2 pl-4 space-y-1.5" style={{ borderColor: hue }}>
                    {sec.bullets.map((b) => (
                      <li key={b} className="text-[13.5px] leading-relaxed text-ink/70 break-words">
                        {b}
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            ))}
          </div>

          {/* FAQ for the hub itself */}
          <section className="max-w-3xl mt-10" aria-labelledby="hub-faq">
            <h2 id="hub-faq" className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mb-3">
              {labels.faq}
            </h2>
            <div className="border-t border-rule">
              {hub.faq.map((f) => (
                <div key={f.q} className="py-4 border-b border-rule">
                  <h3 className="text-[14.5px] font-bold mb-1.5">{f.q}</h3>
                  <p className="text-[13.5px] leading-relaxed text-ink/70 break-words">{f.a}</p>
                </div>
              ))}
            </div>
          </section>

          {hub.subs.length > 0 && (
            <>
              <h2 className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mt-12 mb-1">
                Im Detail
              </h2>
              <p className="text-[14px] text-ink/60 mb-5 max-w-xl">
                Fälle, die eine eigene Seite brauchen, weil sie eigene Fragen mitbringen.
              </p>
            </>
          )}
          {hub.subs.length > 0 && (
          <h3 className="spec text-[9px] text-ink/45 mb-2">Anwendungsfälle</h3>
          )}
          <p className="text-[14px] text-ink/60 mb-6 max-w-xl">
            Jede Seite beschreibt einen konkreten Fall: was gedruckt wird, wo der Code hängt
            und was dabei schiefgeht.
          </p>

          <ul className="border-t border-rule">
            {hub.subs.map((s, i) => (
              <li key={s.slug} className="border-b border-rule">
                <Link
                  href={`${basePath}/${s.slug}`}
                  className="group grid grid-cols-1 sm:grid-cols-[auto_1fr_auto] items-baseline gap-x-5 gap-y-1 py-5 hover:bg-paper-2 transition-colors px-1"
                >
                  <span className="spec text-[10px] text-ink/35 tabular-nums">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span>
                    <span className="block text-[16px] font-bold tracking-tight group-hover:text-ink">
                      {s.metaTitle}
                    </span>
                    <span className="block text-[13.5px] leading-relaxed text-ink/60 mt-1 max-w-2xl">
                      {s.metaDescription}
                    </span>
                  </span>
                  <span className="spec text-[9px] text-ink/40 group-hover:text-ink transition-colors">
                    Lesen
                  </span>
                </Link>
              </li>
            ))}
          </ul>

          {hub.relatedLinks && hub.relatedLinks.length > 0 && (
            <section aria-labelledby="related" className="mt-10">
              <h2 id="related" className="spec text-[9px] text-ink/45 mb-3">
                {labels.related}
              </h2>
              <ul className="space-y-1.5">
                {hub.relatedLinks.map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className="text-[13.5px] text-ink underline decoration-2 underline-offset-4 decoration-[#b23a26] hover:bg-acid hover:no-underline transition-colors"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>

        <SourceList sources={hub.sources} labels={labels} />

        {hub.slug === 'standards' && (
          <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8">
            <LegalNotice labels={labels} />
          </div>
        )}
      </>
    );
  }

  const others = hub.subs.filter((s) => s.slug !== sub.slug);
  const canonical = `${basePath}/${sub.slug}`;

  const breadcrumb = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: labels.home, item: '/' },
      { '@type': 'ListItem', position: 2, name: hub.label, item: basePath },
      { '@type': 'ListItem', position: 3, name: sub.title.split(':')[0], item: canonical },
    ],
  };

  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: sub.faq.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };

  return (
    <>
      <JsonLd data={breadcrumb} />
      <JsonLd data={faqSchema} />

      <header className="border-b border-rule">
        <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-9">
          {crumbs}
          <h1 className="display text-[clamp(1.85rem,4.6vw,3rem)] mt-5 max-w-3xl">
            {sub.title}
          </h1>
          <div className="mt-5 max-w-2xl space-y-3">
            {sub.intro.map((p, i) => (
              <p key={i} className="text-[15.5px] leading-relaxed text-ink/75 break-words">
                {p}
              </p>
            ))}
          </div>
          {sub.translations && sub.translations.length > 0 && (
            <ul className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-5 text-[12.5px]">
              {sub.translations.map((tr) => (
                <li key={tr.href}>
                  <Link
                    href={tr.href}
                    hrefLang={tr.lang}
                    className="text-ink/60 underline decoration-ink/30 underline-offset-4 hover:text-ink hover:decoration-ink transition-colors"
                  >
                    {tr.label}
                  </Link>
                </li>
              ))}
            </ul>
          )}
          <Link
            href={sub.toolLinks[0]?.href || '/'}
            className="inline-flex items-center h-11 px-5 mt-6 text-[13px] font-bold text-white transition-opacity hover:opacity-90"
            style={{ backgroundColor: hue }}
          >
            {sub.toolLinks[0]?.label || 'QR-Code erstellen'}
          </Link>
        </div>
      </header>

      <div className="max-w-[1100px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12">
        <AdSlot position="below-hero" />

        <section aria-labelledby="detail" className="mb-12">
          <h2 id="detail" className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mb-3">
            {labels.detail}
          </h2>
          <div className="max-w-3xl">
            {sub.sections.map((sec) => (
              <section key={sec.title} className="py-5 border-b border-rule last:border-b-0">
                <h3 className="text-[16px] font-bold tracking-tight mb-2">{sec.title}</h3>
                {sec.body.map((par, i) => (
                  <p key={i} className="text-[14.5px] leading-relaxed text-ink/80 mt-2.5 first:mt-0 break-words">
                    {par}
                  </p>
                ))}
                {sec.bullets && (
                  <ul className="mt-3 border-l-2 pl-4 space-y-1.5" style={{ borderColor: hue }}>
                    {sec.bullets.map((b) => (
                      <li key={b} className="text-[13px] leading-relaxed text-ink/70 break-words">
                        {b}
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            ))}
          </div>
        </section>

        <section aria-labelledby="usecases">
          <h2 id="usecases" className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mb-4">
            {labels.cases}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-rule border border-rule">
            {sub.useCases.map((u) => (
              <div key={u.title} className="bg-paper p-5">
                <h3 className="text-[14px] font-bold mb-1.5 leading-snug">{u.title}</h3>
                <p className="text-[13.5px] leading-relaxed text-ink/70 break-words">{u.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section aria-labelledby="steps" className="mt-12">
          <h2 id="steps" className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mb-4">
            {labels.steps}
          </h2>
          <ol className="border-t border-rule">
            {sub.steps.map((s, i) => (
              <li
                key={i}
                className="grid grid-cols-[auto_1fr] gap-5 py-3.5 border-b border-rule items-baseline"
              >
                <span className="spec text-[11px] tabular-nums" style={{ color: hue }}>
                  {String(i + 1).padStart(2, '0')}
                </span>
                <span className="text-[14px] leading-relaxed text-ink/75 break-words">{s}</span>
              </li>
            ))}
          </ol>
        </section>

        <section aria-labelledby="tools" className="mt-12">
          <h2 id="tools" className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mb-4">
            {labels.tools}
          </h2>
          <div className="flex flex-wrap gap-2">
            {sub.toolLinks.map((l) => (
              <Link
                key={l.href + l.label}
                href={l.href}
                className="inline-flex items-center h-10 px-4 border border-ink/20 text-[12.5px] font-semibold hover:border-ink hover:bg-paper-2 transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </div>

          {sub.blogLinks.length > 0 && (
            <>
              <h3 className="spec text-[9px] text-ink/45 mt-6 mb-2">{labels.furtherReading}</h3>
              <ul className="space-y-1.5">
                {sub.blogLinks.map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className="text-[13.5px] text-ink underline decoration-2 underline-offset-4 decoration-[#b23a26] hover:bg-acid hover:no-underline transition-colors"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </>
          )}
        </section>

        <AdSlot position="mid-content" />

        <section aria-labelledby="faq" className="mt-12">
          <h2 id="faq" className="display text-[clamp(1.4rem,2.6vw,1.9rem)] mb-4">
            {labels.faq}
          </h2>
          <div className="border-t border-rule">
            {sub.faq.map((f) => (
              <div key={f.q} className="py-4 border-b border-rule">
                <h3 className="text-[14px] font-bold mb-1.5">{f.q}</h3>
                <p className="text-[13.5px] leading-relaxed text-ink/70 break-words">{f.a}</p>
              </div>
            ))}
          </div>
        </section>

        {hub.slug === 'standards' && <LegalNotice labels={labels} />}

        <div className="mt-12">
          <SourceList sources={sub.sources ?? hub.sources} labels={labels} />
        </div>

        {others.length > 0 && (
          <section aria-labelledby="more" className="mt-12">
            <h2 id="more" className="spec text-[9px] text-ink/45 mb-3">
              {labels.moreCases(hub.label)}
            </h2>
            <div className="flex flex-wrap gap-2">
              {others.map((s) => (
                <Link
                  key={s.slug}
                  href={`${basePath}/${s.slug}`}
                  className="inline-flex items-center h-9 px-3 border border-rule text-[12.5px] font-medium hover:border-ink hover:bg-paper-2 transition-colors"
                >
                  {s.title.split(':')[0]}
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </>
  );
}
