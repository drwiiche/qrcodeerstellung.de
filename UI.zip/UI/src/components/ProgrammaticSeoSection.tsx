/**
 * Sections below the generator.
 *
 * Three blocks, each with a different weight so the page does not read as one
 * repeated card grid (DESIGN.md, RHYTHM 3):
 *   1. an acid band that states the workflow as a numbered run,
 *   2. a quiet asymmetric list of use cases with their colour coding,
 *   3. a two-column FAQ where the questions are the ones this tool really gets.
 */
import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import Link from 'next/link';

const STEPS = [
  {
    title: 'Typ wählen',
    text: 'WLAN, GiroCode, vCard, Paket, Standort, SMS. Zwölf Typen, jeder mit eigener Farbe.',
  },
  {
    title: 'Daten eintragen',
    text: 'Das Formular fragt nur, was der gewählte Typ wirklich braucht. Die Vorschau folgt beim Tippen.',
  },
  {
    title: 'Aussehen prüfen',
    text: 'Farben, Ecken und Rahmen anpassen. Bei zu wenig Kontrast warnt der Scan-Test, bevor Sie drucken.',
  },
  {
    title: 'Herunterladen',
    text: 'SVG für die Druckerei, PNG bis 2048 px für Bildschirm und Aushang, oder direkt drucken.',
  },
];

const SOLUTIONS = [
  {
    href: '/qr-codes-fuer/unternehmen',
    title: 'Unternehmen',
    text: 'Speisekarte am Tisch, Bewertungslink auf der Rechnung, Terminanfrage am Fahrzeug.',
    color: '#be185d',
  },
  {
    href: '/qr-codes-fuer/schulen',
    title: 'Schulen und Bildung',
    text: 'Elternbriefe, Lehrmittel, Raum- und Campus-Orientierung ohne Zettelwirtschaft.',
    color: '#1d4ed8',
  },
  {
    href: '/qr-codes-fuer/veranstaltungen',
    title: 'Veranstaltungen',
    text: 'Programm, Einladung mit Rückmeldung, Einlass und Garderobe.',
    color: '#a16207',
  },
  {
    href: '/qr-codes-fuer/immobilien',
    title: 'Immobilien',
    text: 'Exposé am Objekt, Besichtigungstermin, Hinweise für Mieter im Treppenhaus.',
    color: '#0e7490',
  },
  {
    href: '/qr-codes-fuer/gesundheit',
    title: 'Gesundheit und Fitness',
    text: 'Terminbestätigung, Übungsplan am Gerät, Check-in im Studio.',
    color: '#0e9f6e',
  },
  {
    href: '/qr-codes-auf',
    title: 'Auf Druckerzeugnissen',
    text: 'Größe, Kontrast und Ruhezone, bevor Flyer, Plakat oder Verpackung in die Druckerei gehen.',
    color: '#c2410c',
  },
];

const FAQS = [
  {
    q: 'Landen mein WLAN-Passwort oder meine IBAN auf einem Server?',
    a: 'Nein. Der Code wird in Ihrem Browser berechnet, die Formulardaten werden nicht an einen Server geschickt. Es gibt keine Anmeldung und kein Konto, in dem die Eingaben liegen könnten.',
  },
  {
    q: 'Verfallen die Codes oder gibt es Scan-Limits?',
    a: 'Nein. Es sind statische Codes: Der Inhalt steht im Muster selbst. Sie funktionieren unbegrenzt oft und ändern sich nicht, solange Sie den Code nicht neu erzeugen.',
  },
  {
    q: 'Wie groß muss der Code für die Haustür sein?',
    a: 'Als Orientierung aus der Druckpraxis: mindestens 3 cm Kantenlänge, wenn der Code aus 30 cm Entfernung gescannt wird, und etwa 10 cm, wenn er aus einem Meter gelesen werden soll. Der Scan-Test in der Vorschau zeigt, ob Ihr Motiv bei der gewählten Größe noch lesbar ist.',
  },
  {
    q: 'Was kostet die Nutzung?',
    a: 'Nichts. Es gibt keine Wasserzeichen, keine Begrenzung der Anzahl und keinen Tarif. Auf der Seite stehen Werbeplätze, die nur mit Ihrer Zustimmung geladen werden.',
  },
  {
    q: 'Welche Typen deckt der Generator ab?',
    a: 'Webseite, WLAN, SEPA GiroCode, Visitenkarte (vCard), Paketabstellort, Termin, Standort, Telefon, SMS, WhatsApp, E-Mail und Freitext.',
  },
  {
    q: 'Kann ich den Code gewerblich nutzen?',
    a: 'Ja. Die erzeugten Dateien gehören Ihnen. Sie dürfen sie auf Speisekarten, Rechnungen, Fahrzeugen, Plakaten und Verpackungen verwenden.',
  },
];

export const ProgrammaticSeoSection: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <>
      {/* 1. Workflow: full-bleed acid band */}
      <section id="anleitung" className="bg-acid text-ink">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
            <div className="lg:col-span-4">
              <h2 className="display text-[clamp(1.9rem,4.4vw,3rem)]">
                Vier Schritte,
                <br />
                kein Konto.
              </h2>
              <p className="mt-4 text-[14px] leading-relaxed text-ink/75 max-w-sm">
                Der ganze Ablauf spielt sich auf einer Seite ab. Sie können jederzeit den Typ
                wechseln, die Eingaben bleiben erhalten.
              </p>
            </div>

            <ol className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-px bg-ink/20 border border-ink/20 self-start">
              {STEPS.map((step, i) => (
                <li key={step.title} className="bg-acid p-5">
                  <div className="flex items-baseline gap-3 mb-2">
                    <span className="display text-[1.75rem] text-ink/35">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <h3 className="text-[14px] font-bold">{step.title}</h3>
                  </div>
                  <p className="text-[13px] leading-relaxed text-ink/70">{step.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* 2. Use cases: quiet asymmetric list */}
      <section className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-14">
          <div className="lg:col-span-4">
            <h2 className="display text-[clamp(1.9rem,4.4vw,3rem)]">
              Wofür die Codes
              <br />
              tatsächlich benutzt werden.
            </h2>
            <p className="mt-4 text-[14px] leading-relaxed text-ink/70 max-w-sm">
              Sechs Bereiche, in denen QR-Codes in Deutschland den Alltag tragen. Jede Seite
              beschreibt die konkreten Fälle, die Fallstricke und was gedruckt funktioniert.
            </p>
          </div>

          <ul className="lg:col-span-8 divide-y divide-rule rule-t">
            {SOLUTIONS.map((sol) => (
              <li key={sol.href}>
                <Link
                  href={sol.href}
                  className="group grid grid-cols-[6px_1fr_auto] sm:grid-cols-[6px_180px_1fr_auto] items-center gap-4 sm:gap-6 py-5 hover:bg-paper-2 transition-colors"
                >
                  <span
                    className="self-stretch w-[6px] min-h-[44px]"
                    style={{ backgroundColor: sol.color }}
                    aria-hidden="true"
                  />
                  <span className="text-[15px] font-bold tracking-tight">{sol.title}</span>
                  <span className="text-[13px] leading-relaxed text-ink/65 hidden sm:block">
                    {sol.text}
                  </span>
                  <span className="spec text-[9px] text-ink/40 group-hover:text-ink transition-colors pr-1">
                    Lesen
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* 3. FAQ: two columns, recessed panel */}
      <section className="bg-paper-2 border-y border-rule">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-14">
            <div className="lg:col-span-4">
              <h2 className="display text-[clamp(1.5rem,2.8vw,2.1rem)]">Fragen, die bleiben.</h2>
              <p className="mt-4 text-[14px] leading-relaxed text-ink/70 max-w-sm">
                Wenn hier etwas fehlt, steht die Antwort in der Anleitung oder im Impressum
                unter Kontakt.
              </p>
            </div>

            <div className="lg:col-span-8 border-t border-rule">
              {FAQS.map((faq, idx) => {
                const isOpen = openFaq === idx;
                const panelId = `faq-panel-${idx}`;
                const buttonId = `faq-button-${idx}`;
                return (
                  <div key={faq.q} className="border-b border-rule">
                    <h3>
                      <button
                        type="button"
                        id={buttonId}
                        aria-expanded={isOpen}
                        aria-controls={panelId}
                        onClick={() => setOpenFaq(isOpen ? null : idx)}
                        className="w-full flex items-start justify-between gap-6 py-4 text-left"
                      >
                        <span className="text-[15px] font-semibold leading-snug">{faq.q}</span>
                        <ChevronDown
                          className={`w-4 h-4 shrink-0 mt-1 transition-transform duration-150 ${
                            isOpen ? 'rotate-180' : ''
                          }`}
                          aria-hidden="true"
                        />
                      </button>
                    </h3>
                    <div id={panelId} role="region" aria-labelledby={buttonId} hidden={!isOpen}>
                      <p className="pb-5 pr-10 text-[13.5px] leading-relaxed text-ink/75">
                        {faq.a}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
