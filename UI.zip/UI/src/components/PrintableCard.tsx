/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { QRType, WifiData, SepaData, DeliveryData, VCardData } from '../types/qr';
import { Scissors, ShieldCheck, Wifi, CreditCard, Package } from 'lucide-react';
import { useUi } from './i18n/UiProvider';

interface PrintableCardProps {
  qrImageUrl: string;
  type: QRType;
  wifiData: WifiData;
  sepaData: SepaData;
  deliveryData: DeliveryData;
  vcardData: VCardData;
}

export const PrintableCard: React.FC<PrintableCardProps> = ({
  qrImageUrl,
  type,
  wifiData,
  sepaData,
  deliveryData,
  vcardData,
}) => {
  /*
   * The card is rendered on every page in every locale, so its copy lives in the
   * UI dictionary like every other label. Before this it was German-only, which
   * meant a Polish or Hebrew page shipped a hidden German card in its payload.
   */
  const u = useUi();
  return (
    <div id="printable-qr-card" className="hidden print:block text-slate-900 bg-paper">
      {/* Cut guide header */}
      <div className="flex items-center justify-between pb-4 border-b border-dashed border-slate-400 text-xs text-slate-500">
        <span className="flex items-center gap-1.5 font-mono">
          <Scissors className="w-3.5 h-3.5" /> {u['pr.cut']}
        </span>
        <span className="font-semibold">QR-Generator Deutschland</span>
      </div>

      <div className="text-center py-6">
        {/* Dynamic Badge Title */}
        {type === 'wifi' && (
          <div>
            <div className="inline-flex items-center justify-center p-3 rounded-none bg-blue-50 text-blue-700 mb-3">
              <Wifi className="w-8 h-8" />
            </div>
            <p className="text-3xl font-extrabold tracking-tight text-slate-900">
              {u['pr.wifiTitle']}
            </p>
            <p className="text-sm text-slate-600 mt-1">
              {u['pr.wifiLead']}
            </p>
          </div>
        )}

        {type === 'sepa' && (
          <div>
            <div className="inline-flex items-center justify-center p-3 rounded-none bg-emerald-50 text-emerald-700 mb-3">
              <CreditCard className="w-8 h-8" />
            </div>
            <p className="text-3xl font-extrabold tracking-tight text-slate-900">
              SEPA GiroCode
            </p>
            <p className="text-sm text-slate-600 mt-1">
              {u['pr.sepaLead']}
            </p>
          </div>
        )}

        {type === 'delivery' && (
          <div>
            <div className="inline-flex items-center justify-center p-3 rounded-none bg-amber-50 text-amber-700 mb-3">
              <Package className="w-8 h-8" />
            </div>
            <p className="text-3xl font-extrabold tracking-tight text-slate-900">
              {u['pr.deliveryTitle']}
            </p>
            <p className="text-sm text-slate-600 mt-1">
              {u['pr.deliveryLead']}
            </p>
          </div>
        )}

        {type !== 'wifi' && type !== 'sepa' && type !== 'delivery' && (
          <div>
            <p className="text-3xl font-extrabold tracking-tight text-slate-900">
              {u['pr.scanTitle']}
            </p>
            <p className="text-sm text-slate-600 mt-1">
              {u['pr.scanLead']}
            </p>
          </div>
        )}

        {/* Center QR image */}
        <div className="my-6 inline-block p-4 rounded-none border-2 border-slate-900 bg-paper">
          {qrImageUrl && (
            <img
              src={qrImageUrl}
              alt={u['pr.alt']}
              className="w-64 h-64 mx-auto object-contain"
            />
          )}
        </div>

        {/* Context details block */}
        {type === 'wifi' && (
          <div className="max-w-md mx-auto p-4 rounded-none bg-slate-50 border border-slate-200 text-left text-xs space-y-1.5 font-mono">
            <div>
              <span className="text-slate-500 font-sans font-semibold">{u['pr.ssid']}</span>{' '}
              <strong className="text-slate-900 font-bold">{wifiData.ssid || u['pr.guestNetwork']}</strong>
            </div>
            {wifiData.password && (
              <div>
                <span className="text-slate-500 font-sans font-semibold">{u['pr.password']}</span>{' '}
                <strong className="text-slate-900">{wifiData.password}</strong>
              </div>
            )}
            <div>
              <span className="text-slate-500 font-sans font-semibold">{u['pr.security']}</span>{' '}
              <span className="text-slate-700">{wifiData.encryption}</span>
            </div>
          </div>
        )}

        {type === 'sepa' && (
          <div className="max-w-md mx-auto p-4 rounded-none bg-slate-50 border border-slate-200 text-left text-xs space-y-1.5 font-mono">
            <div>
              <span className="text-slate-500 font-sans font-semibold">{u['pr.recipient']}</span>{' '}
              <strong className="text-slate-900">{sepaData.name || '-'}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-sans font-semibold">{u['pr.iban']}</span>{' '}
              <strong className="text-slate-900">{sepaData.iban || '-'}</strong>
            </div>
            {sepaData.amount && (
              <div>
                <span className="text-slate-500 font-sans font-semibold">{u['pr.amount']}</span>{' '}
                <strong className="text-emerald-700">{sepaData.amount} EUR</strong>
              </div>
            )}
            {sepaData.purpose && (
              <div>
                <span className="text-slate-500 font-sans font-semibold">{u['pr.purpose']}</span>{' '}
                <span className="text-slate-700">{sepaData.purpose}</span>
              </div>
            )}
          </div>
        )}

        {type === 'delivery' && (
          <div className="max-w-md mx-auto p-4 rounded-none bg-amber-50 border border-amber-200 text-left text-xs space-y-1.5">
            <div>
              <span className="text-amber-800 font-bold">{u['pr.recipient']}</span>{' '}
              <span className="text-slate-900 font-semibold">{deliveryData.recipientName}</span>
            </div>
            <div>
              <span className="text-amber-800 font-bold">{u['pr.place']}</span>{' '}
              <span className="text-slate-900 font-semibold">{deliveryData.deliveryLocation}</span>
            </div>
            {deliveryData.specialInstructions && (
              <div>
                <span className="text-amber-800 font-bold">{u['pr.note']}</span>{' '}
                <span className="text-slate-800">{deliveryData.specialInstructions}</span>
              </div>
            )}
          </div>
        )}

        {/* Footer info */}
        <div className="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1 font-sans">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> {u['pr.privacy']}
          </span>
          <span>{u['pr.validity']}</span>
        </div>
      </div>
    </div>
  );
};
