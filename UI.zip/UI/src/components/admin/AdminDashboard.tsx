'use client';

/**
 * AdminDashboard — password-protected control panel.
 *  Login (first run sets the password) → sections:
 *  Allgemein (site/contact), Werbung (ad providers on/off), Analyse (GA4/GTM/snippets),
 *  Passwort (change).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  LogOut,
  Save,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Megaphone,
  BarChart3,
  Settings,
  Lock,
  Mail,
  MailOpen,
  RefreshCw,
  QrCode,
  FileText,
} from 'lucide-react';
import type { AdProvider, AdSlotPosition, SiteSettings } from '@/src/lib/settings';
import { BlogAdmin } from './BlogAdmin';
import { adminFetch, setAdminToken } from '@/src/lib/admin-client';

type Tab = 'general' | 'ads' | 'analytics' | 'blog' | 'messages' | 'security';

interface ContactMessage {
  id: string;
  subject: string;
  message: string;
  email?: string;
  createdAt: string;
  read: boolean;
}

const AD_POSITIONS: { id: AdSlotPosition; label: string }[] = [
  { id: 'below-hero', label: 'Unter der Übersicht' },
  { id: 'mid-content', label: 'Mittig im Inhalt' },
  { id: 'above-footer', label: 'Über dem Footer' },
];

const INPUT =
  'w-full px-4 py-2.5 rounded-none bg-paper border border-rule text-ink text-sm placeholder:text-ink/60 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent';
const TEXTAREA =
  'w-full px-4 py-3 rounded-none bg-paper border border-rule text-ink text-sm placeholder:text-ink/60 focus:outline-none focus:ring-2 focus:ring-black font-mono text-xs';
const CARD = 'bg-paper rounded-none border border-rule p-6';
const LABEL = 'block text-[11px] font-bold uppercase tracking-wider text-ink/60 mb-1.5';
const BTN_PRIMARY =
  'inline-flex items-center gap-2 px-5 py-2.5 rounded-none bg-black hover:bg-paper-2 text-white text-sm font-semibold transition cursor-pointer disabled:opacity-50';
const BTN_SECONDARY =
  'inline-flex items-center gap-2 px-4 py-2 rounded-none bg-paper hover:bg-paper-2 text-ink text-xs font-semibold border border-rule transition cursor-pointer';

function newProvider(): AdProvider {
  return {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    name: 'Neuer Anbieter',
    type: 'adsense',
    clientId: '',
    slots: {},
    snippet: '',
    positions: ['mid-content'],
    enabled: false,
  };
}

export function AdminDashboard() {
  const [authed, setAuthed] = useState<boolean | null>(null); // null = loading
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [busy, setBusy] = useState(false);

  const [tab, setTab] = useState<Tab>('general');
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [dirty, setDirty] = useState(false);
  const [savedFlash, setSavedFlash] = useState(false);

  // Contact messages
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [messagesError, setMessagesError] = useState('');

  // Password change form
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [pwMessage, setPwMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const [showPassword, setShowPassword] = useState(false);

  const loadSettings = useCallback(async () => {
    const res = await adminFetch('/api/admin/settings');
    if (res.status === 401) {
      setAuthed(false);
      return false;
    }
    const data = await res.json();
    setSettings(data.settings);
    setAuthed(true);
    return true;
  }, []);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  const loadMessages = useCallback(async () => {
    setMessagesLoading(true);
    setMessagesError('');
    try {
      const res = await adminFetch('/api/admin/messages');
      if (res.status === 401) {
        setAuthed(false);
        return;
      }
      const data = await res.json();
      setMessages(data.messages || []);
      setUnreadCount(data.unread || 0);
    } catch {
      setMessagesError('Nachrichten konnten nicht geladen werden.');
    } finally {
      setMessagesLoading(false);
    }
  }, []);

  useEffect(() => {
    if (authed && tab === 'messages') loadMessages();
  }, [authed, tab, loadMessages]);

  const toggleRead = async (m: ContactMessage) => {
    setMessages((prev) =>
      prev.map((x) => (x.id === m.id ? { ...x, read: !x.read } : x))
    );
    setUnreadCount((prev) => Math.max(0, prev + (m.read ? 1 : -1)));
    await adminFetch(`/api/admin/messages/${m.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ read: !m.read }),
    });
  };

  const removeMessage = async (m: ContactMessage) => {
    if (!window.confirm('Diese Nachricht wirklich löschen?')) return;
    const res = await adminFetch(`/api/admin/messages/${m.id}`, { method: 'DELETE' });
    if (res.ok) {
      setMessages((prev) => prev.filter((x) => x.id !== m.id));
      if (!m.read) setUnreadCount((prev) => Math.max(0, prev - 1));
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setLoginError('');
    try {
      const res = await adminFetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setLoginError(data.error || 'Anmeldung fehlgeschlagen.');
        return;
      }
      /* The token comes back in the body so the session still works when the
         cookie cannot be stored (sandboxed preview iframe). */
      const data = await res.json().catch(() => ({}));
      if (data.token) setAdminToken(data.token);
      setPassword('');
      const ok = await loadSettings();
      if (!ok) {
        setLoginError('Anmeldung angenommen, aber die Sitzung wurde nicht übernommen. Bitte neu laden.');
      }
    } finally {
      setBusy(false);
    }
  };

  const handleLogout = async () => {
    await adminFetch('/api/admin/logout', { method: 'POST' });
    setAdminToken(null);
    setAuthed(false);
    setSettings(null);
  };

  const patch = (p: Partial<SiteSettings>) => {
    setSettings((prev) => (prev ? { ...prev, ...p } : prev));
    setDirty(true);
  };

  const handleSave = async () => {
    if (!settings) return;
    setBusy(true);
    try {
      const res = await adminFetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        setDirty(false);
        setSavedFlash(true);
        setTimeout(() => setSavedFlash(false), 2500);
      }
    } finally {
      setBusy(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwMessage(null);
    try {
      const res = await adminFetch('/api/admin/password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword: currentPw, newPassword: newPw }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        setPwMessage({ ok: true, text: '✓ Passwort geändert.' });
        setCurrentPw('');
        setNewPw('');
      } else {
        setPwMessage({ ok: false, text: data.error || 'Fehler beim Ändern des Passworts.' });
      }
    } catch {
      setPwMessage({ ok: false, text: 'Netzwerkfehler.' });
    }
  };

  // ---- login screen --------------------------------------------------------
  if (authed === false) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4">
        <form onSubmit={handleLogin} className={`${CARD} w-full max-w-sm space-y-4`}>
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-none bg-black text-white flex items-center justify-center">
              <QrCode className="w-4.5 h-4.5 stroke-[2.2]" />
            </span>
            <div>
              <h1 className="font-bold text-ink text-base tracking-tight">Admin-Dashboard</h1>
              <p className="text-[11px] text-ink/60">
                Erste Anmeldung legt das Passwort fest.
              </p>
            </div>
          </div>

          <div>
            <label htmlFor="admin-password" className={LABEL}>
              Passwort
            </label>
            <div className="relative">
              <input
                id="admin-password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={8}
                required
                autoFocus
                placeholder="Mindestens 8 Zeichen"
                className={INPUT + ' pr-11'}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-ink/60 hover:text-ink cursor-pointer"
                aria-label={showPassword ? 'Passwort verbergen' : 'Passwort anzeigen'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {loginError && (
            <p className="text-xs text-[#B31D00] font-semibold" role="alert">
              {loginError}
            </p>
          )}

          <button type="submit" disabled={busy} className={BTN_PRIMARY + ' w-full justify-center'}>
            <Lock className="w-4 h-4" />
            {busy ? 'Bitte warten…' : 'Anmelden'}
          </button>
        </form>
      </div>
    );
  }

  if (authed === null || !settings) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center text-sm text-ink/60">
        Lade Dashboard…
      </div>
    );
  }

  // ---- dashboard -----------------------------------------------------------
  const tabs: { id: Tab; label: string; icon: React.ReactNode; desc: string }[] = [
    { id: 'general', label: 'Allgemein', icon: <Settings className="w-4 h-4" />, desc: 'Standort, Kontaktdaten und Impressum-Angaben der Website' },
    { id: 'ads', label: 'Werbung', icon: <Megaphone className="w-4 h-4" />, desc: 'Anbieter ein-/ausschalten, Positionen und Slot-IDs verwalten' },
    { id: 'analytics', label: 'Analyse', icon: <BarChart3 className="w-4 h-4" />, desc: 'GA4, Tag Manager und eigene Mess-Snippets – zustimmungsabhängig' },
    { id: 'blog', label: 'Blog', icon: <FileText className="w-4 h-4" />, desc: 'Beiträge erstellen, bearbeiten und veröffentlichen (Keystatic CMS)' },
    { id: 'messages', label: 'Nachrichten', icon: <Mail className="w-4 h-4" />, desc: 'Über das Kontaktformular eingegangene Nachrichten' },
    { id: 'security', label: 'Sicherheit', icon: <Lock className="w-4 h-4" />, desc: 'Passwort für dieses Dashboard ändern' },
  ];
  const current = tabs.find((t) => t.id === tab)!;

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* ---------------- Sidebar ---------------- */}
      <aside className="w-full md:w-64 shrink-0 bg-paper border-b md:border-b-0 md:border-r border-rule md:min-h-screen md:sticky md:top-0 md:flex md:flex-col">
        <div className="hidden md:flex items-center gap-2.5 px-5 h-16 border-b border-rule">
          <span className="w-9 h-9 rounded-none bg-black text-white flex items-center justify-center shrink-0">
            <QrCode className="w-4.5 h-4.5 stroke-[2.2]" />
          </span>
          <div className="min-w-0">
            <p className="font-semibold text-ink text-sm tracking-tight leading-tight">Admin-Dashboard</p>
            <p className="text-[11px] text-ink/60 leading-tight">QR-Generator Deutschland</p>
          </div>
        </div>

        <nav aria-label="Dashboard-Bereiche" className="flex md:flex-col gap-1.5 md:gap-1 overflow-x-auto px-3 py-3 md:py-4 flex-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              aria-current={tab === t.id ? 'page' : undefined}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-none text-xs font-semibold border transition cursor-pointer whitespace-nowrap shrink-0 ${
                tab === t.id
                  ? 'bg-black text-white border-black'
                  : 'bg-paper text-ink/60 border-rule hover:bg-paper-2'
              }`}
            >
              {t.icon}
              {t.label}
              {t.id === 'messages' && unreadCount > 0 && (
                <span className="ml-0.5 inline-flex items-center justify-center min-w-4 h-4 px-1 rounded-none bg-accent text-white text-[10px] font-bold">
                  {unreadCount}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="hidden md:block px-3 pb-4">
          <button onClick={handleLogout} className={BTN_SECONDARY + ' w-full justify-center'}>
            <LogOut className="w-3.5 h-3.5" />
            Abmelden
          </button>
        </div>
      </aside>

      {/* ---------------- Content ---------------- */}
      <main className="flex-1 min-w-0 px-4 sm:px-8 py-8 sm:py-10">
        <div className="max-w-4xl">
        <div className="flex flex-wrap items-start justify-between gap-4 mb-7">
          <div>
            <h1 className="text-xl font-semibold text-ink tracking-tight">{current.label}</h1>
            <p className="text-xs text-ink/60 mt-0.5">{current.desc}</p>
          </div>

          <div className="flex items-center gap-2">
            {savedFlash && (
              <span className="text-xs font-semibold text-emerald-700">✓ Gespeichert</span>
            )}
            {dirty && (
              <button onClick={handleSave} disabled={busy} className={BTN_PRIMARY}>
                <Save className="w-4 h-4" />
                {busy ? 'Speichert…' : 'Speichern'}
              </button>
            )}
            <button onClick={handleLogout} className={BTN_SECONDARY + ' md:hidden'}>
              <LogOut className="w-3.5 h-3.5" />
              Abmelden
            </button>
          </div>
        </div>

      {/* ---------------- Allgemein ---------------- */}
      {tab === 'general' && (
        <div className="space-y-6">
          <section className={CARD}>
            <h2 className="text-sm font-semibold text-ink mb-4 pb-3 border-b border-rule">
              Website
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={LABEL} htmlFor="siteName">Website-Name</label>
                <input
                  id="siteName"
                  className={INPUT}
                  value={settings.siteName}
                  onChange={(e) => patch({ siteName: e.target.value })}
                />
              </div>
              <div>
                <label className={LABEL} htmlFor="domain">Domain</label>
                <input
                  id="domain"
                  className={INPUT}
                  value={settings.domain}
                  onChange={(e) => patch({ domain: e.target.value })}
                />
              </div>
            </div>
          </section>

          <section className={CARD}>
            <h2 className="text-sm font-semibold text-ink mb-4 pb-3 border-b border-rule">
              Kontakt (Impressum)
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={LABEL} htmlFor="c-company">Unternehmen / Projekt</label>
                <input
                  id="c-company"
                  className={INPUT}
                  value={settings.contact.company}
                  onChange={(e) => patch({ contact: { ...settings.contact, company: e.target.value } })}
                />
              </div>
              <div>
                <label className={LABEL} htmlFor="c-responsible">Verantwortliche Person</label>
                <input
                  id="c-responsible"
                  className={INPUT}
                  value={settings.contact.responsiblePerson}
                  onChange={(e) =>
                    patch({ contact: { ...settings.contact, responsiblePerson: e.target.value } })
                  }
                />
              </div>
              <div>
                <label className={LABEL} htmlFor="c-street">Straße &amp; Nr.</label>
                <input
                  id="c-street"
                  className={INPUT}
                  value={settings.contact.street}
                  onChange={(e) => patch({ contact: { ...settings.contact, street: e.target.value } })}
                />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className={LABEL} htmlFor="c-zip">PLZ</label>
                  <input
                    id="c-zip"
                    className={INPUT}
                    value={settings.contact.zip}
                    onChange={(e) => patch({ contact: { ...settings.contact, zip: e.target.value } })}
                  />
                </div>
                <div className="col-span-2">
                  <label className={LABEL} htmlFor="c-city">Ort</label>
                  <input
                    id="c-city"
                    className={INPUT}
                    value={settings.contact.city}
                    onChange={(e) => patch({ contact: { ...settings.contact, city: e.target.value } })}
                  />
                </div>
              </div>
              <div>
                <label className={LABEL} htmlFor="c-email">E-Mail</label>
                <input
                  id="c-email"
                  type="email"
                  className={INPUT}
                  value={settings.contact.email}
                  onChange={(e) => patch({ contact: { ...settings.contact, email: e.target.value } })}
                />
              </div>
              <div>
                <label className={LABEL} htmlFor="c-phone">Telefon</label>
                <input
                  id="c-phone"
                  className={INPUT}
                  value={settings.contact.phone}
                  onChange={(e) => patch({ contact: { ...settings.contact, phone: e.target.value } })}
                />
              </div>
            </div>
          </section>
        </div>
      )}

      {/* ---------------- Werbung ---------------- */}
      {tab === 'ads' && (
        <div className="space-y-6">
          <section className={CARD}>
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-ink">Werbung global</h2>
                <p className="text-xs text-ink/60 mt-0.5">
                  Schaltet alle Werbe-Anzeigen auf der Website ein oder aus.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.ads.enabled}
                  onChange={(e) => patch({ ads: { ...settings.ads, enabled: e.target.checked } })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-zinc-300 peer-focus:outline-none rounded-none peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-paper after:border-rule after:border after:rounded-none after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>
            {!settings.ads.enabled && (
              <p className="mt-3 text-xs text-ink/60 bg-paper-2 border border-rule rounded-none p-3">
                Hinweis: Werbung ist derzeit <strong>deaktiviert</strong>. Anzeigen werden
                zusätzlich erst nach Zustimmung des Besuchers im Cookie-Banner angezeigt.
              </p>
            )}

            {/* Live-Diagnose: warum (noch) keine Anzeigen erscheinen */}
            <div className="mt-4 pt-4 border-t border-rule space-y-2">
              <p className={LABEL}>Checkliste – erst wenn alle vier Punkte erfüllt sind, erscheinen Anzeigen</p>
              <ol className="space-y-1.5 text-xs text-ink/60 list-none">
                <li>
                  <span className="font-semibold text-ink">1. Cookie-Zustimmung:</span> Der Besucher muss im Cookie-Banner „Alle akzeptieren“ oder „Werbung“ aktivieren.
                  Ohne Marketing-Zustimmung werden aus Datenschutzgründen (§ 25 TDDDG) keine Anzeigen geladen.
                </li>
                <li>
                  <span className="font-semibold text-ink">2. Schalter:</span> Global „Werbung global“ aktiviert, Anbieter aktiviert und mindestens eine Position ausgewählt.
                </li>
                <li>
                  <span className="font-semibold text-ink">3. Slot-IDs:</span> Pro Position eine gültige Slot-ID (nur Ziffern) aus Ihrem AdSense-Konto eintragen.
                </li>
                <li>
                  <span className="font-semibold text-ink">4. Freigabe:</span> Google liefert Anzeigen erst nach Freischaltung der Domain im AdSense-Konto.
                  Auf localhost bleiben Einheiten daher leer (kein Fehler) – echte Anzeigen erscheinen erst auf der veröffentlichten Domain.
                </li>
              </ol>
            </div>
          </section>

          {settings.ads.providers.map((provider, index) => (
            <section key={provider.id} className={CARD}>
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-rule">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-ink/60">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <input
                    className="font-semibold text-ink text-sm bg-transparent border-b border-transparent hover:border-rule focus:border-black focus:outline-none"
                    value={provider.name}
                    onChange={(e) => {
                      const providers = settings.ads.providers.map((p) =>
                        p.id === provider.id ? { ...p, name: e.target.value } : p
                      );
                      patch({ ads: { ...settings.ads, providers } });
                    }}
                    aria-label="Anbietername"
                  />
                </div>
                <div className="flex items-center gap-3">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={provider.enabled}
                      onChange={(e) => {
                        const providers = settings.ads.providers.map((p) =>
                          p.id === provider.id ? { ...p, enabled: e.target.checked } : p
                        );
                        patch({ ads: { ...settings.ads, providers } });
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-zinc-300 peer-focus:outline-none rounded-none peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-rule after:border after:rounded-none after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
                  </label>
                  <button
                    onClick={() => {
                      const providers = settings.ads.providers.filter((p) => p.id !== provider.id);
                      patch({ ads: { ...settings.ads, providers } });
                    }}
                    className="text-ink/60 hover:text-accent transition cursor-pointer"
                    aria-label="Anbieter löschen"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className={LABEL}>Anbieter-Typ</label>
                  <select
                    className={INPUT}
                    value={provider.type}
                    onChange={(e) => {
                      const providers = settings.ads.providers.map((p) =>
                        p.id === provider.id
                          ? { ...p, type: e.target.value as AdProvider['type'] }
                          : p
                      );
                      patch({ ads: { ...settings.ads, providers } });
                    }}
                  >
                    <option value="adsense">Google AdSense</option>
                    <option value="custom">Eigener Code (AppLovin, Ezoic, …)</option>
                  </select>
                </div>

                {provider.type === 'adsense' ? (
                  <div>
                    <label className={LABEL}>Publisher-ID</label>
                    <input
                      className={INPUT}
                      placeholder="ca-pub-1234567890123456"
                      value={provider.clientId}
                      onChange={(e) => {
                        const providers = settings.ads.providers.map((p) =>
                          p.id === provider.id ? { ...p, clientId: e.target.value } : p
                        );
                        patch({ ads: { ...settings.ads, providers } });
                      }}
                    />
                  </div>
                ) : (
                  <div className="sm:col-span-1">
                    <label className={LABEL}>Position im Code</label>
                    <p className="text-[11px] text-ink/60">
                      Wählen Sie unten die Anzeigen-Positionen.
                    </p>
                  </div>
                )}
              </div>

              {provider.type === 'adsense' && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                  {AD_POSITIONS.map((pos) => (
                    <div key={pos.id}>
                      <label className={LABEL}>Slot-ID · {pos.label}</label>
                      <input
                        className={INPUT}
                        placeholder="1234567890"
                        inputMode="numeric"
                        value={provider.slots[pos.id] || ''}
                        onChange={(e) => {
                          // Slot-IDs sind reine Ziffern – alles andere wird entfernt,
                          // damit sich keine IDs aneinanderhängen können.
                          const digits = e.target.value.replace(/[^0-9]/g, '').slice(0, 20);
                          const providers = settings.ads.providers.map((p) =>
                            p.id === provider.id
                              ? { ...p, slots: { ...p.slots, [pos.id]: digits } }
                              : p
                          );
                          patch({ ads: { ...settings.ads, providers } });
                        }}
                      />
                    </div>
                  ))}
                </div>
              )}

              {provider.type === 'custom' && (
                <div className="mb-4">
                  <label className={LABEL}>Code-Snippet (HTML/JS)</label>
                  <textarea
                    rows={5}
                    className={TEXTAREA}
                    placeholder={'<script src="https://beispiel.de/werbung.js"></script>'}
                    value={provider.snippet}
                    onChange={(e) => {
                      const providers = settings.ads.providers.map((p) =>
                        p.id === provider.id ? { ...p, snippet: e.target.value } : p
                      );
                      patch({ ads: { ...settings.ads, providers } });
                    }}
                  />
                </div>
              )}

              <div>
                <label className={LABEL}>Anzeigen-Positionen</label>
                <div className="flex flex-wrap gap-2">
                  {AD_POSITIONS.map((pos) => {
                    const active = provider.positions.includes(pos.id);
                    return (
                      <button
                        key={pos.id}
                        type="button"
                        onClick={() => {
                          const positions = active
                            ? provider.positions.filter((p) => p !== pos.id)
                            : [...provider.positions, pos.id];
                          const providers = settings.ads.providers.map((p) =>
                            p.id === provider.id ? { ...p, positions } : p
                          );
                          patch({ ads: { ...settings.ads, providers } });
                        }}
                        className={`px-4 py-1.5 rounded-none text-xs font-semibold border transition cursor-pointer ${
                          active
                            ? 'bg-black text-white border-black'
                            : 'bg-paper text-ink/60 border-rule hover:bg-paper-2'
                        }`}
                      >
                        {pos.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </section>
          ))}

          <button
            onClick={() =>
              patch({ ads: { ...settings.ads, providers: [...settings.ads.providers, newProvider()] } })
            }
            className={BTN_SECONDARY + ' border-dashed'}
          >
            <Plus className="w-4 h-4" />
            Werbe-Anbieter hinzufügen
          </button>
        </div>
      )}

      {/* ---------------- Analyse ---------------- */}
      {tab === 'analytics' && (
        <div className="space-y-6">
          <section className={CARD}>
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-ink">Analyse global</h2>
                <p className="text-xs text-ink/60 mt-0.5">
                  Lädt GA4/GTM/Snippets erst nach Zustimmung im Cookie-Banner.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.analytics.enabled}
                  onChange={(e) =>
                    patch({ analytics: { ...settings.analytics, enabled: e.target.checked } })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-zinc-300 peer-focus:outline-none rounded-none peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-paper after:border-rule after:border after:rounded-none after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>
          </section>

          <section className={CARD}>
            <h2 className="text-sm font-semibold text-ink mb-4 pb-3 border-b border-rule">
              Mess-IDs
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={LABEL} htmlFor="ga4">Google Analytics 4 (G-…)</label>
                <input
                  id="ga4"
                  className={INPUT}
                  placeholder="G-XXXXXXXXXX"
                  value={settings.analytics.ga4Id}
                  onChange={(e) =>
                    patch({ analytics: { ...settings.analytics, ga4Id: e.target.value } })
                  }
                />
              </div>
              <div>
                <label className={LABEL} htmlFor="gtm">Google Tag Manager (GTM-…)</label>
                <input
                  id="gtm"
                  className={INPUT}
                  placeholder="GTM-XXXXXXX"
                  value={settings.analytics.gtmId}
                  onChange={(e) =>
                    patch({ analytics: { ...settings.analytics, gtmId: e.target.value } })
                  }
                />
              </div>
            </div>
          </section>

          <section className={CARD}>
            <label className={LABEL} htmlFor="custom-snippet">
              Eigener Analytics-Code (Plausible, Matomo, …)
            </label>
            <textarea
              id="custom-snippet"
              rows={6}
              className={TEXTAREA}
              placeholder={'<script defer data-domain="ihre-domain.de" src="https://plausible.io/js/script.js"></script>'}
              value={settings.analytics.customSnippet}
              onChange={(e) =>
                patch({ analytics: { ...settings.analytics, customSnippet: e.target.value } })
              }
            />
            <p className="mt-2 text-[11px] text-ink/60">
              Wird im &lt;head&gt; eingefügt, sobald der Besucher der Statistik zustimmt.
            </p>
          </section>
        </div>
      )}

      {/* ---------------- Nachrichten ---------------- */}
      {tab === 'messages' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-ink/60">
              {messagesLoading
                ? 'Lade Nachrichten…'
                : `${messages.length} Nachricht${messages.length === 1 ? '' : 'en'} · ${unreadCount} ungelesen`}
            </p>
            <button onClick={loadMessages} disabled={messagesLoading} className={BTN_SECONDARY}>
              <RefreshCw className={`w-3.5 h-3.5 ${messagesLoading ? 'animate-spin' : ''}`} />
              Aktualisieren
            </button>
          </div>

          {messagesError && (
            <p className="text-xs font-semibold text-[#B31D00]" role="alert">{messagesError}</p>
          )}

          {!messagesLoading && !messagesError && messages.length === 0 && (
            <div className={CARD + ' text-center py-12'}>
              <Mail className="w-6 h-6 text-zinc-300 mx-auto mb-3" />
              <p className="text-sm font-semibold text-ink">Noch keine Nachrichten</p>
              <p className="text-xs text-ink/60 mt-1">
                Über das Kontaktformular im Impressum gesendete Nachrichten erscheinen hier.
              </p>
            </div>
          )}

          {messages.map((m) => (
            <article
              key={m.id}
              className={`${CARD} ${m.read ? '' : 'border-l-4 border-l-[#FF5832]'}`}
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    {!m.read && (
                      <span className="text-[10px] font-bold uppercase tracking-wider text-white bg-accent rounded-none px-2 py-0.5">
                        Neu
                      </span>
                    )}
                    <h3 className="text-sm font-semibold text-ink truncate">{m.subject}</h3>
                  </div>
                  <p className="text-[11px] text-ink/60 mt-1">
                    {new Date(m.createdAt).toLocaleString('de-DE', {
                      dateStyle: 'medium',
                      timeStyle: 'short',
                    })}
                    {m.email && (
                      <>
                        {' · '}
                        <a href={`mailto:${m.email}`} className="text-accent hover:underline">
                          {m.email}
                        </a>
                      </>
                    )}
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={() => toggleRead(m)} className={BTN_SECONDARY}>
                    {m.read ? (
                      <>
                        <Mail className="w-3.5 h-3.5" />
                        Ungelesen
                      </>
                    ) : (
                      <>
                        <MailOpen className="w-3.5 h-3.5" />
                        Gelesen
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => removeMessage(m)}
                    className={BTN_SECONDARY + ' text-[#B31D00] hover:bg-red-50'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Löschen
                  </button>
                </div>
              </div>
              <p className="mt-3 pt-3 border-t border-rule text-xs sm:text-sm text-ink leading-relaxed whitespace-pre-wrap">
                {m.message}
              </p>
            </article>
          ))}
        </div>
      )}

      {/* ---------------- Sicherheit ---------------- */}
      {tab === 'security' && (
        <form onSubmit={handleChangePassword} className={CARD + ' max-w-md space-y-4'}>
          <h2 className="text-sm font-semibold text-ink pb-3 border-b border-rule">
            Passwort ändern
          </h2>
          <div>
            <label className={LABEL} htmlFor="current-pw">Aktuelles Passwort</label>
            <input
              id="current-pw"
              type="password"
              required
              className={INPUT}
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
            />
          </div>
          <div>
            <label className={LABEL} htmlFor="new-pw">Neues Passwort</label>
            <input
              id="new-pw"
              type="password"
              required
              minLength={8}
              className={INPUT}
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
            />
          </div>
          {pwMessage && (
            <p
              className={`text-xs font-semibold ${pwMessage.ok ? 'text-emerald-700' : 'text-[#B31D00]'}`}
              role="alert"
            >
              {pwMessage.text}
            </p>
          )}
          <button type="submit" className={BTN_PRIMARY}>
            <Lock className="w-4 h-4" />
            Passwort ändern
          </button>
        </form>
      )}

      {/* ---------------- Blog (Keystatic CMS) ---------------- */}
      {tab === 'blog' && <BlogAdmin />}
        </div>
      </main>
    </div>
  );
}
