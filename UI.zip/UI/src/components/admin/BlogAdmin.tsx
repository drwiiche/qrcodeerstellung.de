'use client';

/**
 * BlogAdmin — content management for the blog, backed by the Keystatic
 * headless CMS file format (content/posts/<slug>.mdoc) via /api/admin/posts.
 */
import React, { useCallback, useEffect, useState } from 'react';
import { FileText, Plus, Save, Trash2, ExternalLink, RefreshCw, Pencil, ArrowLeft } from 'lucide-react';
import { adminFetch, setAdminToken } from '@/src/lib/admin-client';

interface PostRecord {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  body: string;
}

const CATEGORIES = [
  { value: 'anleitungen', label: 'Anleitungen' },
  { value: 'gastronomie', label: 'Gastronomie' },
  { value: 'marketing', label: 'Marketing' },
  { value: 'technik', label: 'Technik & Tipps' },
  { value: 'recht', label: 'Recht & Privatsphäre' },
  { value: 'ideen', label: 'Anwendungsideen' },
];

const INPUT =
  'w-full px-4 py-2.5 rounded-none bg-paper border border-rule text-ink text-sm placeholder:text-ink/60 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent';
const TEXTAREA =
  'w-full px-4 py-3 rounded-none bg-paper border border-rule text-ink text-sm placeholder:text-ink/60 focus:outline-none focus:ring-2 focus:ring-black';
const CARD = 'bg-paper rounded-none border border-rule p-6';
const LABEL = 'block text-[11px] font-bold uppercase tracking-wider text-ink/60 mb-1.5';
const BTN_PRIMARY =
  'inline-flex items-center gap-2 px-5 py-2.5 rounded-none bg-black hover:bg-paper-2 text-white text-sm font-semibold transition cursor-pointer disabled:opacity-50';
const BTN_SECONDARY =
  'inline-flex items-center gap-2 px-4 py-2 rounded-none bg-paper hover:bg-paper-2 text-ink text-xs font-semibold border border-rule transition cursor-pointer disabled:opacity-50';

const EMPTY: PostRecord = { slug: '', title: '', excerpt: '', date: '', category: 'anleitungen', body: '' };

function slugify(value: string): string {
  const map: Record<string, string> = { ä: 'ae', ö: 'oe', ü: 'ue', Ä: 'Ae', Ö: 'Oe', Ü: 'Ue', ß: 'ss' };
  return value
    .replace(/[äöüÄÖÜß]/g, (c) => map[c] ?? c)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

export function BlogAdmin() {
  const [posts, setPosts] = useState<PostRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<PostRecord | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [flash, setFlash] = useState('');
  const [slugTouched, setSlugTouched] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await adminFetch('/api/admin/posts', { cache: 'no-store' });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setPosts(data.posts || []);
    } catch {
      setError('Beiträge konnten nicht geladen werden.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const startNew = () => {
    setEditing({ ...EMPTY, date: new Date().toISOString().slice(0, 10) });
    setIsNew(true);
    setSlugTouched(false);
    setError('');
  };

  const startEdit = (p: PostRecord) => {
    setEditing(p);
    setIsNew(false);
    setSlugTouched(true);
    setError('');
  };

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch(isNew ? '/api/admin/posts' : `/api/admin/posts/${editing.slug}`, {
        method: isNew ? 'POST' : 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editing),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Speichern fehlgeschlagen.');
      setFlash(isNew ? '✓ Beitrag erstellt' : '✓ Beitrag gespeichert');
      setTimeout(() => setFlash(''), 2500);
      setEditing(null);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Speichern fehlgeschlagen.');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (slug: string) => {
    if (!window.confirm('Diesen Beitrag wirklich endgültig löschen?')) return;
    setBusy(true);
    setError('');
    try {
      const res = await adminFetch(`/api/admin/posts/${slug}`, { method: 'DELETE' });
      if (!res.ok) throw new Error();
      if (editing?.slug === slug) setEditing(null);
      await load();
    } catch {
      setError('Löschen fehlgeschlagen.');
    } finally {
      setBusy(false);
    }
  };

  // ---- editor --------------------------------------------------------------
  if (editing) {
    const set = (patch: Partial<PostRecord>) =>
      setEditing((prev) => (prev ? { ...prev, ...patch } : prev));

    return (
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button onClick={() => setEditing(null)} className={BTN_SECONDARY}>
            <ArrowLeft className="w-3.5 h-3.5" />
            Zurück zur Liste
          </button>
          <div className="flex items-center gap-2">
            {flash && <span className="text-xs font-semibold text-emerald-700">{flash}</span>}
            <button onClick={save} disabled={busy} className={BTN_PRIMARY}>
              <Save className="w-4 h-4" />
              {busy ? 'Speichert…' : isNew ? 'Beitrag erstellen' : 'Speichern'}
            </button>
          </div>
        </div>

        {error && (
          <p className="text-xs font-semibold text-[#B31D00] bg-red-50 border border-red-200 rounded-none p-3" role="alert">
            {error}
          </p>
        )}

        <section className={CARD + ' space-y-4'}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className={LABEL} htmlFor="post-title">Titel</label>
              <input
                id="post-title"
                className={INPUT}
                value={editing.title}
                onChange={(e) => {
                  const title = e.target.value;
                  set({ title, slug: slugTouched ? editing.slug : slugify(title) });
                }}
                placeholder="z. B. WLAN-QR-Code für die Fritz!Box erstellen"
              />
            </div>

            <div>
              <label className={LABEL} htmlFor="post-slug">URL (Slug)</label>
              <input
                id="post-slug"
                className={INPUT + ' font-mono text-xs'}
                value={editing.slug}
                onChange={(e) => {
                  setSlugTouched(true);
                  set({ slug: slugify(e.target.value) });
                }}
                placeholder="wlan-qr-code-fritzbox"
              />
              <p className="mt-1 text-[11px] text-ink/60">/blog/{editing.slug || '…'}</p>
            </div>

            <div>
              <label className={LABEL} htmlFor="post-date">Veröffentlichung</label>
              <input
                id="post-date"
                type="date"
                className={INPUT}
                value={editing.date}
                onChange={(e) => set({ date: e.target.value })}
              />
            </div>

            <div className="sm:col-span-2">
              <label className={LABEL} htmlFor="post-category">Kategorie</label>
              <select
                id="post-category"
                className={INPUT}
                value={editing.category}
                onChange={(e) => set({ category: e.target.value })}
              >
                {CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className={LABEL} htmlFor="post-excerpt">
                Kurzbeschreibung (SEO-Titel & Vorschau, max. 300 Zeichen)
              </label>
              <textarea
                id="post-excerpt"
                rows={2}
                className={TEXTAREA}
                value={editing.excerpt}
                onChange={(e) => set({ excerpt: e.target.value })}
                placeholder="Ein bis zwei Sätze, die Suchmaschinen und Leser überzeugen."
              />
              <p className={`mt-1 text-[11px] ${editing.excerpt.length > 300 ? 'text-[#B31D00] font-semibold' : 'text-ink/60'}`}>
                {editing.excerpt.length}/300
              </p>
            </div>
          </div>
        </section>

        <section className={CARD}>
          <div className="flex items-center justify-between mb-3 pb-3 border-b border-rule">
            <h2 className="text-sm font-semibold text-ink">Inhalt (Markdown)</h2>
            <a
              href={`/blog/${editing.slug}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-accent hover:text-accent"
            >
              Vorschau öffnen
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
          <textarea
            rows={24}
            className={TEXTAREA + ' font-mono text-[13px] leading-relaxed'}
            value={editing.body}
            onChange={(e) => set({ body: e.target.value })}
            placeholder={'## Überschrift\n\nAbsatz mit **fett** und [internem Link](/blog/...).\n\n- Aufzählung'}
          />
          <p className="mt-2 text-[11px] text-ink/60">
            Markdown-Unterstützung: ## Überschrift, **fett**, Listen, Tabellen,{' '}
            [Links](/ziel) und Zitate mit Anführungszeichen.
          </p>
        </section>

        {!isNew && (
          <div className="flex justify-end">
            <button
              onClick={() => remove(editing.slug)}
              disabled={busy}
              className={BTN_SECONDARY + ' text-[#B31D00] hover:bg-red-50'}
            >
              <Trash2 className="w-3.5 h-3.5" />
              Beitrag löschen
            </button>
          </div>
        )}
      </div>
    );
  }

  // ---- list ----------------------------------------------------------------
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs text-ink/60">
          {loading ? 'Lade Beiträge…' : `${posts.length} Beitrag${posts.length === 1 ? '' : 'e'} veröffentlicht`}
        </p>
        <div className="flex items-center gap-2">
          <button onClick={load} disabled={loading} className={BTN_SECONDARY}>
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Aktualisieren
          </button>
          <button onClick={startNew} className={BTN_PRIMARY}>
            <Plus className="w-4 h-4" />
            Neuer Beitrag
          </button>
        </div>
      </div>

      {flash && <p className="text-xs font-semibold text-emerald-700">{flash}</p>}
      {error && (
        <p className="text-xs font-semibold text-[#B31D00] bg-red-50 border border-red-200 rounded-none p-3" role="alert">
          {error}
        </p>
      )}

      {loading ? (
        <div className={CARD + ' text-center py-12 text-sm text-ink/60'}>Lade Beiträge…</div>
      ) : posts.length === 0 ? (
        <div className={CARD + ' text-center py-12'}>
          <FileText className="w-6 h-6 text-zinc-300 mx-auto mb-3" />
          <p className="text-sm font-semibold text-ink">Noch keine Beiträge</p>
          <p className="text-xs text-ink/60 mt-1 mb-4">
            Schreiben Sie Ihren ersten Fachbeitrag – er erscheint sofort unter /blog.
          </p>
          <button onClick={startNew} className={BTN_PRIMARY + ' mx-auto'}>
            <Plus className="w-4 h-4" />
            Neuer Beitrag
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {posts.map((p) => (
            <article key={p.slug} className={CARD + ' flex flex-wrap items-center justify-between gap-3'}>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-accent">
                    {CATEGORIES.find((c) => c.value === p.category)?.label ?? p.category}
                  </span>
                  <span className="text-[11px] text-ink/60">{p.date}</span>
                </div>
                <h3 className="text-sm font-semibold text-ink mt-1">{p.title}</h3>
                <p className="text-xs text-ink/60 mt-0.5 line-clamp-1">{p.excerpt}</p>
                <a
                  href={`/blog/${p.slug}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 mt-1 text-[11px] font-semibold text-ink/60 hover:text-accent"
                >
                  /blog/{p.slug}
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button onClick={() => startEdit(p)} className={BTN_SECONDARY}>
                  <Pencil className="w-3.5 h-3.5" />
                  Bearbeiten
                </button>
                <button
                  onClick={() => remove(p.slug)}
                  disabled={busy}
                  className={BTN_SECONDARY + ' text-[#B31D00] hover:bg-red-50'}
                  aria-label={`Beitrag ${p.title} löschen`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}