'use client';

/**
 * Type selector, reduced to a single row of choices.
 *
 * It used to be a 20-cell grid with two lines of text per cell, roughly 200px
 * of vertical space spent before the first input. Now it is one wrapping row of
 * hairline chips: a 3px colour tick, the name, nothing else. The colour still
 * does the identifying, and the active chip is the only filled element on the
 * page, which is what makes it findable at a glance.
 */
import React from 'react';
import { QRType } from '../types/qr';
import { typeColor } from '../lib/typeColor';
import { useUi } from './i18n/UiProvider';
import { typeLabel } from '../lib/i18n/ui/typeLabel';

interface QRTypeSelectorProps {
  currentType: QRType;
  onSelectType: (type: QRType) => void;
}

/* Order is the same in every language; the label comes from the UI strings. */
const TYPES: QRType[] = [
  'wifi',
  'sepa',
  'vcard',
  'url',
  'delivery',
  'event',
  'standort',
  'phone',
  'sms',
  'whatsapp',
  'email',
  'text',
  'mecard',
  'facebook',
  'instagram',
  'youtube',
  'twitter',
  'paypal',
  'bitcoin',
  'pix',
];

export function QRTypeSelector({ currentType, onSelectType }: QRTypeSelectorProps) {
  const u = useUi();
  return (
    <div>
      <div className="flex items-baseline justify-between gap-4 mb-2.5">
        <h2 className="spec text-ink/45">{u['t.heading']}</h2>
        <span className="spec text-ink/30">{u['t.count']}</span>
      </div>

      <div
        role="group"
        aria-label={u['t.aria']}
        className="flex gap-1.5 overflow-x-auto pb-1 -mx-4 px-4 sm:mx-0 sm:px-0 sm:flex-wrap sm:overflow-visible sm:pb-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {TYPES.map((id) => {
          const active = id === currentType;
          const c = typeColor(id);
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectType(id)}
              aria-pressed={active}
              className={`inline-flex items-center gap-2 h-8 pl-2 pr-3 border text-[12.5px] font-medium shrink-0 transition-colors ${
                active
                  ? 'border-transparent'
                  : 'border-rule bg-paper text-ink/75 hover:border-ink/40 hover:text-ink'
              }`}
              style={active ? { backgroundColor: c.deep, color: c.on } : undefined}
            >
              <span
                className="w-[3px] h-3.5 shrink-0"
                style={{ backgroundColor: active ? c.on : c.hex }}
                aria-hidden="true"
              />
              {typeLabel(u, id)}
            </button>
          );
        })}
      </div>
    </div>
  );
}
