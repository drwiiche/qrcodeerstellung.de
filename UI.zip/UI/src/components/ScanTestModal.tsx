/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Smartphone,
  CheckCircle2,
  X,
  Wifi,
  CreditCard,
  User,
  Package,
  ExternalLink,
  Copy,
  Check,
} from 'lucide-react';
import { QRType } from '../types/qr';
import { useUi } from './i18n/UiProvider';

interface ScanTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  payload: string;
  qrType: QRType;
  qrImageUrl: string;
}

export const ScanTestModal: React.FC<ScanTestModalProps> = ({
  isOpen,
  onClose,
  payload,
  qrType,
  qrImageUrl,
}) => {
  const u = useUi();
  const [copied, setCopied] = useState(false);

  // Close on Escape key for WCAG accessibility
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(payload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="scan-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="bg-paper rounded-none max-w-md w-full overflow-hidden border border-rule">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-rule">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-none bg-black text-white flex items-center justify-center">
              <Smartphone className="w-3.5 h-3.5" />
            </span>
            <h3 id="scan-modal-title" className="font-semibold text-sm text-ink">{u['sc.title']}</h3>
          </div>
          <button
            onClick={onClose}
            aria-label={u['sc.close']}
            className="p-1 rounded-none text-ink/60 hover:text-ink hover:bg-paper-2 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Smartphone Viewfinder Mockup */}
        <div className="p-5 space-y-4">
          <div className="relative mx-auto w-48 h-48 rounded-none border-2 border-dashed border-[#FF5832] bg-paper-2 flex items-center justify-center p-2 overflow-hidden">
            {/* Corner scanning brackets */}
            <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-black" />
            <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-black" />
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-black" />
            <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-black" />

            {/* Laser scanning beam animation */}
            <div className="absolute inset-x-0 h-0.5 bg-ink" />

            {qrImageUrl && (
              <img
                src={qrImageUrl}
                alt={u['sc.alt']}
                className="w-full h-full object-contain"
              />
            )}
          </div>

          {/* Decoded Action Banner */}
          <div className="p-3.5 rounded-none bg-paper-2 border border-rule text-ink space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-ink">
              <CheckCircle2 className="w-4 h-4 text-accent" />
              <span>{u['sc.success']}</span>
            </div>

            <p className="text-xs font-medium text-ink/60">
              {qrType === 'wifi' && '📶 Smartphone fragt: "WLAN-Netzwerk beitreten?"'}
              {qrType === 'sepa' && '💳 Banking-App öffnet Überweisungsmaske mit allen Daten'}
              {qrType === 'vcard' && '👤 Kontaktkarte: "Zu Kontakten hinzufügen?"'}
              {qrType === 'delivery' && '📦 Paketbote sieht Abstellort & Hinweistext sofort'}
              {qrType === 'url' && '🔗 Browser öffnet den Link'}
              {qrType === 'whatsapp' && '💬 WhatsApp Chat wird gestartet'}
              {qrType === 'text' && '📝 Text wird vollständig auf dem Bildschirm angezeigt'}
              {qrType === 'email' && '✉️ Mail-Programm öffnet neue E-Mail'}
              {qrType === 'phone' && '📞 Telefon wählt die Rufnummer'}
              {qrType === 'event' && '📅 Kalender erstellt Termin-Eintrag'}
            </p>
          </div>

          {/* Raw Payload Preview */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-ink/60">{u['sc.payload']}</span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-accent hover:text-accent cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied ? u['pv.copied'] : u['pv.copy']}
              </button>
            </div>
            <pre className="p-3 rounded-none bg-black text-zinc-200 text-xs font-mono max-h-32 overflow-y-auto whitespace-pre-wrap break-all select-all">
              {payload || '(Keine Daten)'}
            </pre>
          </div>

          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 rounded-none bg-black hover:bg-paper-2 text-white font-semibold text-xs transition cursor-pointer"
          >{u['sc.done']}</button>
        </div>
      </div>
    </div>
  );
};
