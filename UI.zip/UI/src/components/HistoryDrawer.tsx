/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { History, X, Trash2, ArrowRight, Clock, QrCode } from 'lucide-react';
import { QRType, QRCustomization } from '../types/qr';
import { QR_TYPE_LABELS } from '../utils/translations';
import { useUi } from './i18n/UiProvider';
import { typeLabel } from '../lib/i18n/ui/typeLabel';

export interface HistoryItem {
  id: string;
  timestamp: number;
  title: string;
  type: QRType;
  previewUrl: string;
  data: Record<string, any>;
  customization: QRCustomization;
}

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
  onRestore: (item: HistoryItem) => void;
  onClear: () => void;
  onDeleteOne: (id: string) => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  history,
  onRestore,
  onClear,
  onDeleteOne,
}) => {
  const u = useUi();
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="history-drawer-title"
      className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-150"
    >
      <div className="w-full max-w-md bg-paper h-full flex flex-col border-l border-rule animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-rule flex items-center justify-between bg-paper-2">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-accent" />
            <h2 id="history-drawer-title" className="text-sm font-bold text-ink">
              Zuletzt erstellte QR-Codes ({history.length})
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={u['hi.close']}
            className="p-1 rounded-none text-ink/60 hover:text-ink hover:bg-paper-2 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {history.length === 0 ? (
            <div className="text-center py-12 text-ink/60 space-y-2">
              <QrCode className="w-10 h-10 mx-auto text-zinc-300 stroke-1" />
              <p className="text-xs font-semibold">{u['hi.empty']}</p>
              <p className="text-[11px] text-ink/60 max-w-xs mx-auto">
                Wenn Sie einen QR-Code herunterladen oder kopieren, wird er automatisch hier lokal auf Ihrem Gerät gespeichert.
              </p>
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-none border border-rule hover:border-rule bg-paper-2/70 hover:bg-paper transition flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-none bg-paper p-1 border border-rule flex-shrink-0">
                    <img
                      src={item.previewUrl}
                      alt={`Vorschau des QR-Codes: ${item.title || 'Gespeicherter Code'}`}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-[10px] text-ink/60 mb-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      <span>•</span>
                      <span className="uppercase font-semibold text-accent">{typeLabel(u, item.type)}</span>
                    </div>
                    <h3 className="text-xs font-bold text-ink truncate">
                      {item.title}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      onRestore(item);
                      onClose();
                    }}
                    className="p-2 rounded-none bg-paper-2 hover:bg-black hover:text-white text-ink transition text-xs font-bold flex items-center gap-1 cursor-pointer"
                    title={u['hi.restore']}
                  >
                    <span>{u['hi.load']}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteOne(item.id)}
                    className="p-2 rounded-none text-ink/60 hover:text-rose-600 transition cursor-pointer"
                    title={u['hi.delete']}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {history.length > 0 && (
          <div className="p-3 border-t border-rule bg-paper-2 flex items-center justify-between">
            <span className="text-[11px] text-ink/60">{u['hi.local']}</span>
            <button
              type="button"
              onClick={onClear}
              className="text-xs text-rose-600 hover:text-rose-800 font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />{u['hi.clear']}</button>
          </div>
        )}
      </div>
    </div>
  );
};
