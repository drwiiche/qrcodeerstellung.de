/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertOctagon, RotateCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-paper flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-paper rounded-none p-6 border border-rule text-center">
            <div className="w-12 h-12 rounded-none bg-paper-2 text-ink flex items-center justify-center mx-auto mb-4">
              <AlertOctagon className="w-6 h-6" />
            </div>
            <h1 className="text-lg font-semibold text-ink mb-2">
              Ein unerwarteter Fehler ist aufgetreten
            </h1>
            <p className="text-xs text-ink/60 mb-6 leading-relaxed">
              Die Anwendung konnte diesen Zustand nicht darstellen. Ihre Daten im Browser sind sicher.
            </p>
            <button
              type="button"
              onClick={() => {
                window.location.reload();
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-none bg-black hover:bg-paper-2 text-white font-semibold text-xs transition cursor-pointer"
            >
              <RotateCw className="w-4 h-4" />
              Seite neu laden
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
