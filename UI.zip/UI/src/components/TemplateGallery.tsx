'use client';

/**
 * Template gallery.
 *
 * Each card is a real prefill: type, values and colour. Clicking one loads it
 * into the generator and scrolls to the form, so the visitor lands on a
 * finished code rather than an empty field.
 */
import React, { useState } from 'react';
import { useSite } from './SiteShell';
import { TEMPLATES, CATEGORY_ORDER, CATEGORY_LABELS, type TemplateCategory } from '../data/templates';
import { typeColor } from '../lib/typeColor';
import { QR_TYPE_LABELS } from '../utils/translations';
import { ArrowRight, Filter } from 'lucide-react';

export function TemplateGallery() {
  const site = useSite();
  const [filter, setFilter] = useState<TemplateCategory | 'alle'>('alle');

  const shown = filter === 'alle' ? TEMPLATES : TEMPLATES.filter((t) => t.category === filter);

  const apply = (id: string) => {
    const t = TEMPLATES.find((x) => x.id === id);
    if (!t) return;
    site.handleApplyTemplate(t.type, t.data, t.custom);
  };

  return (
    <>
      {/* Filter */}
      <div className="sticky top-14 z-30 bg-paper border-b border-rule">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 py-2.5 overflow-x-auto">
            <span className="spec text-[9px] text-ink/40 flex items-center gap-1.5 shrink-0 pr-1">
              <Filter className="w-3 h-3" aria-hidden="true" />
              {shown.length} Vorlagen
            </span>
            <button
              type="button"
              onClick={() => setFilter('alle')}
              aria-pressed={filter === 'alle'}
              className={`shrink-0 h-8 px-3 text-[12px] font-semibold border transition-colors ${
                filter === 'alle'
                  ? 'bg-ink text-paper border-ink'
                  : 'bg-paper text-ink border-rule hover:border-ink'
              }`}
            >
              Alle
            </button>
            {CATEGORY_ORDER.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setFilter(c)}
                aria-pressed={filter === c}
                className={`shrink-0 h-8 px-3 text-[12px] font-semibold border transition-colors ${
                  filter === c
                    ? 'bg-ink text-paper border-ink'
                    : 'bg-paper text-ink border-rule hover:border-ink'
                }`}
              >
                {CATEGORY_LABELS[c].label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {CATEGORY_ORDER.filter((c) => shown.some((t) => t.category === c)).map((cat) => {
          const items = shown.filter((t) => t.category === cat);
          return (
            <section key={cat} id={cat} className="mb-12 scroll-mt-32">
              <div className="flex items-baseline justify-between gap-4 border-b border-ink pb-2.5 mb-0">
                <h2 className="display text-[clamp(1.3rem,2.8vw,1.8rem)]">{CATEGORY_LABELS[cat].label}</h2>
                <span className="spec text-[9px] text-ink/40 shrink-0">
                  {String(items.length).padStart(2, '0')}
                </span>
              </div>
              <p className="mt-2.5 mb-5 text-[13px] leading-relaxed text-ink/65 max-w-2xl">
                {CATEGORY_LABELS[cat].lead}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {items.map((t) => {
                  const c = typeColor(t.type);
                  return (
                    <article key={t.id} className="bg-paper border border-rule flex flex-col">
                      <div className="h-[4px]" style={{ backgroundColor: c.hex }} aria-hidden="true" />
                      <div className="p-4 flex flex-col flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="spec text-[9px] text-ink/45">
                            {QR_TYPE_LABELS[t.type] ?? t.type}
                          </span>
                        </div>
                        <h3 className="text-[14px] font-bold leading-snug">{t.title}</h3>
                        <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink/65 flex-1">
                          {t.description}
                        </p>
                        <button
                          type="button"
                          onClick={() => apply(t.id)}
                          className="mt-4 inline-flex items-center justify-between gap-2 w-full h-9 px-3 text-[12px] font-bold border border-ink text-ink hover:text-paper transition-colors group"
                          style={{ ['--hover-bg' as string]: c.deep }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.backgroundColor = c.deep;
                            e.currentTarget.style.borderColor = c.deep;
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.backgroundColor = '';
                            e.currentTarget.style.borderColor = '';
                          }}
                        >
                          Vorlage laden
                          <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          );
        })}

        <div className="border border-ink bg-ink text-paper on-ink p-6 sm:p-8">
          <h2 className="display text-[clamp(1.4rem,3vw,2rem)] text-paper">
            Keine passende Vorlage?
          </h2>
          <p className="mt-2 text-[14px] leading-relaxed text-paper/70 max-w-lg">
            Jede Vorlage ist nur eine Vorbelegung. Der Generator kann alles auch leer, mit eigenen
            Werten und eigener Farbe.
          </p>
          <a
            href="/"
            className="mt-5 inline-flex items-center h-11 px-5 bg-acid text-ink text-[13px] font-bold hover:bg-paper transition-colors"
          >
            Zum Generator
          </a>
        </div>
      </div>
    </>
  );
}
