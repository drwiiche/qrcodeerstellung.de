/**
 * Byline shown on every long-form page.
 *
 * It answers three questions a reader and a crawler both ask: who stands behind
 * this, when was it last checked, and what are the rules the publisher holds
 * itself to. The third one is a link, which is the point: the claim of care is
 * only worth something if it can be inspected.
 */
import Link from 'next/link';
import { EDITORIAL_PATH, authorName, bylineLabel, reviewedDate } from '../lib/editorial';
import type { Locale } from '../lib/i18n/config';
import { CONTENT_UPDATED } from '../lib/site';

export function Byline({
  locale = 'de',
  date = CONTENT_UPDATED,
  tone = 'light',
  reviewedOn = true,
}: {
  locale?: Locale;
  date?: string;
  /** `light` sits on paper, `dark` sits on the ink header band. */
  tone?: 'light' | 'dark';
  reviewedOn?: boolean;
}) {
  const labels = bylineLabel(locale);
  const muted = tone === 'dark' ? 'text-paper/55' : 'text-ink/55';
  const strong = tone === 'dark' ? 'text-paper/85' : 'text-ink/80';
  const link = tone === 'dark' ? 'text-paper/75 hover:text-paper' : 'text-ink/70 hover:text-ink';

  return (
    <p className={`flex flex-wrap items-center gap-x-2 gap-y-1 spec text-[9px] ${muted}`}>
      <span className={strong}>{authorName(locale)}</span>
      {reviewedOn && (
        <>
          <span aria-hidden="true">·</span>
          <span>
            {labels.reviewed}: {reviewedDate(locale, date)}
          </span>
        </>
      )}
      <span aria-hidden="true">·</span>
      <Link href={EDITORIAL_PATH} className={`underline underline-offset-2 transition-colors ${link}`}>
        {labels.standards}
      </Link>
    </p>
  );
}
