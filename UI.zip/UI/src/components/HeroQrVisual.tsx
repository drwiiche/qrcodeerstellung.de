'use client';

/**
 * HeroQrVisual — decorative animated QR-scan demo for the hero's right column.
 *
 * A looping, purely visual sequence: scan line sweeps a real QR code → the
 * phone picks it up → a confirmation stamp appears → it moves on to the next
 * QR feature of this site (WLAN, GiroCode, vCard, Paket-Abstellort).
 *
 * Design rules of this project apply: plain white card, 16px radius, zinc
 * borders, full-rounded pills, orange accent — and never a shadow.
 * The whole block is aria-hidden (decorative) and honours prefers-reduced-motion.
 */
import React, { useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { Check, QrCode, ScanLine, ShieldCheck, Smartphone, Monitor } from 'lucide-react';

type Stage = 'waiting' | 'scanned' | 'confirmed';

interface Feature {
  label: string;
  caption: string;
  payload: string;
}

/** The four showcase features — each gets its own real QR code in the loop. */
const FEATURES: Feature[] = [
  {
    label: 'Gäste-WLAN',
    caption: 'Für Fritz!Box & Speedport',
    payload: 'WIFI:T:WPA;S:Gast-WLAN;P:willkommen2026;;',
  },
  {
    label: 'SEPA GiroCode',
    caption: 'Offizielle Banküberweisung',
    payload: [
      'BCD', '002', '1', 'S1',
      'QR-Generator Deutschland',
      'DE89370400440532013000',
      '12.50',
      'EUR',
      'Rechnung 2026-01',
    ].join('\n'),
  },
  {
    label: 'vCard',
    caption: 'Digitale Visitenkarte',
    payload: [
      'BEGIN:VCARD',
      'VERSION:3.0',
      'FN:Maximilian Mustermann',
      'ORG:QR-Generator Deutschland',
      'TEL:+49 30 12345678',
      'EMAIL:info@qr-generator-deutschland.de',
      'END:VCARD',
    ].join('\n'),
  },
  {
    label: 'Paket-Abstellort',
    caption: 'Hinweis für den Boten',
    payload: 'https://qr-generator-deutschland.de/paket-abstellort',
  },
];

/**
 * Variant content — the visual adapts to the section it is placed in.
 * - `about`: the classic scan-demo story (3 steps)
 * - `steps`: the 4-step how-it-works flow of the generator
 */
const VARIANT_CONTENT = {
  about: {
    headerTitle: 'Scan-Demo',
    headerSub: 'Live · so scannen Ihre Gäste',
    eyebrow: 'Auf einen Blick',
    headline: ['Scannen. Prüfen.', 'Fertig.'],
    steps: [
      { title: '12 QR-Typen', caption: 'WLAN, SEPA, vCard, Paket …' },
      { title: 'Scan-Score live', caption: 'Kontrast sofort geprüft' },
      { title: 'PNG, SVG & A4-Druck', caption: 'Ohne Wasserzeichen, lebenslang gültig' },
    ],
  },
  steps: {
    headerTitle: 'Live-Beispiel',
    headerSub: 'Generator in vier Schritten',
    eyebrow: 'Der Workflow',
    headline: ['Von der Idee', 'zum QR-Code.'],
    steps: [
      { title: 'QR-Typ wählen', caption: '12 Typen: WLAN, SEPA, vCard …' },
      { title: 'Daten eingeben', caption: 'Formular mit Live-Vorschau' },
      { title: 'Gestalten', caption: 'Farben, Formen & Scan-Score' },
      { title: 'Herunterladen', caption: 'PNG in HD, SVG oder A4-Druck' },
    ],
  },
} as const;

type Variant = keyof typeof VARIANT_CONTENT;

const MOTION = `
@keyframes hq-scan { 0% { top: 10px } 50% { top: calc(100% - 14px) } 100% { top: 10px } }
@keyframes hq-phone { 0%,100% { transform: rotate(0deg) } 20%,60% { transform: rotate(-8deg) } 40%,80% { transform: rotate(8deg) } }
@keyframes hq-stamp { from { opacity: 0; transform: scale(.75) } to { opacity: 1; transform: scale(1) } }
[data-slot="hero-qr-visual"] [data-scan-line] { animation: hq-scan 2.2s ease-in-out infinite; }
[data-slot="hero-qr-visual"] [data-phone] { animation: hq-phone .6s ease-in-out 2; }
[data-slot="hero-qr-visual"] [data-stamp] { animation: hq-stamp .42s cubic-bezier(.2,.8,.2,1) both; }
@media (prefers-reduced-motion: reduce) {
  [data-slot="hero-qr-visual"] * { animation: none !important; transition: none !important; }
}
`;

/** Builds a boolean module grid (quiet zone included) for a payload. */
function buildMatrix(payload: string): boolean[][] | null {
  try {
    const qr = QRCode.create(payload, { errorCorrectionLevel: 'M' });
    const size = qr.modules.size;
    const data = qr.modules.data;
    const grid: boolean[][] = [];
    for (let y = 0; y < size; y++) {
      const row: boolean[] = [];
      for (let x = 0; x < size; x++) row.push(Boolean(data[y * size + x]));
      grid.push(row);
    }
    return grid;
  } catch {
    return null;
  }
}

export const HeroQrVisual: React.FC<{ className?: string; variant?: Variant }> = ({
  className = '',
  variant = 'about',
}) => {
  const content = VARIANT_CONTENT[variant];
  const [stage, setStage] = useState<Stage>('waiting');
  const [index, setIndex] = useState(0);
  const [reduced, setReduced] = useState(false);
  const [mounted, setMounted] = useState(false);

  // Real QR matrices for every showcase feature (computed once).
  const matrices = useMemo(() => FEATURES.map((f) => buildMatrix(f.payload)), []);

  useEffect(() => {
    setMounted(true);
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  const playing = mounted && !reduced;
  const feature = FEATURES[index];

  // The loop: waiting → scanned → confirmed → next feature.
  useEffect(() => {
    if (!playing) return;
    const timers = [
      window.setTimeout(() => setStage('scanned'), 2400),
      window.setTimeout(() => setStage('confirmed'), 4000),
      window.setTimeout(() => {
        setStage('waiting');
        setIndex((i) => (i + 1) % FEATURES.length);
      }, 6400),
    ];
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [playing, index]);

  const matrix = matrices[index];
  const quiet = 3;
  const gridSize = matrix ? matrix.length + quiet * 2 : 0;

  // Active step advances with the scan stage; the last step lights up on confirm.
  const stageStep =
    stage === 'confirmed'
      ? content.steps.length
      : stage === 'scanned'
        ? Math.min(2, content.steps.length)
        : 1;
  const statusText =
    stage === 'confirmed'
      ? 'Scan bestätigt ✓'
      : stage === 'scanned'
        ? 'Auf dem Smartphone erkannt'
        : 'Bereit zum Scannen';

  return (
    <section
      data-slot="hero-qr-visual"
      data-stage={stage}
      aria-hidden="true"
      className={`w-full max-w-[540px] bg-paper rounded-none border border-rule ${className}`}
    >
      <style>{MOTION}</style>

      {/* Header */}
      <header className="flex items-center justify-between gap-3 px-5 sm:px-6 pt-5 pb-4">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="w-9 h-9 shrink-0 rounded-none bg-black text-white flex items-center justify-center">
            <QrCode className="w-4 h-4 stroke-[2.2]" />
          </span>
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-ink tracking-tight truncate">{content.headerTitle}</h2>
            <p className="text-[11px] text-ink/60">{content.headerSub}</p>
          </div>
        </div>
        <span className="flex shrink-0 items-center gap-2 rounded-none border border-rule px-3 py-1.5 text-ink/60">
          <Smartphone className="w-3.5 h-3.5" />
          <span className="h-px w-4 bg-zinc-200" />
          <Monitor className="w-3.5 h-3.5" />
        </span>
      </header>

      {/* Body: QR tile + steps */}
      <div className="flex flex-col sm:flex-row items-center gap-6 px-5 sm:px-6 pb-5">
        {/* QR column */}
        <div className="flex flex-col items-center shrink-0">
          <div className="relative rounded-none border border-rule bg-paper-2 p-2.5">
            <div className="relative flex size-[188px] items-center justify-center overflow-hidden rounded-[12px] bg-paper">
              <div
                className={`size-full transition-all duration-300 ${
                  stage === 'confirmed'
                    ? 'opacity-10 blur-sm'
                    : stage === 'scanned'
                      ? 'opacity-40'
                      : 'opacity-100'
                }`}
              >
                {matrix ? (
                  <svg
                    viewBox={`0 0 ${gridSize} ${gridSize}`}
                    shapeRendering="crispEdges"
                    className="size-full p-2"
                    fill="#000000"
                  >
                    {matrix.flatMap((row, y) =>
                      row.map((filled, x) =>
                        filled ? (
                          <rect key={`${x}-${y}`} x={x + quiet} y={y + quiet} width="1" height="1" />
                        ) : null
                      )
                    )}
                  </svg>
                ) : (
                  <div className="size-full flex items-center justify-center">
                    <ScanLine className="w-10 h-10 text-zinc-300" />
                  </div>
                )}
              </div>

              {/* Scan line (waiting only) */}
              {stage === 'waiting' && (
                <span
                  data-scan-line
                  className="pointer-events-none absolute inset-x-3 h-0.5 rounded-none bg-accent before:absolute before:inset-x-0 before:-top-7 before:h-7 before:rounded-b before:bg-ink"
                />
              )}

              {/* Phone pickup */}
              {stage === 'scanned' && (
                <span
                  data-phone
                  className="absolute flex size-14 items-center justify-center rounded-none border border-rule bg-paper text-ink"
                >
                  <Smartphone className="w-7 h-7" />
                </span>
              )}

              {/* Confirmation stamp */}
              {stage === 'confirmed' && (
                <div
                  data-stamp
                  className="absolute inset-0 flex flex-col items-center justify-center gap-2.5 px-3 text-center bg-paper/85"
                >
                  <span className="flex size-14 items-center justify-center rounded-none bg-accent text-white">
                    <Check className="w-7 h-7" strokeWidth={2.5} />
                  </span>
                  <p className="text-xs font-semibold text-ink">Gescannt &amp; bereit</p>
                </div>
              )}
            </div>

            {/* Feature badge under the tile */}
            <span className="absolute -bottom-2.5 left-1/2 flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-none border border-rule bg-paper px-2.5 py-1 text-[10px] font-medium text-ink/60">
              <span className="w-1.5 h-1.5 rounded-none bg-accent" />
              {feature.label}
            </span>
          </div>

          <p className="mt-5 min-h-8 max-w-[230px] text-center text-[11px] leading-4 text-ink/60">
            {statusText} · {feature.caption}
          </p>
        </div>

        {/* Guidance column */}
        <div className="w-full min-w-0">
          <p className="mb-2 text-[10px] font-medium uppercase tracking-[.18em] text-ink/60">
            {content.eyebrow}
          </p>
          <h3 className="text-2xl font-semibold leading-[1.15] tracking-tight text-ink">
            {content.headline[0]}
            <br />
            {content.headline[1]}
          </h3>
          <ol className="mt-4 space-y-3">
            {content.steps.map((step, i) => {
              const stepNo = i + 1;
              const active = stageStep >= stepNo;
              return (
                <li key={step.title} className="flex items-center gap-3">
                  <span
                    className={`flex size-6 shrink-0 items-center justify-center rounded-none border text-[10px] font-semibold ${
                      active
                        ? 'border-black bg-black text-white'
                        : 'border-rule text-ink/60'
                    }`}
                  >
                    {stageStep > stepNo ? (
                      <Check className="w-3 h-3" />
                    ) : (
                      String(stepNo).padStart(2, '0')
                    )}
                  </span>
                  <span className="min-w-0">
                    <span className={`block text-xs font-semibold ${active ? 'text-ink' : 'text-ink/60'}`}>
                      {step.title}
                    </span>
                    <span className="block text-[11px] text-ink/60">{step.caption}</span>
                  </span>
                </li>
              );
            })}
          </ol>
        </div>
      </div>

      {/* Footer */}
      <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-rule bg-[#FAFAFA] rounded-b-[16px] px-5 sm:px-6 py-3">
        <span className="flex items-center gap-1.5 text-[10px] text-ink/60">
          <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
          100 % lokal im Browser – nichts wird hochgeladen
        </span>
        <span className="text-[10px] text-ink/60">Kostenlos &amp; ohne Konto</span>
      </footer>
    </section>
  );
};

export default HeroQrVisual;
