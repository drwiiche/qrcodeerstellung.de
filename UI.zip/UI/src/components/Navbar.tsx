'use client';

/**
 * Navbar — an ink index bar. Three grouped menus (QR-Typen, Lösungen, Ratgeber)
 * plus the two real actions: history and jump-to-generator.
 *
 * Every entry here has a destination that exists: QR types select a tab and
 * scroll to the generator, the solution/guide entries are real routes.
 */
import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LanguageSwitcher } from './i18n/LanguageSwitcher';
import { LOCALES } from '../lib/i18n/config';
import { QrCode, History, ChevronDown, Menu, X } from 'lucide-react';
import { QRType } from '../types/qr';
import { typeColor } from '../lib/typeColor';

interface NavbarProps {
  onScrollToSeo: () => void;
  onOpenHistory: () => void;
  historyCount: number;
  onNavigateHome?: () => void;
  onSelectQRType?: (type: QRType) => void;
}

const QR_TYPE_ITEMS: { id: QRType; label: string }[] = [
  { id: 'wifi', label: 'WLAN-Gastzugang' },
  { id: 'sepa', label: 'SEPA GiroCode' },
  { id: 'vcard', label: 'Visitenkarte (vCard)' },
  { id: 'url', label: 'Webseite / URL' },
  { id: 'delivery', label: 'Paket-Abstellort' },
  { id: 'event', label: 'Termin / Kalender' },
  { id: 'standort', label: 'Standort auf Karte' },
  { id: 'phone', label: 'Telefonnummer' },
  { id: 'sms', label: 'SMS' },
  { id: 'whatsapp', label: 'WhatsApp' },
  { id: 'email', label: 'E-Mail' },
  { id: 'text', label: 'Freitext' },
];

const SOLUTION_ITEMS = [
  { href: '/qr-code-generator', label: 'Alle QR-Typen im Detail' },
  { href: '/vorlagen', label: 'Vorlagen zum Laden' },
  { href: '/qr-codes-fuer/unternehmen', label: 'Für Unternehmen' },
  { href: '/qr-codes-fuer/schulen', label: 'Für Schulen und Bildung' },
  { href: '/qr-codes-fuer/veranstaltungen', label: 'Für Veranstaltungen' },
  { href: '/qr-codes-fuer/immobilien', label: 'Für Immobilien' },
  { href: '/qr-codes-fuer/gesundheit', label: 'Gesundheit und Fitness' },
  { href: '/qr-codes-auf', label: 'Auf Druckerzeugnissen' },
];

const GUIDE_ITEMS = [
  { href: '/anleitungen', label: 'Anleitung: QR-Code erstellen' },
  { href: '/standards', label: 'Normen und Pflichten' },
  { href: '/blog', label: 'Ratgeber' },
  { href: '/ueber-uns', label: 'Über dieses Werkzeug' },
];

export const Navbar: React.FC<NavbarProps> = ({
  onScrollToSeo,
  onOpenHistory,
  historyCount,
  onNavigateHome,
  onSelectQRType,
}) => {
  const [openMenu, setOpenMenu] = useState<'types' | 'solutions' | 'guides' | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const headerRef = useRef<HTMLElement | null>(null);
  const pathname = usePathname();

  useEffect(() => {
    setOpenMenu(null);
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpenMenu(null);
        setMobileOpen(false);
      }
    };
    const onClick = (e: MouseEvent) => {
      if (headerRef.current && !headerRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
      }
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onClick);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onClick);
    };
  }, []);

  const pickType = (id: QRType) => {
    onSelectQRType?.(id);
    setOpenMenu(null);
    setMobileOpen(false);
    onScrollToSeo();
  };

  const menuBtn = (id: 'types' | 'solutions' | 'guides', label: string) => (
    <button
      type="button"
      aria-haspopup="true"
      aria-expanded={openMenu === id}
      onClick={() => setOpenMenu(openMenu === id ? null : id)}
      className={`inline-flex items-center gap-1.5 h-9 px-3 text-[13px] font-medium border-b-2 transition-colors ${
        openMenu === id
          ? 'border-acid text-acid'
          : 'border-transparent text-paper/80 hover:text-paper hover:border-paper/30'
      }`}
    >
      {label}
      <ChevronDown
        className={`w-3.5 h-3.5 transition-transform duration-150 ${
          openMenu === id ? 'rotate-180' : ''
        }`}
      />
    </button>
  );

  const dropPanel =
    'absolute top-full left-0 mt-2 bg-paper text-ink border border-ink z-50';

  return (
    <header
      ref={headerRef}
      className="sticky top-0 z-40 bg-ink text-paper border-b border-ink on-ink"
    >
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 gap-4">
          {/* Mark: a QR finder pattern squared off, not a rounded avatar. */}
          <button
            type="button"
            onClick={onNavigateHome}
            className="flex items-center gap-2.5 text-left shrink-0 group"
          >
            <span className="w-7 h-7 bg-accent flex items-center justify-center rim">
              <QrCode className="w-4 h-4 text-ink" strokeWidth={2.5} />
            </span>
            <span className="leading-none">
              <span className="block text-[15px] font-bold tracking-tight">QR-Generator</span>
              <span className="block spec text-[9px] text-paper/55 mt-1">Deutschland</span>
            </span>
          </button>

          {/* Desktop menus */}
          <nav aria-label="Hauptnavigation" className="hidden lg:flex items-center gap-1 relative">
            {menuBtn('types', 'QR-Typen')}
            {menuBtn('solutions', 'Lösungen')}
            {menuBtn('guides', 'Ratgeber')}

            {openMenu === 'types' && (
              <div className={`${dropPanel} w-[520px] max-w-[90vw] grid grid-cols-2 divide-x divide-rule`}>
                {QR_TYPE_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => pickType(item.id)}
                    className="flex items-center gap-2.5 px-3.5 py-2.5 text-[13px] text-ink/80 hover:bg-paper-2 hover:text-ink transition-colors text-left"
                  >
                    <span
                      className="w-2 h-2 shrink-0"
                      style={{ backgroundColor: typeColor(item.id).hex }}
                      aria-hidden="true"
                    />
                    {item.label}
                  </button>
                ))}
              </div>
            )}

            {openMenu === 'solutions' && (
              <div className={`${dropPanel} w-[300px]`}>
                {SOLUTION_ITEMS.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center justify-between px-3.5 py-2.5 text-[13px] text-ink/80 hover:bg-paper-2 hover:text-ink transition-colors border-b border-rule last:border-0"
                  >
                    {item.label}
                    <span className="spec text-ink/35 text-[9px]">Seite</span>
                  </Link>
                ))}
              </div>
            )}

            {openMenu === 'guides' && (
              <div className={`${dropPanel} w-[300px]`}>
                {GUIDE_ITEMS.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center justify-between px-3.5 py-2.5 text-[13px] text-ink/80 hover:bg-paper-2 hover:text-ink transition-colors border-b border-rule last:border-0"
                  >
                    {item.label}
                    <span className="spec text-ink/35 text-[9px]">Seite</span>
                  </Link>
                ))}
              </div>
            )}
          </nav>

          {/* Real actions only */}
          <div className="flex items-center gap-2 shrink-0">
            {/* The German tree had no way into the eleven locales at all: the
                switcher only existed inside the locale layout. Same component,
                so a reader on a German-only page is offered the homepage of the
                target language instead of a 404. */}
            <div className="hidden md:block">
              <LanguageSwitcher current="de" label="Sprache" />
            </div>
            <button
              type="button"
              onClick={onOpenHistory}
              aria-label={`Verlauf öffnen${
                historyCount > 0 ? `, ${historyCount} gespeicherte Codes` : ''
              }`}
              className="inline-flex items-center gap-1.5 h-9 px-2.5 text-[13px] font-medium text-paper/85 border border-paper/25 hover:border-paper hover:text-paper transition-colors"
            >
              <History className="w-3.5 h-3.5" strokeWidth={2.2} />
              <span className="hidden sm:inline">Verlauf</span>
              {historyCount > 0 && (
                <span className="ml-0.5 min-w-[16px] h-4 px-1 bg-acid text-ink text-[10px] font-bold grid place-items-center tabular-nums">
                  {historyCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={onScrollToSeo}
              className="hidden sm:inline-flex items-center h-9 px-4 text-[13px] font-bold bg-acid text-ink hover:bg-paper transition-colors"
            >
              Code erstellen
            </button>

            <button
              type="button"
              aria-label={mobileOpen ? 'Menü schließen' : 'Menü öffnen'}
              aria-expanded={mobileOpen}
              aria-controls="mobile-nav"
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden grid place-items-center w-9 h-9 border border-paper/25 text-paper hover:border-paper transition-colors"
            >
              {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile panel */}
      {mobileOpen && (
        <nav
          id="mobile-nav"
          aria-label="Mobile Navigation"
          className="lg:hidden border-t border-paper/15 max-h-[75vh] overflow-y-auto"
        >
          <div className="px-4 sm:px-6 py-4">
            <p className="spec text-[9px] text-paper/45 mb-2">QR-Typ wählen</p>
            <div className="grid grid-cols-2 gap-x-4">
              {QR_TYPE_ITEMS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => pickType(item.id)}
                  className="flex items-center gap-2 py-2.5 text-[13px] text-paper/80 hover:text-paper border-b border-paper/10 text-left"
                >
                  <span
                    className="w-2 h-2 shrink-0"
                    style={{ backgroundColor: typeColor(item.id).hex }}
                    aria-hidden="true"
                  />
                  {item.label}
                </button>
              ))}
            </div>

            <p className="spec text-[9px] text-paper/45 mt-5 mb-2">Lösungen</p>
            {SOLUTION_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block py-2.5 text-[13px] text-paper/80 hover:text-paper border-b border-paper/10"
              >
                {item.label}
              </Link>
            ))}

            <p className="spec text-[9px] text-paper/45 mt-5 mb-2">Ratgeber</p>
            {GUIDE_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block py-2.5 text-[13px] text-paper/80 hover:text-paper border-b border-paper/10"
              >
                {item.label}
              </Link>
            ))}

            <p className="spec text-[9px] text-paper/45 mt-5 mb-2">Sprache</p>
            <div className="flex flex-wrap gap-x-4 gap-y-2">
              {LOCALES.filter((l) => l.code !== 'de').map((l) => (
                <a
                  key={l.code}
                  href={`/${l.code}`}
                  hrefLang={l.hreflang}
                  lang={l.htmlLang}
                  className="py-1 text-[13px] text-paper/80 hover:text-paper"
                >
                  {l.nativeName}
                </a>
              ))}
            </div>
          </div>
        </nav>
      )}
    </header>
  );
};
