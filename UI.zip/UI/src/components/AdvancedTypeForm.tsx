'use client';

/**
 * One form for the schema-driven types.
 *
 * Renders whatever field list it is handed. The visual language matches the
 * hand-written forms in QRForm.tsx (square corners, hairline rules, uppercase
 * micro labels) so a visitor cannot tell which types are schema-driven.
 */
import React from 'react';
import type { AdvancedType } from '../utils/payloads';
import { ADVANCED_SCHEMA } from '../lib/qrTypeSchema';
import { typeColor } from '../lib/typeColor';
import type { QRType } from '../types/qr';

export function AdvancedTypeForm({
  type,
  values,
  onChange,
}: {
  type: AdvancedType;
  values: Record<string, string>;
  onChange: React.Dispatch<React.SetStateAction<Record<string, string>>>;
}) {
  const schema = ADVANCED_SCHEMA[type];
  if (!schema) return null;

  const c = typeColor(type as QRType);

  const set = (id: string, value: string) => onChange((prev) => ({ ...prev, [id]: value }));

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-2.5 px-3 py-2.5 bg-paper-2 border border-rule">
        <span className="w-2 h-2 mt-1.5 shrink-0" style={{ backgroundColor: c.hex }} aria-hidden="true" />
        <p className="text-[12.5px] leading-relaxed text-ink/75">{schema.intro}</p>
      </div>

      {/* Fields flagged `half` sit in a two-column row with the next one. */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {schema.fields.map((f) => {
          const value = values[f.id] ?? '';
          const empty = f.required && value.trim().length === 0;
          return (
            <div key={f.id} className={f.half ? '' : 'sm:col-span-2'}>
              <label
                htmlFor={`adv-${f.id}`}
                className="block text-[10px] font-bold uppercase tracking-[0.1em] text-ink/55 mb-1.5"
              >
                {f.label}
                {f.required && <span className="text-accent-text"> *</span>}
              </label>
              <input
                id={`adv-${f.id}`}
                name={f.id}
                type={f.type ?? 'text'}
                inputMode={f.inputMode}
                placeholder={f.placeholder}
                maxLength={f.maxLength}
                value={value}
                onChange={(e) => set(f.id, e.target.value)}
                aria-invalid={empty ? true : undefined}
                aria-describedby={f.hint ? `adv-${f.id}-hint` : undefined}
                className={`w-full px-3.5 py-2.5 bg-paper text-ink text-[14px] border transition-colors focus:outline-none focus:ring-2 focus:ring-ink ${
                  empty ? 'border-accent' : 'border-rule'
                }`}
              />
              {f.hint && (
                <p id={`adv-${f.id}-hint`} className="mt-1.5 text-[11.5px] leading-relaxed text-ink/55">
                  {f.hint}
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
