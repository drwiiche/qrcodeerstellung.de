/**
 * DSGVO & TDDDG compliant Cookie Consent Banner.
 */

import React, { useState, useEffect, useRef } from 'react';
import { ShieldCheck, ChevronDown, ChevronUp, Check, Info } from 'lucide-react';
import { getCookieConsent, setCookieConsent, CookiePreferences } from '../utils/analytics';
import { useUi } from './i18n/UiProvider';

interface CookieBannerProps {
  onNavigate: (route: string) => void;
  /**
   * Drops the expandable per-category panel. Used on locale pages, where those
   * category descriptions are still German: the honest choice is the two
   * unambiguous options (necessary only, or everything) rather than a
   * half-translated detail view. Opting out stays one click away, which is the
   * direction consent law actually cares about.
   */
  compact?: boolean;
}

export const CookieBanner: React.FC<CookieBannerProps> = ({ onNavigate, compact = false }) => {
  const u = useUi();
  const [isOpen, setIsOpen] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [analyticsAllowed, setAnalyticsAllowed] = useState(false);
  const [marketingAllowed, setMarketingAllowed] = useState(false);
  const bannerRef = useRef<HTMLElement | null>(null);

  // The consent banner and the mobile action bar are both fixed to the bottom
  // edge, so the bar hides itself while the banner is open (see index.css).
  useEffect(() => {
    document.body.dataset.consentOpen = isOpen ? 'true' : 'false';
    const el = bannerRef.current;
    if (!isOpen || !el) {
      document.body.style.removeProperty('--consent-height');
      return () => {
        delete document.body.dataset.consentOpen;
      };
    }
    const publishHeight = () => {
      document.body.style.setProperty('--consent-height', `${el.offsetHeight}px`);
    };
    publishHeight();
    const observer = new ResizeObserver(publishHeight);
    observer.observe(el);
    return () => {
      observer.disconnect();
      document.body.style.removeProperty('--consent-height');
      delete document.body.dataset.consentOpen;
    };
  }, [isOpen, showDetails]);

  useEffect(() => {
    const consent = getCookieConsent();
    if (!consent) {
      setIsOpen(true);
    }

    const handleReopen = () => {
      const current = getCookieConsent();
      if (current) {
        setAnalyticsAllowed(current.analytics);
        setMarketingAllowed(current.marketing);
      }
      setShowDetails(true);
      setIsOpen(true);
    };

    window.addEventListener('open_cookie_settings', handleReopen);
    return () => window.removeEventListener('open_cookie_settings', handleReopen);
  }, []);

  const handleAcceptAll = () => {
    setCookieConsent({ essential: true, analytics: true, marketing: true });
    setIsOpen(false);
  };

  const handleAcceptEssentialOnly = () => {
    setCookieConsent({ essential: true, analytics: false, marketing: false });
    setIsOpen(false);
  };

  const handleSaveCustom = () => {
    setCookieConsent({ essential: true, analytics: analyticsAllowed, marketing: marketingAllowed });
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <aside ref={bannerRef} aria-label={u['ck.title']} className="fixed bottom-0 inset-x-0 z-50 px-3 sm:px-4 py-3.5 bg-ink text-paper on-ink border-t-2 border-acid">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Text & Notice */}
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 bg-acid text-ink grid place-items-center shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </span>
              <h2 className="font-bold text-sm sm:text-[15px] tracking-tight text-paper">
                {u['ck.title']}
              </h2>
            </div>
            <p className="text-[12px] text-paper/70 leading-relaxed">
              {u['ck.body']}
            </p>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-paper/55">
              <button
                type="button"
                onClick={() => onNavigate('datenschutz')}
                className="underline hover:text-paper transition-colors"
              >
                Datenschutzerklärung
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => onNavigate('impressum')}
                className="underline hover:text-paper transition-colors"
              >
                Impressum
              </button>
              {!compact && <span>·</span>}
              {!compact && <button
                type="button"
                onClick={() => setShowDetails(!showDetails)}
                className="inline-flex items-center gap-1 hover:text-paper transition-colors font-semibold text-paper/80"
              >
                {showDetails ? (
                  <>
                    <span>{u['ck.less']}</span>
                    <ChevronUp className="w-3 h-3" />
                  </>
                ) : (
                  <>
                    <span>{u['ck.settings']}</span>
                    <ChevronDown className="w-3 h-3" />
                  </>
                )}
              </button>}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 flex-shrink-0">
            <button
              type="button"
              onClick={handleAcceptEssentialOnly}
              className="h-10 px-4 text-[12px] font-semibold border border-paper/35 text-paper hover:border-paper hover:bg-paper/10 transition-colors"
            >
              {u['ck.essential']}
            </button>
            {showDetails ? (
              <button
                type="button"
                onClick={handleSaveCustom}
                className="h-10 px-4 text-[12px] font-semibold border border-paper/35 text-paper hover:border-paper hover:bg-paper/10 transition-colors"
              >
                Auswahl speichern
              </button>
            ) : null}
            <button
              type="button"
              onClick={handleAcceptAll}
              className="h-10 px-5 text-[12px] font-bold bg-acid text-ink hover:bg-paper transition-colors"
            >
              {u['ck.accept']}
            </button>
          </div>
        </div>

        {/* Expandable details panel */}
        {showDetails && !compact && (
          <div className="mt-4 pt-3 border-t border-paper/20 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3.5 border border-paper/20">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-paper flex items-center gap-1.5 text-[12px]">
                  <Check className="w-3.5 h-3.5 text-accent" />
                  Technisch essenziell
                </span>
                <span className="spec text-[9px] text-paper/60 bg-paper/10 px-1.5 py-0.5">
                  Immer aktiv
                </span>
              </div>
              <p className="text-[11px] text-paper/60 leading-normal mt-1.5">
                Speichert Ihre QR-Eingaben, Vorlagen und den lokalen Verlauf sicher in Ihrem Browser (HTML5 LocalStorage). Keine Server-Cookies.
              </p>
            </div>

            <div className="p-3.5 border border-paper/20">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-paper flex items-center gap-1.5 text-[12px]">
                  <Info className="w-3.5 h-3.5" />
                  Anonyme Nutzungsstatistik
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={analyticsAllowed}
                    onChange={(e) => setAnalyticsAllowed(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-zinc-300 peer-focus:outline-none rounded-none peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-rule after:border after:rounded-none after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
              <p className="text-[11px] text-paper/60 leading-normal mt-1.5">
                Hilft uns zu verstehen, welche QR-Typen am beliebtesten sind (z. B. WLAN vs. SEPA), ohne IP-Adressen oder persönliche Daten zu speichern.
              </p>
            </div>

            <div className="p-3.5 border border-paper/20">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-paper flex items-center gap-1.5 text-[12px]">
                  <Info className="w-3.5 h-3.5" />
                  Werbung &amp; Marketing
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={marketingAllowed}
                    onChange={(e) => setMarketingAllowed(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-zinc-300 peer-focus:outline-none rounded-none peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-paper after:border-rule after:border after:rounded-none after:h-4 after:w-4 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
              <p className="text-[11px] text-paper/60 leading-normal mt-1.5">
                Ermöglicht die Einblendung von Anzeigen unserer Werbepartner (z. B. Google AdSense). Ohne Zustimmung werden keine Werbungskookies gesetzt.
              </p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
