'use client';

import React, { useState } from 'react';
import {
  CheckCircle2,
  Printer,
  ArrowLeft,
  Share2,
  ThumbsUp,
  ThumbsDown,
  ShieldCheck,
  Smartphone,
  Info,
} from 'lucide-react';
import { trackEvent } from '../utils/analytics';
import { useSite } from './SiteShell';

export const ThankYouPage: React.FC = () => {
  const { navigate, addToast: onNotify } = useSite();
  const onNavigateHome = () => navigate('home');
  const [feedbackGiven, setFeedbackGiven] = useState<'yes' | 'no' | null>(null);

  const handleFeedback = (isPositive: boolean) => {
    setFeedbackGiven(isPositive ? 'yes' : 'no');
    trackEvent('feedback_submitted', { success: isPositive });
    onNotify?.(isPositive ? '✓ Vielen Dank für Ihr Feedback!' : 'Danke für die Rückmeldung. Wir verbessern den Scanner!');
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'QR-Generator Deutschland',
          text: 'Kostenlos hochauflösende QR-Codes für Zuhause, WLAN und SEPA erstellen.',
          url: window.location.origin,
        });
      } catch {
        // user cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.origin);
      onNotify?.('✓ Link in die Zwischenablage kopiert!');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12">
      {/* Heading — no pill badge above it */}
      <div className="max-w-2xl mx-auto mb-10 text-left">
        <div className="w-12 h-12 rounded-none bg-black text-white flex items-center justify-center mb-5">
          <CheckCircle2 className="w-6 h-6 stroke-[2]" />
        </div>
        <h1 className="text-2xl sm:text-4xl font-semibold text-ink tracking-tight mb-3">
          Vielen Dank für Ihre Nutzung!
        </h1>
        <p className="text-sm sm:text-base text-ink/60 leading-relaxed">
          Ihr QR-Code wurde in bester Vektor- oder Ultra-HD-Auflösung vorbereitet.
          Damit im Alltag, im Hausflur oder am Tresen jeder Scan auf Anhieb klappt, beachten Sie die folgenden Empfehlungen:
        </p>
      </div>

      {/* Recommended Print & Sizing Guidelines */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
        <div className="bg-paper-2 rounded-none border border-rule p-5">
          <div className="w-8 h-8 rounded-none bg-paper border border-rule text-ink flex items-center justify-center font-semibold text-xs mb-4">
            1
          </div>
          <h2 className="font-semibold text-ink text-sm mb-2">
            Optimale Mindestgröße
          </h2>
          <p className="text-xs text-ink/60 leading-relaxed">
            • <strong className="text-ink">Visitenkarten:</strong> min. 20 × 20 mm<br />
            • <strong className="text-ink">Tischaufsteller / A6:</strong> 30 × 30 mm<br />
            • <strong className="text-ink">Haustür & A4 Flyer:</strong> 40 × 40 mm
          </p>
        </div>

        <div className="bg-paper-2 rounded-none border border-rule p-5">
          <div className="w-8 h-8 rounded-none bg-paper border border-rule text-ink flex items-center justify-center font-semibold text-xs mb-4">
            2
          </div>
          <h2 className="font-semibold text-ink text-sm mb-2">
            Weißer Rand (Quiet Zone)
          </h2>
          <p className="text-xs text-ink/60 leading-relaxed">
            Lassen Sie stets einen unbedruckten weißen Rand von mindestens 4 Modulen um den QR-Code frei. Dunkle Hintergründe direkt an der Kante erschweren Smartphone-Kameras das Fokussieren.
          </p>
        </div>

        <div className="bg-paper-2 rounded-none border border-rule p-5">
          <div className="w-8 h-8 rounded-none bg-paper border border-rule text-ink flex items-center justify-center font-semibold text-xs mb-4">
            3
          </div>
          <h2 className="font-semibold text-ink text-sm mb-2">
            Test-Scan vor Druck
          </h2>
          <p className="text-xs text-ink/60 leading-relaxed">
            Führen Sie vor dem Massendruck oder Laminieren immer einen Probescan mit der Standard-Kamera-App (iOS & Android) durch.
          </p>
        </div>
      </div>

      {/* Interactive Scan Test Check & Feedback — flat smoke card, no gradient/shadow */}
      <div className="bg-paper-2 rounded-none p-6 sm:p-8 mb-10 border border-rule">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-left">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-ink/60 uppercase tracking-wider">
              <Smartphone className="w-4 h-4" />
              Qualitätssicherung
            </span>
            <h2 className="text-lg sm:text-xl font-semibold text-ink">
              Hat Ihr Smartphone den QR-Code sofort erkannt?
            </h2>
            <p className="text-xs text-ink/60 max-w-lg">
              Ihr Feedback hilft uns sicherzustellen, dass alle deutschen Banking-Apps (Sparkasse, ING, DKB) und Router (Fritz!Box, Telekom) 100% kompatibel bleiben.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {feedbackGiven ? (
              <div className="flex items-center gap-2 bg-paper text-ink border border-rule px-4 py-2.5 rounded-none text-xs font-semibold">
                <CheckCircle2 className="w-4 h-4 text-accent" />
                Vielen Dank für Ihre Rückmeldung!
              </div>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => handleFeedback(true)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-none bg-black hover:bg-paper-2 text-white font-semibold text-xs transition cursor-pointer"
                >
                  <ThumbsUp className="w-4 h-4" />
                  <span>Ja, sofort!</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleFeedback(false)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-none bg-paper hover:bg-paper-2 text-ink font-semibold text-xs border border-rule transition cursor-pointer"
                >
                  <ThumbsDown className="w-4 h-4" />
                  <span>Gab Probleme</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Return & Sharing Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-6 border-t border-rule">
        <button
          type="button"
          onClick={onNavigateHome}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-none bg-black hover:bg-paper-2 text-white text-xs sm:text-sm font-semibold transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Weiteren QR-Code kostenlos erstellen</span>
        </button>

        <button
          type="button"
          onClick={handleShare}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-none bg-paper hover:bg-paper-2 text-ink text-xs sm:text-sm font-semibold border border-rule transition cursor-pointer"
        >
          <Share2 className="w-4 h-4" />
          <span>QR-Generator weiterempfehlen</span>
        </button>
      </div>
    </div>
  );
};
