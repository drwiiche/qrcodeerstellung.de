/**
 * Locale guide page.
 *
 * A long-form answer page rather than a landing page: one table of contents,
 * real sections with subheads, a size table, and a FAQ. The generated QR type
 * is linked from the CTA, so the page always has a path back into the tool.
 */
import Link from 'next/link';
import type { Guide } from '../../lib/i18n/guide';
import type { Locale } from '../../lib/i18n/config';
import { localeMeta } from '../../lib/i18n/config';
import type { LocaleDict } from '../../lib/i18n/dictionaries';
import { dict } from '../../lib/i18n/dictionaries';
import { ArrowRight, ChevronLeft } from 'lucide-react';
import { Byline } from '../Byline';

function slugify(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\u0590-\u05ff\u0600-\u06ff]+/g, '-')
    .replace(/^-|-$/g, '');
}

export function GuidePage({
  guide,
  locale,
  related,
  languages = [],
}: {
  guide: Guide;
  locale: Locale;
  related: { label: string; href: string }[];
  /** The same guide in the other locales, linked visibly as well as in hreflang. */
  languages?: { code: string; name: string; href: string }[];
}) {
  const meta = localeMeta(locale);
  const rtl = meta.dir === 'rtl';
  const t: LocaleDict = dict(locale);
  const homeHref = locale === 'de' ? '/' : `/${locale}`;
  /* A locale guide used to send every reader to the German root, which is the
     generator in German. On a locale page the generator is rendered inline on
     that locale's home, so the link stays in the language and only carries the
     type to preselect. */
  const toolHref = locale === 'de' ? `/?type=${guide.toolType}` : `/${locale}?type=${guide.toolType}#generator`;

  return (
    <>
      <article>
        {/* Head */}
        <header className="bg-ink text-paper on-ink">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-9 sm:pt-8 sm:pb-10">
            <nav aria-label="Breadcrumb" className="flex items-center gap-2 spec text-[9px] mb-6">
              <Link href={homeHref} className="text-paper/45 hover:text-paper transition-colors">
                {meta.nativeName}
              </Link>
              <span className="text-paper/25" aria-hidden="true">
                /
              </span>
              <span className="text-paper/70">{guide.ui.contents}</span>
            </nav>

            <div className="grid lg:grid-cols-12 gap-8 lg:gap-10 items-start">
              <div className="lg:col-span-8">
                <h1 className="display text-[clamp(1.7rem,3.4vw,2.5rem)] text-paper">{guide.h1}</h1>
                <p className="mt-5 max-w-2xl text-[15px] sm:text-base leading-relaxed text-paper/75">
                  {guide.lead}
                </p>
                <Link
                  href={toolHref}
                  className="mt-7 inline-flex items-center gap-2 h-12 px-6 bg-acid text-ink text-[14px] font-bold hover:bg-paper transition-colors"
                >
                  {guide.cta.label}
                  <ArrowRight
                    className="w-4 h-4"
                    style={rtl ? { transform: 'scaleX(-1)' } : undefined}
                    aria-hidden="true"
                  />
                </Link>
                <p className="mt-2.5 spec text-[9px] text-paper/40">{guide.cta.hint}</p>
                <div className="mt-4 pt-3 border-t border-paper/15">
                  <Byline locale={locale} tone="dark" />
                </div>
              </div>

              {/* Table of contents: real jump links, numbered */}
              <nav aria-label={guide.ui.contents} className="lg:col-span-4 w-full">
                <p className="spec text-paper/50 mb-2.5">{guide.ui.contents}</p>
                <ol className="border-t border-paper/15">
                  {guide.sections.map((s, i) => (
                    <li key={s.h2} className="border-b border-paper/15">
                      <a
                        href={`#${slugify(s.h2)}`}
                        className="flex items-baseline gap-3 py-2.5 text-[13px] text-paper/80 hover:text-acid transition-colors"
                      >
                        <span className="spec text-[9px] text-paper/35 tabular-nums">
                          {String(i + 1).padStart(2, '0')}
                        </span>
                        <span>{s.h2}</span>
                      </a>
                    </li>
                  ))}
                  <li className="border-b border-paper/15">
                    <a
                      href="#faq"
                      className="flex items-baseline gap-3 py-2.5 text-[13px] text-paper/80 hover:text-acid transition-colors"
                    >
                      <span className="spec text-[9px] text-paper/35 tabular-nums">
                        {String(guide.sections.length + 1).padStart(2, '0')}
                      </span>
                      <span>{guide.ui.faq}</span>
                    </a>
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </header>

        <div className="h-px bg-rule" aria-hidden="true" />

        {/* Body */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-14">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-14">
            <div className="lg:col-span-8">
              {guide.answer && (
                <div
                  className="answer-block mb-7 border-s-[3px] border-acid bg-paper-2 px-4 py-3.5"
                  style={{ borderInlineStartWidth: 3 }}
                >
                  <p className="spec text-[9px] text-ink/45 mb-1.5">{guide.answer.label}</p>
                  <p className="text-[15px] leading-relaxed text-ink font-medium">
                    {guide.answer.text}
                  </p>
                </div>
              )}

              {guide.intro.map((p, i) => (
                <p
                  key={i}
                  className={
                    i === 0
                      ? 'text-[16px] sm:text-[17px] leading-relaxed text-ink font-medium'
                      : 'mt-4 text-[15px] leading-relaxed text-ink/80'
                  }
                >
                  {p}
                </p>
              ))}

              {guide.sections.map((s) => (
                <section key={s.h2} id={slugify(s.h2)} className="mt-10 scroll-mt-20">
                  <h2 className="display text-[clamp(1.4rem,3vw,1.9rem)]">{s.h2}</h2>
                  {s.body.map((p, i) => (
                    <p key={i} className="mt-3.5 text-[15px] leading-relaxed text-ink/80">
                      {p}
                    </p>
                  ))}
                  {s.bullets && (
                    <ul className="mt-4 space-y-2">
                      {s.bullets.map((b) => (
                        /* Flex marker instead of a pseudo element: the accent
                           square then sits on the correct side in RTL without
                           relying on logical-property support in the build. */
                        <li key={b} className="flex items-start gap-2.5">
                          <span
                            className="mt-[0.55em] w-1.5 h-1.5 bg-accent shrink-0"
                            aria-hidden="true"
                          />
                          <span className="text-[14px] leading-relaxed text-ink/75">{b}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              ))}

              {/* Size table */}
              {guide.table && (
                <section className="mt-10">
                  <h2 className="display text-[clamp(1.4rem,3vw,1.9rem)]">{guide.ui.tableCaption}</h2>
                  <div className="mt-4 border border-rule overflow-x-auto">
                    <table className="w-full text-left">
                      <caption className="sr-only">{guide.table.caption}</caption>
                      <thead className="bg-paper-2">
                        <tr>
                          {guide.table.head.map((h) => (
                            <th key={h} className="px-3 py-2 text-[12px] font-bold text-start">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {guide.table.rows.map((row) => (
                          <tr key={row.join('|')} className="border-t border-rule">
                            {row.map((cell, i) => (
                              <td
                                key={i}
                                className={`px-3 py-2 text-[13px] ${i === 0 ? 'font-semibold' : 'text-ink/70'}`}
                              >
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>
              )}
            </div>

            {/* Sticky sidebar: CTA plus related links */}
            <aside className="lg:col-span-4">
              <div className="lg:sticky lg:top-20 space-y-4">
                <div className="border border-ink bg-ink text-paper on-ink p-5">
                  <p className="text-[14px] font-bold text-paper">{guide.cta.label}</p>
                  <p className="mt-1.5 spec text-[9px] text-paper/50">{guide.cta.hint}</p>
                  <Link
                    href={toolHref}
                    className="mt-4 inline-flex items-center justify-center w-full h-10 bg-acid text-ink text-[13px] font-bold hover:bg-paper transition-colors"
                  >
                    {t.cta.button}
                  </Link>
                </div>

                {languages.length > 0 && (
                  <div className="border border-rule">
                    <p className="spec text-[9px] text-ink/45 px-4 pt-3.5">{t.nav.language}</p>
                    <ul className="flex flex-wrap gap-1.5 p-3">
                      {languages.map((l) => (
                        <li key={l.code}>
                          <Link
                            href={l.href}
                            hrefLang={l.code}
                            className="inline-flex items-center h-7 px-2 border border-rule spec text-[9px] text-ink/60 hover:border-ink hover:text-ink transition-colors"
                          >
                            {l.name}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {related.length > 0 && (
                  <div className="border border-rule">
                    <p className="spec text-[9px] text-ink/45 px-4 pt-3.5">{guide.ui.related}</p>
                    <ul className="mt-2">
                      {related.map((r) => (
                        <li key={r.href} className="border-t border-rule">
                          <Link
                            href={r.href}
                            className="flex items-center justify-between gap-3 px-4 py-3 text-[13px] hover:bg-paper-2 transition-colors"
                          >
                            <span>{r.label}</span>
                            <ArrowRight
                              className="w-3.5 h-3.5 text-ink/30 shrink-0"
                              style={rtl ? { transform: 'scaleX(-1)' } : undefined}
                              aria-hidden="true"
                            />
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </aside>
          </div>
        </div>

        {/* FAQ */}
        <section id="faq" className="bg-paper-2 border-y border-rule scroll-mt-20">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-14">
            <h2 className="display text-[clamp(1.5rem,3.4vw,2.1rem)]">{guide.ui.faq}</h2>
            <div className="mt-6 border-t border-rule max-w-3xl">
              {guide.faq.map((f) => (
                <div key={f.q} className="py-4 border-b border-rule">
                  <h3 className="text-[15px] font-bold mb-1.5">{f.q}</h3>
                  <p className="text-[14px] leading-relaxed text-ink/75">{f.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <Link
            href={homeHref}
            className="inline-flex items-center gap-2 text-[13px] text-ink/60 hover:text-ink transition-colors"
          >
            <ChevronLeft
              className="w-4 h-4"
              style={rtl ? { transform: 'scaleX(-1)' } : undefined}
              aria-hidden="true"
            />
            {guide.ui.back}
          </Link>
        </div>
      </article>
    </>
  );
}
