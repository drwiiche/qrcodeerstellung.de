'use client';

/**
 * Language switcher.
 *
 * Maps the current URL onto the equivalent URL in every other locale, so the
 * switch never dumps the visitor on a homepage when they were reading
 * something specific. German is unprefixed, so it is the `code === 'de'` case.
 */
import { usePathname } from 'next/navigation';
import { useId, useState, useRef, useEffect } from 'react';
import { LOCALES, DEFAULT_LOCALE, localePath, type Locale } from '../../lib/i18n/config';
import { guideSlugsFor } from '../../lib/i18n/guides/slugs';
import { Globe, ChevronDown } from 'lucide-react';

/**
 * Hand-mapped bilingual pairs: paths that exist in German and English under
 * different URLs, so neither a prefix swap nor the guide map can find them.
 */
const BILINGUAL: Record<string, { de: string; en: string }> = {
  '/standards/wein-e-label': { de: '/standards/wein-e-label', en: '/wine-e-label' },
  '/wine-e-label': { de: '/standards/wein-e-label', en: '/wine-e-label' },
};

/** Strip a locale prefix, if present, leaving the locale-neutral path. */
function stripLocale(pathname: string): { locale: Locale; rest: string } {
  const seg = pathname.split('/').filter(Boolean);
  const first = seg[0];
  if (first && LOCALES.some((l) => l.code === first) && first !== DEFAULT_LOCALE) {
    return { locale: first as Locale, rest: '/' + seg.slice(1).join('/') };
  }
  return { locale: DEFAULT_LOCALE, rest: pathname === '' ? '/' : pathname };
}

export function LanguageSwitcher({ current, label }: { current: Locale; label: string }) {
  const pathname = usePathname() || '/';
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);
  const menuId = useId();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onClick);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onClick);
    };
  }, []);

  const { locale: active, rest } = stripLocale(pathname);
  const activeMeta = LOCALES.find((l) => l.code === active) ?? LOCALES[0];

  /*
   * Guide pages have a per-locale slug, so the generic path swap would build a
   * URL that does not exist. Detect the guide here and map to its slug in each
   * target locale instead.
   */
  const guideSlugs = guideSlugsFor(active, rest.replace(/^\//, ''));

  /**
   * The equivalent URL for `code`.
   *
   * Only three kinds of path exist under a locale prefix: the locale homepage,
   * the guide pages, and the few bilingual pairs below. Everything else in the
   * German tree (the standards cluster, the blog, the legal pages) has no
   * localized counterpart, and a straight prefix swap would ship a 404 to
   * anyone who switches language while reading one of those pages. So the
   * fallback is that locale's homepage, which is always real, and the guide map
   * supplies the exact page whenever one exists.
   */
  const hrefFor = (code: Locale): string => {
    const slug = guideSlugs?.[code];
    if (slug) return localePath(code, '/' + slug);

    /* Pages that exist in exactly two languages under different paths. */
    const pair = BILINGUAL[rest];
    if (pair) {
      const target = code === DEFAULT_LOCALE ? pair.de : code === 'en' ? pair.en : null;
      if (target) return target;
    }

    return localePath(code, '/');
  };

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-haspopup="true"
        aria-expanded={open}
        aria-controls={menuId}
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-1.5 h-9 px-2.5 text-[13px] font-medium text-paper/85 border border-paper/25 hover:border-paper hover:text-paper transition-colors"
      >
        <Globe className="w-3.5 h-3.5" aria-hidden="true" />
        <span className="sr-only">{label}:</span>
        <span>{activeMeta.nativeName}</span>
        <ChevronDown
          className={`w-3.5 h-3.5 transition-transform duration-150 ${open ? 'rotate-180' : ''}`}
          aria-hidden="true"
        />
      </button>

      {open && (
        <div
          id={menuId}
          className="absolute end-0 top-full mt-1 w-56 bg-paper text-ink border border-ink z-50 max-h-[70vh] overflow-y-auto"
        >
          <ul>
            {LOCALES.map((l) => {
              const href = hrefFor(l.code);
              const isActive = l.code === active;
              return (
                <li key={l.code}>
                  <a
                    href={href}
                    hrefLang={l.hreflang}
                    lang={l.htmlLang}
                    aria-current={isActive ? 'true' : undefined}
                    onClick={() => setOpen(false)}
                    className={`flex items-center justify-between gap-3 px-3 py-2.5 text-[13px] border-b border-rule last:border-b-0 transition-colors ${
                      isActive ? 'bg-ink text-paper font-semibold' : 'hover:bg-paper-2'
                    }`}
                  >
                    <span>{l.nativeName}</span>
                    <span
                      className={`spec text-[9px] ${isActive ? 'text-acid' : 'text-ink/35'}`}
                      aria-hidden="true"
                    >
                      {l.code.toUpperCase()}
                    </span>
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
