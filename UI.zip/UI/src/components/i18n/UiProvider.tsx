'use client';

/**
 * UI string provider for the generator.
 *
 * The generator components were written in German with the copy inline. Making
 * them usable in the other eleven locales without rewriting every screen means
 * moving that copy into `src/lib/i18n/ui` and reading it from here.
 *
 * The default is the German object, so the German tree needs no provider at
 * all, and a component rendered outside a provider still shows German rather
 * than blank labels.
 */
import { createContext, useContext } from 'react';
import { uiDe, type UiStrings } from '../../lib/i18n/ui/de';

const UiContext = createContext<UiStrings>(uiDe);

export function UiProvider({
  strings,
  children,
}: {
  strings?: UiStrings;
  children: React.ReactNode;
}) {
  return <UiContext.Provider value={strings ?? uiDe}>{children}</UiContext.Provider>;
}

export function useUi(): UiStrings {
  return useContext(UiContext);
}
