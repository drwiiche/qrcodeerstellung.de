/**
 * Localized landing page.
 *
 * Server-rendered from the locale's own dictionary. The structure is shared
 * (it is a tool page, so the sections are the tool's story) but the copy is
 * written per locale, and the `local` block carries the locale-specific
 * material that earns the page its URL: Paczkomat, Pix, Честный знак, menu,
 * troubleshooting, Wi-Fi.
 */
import Link from 'next/link';
import { localeMeta, localePath, DEFAULT_LOCALE, type Locale } from '../../lib/i18n/config';
import { allTypeNames, dict } from '../../lib/i18n/dictionaries';
import { TYPE_COLORS } from '../../lib/typeColor';
import type { QRType } from '../../types/qr';
import { GUIDE_SLUGS, typeGuideSlug } from '../../lib/i18n/guides/slugs';

/**
 * Where a type link should go.
 *
 * On a locale page without the instrument, the only generator was the German
 * root, so every path led out of the language. With the instrument on the page
 * the links address it directly.
 */
function generatorHref(type: string, withTool = false) {
  return withTool ? `#generator` : `/?type=${type}`;
}

export function LocaleLanding({
  locale,
  instrument,
}: {
  locale: Locale;
  /**
   * The real generator, rendered by the page and passed in. When it is present
   * the band stops being a call to action that leaves the language: there is
   * nothing to leave for, the tool is right below.
   */
  instrument?: React.ReactNode;
}) {
  const t = dict(locale);
  const withTool = Boolean(instrument);
  const meta = localeMeta(locale);
  /* Twelve original types plus the eight second-wave ones, all twenty colour
     coded from the same palette the tool uses. */
  const typeNames = allTypeNames(locale);
  const isDefault = locale === DEFAULT_LOCALE;
  const homeHref = isDefault ? '/' : `/${locale}`;
  const prefix = isDefault ? '' : `/${locale}`;
  const wifiGuide = `${prefix}/${GUIDE_SLUGS.wifi[locale]}`;
  /* Not every guide exists in every locale, so the link only appears where
     there is something behind it. */
  const menuSlug = GUIDE_SLUGS.menu?.[locale];
  const menuGuide = menuSlug ? `${prefix}/${menuSlug}` : null;

  return (
    <>
      {/* The generator itself, in this language, first: the German page puts the
          tool in the first viewport, so a locale page has to do the same. */}
      {instrument && (
        <section id="generator" className="scroll-mt-16 border-b border-rule">
          {instrument}
        </section>
      )}

      {/* Statement band */}
      <section className="bg-ink text-paper on-ink">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-12 sm:pt-14 sm:pb-16">
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 spec text-[9px] mb-6">
            <span className="text-paper/45">{meta.nativeName}</span>
          </nav>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-7">
              <p className="spec text-acid mb-5">{t.hero.eyebrow}</p>
              {withTool ? (
                /* The instrument below carries the h1 for the page. */
                <p className="display text-[clamp(1.75rem,3.8vw,2.7rem)] text-paper">
                  {t.hero.titleTop}
                  <br />
                  <span className="text-acid">{t.hero.titleAccent}</span>
                </p>
              ) : (
                <h1 className="display text-[clamp(1.75rem,3.8vw,2.7rem)] text-paper">
                  {t.hero.titleTop}
                  <br />
                  <span className="text-acid">{t.hero.titleAccent}</span>
                </h1>
              )}
              <p className="mt-6 max-w-xl text-[15px] sm:text-base leading-relaxed text-paper/75">
                {t.hero.lead}
              </p>

              <div className={`mt-8 flex-wrap items-center gap-3 ${withTool ? 'hidden' : 'flex'}`}>
                <Link
                  href={generatorHref('wifi', withTool)}
                  className="inline-flex items-center h-12 px-6 bg-acid text-ink text-[14px] font-bold hover:bg-paper transition-colors"
                >
                  {t.hero.cta}
                </Link>
              </div>

              <dl className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-px bg-paper/15 border border-paper/15 max-w-xl">
                {t.hero.facts.map((f) => (
                  <div key={f.term} className="bg-ink px-3.5 py-3">
                    <dt className="text-[13px] font-semibold text-paper">{f.term}</dt>
                    <dd className="spec text-[9px] text-paper/50 mt-1">{f.desc}</dd>
                  </div>
                ))}
              </dl>
            </div>

            {/* Type list, colour coded, straight into the generator */}
            <div className="lg:col-span-5 w-full">
              <h2 className="spec text-paper/60 mb-2.5">{t.types.title}</h2>
              <div className="border border-paper/20 divide-y divide-paper/10">
                {Object.entries(typeNames).map(([key, label]) => (
                  <Link
                    key={key}
                    /* A written page in this language beats another jump to the
                       tool: the reader who wants to know whether a GiroCode is
                       the right thing gets an answer instead of a form. The
                       in-page generator stays the fallback for every type that
                       has no page yet. */
                    href={
                      isDefault
                        ? generatorHref(key, withTool)
                        : typeGuideSlug(locale, key)
                          ? `${prefix}/${typeGuideSlug(locale, key)}`
                          : generatorHref(key, withTool)
                    }
                    className="flex items-center gap-3 text-left transition-colors hover:bg-paper/[0.05]"
                  >
                    <span
                      className="w-9 self-stretch shrink-0"
                      style={{ backgroundColor: TYPE_COLORS[key as QRType]?.hex ?? '#475569' }}
                      aria-hidden="true"
                    />
                    <span className="flex-1 py-2 text-[13px] font-medium text-paper/85">{label}</span>
                    <span
                      className="spec text-[9px] text-paper/30 pr-3"
                      style={meta.dir === 'rtl' ? { transform: 'scaleX(-1)' } : undefined}
                      aria-hidden="true"
                    >
                      →
                    </span>
                  </Link>
                ))}
              </div>
              <p className="mt-3 text-[12px] leading-relaxed text-paper/50">{t.types.lead}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Spectrum rule */}
      <div className="flex h-[8px]" aria-hidden="true">
        {Object.keys(typeNames).map((k) => (
          <span key={k} className="flex-1" style={{ backgroundColor: TYPE_COLORS[k as QRType]?.hex ?? '#475569' }} />
        ))}
      </div>

      {/* How it works */}
      <section id="how" className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-14 scroll-mt-20">
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
          <div className="lg:col-span-4">
            <h2 className="display text-[clamp(1.4rem,2.6vw,1.9rem)]">{t.how.title}</h2>
            <p className="mt-4 text-[14px] leading-relaxed text-ink/70 max-w-sm">{t.how.lead}</p>
          </div>
          <ol className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-px bg-rule border border-rule self-start">
            {t.how.steps.map((s, i) => (
              <li key={s.title} className="bg-paper p-5">
                <div className="flex items-baseline gap-3 mb-2">
                  <span className="display text-[1.6rem] text-ink/25 tabular-nums">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <h3 className="text-[14px] font-bold">{s.title}</h3>
                </div>
                <p className="text-[13px] leading-relaxed text-ink/70">{s.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Why this one */}
      <section id="why" className="bg-acid text-ink scroll-mt-20">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-14">
          <h2 className="display text-[clamp(1.4rem,2.6vw,1.9rem)] max-w-lg">{t.why.title}</h2>
          <p className="mt-3 text-[14px] leading-relaxed text-ink/70 max-w-xl">{t.why.lead}</p>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-px bg-ink/20 border border-ink/20">
            {t.why.items.map((item) => (
              <div key={item.title} className="bg-acid p-5">
                <h3 className="text-[14px] font-bold mb-1.5">{item.title}</h3>
                <p className="text-[13px] leading-relaxed text-ink/70">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Locale-specific block */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="max-w-3xl">
          <p className="spec text-[9px] text-ink/45 mb-3">{t.local.eyebrow}</p>
          <h2 className="display text-[clamp(1.7rem,4vw,2.5rem)]">{t.local.title}</h2>
          {t.local.body.map((p, i) => (
            <p key={i} className="mt-4 text-[15px] leading-relaxed text-ink/80">
              {p}
            </p>
          ))}
          <ul className="mt-6 border-l-2 border-ink/20 pl-4 space-y-2">
            {t.local.points.map((p) => (
              <li key={p} className="text-[13.5px] leading-relaxed text-ink/70">
                {p}
              </li>
            ))}
          </ul>
          <div
            className="mt-6 flex flex-wrap items-center gap-2"
            style={meta.dir === 'rtl' ? { flexDirection: 'row-reverse', justifyContent: 'flex-end' } : undefined}
          >
            <Link
              href={wifiGuide}
              className="inline-flex items-center gap-2 h-11 px-5 bg-ink text-paper text-[13px] font-bold hover:bg-accent transition-colors"
            >
              {t.typeNames.wifi}
              <span aria-hidden="true" style={meta.dir === 'rtl' ? { transform: 'scaleX(-1)' } : undefined}>
                →
              </span>
            </Link>
            {menuGuide && (
              <Link
                href={menuGuide}
                className="inline-flex items-center gap-2 h-11 px-5 border border-ink text-ink text-[13px] font-bold hover:bg-ink hover:text-paper transition-colors"
              >
                {t.nav.menu}
                <span aria-hidden="true" style={meta.dir === 'rtl' ? { transform: 'scaleX(-1)' } : undefined}>
                  →
                </span>
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="bg-paper-2 border-y border-rule scroll-mt-20">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-14">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
            <div className="lg:col-span-4">
              <h2 className="display text-[clamp(1.7rem,4vw,2.5rem)]">{t.faq.title}</h2>
            </div>
            <div className="lg:col-span-8 border-t border-rule">
              {t.faq.items.map((f) => (
                <div key={f.q} className="py-4 border-b border-rule">
                  <h3 className="text-[15px] font-bold mb-1.5">{f.q}</h3>
                  <p className="text-[13.5px] leading-relaxed text-ink/70">{f.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="border border-ink bg-ink text-paper on-ink p-6 sm:p-9">
          <h2 className="display text-[clamp(1.6rem,3.4vw,2.2rem)] text-paper">{t.cta.title}</h2>
          <p className="mt-2 text-[14px] leading-relaxed text-paper/70 max-w-md">{t.cta.lead}</p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <Link
              href={generatorHref('wifi', withTool)}
              className="inline-flex items-center h-11 px-5 bg-acid text-ink text-[13px] font-bold hover:bg-paper transition-colors"
            >
              {t.cta.button}
            </Link>
            <span className="spec text-[9px] text-paper/40">{t.cta.hint}</span>
          </div>
        </div>
      </section>

      <div className="h-14 lg:hidden" aria-hidden="true" />
    </>
  );
}
