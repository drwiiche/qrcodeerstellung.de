/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Palette,
  Shapes,
  Image as ImageIcon,
  SquareCheck,
  Upload,
  Trash2,
  Check,
  Plus,
} from 'lucide-react';
import { QRCustomization, DotStyle, CornerStyle, FrameType } from '../types/qr';
import { validateImageFile } from '../utils/security';
import { BUILTIN_ICONS } from '../utils/qrRenderer';
import { ICON_LABELS } from '../utils/translations';
import { IroColorPicker } from './IroColorPicker';
import { processDesignImage } from '../utils/imageUpload';
import { useUi } from './i18n/UiProvider';

interface QRCustomizerProps {
  customization: QRCustomization;
  setCustomization: React.Dispatch<React.SetStateAction<QRCustomization>>;
}

// 6 Core Colors from the user's uploaded palette
export const PALETTE_COLORS = [
  { name: 'Pure Black', hex: '#000000', label: 'Tiefschwarz' },
  { name: 'Firebrick', hex: '#B31D00', label: 'Dunkelrot' },
  { name: 'Red Orange', hex: '#FF5832', label: 'Rotorange' },
  { name: 'Coral', hex: '#FF8E40', label: 'Koralle' },
  { name: 'Peach Orange', hex: '#FFB867', label: 'Pfirsich' },
  { name: 'White Smoke', hex: '#F4F4F5', label: 'Hellgrau' },
  { name: 'Pure White', hex: '#FFFFFF', label: 'Reinweiß' },
];

export const COLOR_PRESETS = [
  { name: 'Reines Schwarz', fg: '#000000', bg: '#ffffff', grad: '#18181b' },
  { name: 'Rotorange Flamme', fg: '#FF5832', bg: '#ffffff', grad: '#FF8E40' },
  { name: 'Dunkelrot & Smoke', fg: '#B31D00', bg: '#F4F4F5', grad: '#FF5832' },
  { name: 'Koralle Warmton', fg: '#FF8E40', bg: '#ffffff', grad: '#FFB867' },
  { name: 'Monochrom Invers', fg: '#ffffff', bg: '#000000', grad: '#F4F4F5' },
];

// Defined visual icon collections with 3x2 / 4x2 thumbnails
interface IconCollection {
  id: string;
  name: string;
  desc: string;
  iconKeys: string[];
}

const ICON_COLLECTIONS: IconCollection[] = [
  {
    id: 'wifi-tech',
    name: 'WLAN & Netzwerk',
    desc: 'Router, Fritz!Box, Sicherheit & Schlüssel',
    iconKeys: ['wifi', 'router', 'lock', 'key', 'shield', 'wifi'],
  },
  {
    id: 'banking-sepa',
    name: 'Finanzen & SEPA',
    desc: 'GiroCode, Euro, Bankkonto & Belege',
    iconKeys: ['sepa', 'card', 'bank', 'receipt', 'card', 'sepa'],
  },
  {
    id: 'door-delivery',
    name: 'Haustür & Paketboten',
    desc: 'Paketbox, DHL, Hermes, Klingel & Haus',
    iconKeys: ['box', 'house', 'truck', 'bell', 'pin', 'box'],
  },
  {
    id: 'contact-social',
    name: 'Kontakte & Medien',
    desc: 'Visitenkarte, WhatsApp, Telefon, Mail & Kalender',
    iconKeys: ['user', 'whatsapp', 'phone', 'mail', 'calendar', 'globe'],
  },
  {
    id: 'gastro-retail',
    name: 'Gastro & Handel',
    desc: 'Speisekarte, Café, Bewertungen & Aktionen',
    iconKeys: ['restaurant', 'coffee', 'star', 'heart', 'tag', 'star'],
  },
];

export const QRCustomizer: React.FC<QRCustomizerProps> = ({
  customization,
  setCustomization,
}) => {
  const u = useUi();
  const [activeTab, setActiveTab] = useState<'shapes' | 'colors' | 'logo' | 'frames'>('shapes');
  const [selectedCollectionId, setSelectedCollectionId] = useState<string>('wifi-tech');
  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError(null);
    const file = e.target.files?.[0];
    if (file) {
      const validation = validateImageFile(file);
      if (!validation.isValid) {
        setUploadError(validation.error || 'Ungültige Datei.');
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        setCustomization((prev) => ({
          ...prev,
          logoType: 'custom',
          customLogoUrl: reader.result as string,
          errorCorrectionLevel: 'H',
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const activeCollection =
    ICON_COLLECTIONS.find((c) => c.id === selectedCollectionId) || ICON_COLLECTIONS[0];

  return (
    <div className="qr-tool bg-paper border border-rule">
      {/* Section tabs: four numbered tabs, a 2x2 grid on phones so nothing
          ever needs horizontal scrolling. */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-rule border-b border-rule">
        {[
          { id: 'shapes' as const, n: '01', label: u['cz.tabShapes'] },
          { id: 'colors' as const, n: '02', label: u['cz.tabColors'] },
          { id: 'logo' as const, n: '03', label: u['cz.tabIcons'] },
          { id: 'frames' as const, n: '04', label: u['cz.tabFrame'] },
        ].map((tab) => {
          const on = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              aria-pressed={on}
              className={`flex items-baseline gap-2 px-3 py-2.5 text-left transition-colors ${
                on ? 'bg-ink text-paper' : 'bg-paper text-ink hover:bg-paper-2'
              }`}
            >
              <span className={`spec text-[9px] ${on ? 'text-acid' : 'text-ink/35'}`}>
                {tab.n}
              </span>
              <span className="text-[13px] font-semibold">{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="p-5 sm:p-6">
        {/* ================= SHAPES TAB ================= */}
        {activeTab === 'shapes' && (
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-2">{u['cz.pixelStyle']}</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: 'squares', label: 'Quadratisch' },
                  { id: 'rounded', label: 'Abgerundet' },
                  { id: 'dots', label: 'Punkte / Dots' },
                  { id: 'classy', label: 'Diamant' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        dotStyle: item.id as DotStyle,
                      })
                    }
                    className={`p-3.5 rounded-none border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      customization.dotStyle === item.id
                        ? 'border-black bg-paper-2 text-ink font-bold ring-2 ring-black/10'
                        : 'border-rule bg-paper hover:bg-paper-2 text-ink'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-none flex items-center justify-center bg-zinc-100 text-ink">
                      {item.id === 'squares' && <div className="w-3.5 h-3.5 bg-black" />}
                      {item.id === 'rounded' && <div className="w-3.5 h-3.5 bg-black rounded-sm" />}
                      {item.id === 'dots' && <div className="w-3.5 h-3.5 bg-black rounded-none" />}
                      {item.id === 'classy' && <div className="w-3 h-3 bg-black rotate-45" />}
                    </div>
                    <span className="text-xs">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-2">{u['cz.finder']}</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: 'square', label: 'Quadratisch' },
                  { id: 'rounded', label: 'Leicht rund' },
                  { id: 'extra-rounded', label: 'Voll rund' },
                  { id: 'leaf', label: 'Blattform' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        cornerStyle: item.id as CornerStyle,
                      })
                    }
                    className={`p-3.5 rounded-none border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      customization.cornerStyle === item.id
                        ? 'border-black bg-paper-2 text-ink font-bold ring-2 ring-black/10'
                        : 'border-rule bg-paper hover:bg-paper-2 text-ink'
                    }`}
                  >
                    <div className="w-7 h-7 flex items-center justify-center">
                      <div
                        className={`w-6 h-6 border-2 border-black p-0.5 flex items-center justify-center ${
                          item.id === 'rounded'
                            ? 'rounded-none'
                            : item.id === 'extra-rounded'
                            ? 'rounded-none'
                            : item.id === 'leaf'
                            ? 'rounded-tl-xl rounded-br-xl'
                            : 'rounded-none'
                        }`}
                      >
                        <div
                          className={`w-2 h-2 bg-black ${
                            item.id === 'extra-rounded' ? 'rounded-none' : 'rounded-none'
                          }`}
                        />
                      </div>
                    </div>
                    <span className="text-xs">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold uppercase tracking-wider text-ink/60">{u['cz.ecc']}</label>
                <span className="text-xs text-ink/60">
                  {customization.errorCorrectionLevel === 'M' ? 'Standard (15%)' : `Level ${customization.errorCorrectionLevel}`}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {(['L', 'M', 'Q', 'H'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        errorCorrectionLevel: lvl,
                      })
                    }
                    className={`py-2 rounded-none border text-xs font-bold transition cursor-pointer ${
                      customization.errorCorrectionLevel === lvl
                        ? 'bg-black text-white border-black'
                        : 'bg-paper text-ink border-rule hover:bg-paper-2'
                    }`}
                  >
                    Level {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= COLORS TAB ================= */}
        {activeTab === 'colors' && (
          <div className="space-y-6">
            {/* Custom Palette Swatches */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-2">{u['cz.palette']}</label>
              <div className="flex flex-wrap items-center gap-2">
                {PALETTE_COLORS.map((c) => (
                  <button
                    key={c.hex}
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        foregroundColor: c.hex,
                      })
                    }
                    className="flex items-center gap-2 px-3 py-1.5 rounded-none border border-rule bg-paper hover:bg-paper-2 transition cursor-pointer text-xs"
                    title={c.label}
                  >
                    <span
                      className="w-4 h-4 rounded-none border border-black/10 flex-shrink-0"
                      style={{ backgroundColor: c.hex }}
                    />
                    <span className="font-semibold text-ink">{c.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Presets */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-2">{u['cz.colorPresets']}</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {COLOR_PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        foregroundColor: p.fg,
                        backgroundColor: p.bg,
                        gradientColor: p.grad,
                      })
                    }
                    className="p-3 rounded-none border border-rule hover:border-black/30 bg-paper text-left transition cursor-pointer flex items-center justify-between"
                  >
                    <div>
                      <span className="text-xs font-bold text-ink block">{p.name}</span>
                      <span className="text-[10px] text-ink/60 font-mono uppercase">{p.fg}</span>
                    </div>
                    <div className="flex -space-x-1">
                      <span
                        className="w-5 h-5 rounded-none border border-rule"
                        style={{ backgroundColor: p.fg }}
                      />
                      <span
                        className="w-5 h-5 rounded-none border border-rule"
                        style={{ backgroundColor: p.bg }}
                      />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Manual Color Pickers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-rule">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['cz.fg']}</label>
                <div className="flex items-center gap-3 flex-wrap">
                  <IroColorPicker
                    value={customization.foregroundColor}
                    onChange={(hex) => setCustomization({ ...customization, foregroundColor: hex })}
                    label="Rad + Helligkeit"
                  />
                  <input
                    type="text"
                    value={customization.foregroundColor}
                    onChange={(e) =>
                      setCustomization({ ...customization, foregroundColor: e.target.value })
                    }
                    className="w-28 px-3 py-2 rounded-none border border-rule text-xs font-mono uppercase bg-paper"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['cz.bg']}</label>
                <div className="flex items-center gap-3 flex-wrap">
                  <IroColorPicker
                    value={customization.backgroundColor === 'transparent' ? '#ffffff' : customization.backgroundColor}
                    onChange={(hex) => setCustomization({ ...customization, backgroundColor: hex })}
                    label="Rad + Helligkeit"
                  />
                  <input
                    type="text"
                    value={customization.backgroundColor}
                    onChange={(e) =>
                      setCustomization({ ...customization, backgroundColor: e.target.value })
                    }
                    className="w-28 px-3 py-2 rounded-none border border-rule text-xs font-mono uppercase bg-paper"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        backgroundColor:
                          customization.backgroundColor === 'transparent' ? '#ffffff' : 'transparent',
                      })
                    }
                    className="px-3 py-2 rounded-none border border-rule text-xs font-medium text-ink hover:bg-paper-2 transition cursor-pointer"
                  >
                    {customization.backgroundColor === 'transparent' ? 'Deckend' : 'Transparent'}
                  </button>
                </div>
              </div>
            </div>

            {/* ---------- Design: Hintergrundbild & Rahmenbild ---------- */}
            <div className="space-y-5 pt-4 border-t border-rule">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-2">{u['cz.bgImage']}</label>
                <div className="flex flex-wrap items-center gap-3">
                  {customization.backgroundImageUrl ? (
                    <img
                      src={customization.backgroundImageUrl}
                      alt="Vorschau Hintergrundbild"
                      className="w-14 h-14 rounded-none border border-rule object-cover"
                    />
                  ) : (
                    <span className="w-14 h-14 rounded-none border border-dashed border-rule flex items-center justify-center text-[10px] text-ink/60">{u['cz.none']}</span>
                  )}
                  <label className="inline-flex items-center gap-2 px-4 py-2 rounded-none bg-paper hover:bg-paper-2 text-ink text-xs font-semibold border border-rule transition cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    {customization.backgroundImageUrl ? 'Ersetzen' : 'Bild hochladen'}
                    <input
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        e.target.value = '';
                        if (!file) return;
                        setUploadError(null);
                        try {
                          const img = await processDesignImage(file);
                          setCustomization({
                            ...customization,
                            backgroundImageUrl: img.dataUrl,
                            bgImageLuminance: img.luminance,
                            backgroundImageOpacity: customization.backgroundImageOpacity ?? 0.35,
                          });
                        } catch (err) {
                          setUploadError(err instanceof Error ? err.message : 'Upload fehlgeschlagen.');
                        }
                      }}
                    />
                  </label>
                  {customization.backgroundImageUrl && (
                    <button
                      type="button"
                      onClick={() =>
                        setCustomization({
                          ...customization,
                          backgroundImageUrl: undefined,
                          bgImageLuminance: undefined,
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-none bg-paper hover:bg-red-50 text-[#B31D00] text-xs font-semibold border border-rule transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />{u['pv.remove']}</button>
                  )}
                </div>

                {customization.backgroundImageUrl && (
                  <div className="mt-3">
                    <label className="flex items-center justify-between text-[11px] font-semibold text-ink/60 mb-1.5">
                      <span>{u['cz.opacity']}</span>
                      <span className="font-mono">
                        {Math.round((customization.backgroundImageOpacity ?? 0.35) * 100)} %
                      </span>
                    </label>
                    <input
                      type="range"
                      min={15}
                      max={60}
                      step={5}
                      value={Math.round((customization.backgroundImageOpacity ?? 0.35) * 100)}
                      onChange={(e) =>
                        setCustomization({
                          ...customization,
                          backgroundImageOpacity: Number(e.target.value) / 100,
                        })
                      }
                      className="w-full accent-black cursor-pointer"
                    />
                  </div>
                )}

                <p className="mt-2 text-[11px] text-ink/60 leading-relaxed">{u['cz.imageOnly']}<strong>hinter den Modulen</strong>; die Ruhezone bleibt frei.
                  Die Scan-Prüfung weiter unten warnt automatisch, wenn der Hintergrund zu dunkel
                  oder die Deckkraft zu hoch wird – maximal 60 % sind technisch erlaubt.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-2">{u['cz.frameImage']}</label>
                <div className="flex flex-wrap items-center gap-3">
                  {customization.borderImageUrl ? (
                    <img
                      src={customization.borderImageUrl}
                      alt="Vorschau Rahmenbild"
                      className="w-14 h-14 rounded-none border border-rule object-cover"
                    />
                  ) : (
                    <span className="w-14 h-14 rounded-none border border-dashed border-rule flex items-center justify-center text-[10px] text-ink/60">{u['cz.none']}</span>
                  )}
                  <label className="inline-flex items-center gap-2 px-4 py-2 rounded-none bg-paper hover:bg-paper-2 text-ink text-xs font-semibold border border-rule transition cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    {customization.borderImageUrl ? 'Ersetzen' : 'Bild hochladen'}
                    <input
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        e.target.value = '';
                        if (!file) return;
                        setUploadError(null);
                        try {
                          const img = await processDesignImage(file);
                          setCustomization({ ...customization, borderImageUrl: img.dataUrl });
                        } catch (err) {
                          setUploadError(err instanceof Error ? err.message : 'Upload fehlgeschlagen.');
                        }
                      }}
                    />
                  </label>
                  {customization.borderImageUrl && (
                    <button
                      type="button"
                      onClick={() => setCustomization({ ...customization, borderImageUrl: undefined })}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-none bg-paper hover:bg-red-50 text-[#B31D00] text-xs font-semibold border border-rule transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />{u['pv.remove']}</button>
                  )}
                </div>
                <p className="mt-2 text-[11px] text-ink/60 leading-relaxed">{u['cz.frameImageHint']}<strong>dekorativen Rand außerhalb</strong> der Ruhezone –
                  die Scanfläche selbst bleibt einfarbig und dadurch zuverlässig lesbar.
                </p>
              </div>

              {uploadError && (
                <p className="text-xs font-semibold text-[#B31D00] bg-red-50 border border-red-200 rounded-none p-3" role="alert">
                  {uploadError}
                </p>
              )}
            </div>
          </div>
        )}

        {/* ================= LOGO & ICONS TAB (Grid of Visible Collections with 3x2 / 4x2 thumbnails) ================= */}
        {activeTab === 'logo' && (
          <div className="space-y-6">
            {/* Top controls: Reset icon & Upload custom */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-rule">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setCustomization({
                      ...customization,
                      logoType: 'none',
                      customLogoUrl: undefined,
                    })
                  }
                  className={`px-4 py-2 rounded-none text-xs font-bold transition cursor-pointer border ${
                    customization.logoType === 'none' && !customization.customLogoUrl
                      ? 'bg-black text-white border-black'
                      : 'bg-paper text-ink border-rule hover:bg-paper-2'
                  }`}
                >{u['cz.noIcon']}</button>
                <span className="text-xs text-ink/60">
                  {customization.logoType !== 'none' || customization.customLogoUrl
                    ? 'Aktiviert: ' + (customization.customLogoUrl ? 'Eigenes Bild' : ICON_LABELS[customization.logoType] || customization.logoType)
                    : 'Kein Icon im Zentrum'}
                </span>
              </div>

              {/* Quick Size Slider */}
              <div className="flex items-center gap-2 text-xs text-ink/60">
                <span className="font-semibold">{u['cz.iconSize']}</span>
                <input
                  type="range"
                  min={0.16}
                  max={0.28}
                  step={0.02}
                  value={customization.logoSize}
                  onChange={(e) =>
                    setCustomization({
                      ...customization,
                      logoSize: parseFloat(e.target.value),
                    })
                  }
                  className="w-24 accent-[#FF5832] cursor-pointer"
                />
              </div>
            </div>

            {/* Grid of Visible Collections with 3x2 Thumbnail Previews */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-xs font-bold uppercase tracking-wider text-ink/60">{u['cz.iconBrowse']}</label>
                <span className="text-xs text-ink/60">{u['cz.iconPick']}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {ICON_COLLECTIONS.map((col) => {
                  const isSelected = selectedCollectionId === col.id;
                  return (
                    <button
                      key={col.id}
                      type="button"
                      onClick={() => setSelectedCollectionId(col.id)}
                      className={`p-3.5 rounded-none border text-left transition cursor-pointer flex flex-col justify-between min-h-[176px] ${
                        isSelected
                          ? 'border-black bg-paper-2 ring-2 ring-black/10'
                          : 'border-rule bg-paper hover:bg-paper-2'
                      }`}
                    >
                      {/* 3x2 Mini-Grid Thumbnail */}
                      <div className="w-full bg-paper rounded-[10px] p-2.5 border border-rule/80 mb-2.5">
                        <div className="grid grid-cols-3 gap-2 items-center justify-items-center">
                          {col.iconKeys.map((k, i) => (
                            <div
                              key={i}
                              className="w-5 h-5 flex items-center justify-center text-ink"
                              dangerouslySetInnerHTML={{
                                __html: BUILTIN_ICONS[k] || BUILTIN_ICONS.wifi,
                              }}
                            />
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-xs sm:text-sm text-ink tracking-tight">
                            {col.name}
                          </h4>
                          {isSelected && (
                            <span className="w-2 h-2 rounded-none bg-accent" />
                          )}
                        </div>
                        <p className="text-[11px] text-ink/60 line-clamp-1 mt-0.5">
                          {col.desc}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active Collection Icon Selector */}
            <div className="p-4 rounded-none bg-paper-2 border border-rule">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-ink">
                    Icons in „{activeCollection.name}“:
                  </h4>
                  <p className="text-[11px] text-ink/60">{u['cz.iconClick']}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                {Array.from(new Set(activeCollection.iconKeys)).map((iconKey) => {
                  const isCurrentIcon = customization.logoType === iconKey;
                  return (
                    <button
                      key={iconKey}
                      type="button"
                      onClick={() =>
                        setCustomization({
                          ...customization,
                          logoType: iconKey,
                          customLogoUrl: undefined,
                          errorCorrectionLevel: 'H',
                        })
                      }
                      className={`p-3 rounded-none border flex flex-col items-center justify-center gap-1.5 transition cursor-pointer ${
                        isCurrentIcon
                          ? 'border-transparent bg-black text-white'
                          : 'border-rule bg-paper hover:bg-paper-2 text-ink'
                      }`}
                    >
                      <div
                        className="w-6 h-6 flex items-center justify-center"
                        dangerouslySetInnerHTML={{
                          __html: BUILTIN_ICONS[iconKey] || BUILTIN_ICONS.wifi,
                        }}
                      />
                      <span className="text-[10px] font-semibold uppercase tracking-wider">
                        {ICON_LABELS[iconKey] || iconKey}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Logo Upload Card */}
            <div className="border border-dashed border-rule rounded-none p-5 text-center bg-paper">
              <label className="block text-xs font-bold uppercase tracking-wider text-ink mb-1">{u['cz.logo']}</label>
              <p className="text-xs text-ink/60 mb-3">{u['cz.logoHint']}</p>

              {customization.customLogoUrl ? (
                <div className="flex items-center justify-center gap-3">
                  <img
                    src={customization.customLogoUrl}
                    alt="Vorschau des benutzerdefinierten QR-Code Logos"
                    className="w-12 h-12 object-contain rounded-none border border-rule bg-paper p-1"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        customLogoUrl: undefined,
                        logoType: 'none',
                      })
                    }
                    className="px-4 py-2 rounded-none bg-zinc-100 hover:bg-paper-2 text-ink text-xs font-semibold transition cursor-pointer"
                  >{u['pv.remove']}</button>
                </div>
              ) : (
                <label className="inline-flex items-center gap-2 px-5 py-2.5 rounded-none bg-black hover:bg-paper-2 text-xs font-bold text-white cursor-pointer transition">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{u['cz.logoPick']}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              )}

              {uploadError && (
                <p className="text-xs text-red-600 mt-2 font-medium">{uploadError}</p>
              )}
            </div>
          </div>
        )}

        {/* ================= FRAMES TAB ================= */}
        {activeTab === 'frames' && (
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-2">{u['cz.frameStyle']}</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'none', label: 'Ohne Rahmen' },
                  { id: 'bottom-bar', label: 'Banner unten' },
                  { id: 'top-bar', label: 'Banner oben' },
                  { id: 'badge-card', label: 'Kompakte Karte' },
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() =>
                      setCustomization({
                        ...customization,
                        frameType: f.id as FrameType,
                      })
                    }
                    className={`p-3 rounded-none border text-xs font-semibold transition cursor-pointer ${
                      customization.frameType === f.id
                        ? 'border-black bg-paper-2 text-ink font-bold'
                        : 'border-rule bg-paper hover:bg-paper-2 text-ink'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {customization.frameType !== 'none' && (
              <div className="space-y-4 pt-3 border-t border-rule">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['cz.frameText']}</label>
                  <input
                    type="text"
                    value={customization.frameText}
                    onChange={(e) =>
                      setCustomization({ ...customization, frameText: e.target.value })
                    }
                    placeholder="z. B. HIER SCANNEN oder WLAN GAST"
                    className="w-full px-4 py-2.5 rounded-none border border-rule text-xs text-ink uppercase tracking-wider bg-paper focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['cz.frameColor']}</label>
                    <div className="flex items-center gap-3 flex-wrap">
                      <IroColorPicker
                        width={96}
                        value={customization.frameColor}
                        onChange={(hex) => setCustomization({ ...customization, frameColor: hex })}
                      />
                      <input
                        type="text"
                        value={customization.frameColor}
                        onChange={(e) =>
                          setCustomization({ ...customization, frameColor: e.target.value })
                        }
                        className="w-24 px-3 py-1.5 rounded-none border border-rule text-xs font-mono uppercase bg-paper"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['cz.textColor']}</label>
                    <div className="flex items-center gap-3 flex-wrap">
                      <IroColorPicker
                        width={96}
                        value={customization.frameTextColor}
                        onChange={(hex) => setCustomization({ ...customization, frameTextColor: hex })}
                      />
                      <input
                        type="text"
                        value={customization.frameTextColor}
                        onChange={(e) =>
                          setCustomization({ ...customization, frameTextColor: e.target.value })
                        }
                        className="w-24 px-3 py-1.5 rounded-none border border-rule text-xs font-mono uppercase bg-paper"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
