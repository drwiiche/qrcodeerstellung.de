'use client';

/**
 * SiteShell — the client boundary for all public pages.
 * Owns every piece of application state (QR data, customization, history,
 * toasts, modals) and exposes it through SiteContext so individual pages
 * (home, danke, impressum, ...) can consume it without prop drilling.
 */
import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useMemo,
} from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { Navbar } from './Navbar';
import { UiProvider } from './i18n/UiProvider';
import { uiDe } from '../lib/i18n/ui/de';
import { CookieBanner } from './CookieBanner';
import { ErrorBoundary } from './ErrorBoundary';
import { ToastContainer, ToastMessage } from './Toast';
import { HistoryDrawer, HistoryItem } from './HistoryDrawer';
import { ScanTestModal } from './ScanTestModal';
import { PrintableCard } from './PrintableCard';
import { AdSlot } from './AdSlot';
import { AnalyticsScripts } from './AnalyticsScripts';
import { QrCode, Download, History } from 'lucide-react';
import { trackEvent } from '../utils/analytics';
import { QRType, QRCustomization, URLData, WifiData, SepaData, VCardData, DeliveryData, TextData, EmailData, WhatsappData, SmsData, StandortData, PhoneData, EventData } from '../types/qr';
import { formatWifiPayload } from '../utils/wifi';
import { formatSepaPayload } from '../utils/sepa';
import { formatVCardPayload } from '../utils/vcard';
import { formatDeliveryPayload } from '../utils/delivery';
import { formatEventPayload } from '../utils/event';
import { formatAdvancedPayload } from '../utils/payloads';
import { ADVANCED_DEFAULTS, isAdvancedType } from '../lib/qrTypeSchema';
import { renderQRCodeToCanvas } from '../utils/qrRenderer';
import { Language, TRANSLATIONS } from '../utils/translations';

const STORAGE_KEY = 'qr_deutschland_history_v1';

export interface SiteContextValue {
  lang: Language;
  navigate: (route: string) => void;
  scrollToSeo: () => void;
  scrollToForm: () => void;
  // QR type + payload
  type: QRType;
  handleSelectType: (t: QRType) => void;
  payload: string;
  qrImageUrl: string;
  isRendering: boolean;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  // form data
  urlData: URLData; setUrlData: React.Dispatch<React.SetStateAction<URLData>>;
  wifiData: WifiData; setWifiData: React.Dispatch<React.SetStateAction<WifiData>>;
  sepaData: SepaData; setSepaData: React.Dispatch<React.SetStateAction<SepaData>>;
  vcardData: VCardData; setVcardData: React.Dispatch<React.SetStateAction<VCardData>>;
  deliveryData: DeliveryData; setDeliveryData: React.Dispatch<React.SetStateAction<DeliveryData>>;
  textData: TextData; setTextData: React.Dispatch<React.SetStateAction<TextData>>;
  emailData: EmailData; setEmailData: React.Dispatch<React.SetStateAction<EmailData>>;
  whatsappData: WhatsappData; setWhatsappData: React.Dispatch<React.SetStateAction<WhatsappData>>;
  smsData: SmsData; setSmsData: React.Dispatch<React.SetStateAction<SmsData>>;
  standortData: StandortData; setStandortData: React.Dispatch<React.SetStateAction<StandortData>>;
  /** Flat value map shared by every schema-driven type. */
  advanced: Record<string, string>; setAdvanced: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  phoneData: PhoneData; setPhoneData: React.Dispatch<React.SetStateAction<PhoneData>>;
  eventData: EventData; setEventData: React.Dispatch<React.SetStateAction<EventData>>;
  // customization
  customization: QRCustomization;
  setCustomization: React.Dispatch<React.SetStateAction<QRCustomization>>;
  /** Downloads the current code as PNG at the configured export size. */
  downloadPng: () => void;
  // history
  history: HistoryItem[];
  handleSaveToHistory: () => void;
  handleRestoreHistory: (item: HistoryItem) => void;
  handleClearHistory: () => void;
  handleDeleteOneHistory: (id: string) => void;
  // overlays
  isScanTestOpen: boolean; openScanTest: () => void; closeScanTest: () => void;
  isHistoryOpen: boolean; openHistory: () => void; closeHistory: () => void;
  // toasts
  addToast: (text: string, type?: 'success' | 'error' | 'info') => void;
  // templates
  handleApplyTemplate: (
    t: QRType,
    data: Record<string, any>,
    custom?: Partial<QRCustomization>
  ) => void;
}

const SiteContext = createContext<SiteContextValue | null>(null);

export function useSite(): SiteContextValue {
  const ctx = useContext(SiteContext);
  if (!ctx) throw new Error('useSite must be used within SiteShell');
  return ctx;
}

export function SiteShell({
  children,
  ui,
  chrome = true,
}: {
  children: React.ReactNode;
  /** Translated generator strings. Absent means German, which is the default. */
  ui?: import('../lib/i18n/ui/de').UiStrings;
  /**
   * The German tree renders its own Navbar, ad slot and footer. A locale page
   * already has translated chrome in its layout, so it asks for the state
   * provider and the modals without a second header.
   */
  chrome?: boolean;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [lang] = useState<Language>('de');
  const [type, setType] = useState<QRType>('wifi');
  const [isScanTestOpen, setIsScanTestOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isRendering, setIsRendering] = useState(false);
  const [qrImageUrl, setQrImageUrl] = useState<string>('');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // ---- navigation ----------------------------------------------------------
  const navigate = (route: string) => {
    const targetPath = route === 'home' ? '/' : `/${route}`;
    if (pathname !== targetPath) {
      router.push(targetPath);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSeo = () => {
    const scroll = () =>
      document.getElementById('anleitung')?.scrollIntoView({ behavior: 'smooth' });
    if (pathname !== '/') {
      router.push('/');
      setTimeout(scroll, 300);
    } else {
      scroll();
    }
  };

  const scrollToForm = () => {
    const el = document.getElementById('qr-form-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else if (pathname !== '/') {
      router.push('/');
    }
  };

  // ---- page view tracking (client-side) ------------------------------------
  useEffect(() => {
    trackEvent('page_view', { route: pathname });
  }, [pathname]);

  // ---- history (loaded after mount to avoid SSR/hydration mismatch) --------
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyHydrated, setHistoryHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setHistory(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    setHistoryHydrated(true);
  }, []);

  useEffect(() => {
    if (!historyHydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch (e) {
      console.warn('Could not persist history to localStorage', e);
    }
  }, [history, historyHydrated]);

  const addToast = (text: string, toastType: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, text, type: toastType }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // ---- form states ---------------------------------------------------------
  const [urlData, setUrlData] = useState<URLData>({ url: 'https://the-qrcode-generator.com' });
  const [wifiData, setWifiData] = useState<WifiData>({
    ssid: 'FRITZ!Box Gastzugang',
    password: 'wlan-passwort-zuhause-2026',
    encryption: 'WPA',
    hidden: false,
  });
  const [sepaData, setSepaData] = useState<SepaData>({
    name: 'Hausverwaltung Berlin GmbH',
    iban: 'DE89 3705 0198 0000 0123 45',
    bic: '',
    amount: '450.00',
    purpose: 'Miete & Nebenkosten Oktober',
    reference: '',
  });
  const [vcardData, setVcardData] = useState<VCardData>({
    firstName: 'Maximilian',
    lastName: 'Mustermann',
    organization: 'Handwerk & Beratung',
    title: 'Geschäftsführer',
    phone: '+49 30 12345678',
    mobile: '+49 170 1234567',
    email: 'max@mustermann-service.de',
    street: 'Friedrichstraße 123',
    zip: '10117',
    city: 'Berlin',
    country: 'Deutschland',
    website: 'https://mustermann-service.de',
    note: 'Kundenberatung vor Ort',
  });
  const [deliveryData, setDeliveryData] = useState<DeliveryData>({
    recipientName: 'Familie Weber (3. OG rechts)',
    deliveryLocation: 'Hinter den Blumenkübeln auf der Terrasse abstellen',
    parcelServices: ['DHL', 'Hermes', 'Amazon', 'DPD'],
    phone: '+49 170 1234567',
    specialInstructions: 'Bitte 1x kurz klingeln und abstellen',
  });
  const [textData, setTextData] = useState<TextData>({
    text: 'Herzlich willkommen in unserer Ferienwohnung in Deutschland!',
  });
  const [emailData, setEmailData] = useState<EmailData>({
    email: 'kontakt@ferienwohnung-schwarzwald.de',
    subject: 'Buchungsanfrage',
    body: 'Guten Tag, wir möchten eine Buchung für den Sommer anfragen...',
  });
  const [whatsappData, setWhatsappData] = useState<WhatsappData>({
    phoneNumber: '+491701234567',
    message: 'Hallo! Wir haben eine Frage zur Ferienwohnung.',
  });
  const [smsData, setSmsData] = useState<SmsData>({
    phoneNumber: '+49 170 1234567',
    message: 'Hallo, ich interessiere mich für Ihr Angebot.',
  });
  /*
   * One state object for every schema-driven type. Switching between mecard and
   * pix keeps the other type's values, which is the behaviour the twelve
   * original types already had with their individual states.
   */
  const [advanced, setAdvanced] = useState<Record<string, string>>({
    ...ADVANCED_DEFAULTS.mecard,
    ...ADVANCED_DEFAULTS.facebook,
    ...ADVANCED_DEFAULTS.twitter,
    ...ADVANCED_DEFAULTS.youtube,
    ...ADVANCED_DEFAULTS.instagram,
    ...ADVANCED_DEFAULTS.bitcoin,
    ...ADVANCED_DEFAULTS.paypal,
    ...ADVANCED_DEFAULTS.pix,
  });

  const [standortData, setStandortData] = useState<StandortData>({
    latitude: '52.520008',
    longitude: '13.404954',
    label: 'Treffpunkt am Haupteingang',
  });
  const [phoneData, setPhoneData] = useState<PhoneData>({ phoneNumber: '+493012345678' });
  const [eventData, setEventData] = useState<EventData>({
    title: 'Eigentümerversammlung & Sommerfest',
    location: 'Gemeinschaftsraum, EG links',
    startDate: '2026-07-15',
    startTime: '18:00',
    endDate: '2026-07-15',
    endTime: '21:00',
    description: 'Jährliche Versammlung der Hausgemeinschaft.',
  });

  // ---- customization -------------------------------------------------------
  const [customization, setCustomization] = useState<QRCustomization>({
    foregroundColor: '#0f172a',
    backgroundColor: '#ffffff',
    useGradient: false,
    gradientColor: '#2563eb',
    gradientType: 'linear',
    gradientAngle: 45,
    dotStyle: 'rounded',
    cornerStyle: 'extra-rounded',
    eyeBorderColor: '#0f172a',
    eyeCenterColor: '#0f172a',
    errorCorrectionLevel: 'M',
    logoType: 'none',
    logoSize: 0.22,
    frameType: 'none',
    frameColor: '#2563eb',
    frameText: 'HIER SCANNEN',
    frameTextColor: '#ffffff',
    size: 1024,
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // ---- payload -------------------------------------------------------------
  const payload = useMemo(() => {
    switch (type) {
      case 'url':
        return urlData.url || 'https://qr-generator-deutschland.de';
      case 'wifi':
        return formatWifiPayload(wifiData);
      case 'sepa':
        return formatSepaPayload(sepaData);
      case 'vcard':
        return formatVCardPayload(vcardData);
      case 'delivery':
        return formatDeliveryPayload(deliveryData);
      case 'text':
        return textData.text || 'QR-Code Text';
      case 'email':
        return `mailto:${emailData.email}?subject=${encodeURIComponent(emailData.subject)}&body=${encodeURIComponent(emailData.body)}`;
      case 'whatsapp': {
        const cleanPhone = whatsappData.phoneNumber.replace(/[^0-9]/g, '');
        return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(whatsappData.message)}`;
      }
      case 'sms': {
        const smsPhone = smsData.phoneNumber.replace(/[^0-9+]/g, '');
        const body = smsData.message ? `?body=${encodeURIComponent(smsData.message)}` : '';
        return `sms:${smsPhone}${body}`;
      }
      case 'standort': {
        const lat = parseFloat(standortData.latitude.replace(',', '.'));
        const lng = parseFloat(standortData.longitude.replace(',', '.'));
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return 'https://www.google.com/maps';
        return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
      }
      case 'phone':
        return `tel:${phoneData.phoneNumber}`;
      case 'mecard':
      case 'facebook':
      case 'twitter':
      case 'youtube':
      case 'instagram':
      case 'bitcoin':
      case 'paypal':
      case 'pix': {
        const built = formatAdvancedPayload(type, advanced);
        return built || 'https://qr-generator-deutschland.de';
      }
      case 'event':
        /* Moved out of this switch: the inline version appended a literal "Z"
           to local times, which placed every German event one or two hours
           late in the calendar. See utils/event.ts. */
        return formatEventPayload(eventData);
      default:
        return 'https://qr-generator-deutschland.de';
    }
  }, [type, urlData, wifiData, sepaData, vcardData, deliveryData, textData, emailData, whatsappData, smsData, standortData, phoneData, eventData, advanced]);

  const handleSelectType = (newType: QRType) => {
    setType(newType);
    trackEvent('qr_type_change', { type: newType });
  };

  // ---- QR rendering --------------------------------------------------------
  // The canvas lives inside the preview card, which can mount a commit after
  // this provider. A plain effect therefore found `canvasRef.current === null`
  // on first load and the code was never drawn, so we retry across animation
  // frames until the element exists, then render into it.
  useEffect(() => {
    let cancelled = false;
    let frame = 0;
    let attempts = 0;

    const render = async () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        if (!cancelled && attempts++ < 120) {
          frame = requestAnimationFrame(render);
        }
        return;
      }

      setIsRendering(true);
      try {
        await renderQRCodeToCanvas(canvas, payload, customization, 800);
        if (!cancelled) {
          setQrImageUrl(canvas.toDataURL('image/png'));
          trackEvent('qr_generated', { type });
        }
      } catch (err) {
        console.error('[qr] render failed', err);
        if (!cancelled) setQrImageUrl('');
      } finally {
        if (!cancelled) setIsRendering(false);
      }
    };

    render();

    return () => {
      cancelled = true;
      if (frame) cancelAnimationFrame(frame);
    };
  }, [payload, customization, type]);

  // ---- export -------------------------------------------------------------
  // Shared so the desktop preview card and the mobile action bar trigger the
  // same export instead of one of them being decorative.
  const downloadPng = () => {
    const canvas = canvasRef.current;
    if (!canvas) {
      addToast(T['tst.drawing'], 'info');
      return;
    }
    try {
      const link = document.createElement('a');
      link.download = `qr-code-${type}-${Date.now()}.png`;
      link.href = canvas.toDataURL('image/png', 1.0);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      addToast(T['tst.pngOk'].replace('{size}', String(customization.size)));
      trackEvent('qr_download_png', { size: customization.size, source: 'mobile-bar' });
    } catch {
      addToast(T['tst.pngBlocked'], 'error');
    }
  };

  // ---- history actions -----------------------------------------------------
  const handleSaveToHistory = () => {
    let title = 'QR-Code';
    let dataToSave: Record<string, any> = {};

    if (type === 'wifi') {
      title = `WLAN: ${wifiData.ssid || 'Gastzugang'}`;
      dataToSave = wifiData;
    } else if (type === 'sepa') {
      title = `SEPA: ${sepaData.name || 'Überweisung'}${sepaData.amount ? ` (${sepaData.amount} €)` : ''}`;
      dataToSave = sepaData;
    } else if (type === 'delivery') {
      title = `Paket: ${deliveryData.recipientName || 'Haustür'}`;
      dataToSave = deliveryData;
    } else if (type === 'vcard') {
      title = `Kontakt: ${vcardData.firstName} ${vcardData.lastName}`;
      dataToSave = vcardData;
    } else if (type === 'url') {
      title = `Link: ${urlData.url.substring(0, 32)}`;
      dataToSave = urlData;
    } else {
      title = `${type.toUpperCase()} QR-Code`;
      dataToSave = textData;
    }

    const newItem: HistoryItem = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      title,
      type,
      previewUrl: qrImageUrl,
      data: dataToSave,
      customization: { ...customization },
    };

    setHistory((prev) => [newItem, ...prev.filter((i) => i.title !== title)].slice(0, 12));
    addToast(T['tst.historySaved']);
  };

  const handleRestoreHistory = (item: HistoryItem) => {
    setType(item.type);
    if (item.type === 'wifi') setWifiData(item.data as WifiData);
    else if (item.type === 'sepa') setSepaData(item.data as SepaData);
    else if (item.type === 'delivery') setDeliveryData(item.data as DeliveryData);
    else if (item.type === 'vcard') setVcardData(item.data as VCardData);
    else if (item.type === 'url') setUrlData(item.data as URLData);
    else if (item.type === 'text') setTextData(item.data as TextData);
    else if (item.type === 'sms') setSmsData(item.data as SmsData);
    else if (item.type === 'standort') setStandortData(item.data as StandortData);

    if (item.customization) setCustomization(item.customization);
    addToast(`${T['tst.historyLoaded']} ${item.title}`);
  };

  const handleClearHistory = () => {
    setHistory([]);
    addToast(T['tst.historyCleared'], 'info');
  };

  const handleDeleteOneHistory = (id: string) => {
    setHistory((prev) => prev.filter((i) => i.id !== id));
  };

  // ---- template application ------------------------------------------------
  const handleApplyTemplate = (
    tmplType: QRType,
    data: Record<string, any>,
    custom?: Partial<QRCustomization>
  ) => {
    setType(tmplType);
    if (tmplType === 'wifi') setWifiData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'sepa') setSepaData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'delivery') setDeliveryData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'vcard') setVcardData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'url') setUrlData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'text') setTextData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'whatsapp') setWhatsappData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'sms') setSmsData((prev) => ({ ...prev, ...data }));
    else if (tmplType === 'standort') setStandortData((prev) => ({ ...prev, ...data }));
    else if (isAdvancedType(tmplType)) setAdvanced((prev) => ({ ...prev, ...data }));

    if (custom) setCustomization((prev) => ({ ...prev, ...custom }));
    trackEvent('template_applied', { type: tmplType });
    addToast(T['tst.templateLoaded']);
    scrollToForm();
  };

  const value: SiteContextValue = {
    lang,
    navigate,
    scrollToSeo,
    scrollToForm,
    type,
    handleSelectType,
    payload,
    qrImageUrl,
    isRendering,
    canvasRef,
    urlData, setUrlData,
    wifiData, setWifiData,
    sepaData, setSepaData,
    vcardData, setVcardData,
    deliveryData, setDeliveryData,
    textData, setTextData,
    emailData, setEmailData,
    whatsappData, setWhatsappData,
    smsData, setSmsData,
    standortData, setStandortData,
    advanced, setAdvanced,
    phoneData, setPhoneData,
    eventData, setEventData,
    customization,
    setCustomization,
    downloadPng,
    history,
    handleSaveToHistory,
    handleRestoreHistory,
    handleClearHistory,
    handleDeleteOneHistory,
    isScanTestOpen,
    openScanTest: () => setIsScanTestOpen(true),
    closeScanTest: () => setIsScanTestOpen(false),
    isHistoryOpen,
    openHistory: () => setIsHistoryOpen(true),
    closeHistory: () => setIsHistoryOpen(false),
    addToast,
    handleApplyTemplate,
  };

  const t = TRANSLATIONS[lang];
  /* Toasts must speak the same language as the instrument. `chrome` pages (the
     German tree) pass no ui and get German, which is what they want. */
  const T = ui ?? uiDe;

  return (
    <UiProvider strings={ui}>
    <SiteContext.Provider value={value}>
      <ErrorBoundary>
        <div className="min-h-screen bg-paper flex flex-col font-sans">
          {chrome && (
          <Navbar
            onScrollToSeo={scrollToSeo}
            onOpenHistory={() => setIsHistoryOpen(true)}
            historyCount={history.length}
            onNavigateHome={() => navigate('home')}
            onSelectQRType={(t) => {
              handleSelectType(t);
              navigate('home');
              setTimeout(() => scrollToForm(), 120);
            }}
          />
          )}

          <main className="flex-1 w-full">{children}</main>

          {chrome && <AdSlot position="above-footer" />}

          {/* Footer: ink band, only destinations that exist */}
          {chrome && (<footer className="bg-ink text-paper on-ink">
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-14">
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-x-6 gap-y-10">
                <div className="col-span-2">
                  <div className="flex items-center gap-2.5 mb-3">
                    <span className="w-7 h-7 bg-accent grid place-items-center">
                      <QrCode className="w-4 h-4 text-ink" strokeWidth={2.5} />
                    </span>
                    <span className="text-[15px] font-bold tracking-tight">QR-Generator Deutschland</span>
                  </div>
                  <p className="text-[13px] leading-relaxed text-paper/60 max-w-xs">
                    Ein kostenloses Werkzeug für QR-Codes, die im Alltag wirklich gebraucht
                    werden: Gäste-WLAN, Überweisungen, Paketabstellorte, Visitenkarten.
                    Die Codes werden im Browser erzeugt.
                  </p>
                  <button
                    type="button"
                    onClick={() => window.dispatchEvent(new CustomEvent('open_cookie_settings'))}
                    className="mt-5 inline-flex items-center gap-2 text-[12px] font-medium text-acid hover:text-paper border-b border-acid/50 hover:border-paper pb-0.5 transition-colors"
                  >
                    Cookie-Einstellungen
                  </button>
                </div>

                <div>
                  <h2 className="text-[12px] font-bold mb-3 text-paper">Beliebte Typen</h2>
                  <ul className="space-y-2 text-[13px] text-paper/60">
                    {[
                      ['wifi', 'WLAN für Fritz!Box'],
                      ['sepa', 'SEPA GiroCode'],
                      ['delivery', 'Paket-Abstellort'],
                      ['vcard', 'Visitenkarte (vCard)'],
                    ].map(([id, label]) => (
                      <li key={id}>
                        <button
                          type="button"
                          onClick={() => {
                            handleSelectType(id as QRType);
                            navigate('home');
                          }}
                          className="hover:text-paper transition-colors text-left"
                        >
                          {label}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h2 className="text-[12px] font-bold mb-3 text-paper">Nach Branche</h2>
                  <ul className="space-y-2 text-[13px] text-paper/60">
                    {[
                      ['/qr-codes-fuer/unternehmen', 'Unternehmen'],
                      ['/qr-codes-fuer/schulen', 'Schulen und Bildung'],
                      ['/qr-codes-fuer/veranstaltungen', 'Veranstaltungen'],
                      ['/qr-codes-fuer/immobilien', 'Immobilien'],
                      ['/qr-codes-fuer/gesundheit', 'Gesundheit und Fitness'],
                      ['/qr-codes-auf', 'Druckerzeugnisse'],
                      ['/qr-code-generator', 'Alle QR-Typen'],
                      ['/standards', 'Normen und Pflichten'],
                    ].map(([href, label]) => (
                      <li key={href}>
                        <Link href={href} className="hover:text-paper transition-colors">
                          {label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h2 className="text-[12px] font-bold mb-3 text-paper">Lesen und Rechtliches</h2>
                  <ul className="space-y-2 text-[13px] text-paper/60">
                    <li>
                      <Link href="/anleitungen" className="hover:text-paper transition-colors">
                        Anleitung
                      </Link>
                    </li>
                    <li>
                      <Link href="/blog" className="hover:text-paper transition-colors">
                        Ratgeber
                      </Link>
                    </li>
                    <li>
                      <Link href="/vorlagen" className="hover:text-paper transition-colors">
                        Vorlagen
                      </Link>
                    </li>
                    <li>
                      <Link href="/wlan-qr-code" className="hover:text-paper transition-colors">
                        WLAN QR-Code
                      </Link>
                    </li>
                    <li>
                      <Link href="/qr-code-recht" className="hover:text-paper transition-colors">
                        QR-Code und Recht
                      </Link>
                    </li>
                    <li>
                      <Link href="/qr-code-funktioniert-nicht" className="hover:text-paper transition-colors">
                        Code wird nicht erkannt
                      </Link>
                    </li>
                    <li>
                      <Link href="/ueber-uns" className="hover:text-paper transition-colors">
                        Über dieses Werkzeug
                      </Link>
                    </li>
                    <li>
                      <Link href="/redaktion" className="hover:text-paper transition-colors">
                        Redaktionelle Richtlinien
                      </Link>
                    </li>
                    <li>
                      <button
                        type="button"
                        onClick={() => navigate('datenschutz')}
                        className="hover:text-paper transition-colors"
                      >
                        Datenschutz
                      </button>
                    </li>
                    <li>
                      <button
                        type="button"
                        onClick={() => navigate('impressum')}
                        className="hover:text-paper transition-colors"
                      >
                        Impressum
                      </button>
                    </li>
                    <li>
                      <button
                        type="button"
                        onClick={() => navigate('agb')}
                        className="hover:text-paper transition-colors"
                      >
                        AGB
                      </button>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="mt-12 pt-5 border-t border-paper/15 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <p className="spec text-[9px] text-paper/40">
                  QR-Generator Deutschland, kostenlos und ohne Konto
                </p>
                <p className="spec text-[9px] text-paper/40">
                  Codes werden lokal im Browser erzeugt
                </p>
              </div>
            </div>
          </footer>)}

          {/* Smartphone Scan Simulator Modal */}
          <ScanTestModal
            isOpen={isScanTestOpen}
            onClose={() => setIsScanTestOpen(false)}
            payload={payload}
            qrType={type}
            qrImageUrl={qrImageUrl}
          />

          {/* History Drawer Modal */}
          <HistoryDrawer
            isOpen={isHistoryOpen}
            onClose={() => setIsHistoryOpen(false)}
            history={history}
            onRestore={handleRestoreHistory}
            onClear={handleClearHistory}
            onDeleteOne={handleDeleteOneHistory}
          />

          {/* Cookie Consent Banner */}
          <CookieBanner onNavigate={navigate} compact={!chrome} />

          {/* Toast Notification Container */}
          <ToastContainer toasts={toasts} onDismiss={removeToast} />

          {/* Hidden Printable A4 Card Component (Activated during window.print()) */}
          <PrintableCard
            qrImageUrl={qrImageUrl}
            type={type}
            wifiData={wifiData}
            sepaData={sepaData}
            deliveryData={deliveryData}
            vcardData={vcardData}
          />

          {/* Consent-gated analytics (GA4/GTM/custom) */}
          <AnalyticsScripts />
        </div>
      </ErrorBoundary>
    </SiteContext.Provider>
    </UiProvider>
  );
}
