'use client';

/**
 * HomeView: the generator, not a landing page.
 *
 * The previous version opened with a full-height statement band, a twelve-hue
 * spectrum rule and a heading before the visitor reached a single input. That
 * looked like a poster and behaved like one: the thing people come for was a
 * scroll away. This version puts the tool in the first viewport.
 *
 * Order on a 900px-tall screen: a two-line masthead, the type row, then the
 * form on the left and the live preview on the right. On a phone the preview
 * comes first, so the code you are building is visible from the start.
 *
 * Visual language: washi paper, sumi ink, hairlines, one warm accent. The
 * per-type colours are the only saturated element, and they mean something.
 */
import React, { useEffect } from 'react';
import { QRTypeSelector } from './QRTypeSelector';
import { QRForm } from './QRForm';
import { QRCustomizer } from './QRCustomizer';
import { QRPreviewCard } from './QRPreviewCard';
import { ProgrammaticSeoSection } from './ProgrammaticSeoSection';
import { AdSlot } from './AdSlot';
import { useSite } from './SiteShell';
import { Download, History, ScanLine } from 'lucide-react';
import { QRType } from '../types/qr';
import { QR_TYPE_LABELS } from '../utils/translations';
import { typeColor } from '../lib/typeColor';
import { useUi } from './i18n/UiProvider';
import { typeLabel } from '../lib/i18n/ui/typeLabel';

/**
 * `showSeo` is false on a locale page: the German programmatic SEO block below
 * the instrument is German prose, and a localized page carries its own
 * translated sections instead.
 */
export function HomeView({ showSeo = true }: { showSeo?: boolean }) {
  const u = useUi();
  const site = useSite();
  const active = typeColor(site.type);

  // Preselect a QR type via /?type=wifi
  useEffect(() => {
    const requested = new URLSearchParams(window.location.search).get('type');
    if (requested && requested in QR_TYPE_LABELS) {
      site.handleSelectType(requested as QRType);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      {/* ------------------------------------------------------------------
          Masthead: two lines, no band, no colour rule
      ------------------------------------------------------------------ */}
      <section className="border-b border-rule">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 pt-7 pb-6 sm:pt-9 sm:pb-7">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-x-10 gap-y-4 items-end">
            <div className="lg:col-span-7">
              <p className="spec text-ink/45">{u['m.kicker']}</p>
              <h1 className="display text-[clamp(1.75rem,3.6vw,2.55rem)] mt-2.5 text-ink">{u['m.h1']}</h1>
            </div>
            <div className="lg:col-span-5">
              <p className="hidden sm:block text-[13.5px] leading-relaxed text-ink/60 lg:text-right">
                {u['m.lead']}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------------
          The instrument
      ------------------------------------------------------------------ */}
      <section className="max-w-[1440px] w-full mx-auto px-4 sm:px-6 lg:px-8 pt-5 pb-12">
        <QRTypeSelector currentType={site.type} onSelectType={site.handleSelectType} />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start mt-6">
          {/*
           * Preview first on a phone: the whole request was that the code is
           * visible without scrolling, and on a narrow screen that means above
           * the form, not beside it.
           */}
          <div className="lg:col-span-5 xl:col-span-4 lg:order-2 lg:sticky lg:top-[68px] space-y-4 min-w-0">
            <QRPreviewCard
              canvasRef={site.canvasRef}
              qrImageUrl={site.qrImageUrl}
              payload={site.payload}
              customization={site.customization}
              setCustomization={site.setCustomization}
              onOpenScanTest={site.openScanTest}
              onSaveToHistory={site.handleSaveToHistory}
              onNotify={site.addToast}
              onNavigateThankYou={() => site.navigate('danke')}
              isRendering={site.isRendering}
              accentColor={active.deep}
              accentVivid={active.hex}
              typeLabel={typeLabel(u, site.type)}
            />
          </div>

          {/* Left: input and appearance */}
          <div
            id="qr-form-section"
            className="lg:col-span-7 xl:col-span-8 lg:order-1 space-y-6 min-w-0"
          >
            <div
              className="qr-tool bg-paper border border-rule"
              style={{ borderTopWidth: 2, borderTopColor: active.hex }}
            >
              <div className="flex items-center justify-between gap-4 px-4 sm:px-5 py-2.5 border-b border-rule">
                <h2 className="text-[13px] font-semibold text-ink">{u['m.formTitle']}</h2>
                <span className="spec text-[9px] text-ink/40 hidden sm:block">{u['m.previewHint']}</span>
              </div>

              <div className="p-4 sm:p-5">
                <QRForm
                  type={site.type}
                  urlData={site.urlData}
                  setUrlData={site.setUrlData}
                  wifiData={site.wifiData}
                  setWifiData={site.setWifiData}
                  sepaData={site.sepaData}
                  setSepaData={site.setSepaData}
                  vcardData={site.vcardData}
                  setVcardData={site.setVcardData}
                  deliveryData={site.deliveryData}
                  setDeliveryData={site.setDeliveryData}
                  textData={site.textData}
                  setTextData={site.setTextData}
                  emailData={site.emailData}
                  setEmailData={site.setEmailData}
                  whatsappData={site.whatsappData}
                  setWhatsappData={site.setWhatsappData}
                  smsData={site.smsData}
                  setSmsData={site.setSmsData}
                  standortData={site.standortData}
                  setStandortData={site.setStandortData}
                  advanced={site.advanced}
                  setAdvanced={site.setAdvanced}
                  phoneData={site.phoneData}
                  setPhoneData={site.setPhoneData}
                  eventData={site.eventData}
                  setEventData={site.setEventData}
                  lang={site.lang}
                />
              </div>
            </div>

            <QRCustomizer customization={site.customization} setCustomization={site.setCustomization} />

            {/* Export facts, stated once, quietly */}
            <ul className="grid grid-cols-1 sm:grid-cols-3 gap-px bg-rule border border-rule">
              {[u['m.threeFacts1'], u['m.threeFacts2'], u['m.threeFacts3']].map((line) => (
                <li key={line} className="bg-paper px-4 py-3 text-[12px] leading-snug text-ink/70">
                  {line}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Ads keep their sanctioned slots; nothing renders without consent. */}
        {showSeo && (
          <>
            <div className="mt-10">
              <AdSlot position="below-hero" />
            </div>
            <AdSlot position="mid-content" />
          </>
        )}
      </section>

      {/* How it works, use cases, FAQ */}
      {showSeo && <ProgrammaticSeoSection />}

      {/* Mobile action bar: real actions only */}
      <div
        data-mobile-bar
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-ink text-paper border-t border-paper/20 px-3 py-2 on-ink"
        role="region"
        aria-label={u['m.quickActions']}
      >
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={site.openScanTest}
            aria-label={u['m.scanCheck']}
            className="flex items-center gap-2 h-11 min-w-0 flex-1 border border-paper/25 px-2 text-left"
          >
            <span className="w-7 h-7 bg-paper shrink-0 grid place-items-center">
              {site.qrImageUrl ? (
                <img
                  src={site.qrImageUrl}
                  alt={u['m.altSmall']}
                  className="w-full h-full object-contain"
                />
              ) : (
                <ScanLine className="w-4 h-4 text-ink" />
              )}
            </span>
            <span className="min-w-0">
              <span className="block text-[12px] font-semibold leading-tight truncate">{u['m.scanTest']}</span>
              <span className="block spec text-[9px] text-paper/50 truncate">
                {typeLabel(u, site.type)}
              </span>
            </span>
          </button>

          <button
            type="button"
            onClick={site.handleSaveToHistory}
            aria-label={u['m.saveHistory']}
            title={u['m.saveHistory']}
            className="grid place-items-center w-11 h-11 border border-paper/25 text-paper"
          >
            <History className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={site.downloadPng}
            className="inline-flex items-center gap-1.5 h-11 px-3.5 font-semibold text-[12px] bg-acid text-ink"
          >
            <Download className="w-4 h-4" />{u['m.download']}</button>
        </div>
      </div>

      {/* Room for the fixed bar so it never covers the footer */}
      <div className="h-16 lg:hidden" aria-hidden="true" />
    </>
  );
}
