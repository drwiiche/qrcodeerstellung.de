'use client';

/**
 * IroColorPicker — compact iro.js (@jaames/iro) color wheel + brightness
 * slider, used instead of the native browser color input.
 */
import React, { useEffect, useRef } from 'react';
import iro from '@jaames/iro';

interface IroColorPickerProps {
  value: string;
  onChange: (hex: string) => void;
  width?: number;
  label?: string;
}

/** Minimal structural view of an iro picker instance. */
interface IroInstance {
  color: { hexString: string };
  on: (event: string, cb: (color: { hexString: string }) => void) => void;
  destroy?: () => void;
}

type IroColorPickerCtor = new (
  parent: HTMLElement,
  props: Record<string, unknown>
) => IroInstance;

// The published typings expose ColorPicker as a factory; at runtime it is
// constructible with `new`, so we type the constructor ourselves.
const ColorPickerCtor = iro.ColorPicker as unknown as IroColorPickerCtor;

// iro 5.x does NOT resolve string layout names ("wheel" / "slider" — the
// bundle literally contains `// TODO: implement some?` for that shorthand),
// so they must be passed as the real UI components or nothing renders.
const layout = [
  { component: iro.ui.Wheel },
  { component: iro.ui.Slider, options: { sliderType: 'value' } },
] as unknown as Record<string, unknown>[];

export function IroColorPicker({ value, onChange, width = 126, label }: IroColorPickerProps) {
  const holderRef = useRef<HTMLDivElement | null>(null);
  const pickerRef = useRef<IroInstance | null>(null);
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  // Create the widget once per width.
  useEffect(() => {
    if (!holderRef.current) return;
    // Defensive: never mount a second widget on top of a previous one
    // (dev double-effects / HMR must not leave duplicates behind).
    holderRef.current.innerHTML = '';
    const picker = new ColorPickerCtor(holderRef.current, {
      width,
      color: value,
      borderWidth: 1,
      borderColor: '#e4e4e7',
      handleRadius: 6,
      wheelLightness: true,
      layout,
    });
    picker.on('color:change', (color) => {
      onChangeRef.current(color.hexString);
    });
    pickerRef.current = picker;
    return () => {
      try {
        picker.destroy?.();
      } catch {
        /* widget already gone */
      }
      // iro's destroy() does not remove the DOM it mounted (and React
      // StrictMode runs effects twice in dev), so clear it explicitly.
      if (holderRef.current) holderRef.current.innerHTML = '';
      pickerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width]);

  // Sync external value changes (presets, history restore) into the widget.
  useEffect(() => {
    const picker = pickerRef.current;
    if (!picker) return;
    if (picker.color.hexString.toLowerCase() !== value.toLowerCase()) {
      try {
        picker.color.hexString = value;
      } catch {
        /* invalid hex — keep widget state */
      }
    }
  }, [value]);

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div ref={holderRef} aria-label={label || 'Farbwähler'} style={{ width }} />
      {label && <span className="text-[11px] font-medium text-ink/60">{label}</span>}
    </div>
  );
}