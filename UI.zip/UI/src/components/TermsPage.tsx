'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, FileText, CheckCircle2 } from 'lucide-react';

export const TermsPage: React.FC = () => {
  const router = useRouter();
  const onNavigateHome = () => router.push('/');

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12">
      <button
        type="button"
        onClick={onNavigateHome}
        className="inline-flex items-center gap-1.5 text-xs font-bold text-accent hover:text-accent mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Zurück zum Generator</span>
      </button>

      <div className="bg-paper rounded-none border border-rule p-6 sm:p-10 space-y-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-ink tracking-tight mb-2">
            Allgemeine Nutzungsbedingungen (AGB)
          </h1>
          <p className="text-xs text-ink/60">
            Stand: 2026 · Für QR-Generator Deutschland
          </p>
        </div>

        <section className="space-y-3 text-xs sm:text-sm text-ink leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-ink border-b border-rule pb-2">
            § 1 Leistungsgegenstand und Bereitstellung
          </h2>
          <p>
            (1) <em>QR-Generator Deutschland</em> stellt dem Nutzer ein webbasiertes Software-Werkzeug zur clientseitigen Generierung von zweidimensionalen Barcodes (QR-Codes) zur Verfügung.
          </p>
          <p>
            (2) Die Nutzung der Basisfunktionen ist kostenlos. Alle erzeugten QR-Codes sind statisch: Es werden keine Weiterleitungs-Server (Redirects) zwischengeschaltet, sodass die Codes dauerhaft und zeitlich unbegrenzt funktionsfähig bleiben.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-ink leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-ink border-b border-rule pb-2">
            § 2 Nutzung für private und gewerbliche Zwecke
          </h2>
          <p>
            Die mit diesem Generator erstellten QR-Codes dürfen sowohl für private Zwecke (z. B. Gast-WLAN, Haustür-Hinweise, private Kontakte) als auch für gewerbliche Zwecke (z. B. Rechnungen mit SEPA GiroCode, Flyer, Speisekarten, Visitenkarten) lizenzfrei und ohne Lizenzgebühren verwendet werden.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-ink leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-ink border-b border-rule pb-2">
            § 3 Prüfpflicht des Nutzers vor Massendruck
          </h2>
          <p className="p-4 rounded-none bg-paper-2 border border-rule text-ink">
            <strong>Wichtiger Hinweis vor Druckaufträgen:</strong> Der Nutzer ist verpflichtet, vor der Vervielfältigung, dem Druck auf Werbemitteln oder dem Laminieren in größerer Stückzahl einen Probedruck und Test-Scans mit mehreren Smartphone-Modellen durchzuführen.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-ink leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-ink border-b border-rule pb-2">
            § 4 Gewährleistung und Haftung
          </h2>
          <p>
            (1) Die Dienste werden im Zustand „wie besehen“ (as is) und ohne Gewähr für eine unterbrechungsfreie Verfügbarkeit bereitgestellt.
          </p>
          <p>
            (2) Der Anbieter haftet unbeschränkt für Vorsatz und grobe Fahrlässigkeit. Eine Haftung für Folgeschäden durch fehlerhafte QR-Code-Eingaben oder unzureichende Scanbarkeit auf Fremdgeräten ist im gesetzlich zulässigen Rahmen ausgeschlossen.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-ink leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-ink border-b border-rule pb-2">
            § 5 Schlussbestimmungen
          </h2>
          <p>
            Es gilt das Recht der Bundesrepublik Deutschland. Sollten einzelne Bestimmungen dieser Bedingungen unwirksam sein, bleibt die Wirksamkeit der übrigen Bestimmungen hiervon unberührt.
          </p>
        </section>
      </div>
    </div>
  );
};
