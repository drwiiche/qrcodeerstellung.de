/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Wifi,
  Eye,
  EyeOff,
  CreditCard,
  Building,
  Info,
  Euro,
  HelpCircle,
  Truck,
  Plus,
  MapPin,
} from 'lucide-react';
import {
  QRType,
  URLData,
  WifiData,
  SepaData,
  VCardData,
  DeliveryData,
  TextData,
  EmailData,
  WhatsappData,
  SmsData,
  StandortData,
  PhoneData,
  EventData,
} from '../types/qr';
import { formatIbanDisplay } from '../utils/sepa';
import { validateIbanChecksum } from '../utils/security';
import { Language, TRANSLATIONS } from '../utils/translations';
import { AdvancedTypeForm } from './AdvancedTypeForm';
import { isAdvancedType } from '../lib/qrTypeSchema';
import { useUi } from './i18n/UiProvider';

interface QRFormProps {
  type: QRType;
  urlData: URLData;
  setUrlData: React.Dispatch<React.SetStateAction<URLData>>;
  wifiData: WifiData;
  setWifiData: React.Dispatch<React.SetStateAction<WifiData>>;
  sepaData: SepaData;
  setSepaData: React.Dispatch<React.SetStateAction<SepaData>>;
  vcardData: VCardData;
  setVcardData: React.Dispatch<React.SetStateAction<VCardData>>;
  deliveryData: DeliveryData;
  setDeliveryData: React.Dispatch<React.SetStateAction<DeliveryData>>;
  textData: TextData;
  setTextData: React.Dispatch<React.SetStateAction<TextData>>;
  emailData: EmailData;
  setEmailData: React.Dispatch<React.SetStateAction<EmailData>>;
  whatsappData: WhatsappData;
  setWhatsappData: React.Dispatch<React.SetStateAction<WhatsappData>>;
  smsData: SmsData;
  setSmsData: React.Dispatch<React.SetStateAction<SmsData>>;
  standortData: StandortData;
  setStandortData: React.Dispatch<React.SetStateAction<StandortData>>;
  /** Flat value map for every schema-driven type (mecard, social, payments). */
  advanced: Record<string, string>;
  setAdvanced: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  phoneData: PhoneData;
  setPhoneData: React.Dispatch<React.SetStateAction<PhoneData>>;
  eventData: EventData;
  setEventData: React.Dispatch<React.SetStateAction<EventData>>;
  lang: Language;
}

export const QRForm: React.FC<QRFormProps> = ({
  type,
  urlData,
  setUrlData,
  wifiData,
  setWifiData,
  sepaData,
  setSepaData,
  vcardData,
  setVcardData,
  deliveryData,
  setDeliveryData,
  textData,
  setTextData,
  emailData,
  setEmailData,
  whatsappData,
  setWhatsappData,
  smsData,
  setSmsData,
  standortData,
  setStandortData,
  advanced,
  setAdvanced,
  phoneData,
  setPhoneData,
  eventData,
  setEventData,
  lang,
}) => {
  const u = useUi();
  const [showWifiPass, setShowWifiPass] = useState(false);
  const t = TRANSLATIONS[lang];

  // ==================== URL FORM ====================
  if (type === 'url') {
    const isInvalidUrl = urlData.url.trim().length > 0 && !/^https?:\/\//i.test(urlData.url.trim());
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['url.label']}</label>
          <div className="relative">
            <input
              type="url"
              placeholder={u['url.ph']}
              value={urlData.url}
              onChange={(e) => setUrlData({ ...urlData, url: e.target.value })}
              className={`w-full px-4 py-2.5 rounded-none border bg-paper text-ink text-base sm:text-sm focus:outline-none transition ${
                isInvalidUrl
                  ? 'border-amber-400 ring-2 ring-amber-500/20 bg-amber-50/20'
                  : 'border-rule focus:ring-2 focus:ring-black focus:border-transparent'
              }`}
            />
          </div>
          {isInvalidUrl ? (
            <p className="mt-1.5 text-xs text-amber-700 font-medium flex items-center gap-1">
              <span>⚠️ Hinweis: Für direktes Öffnen im Handy-Browser sollte die URL mit <strong>https://</strong> beginnen.</span>
            </p>
          ) : (
            <p className="mt-1.5 text-xs text-ink/60">{u['url.hint']}</p>
          )}
        </div>

        {/* Quick German URL Presets */}
        <div className="pt-2">
          <span className="text-[11px] font-semibold text-ink/60 block mb-1.5">{u['url.templatesHead']}</span>
          <div className="flex flex-wrap gap-1.5">
            {[
              { label: 'Fritz!Box Router Menü', url: 'http://fritz.box' },
              { label: 'Telekom Router Menü', url: 'http://speedport.ip' },
              { label: 'Hausordnung & Kehrwoche', url: 'https://beispiel.de/hausordnung' },
              { label: 'Speisekarte / Café', url: 'https://beispiel-cafe.de/menu' },
            ].map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setUrlData({ url: p.url })}
                className="text-xs px-2.5 py-1 rounded-none bg-zinc-100 hover:bg-paper-2 text-ink font-medium transition cursor-pointer"
              >
                + {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ==================== WI-FI FORM ====================
  if (type === 'wifi') {
    const isSsidEmpty = !wifiData.ssid.trim();
    const isWpaPassTooShort =
      wifiData.encryption !== 'nopass' &&
      wifiData.password.length > 0 &&
      wifiData.password.length < 8;

    return (
      <div className="space-y-4">
        <div className="bg-paper-2 border border-rule rounded-none p-3.5 flex items-start gap-2.5">
          <Wifi className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
          <div className="text-xs text-ink">
            <p className="font-semibold">{u['url.compat']}</p>
            <p className="text-ink/60 mt-0.5">
              {u['wifi.info']}
            </p>
          </div>
        </div>

        {/* Router Quick Presets */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-ink/60">{u['url.routerLabel']}</span>
          <button
            type="button"
            onClick={() =>
              setWifiData({
                ...wifiData,
                ssid: 'FRITZ!Box Gastzugang',
                encryption: 'WPA',
                hidden: false,
              })
            }
            className="text-xs px-2.5 py-1 rounded-none bg-paper-2 text-ink border border-rule hover:bg-paper-2 font-medium transition cursor-pointer"
          >{u['url.fritz']}</button>
          <button
            type="button"
            onClick={() =>
              setWifiData({
                ...wifiData,
                ssid: 'Speedport-Gäste-WLAN',
                encryption: 'WPA',
                hidden: false,
              })
            }
            className="text-xs px-2.5 py-1 rounded-none bg-pink-50 text-pink-800 border border-pink-200 hover:bg-pink-100 font-medium transition cursor-pointer"
          >{u['url.speedport']}</button>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['wifi.ssid']}</label>
          <input
            type="text"
            placeholder={u['wifi.ssidPh']}
            value={wifiData.ssid}
            onChange={(e) => setWifiData({ ...wifiData, ssid: e.target.value })}
            className={`w-full px-4 py-2.5 rounded-none border bg-paper text-ink text-base sm:text-sm focus:outline-none transition ${
              isSsidEmpty
                ? 'border-rose-400 ring-2 ring-rose-500/20 bg-rose-50/20'
                : 'border-rule focus:ring-2 focus:ring-black'
            }`}
          />
          {isSsidEmpty && (
            <p className="mt-1 text-xs text-rose-600 font-medium">
              ⚠️ Der WLAN-Name (SSID) ist erforderlich, damit Smartphones das Netzwerk finden können.
            </p>
          )}
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['wifi.pass']}</label>
          <div className="relative">
            <input
              type={showWifiPass ? 'text' : 'password'}
              placeholder={u['wifi.passPh']}
              value={wifiData.password}
              onChange={(e) => setWifiData({ ...wifiData, password: e.target.value })}
              className={`w-full px-4 py-2.5 pr-10 rounded-none border bg-paper text-ink text-base sm:text-sm focus:outline-none transition ${
                isWpaPassTooShort
                  ? 'border-amber-400 ring-2 ring-amber-500/20 bg-amber-50/20'
                  : 'border-rule focus:ring-2 focus:ring-black'
              }`}
            />
            <button
              type="button"
              onClick={() => setShowWifiPass(!showWifiPass)}
              className="absolute right-3 top-1/2 -tranzinc-y-1/2 text-ink/60 hover:text-ink/60 cursor-pointer"
            >
              {showWifiPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {isWpaPassTooShort && (
            <p className="mt-1 text-xs text-amber-700 font-medium">
              ⚠️ WPA/WPA2-Verschlüsselung verlangt mindestens 8 Zeichen (Fritz!Box Standard: 16-20 Ziffern).
            </p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['wifi.enc']}</label>
            <select
              value={wifiData.encryption}
              onChange={(e) =>
                setWifiData({
                  ...wifiData,
                  encryption: e.target.value as 'WPA' | 'WEP' | 'nopass',
                })
              }
              className="w-full px-3.5 py-2 rounded-none border border-rule bg-paper text-ink text-sm focus:outline-none focus:ring-2 focus:ring-black"
            >
              <option value="WPA">{u['wifi.wpa']}</option>
              <option value="WEP">{u['wifi.wep']}</option>
              <option value="nopass">{u['wifi.open']}</option>
            </select>
          </div>

          <div className="flex items-center pt-6">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-ink">
              <input
                type="checkbox"
                checked={wifiData.hidden}
                onChange={(e) => setWifiData({ ...wifiData, hidden: e.target.checked })}
                className="w-4 h-4 rounded text-ink focus:ring-black border-rule"
              />{u['wifi.hidden']}</label>
          </div>
        </div>
      </div>
    );
  }

  // ==================== SEPA GIROCODE FORM ====================
  if (type === 'sepa') {
    return (
      <div className="space-y-4">
        <div className="bg-paper-2 border border-rule rounded-none p-3.5 flex items-start gap-2.5">
          <CreditCard className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
          <div className="text-xs text-ink">
            <p className="font-semibold">{u['sepa.official']}</p>
            <p className="text-ink/60 mt-0.5">
              Kompatibel mit Sparkasse, Volksbank, Deutsche Bank, Commerzbank, DKB, ING, Postbank & allen deutschen Banking Apps.
            </p>
          </div>
        </div>

        {/* Quick German SEPA Templates */}
        <div>
          <span className="text-[11px] font-semibold text-ink/60 block mb-1.5">{u['sepa.templatesHead']}</span>
          <div className="flex flex-wrap gap-1.5">
            {[
              {
                label: 'WG Miete & Nebenkosten',
                purpose: 'WG Miete Anteil Oktober',
                amount: '450.00',
              },
              {
                label: 'Rundfunkbeitrag (GEZ)',
                purpose: 'Beitragsnummer 123456789',
                amount: '55.08',
              },
              {
                label: 'Kaution / Stellplatz',
                purpose: 'Mietkaution Wohnung 3.OG',
                amount: '1200.00',
              },
              {
                label: 'Handwerkerrechnung',
                purpose: 'Rechnung Reparatur Heizung',
                amount: '185.50',
              },
            ].map((tmpl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() =>
                  setSepaData({
                    ...sepaData,
                    purpose: tmpl.purpose,
                    amount: tmpl.amount,
                  })
                }
                className="text-xs px-2.5 py-1 rounded-none bg-paper-2 text-ink border border-rule hover:bg-paper-2 font-medium transition cursor-pointer"
              >
                + {tmpl.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['sepa.name']}</label>
            <input
              type="text"
              placeholder={u['sepa.namePh']}
              value={sepaData.name}
              onChange={(e) => setSepaData({ ...sepaData, name: e.target.value })}
              className={`w-full px-4 py-2.5 rounded-none border bg-paper text-ink text-base sm:text-sm focus:outline-none transition ${
                !sepaData.name.trim()
                  ? 'border-rose-300 ring-2 ring-rose-500/10'
                  : 'border-rule focus:ring-2 focus:ring-black'
              }`}
            />
            {!sepaData.name.trim() && (
              <p className="mt-1 text-xs text-rose-600 font-medium">
                ⚠️ Empfängername ist für Banküberweisungen erforderlich.
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['sepa.amount']}</label>
            <div className="relative">
              <input
                type="text"
                placeholder={u['sepa.amountPh']}
                value={sepaData.amount}
                onChange={(e) => setSepaData({ ...sepaData, amount: e.target.value })}
                className="w-full px-4 py-2.5 pl-8 rounded-none border border-rule bg-paper text-ink text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-black "
              />
              <span className="absolute left-3 top-1/2 -tranzinc-y-1/2 text-ink/60 font-bold text-sm">
                €
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="sepa-iban-input" className="block text-xs font-bold uppercase tracking-wider text-ink/60">{u['sepa.iban']}</label>
              {(() => {
                const cleaned = sepaData.iban.replace(/\s+/g, '');
                if (cleaned.length >= 15) {
                  const check = validateIbanChecksum(sepaData.iban);
                  if (check.isValid) {
                    return (
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-none border border-emerald-200">
                        ✓ Gültige Prüfziffer
                      </span>
                    );
                  } else {
                    return (
                      <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-none border border-rose-200">
                        {check.message || 'Ungültige IBAN'}
                      </span>
                    );
                  }
                }
                return null;
              })()}
            </div>
            {(() => {
              const cleaned = sepaData.iban.replace(/\s+/g, '');
              const isInvalidIban = cleaned.length >= 15 && !validateIbanChecksum(sepaData.iban).isValid;
              return (
                <input
                  id="sepa-iban-input"
                  type="text"
                  placeholder={u['sepa.ibanPh']}
                  value={sepaData.iban}
                  onChange={(e) =>
                    setSepaData({ ...sepaData, iban: formatIbanDisplay(e.target.value) })
                  }
                  className={`w-full px-4 py-2.5 font-mono text-base sm:text-sm uppercase rounded-none border bg-paper text-ink focus:outline-none transition ${
                    isInvalidIban
                      ? 'border-rose-400 ring-2 ring-rose-500/20 bg-rose-50/20'
                      : 'border-rule focus:ring-2 focus:ring-black'
                  }`}
                />
              );
            })()}
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['sepa.bic']}</label>
            <input
              type="text"
              placeholder={u['sepa.bicPh']}
              value={sepaData.bic}
              onChange={(e) =>
                setSepaData({ ...sepaData, bic: e.target.value.toUpperCase() })
              }
              className="w-full px-4 py-2.5 font-mono text-sm uppercase rounded-none border border-rule bg-paper text-ink focus:outline-none focus:ring-2 focus:ring-black "
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['sepa.reference']}</label>
          <input
            type="text"
            placeholder={u['sepa.referencePh']}
            maxLength={140}
            value={sepaData.purpose}
            onChange={(e) => setSepaData({ ...sepaData, purpose: e.target.value })}
            className="w-full px-4 py-2.5 rounded-none border border-rule bg-paper text-ink text-sm focus:outline-none focus:ring-2 focus:ring-black "
          />
        </div>
      </div>
    );
  }

  // ==================== VCARD FORM ====================
  if (type === 'vcard') {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.first']}</label>
            <input
              type="text"
              placeholder={u['vcard.firstPh']}
              value={vcardData.firstName}
              onChange={(e) => setVcardData({ ...vcardData, firstName: e.target.value })}
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.last']}</label>
            <input
              type="text"
              placeholder={u['vcard.lastPh']}
              value={vcardData.lastName}
              onChange={(e) => setVcardData({ ...vcardData, lastName: e.target.value })}
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.mobile']}</label>
            <input
              type="tel"
              placeholder={u['vcard.mobilePh']}
              value={vcardData.mobile}
              onChange={(e) => setVcardData({ ...vcardData, mobile: e.target.value })}
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.email']}</label>
            <input
              type="email"
              placeholder={u['vcard.emailPh']}
              value={vcardData.email}
              onChange={(e) => setVcardData({ ...vcardData, email: e.target.value })}
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.company']}</label>
            <input
              type="text"
              placeholder={u['vcard.companyPh']}
              value={vcardData.organization}
              onChange={(e) =>
                setVcardData({ ...vcardData, organization: e.target.value })
              }
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.job']}</label>
            <input
              type="text"
              placeholder={u['vcard.jobPh']}
              value={vcardData.title}
              onChange={(e) => setVcardData({ ...vcardData, title: e.target.value })}
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.street']}</label>
            <input
              type="text"
              placeholder={u['vcard.streetPh']}
              value={vcardData.street}
              onChange={(e) => setVcardData({ ...vcardData, street: e.target.value })}
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['vcard.city']}</label>
            <input
              type="text"
              placeholder={u['vcard.cityPh']}
              value={vcardData.city ? `${vcardData.zip} ${vcardData.city}`.trim() : vcardData.zip}
              onChange={(e) => {
                const parts = e.target.value.split(' ');
                setVcardData({
                  ...vcardData,
                  zip: parts[0] || '',
                  city: parts.slice(1).join(' ') || '',
                });
              }}
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>
      </div>
    );
  }

  // ==================== DELIVERY / PAKETBOTE FORM ====================
  if (type === 'delivery') {
    return (
      <div className="space-y-4">
        <div className="bg-paper-2 border border-rule rounded-none p-3.5 flex items-start gap-2.5">
          <Truck className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
          <div className="text-xs text-ink">
            <p className="font-semibold">{u['delivery.head']}</p>
            <p className="text-ink/60 mt-0.5">
              Ideal für die Klingel oder den Briefkasten: DHL, Hermes, Amazon und DPD Boten sehen sofort, wo das Paket sicher abgelegt werden darf, wenn Sie im Home-Office sind.
            </p>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['delivery.name']}</label>
          <input
            type="text"
            placeholder={u['delivery.namePh']}
            value={deliveryData.recipientName}
            onChange={(e) =>
              setDeliveryData({ ...deliveryData, recipientName: e.target.value })
            }
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['delivery.place']}</label>
          <input
            type="text"
            placeholder={u['delivery.placePh']}
            value={deliveryData.deliveryLocation}
            onChange={(e) =>
              setDeliveryData({ ...deliveryData, deliveryLocation: e.target.value })
            }
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />

          {/* Quick location chips */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {[
              'Vor der Wohnungstür im Flur',
              'Im Carport hinter der Mülltonne',
              'In der Paketbox am Eingang',
              'Beim Nachbarn im Erdgeschoss',
              'Auf der überdachten Terrasse',
            ].map((loc, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setDeliveryData({ ...deliveryData, deliveryLocation: loc })}
                className="text-xs px-2.5 py-1 rounded-none bg-zinc-100 hover:bg-paper-2 text-ink font-medium transition cursor-pointer"
              >
                + {loc}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['delivery.phone']}</label>
            <input
              type="tel"
              placeholder={u['delivery.phonePh']}
              value={deliveryData.phone}
              onChange={(e) =>
                setDeliveryData({ ...deliveryData, phone: e.target.value })
              }
              className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['delivery.carriers']}</label>
            <div className="flex flex-wrap gap-2 pt-1">
              {['DHL', 'Hermes', 'Amazon', 'DPD', 'GLS'].map((srv) => {
                const checked = deliveryData.parcelServices.includes(srv);
                return (
                  <button
                    key={srv}
                    type="button"
                    onClick={() => {
                      if (checked) {
                        setDeliveryData({
                          ...deliveryData,
                          parcelServices: deliveryData.parcelServices.filter((s) => s !== srv),
                        });
                      } else {
                        setDeliveryData({
                          ...deliveryData,
                          parcelServices: [...deliveryData.parcelServices, srv],
                        });
                      }
                    }}
                    className={`text-xs px-2.5 py-1 rounded-none font-semibold border transition ${
                      checked
                        ? 'bg-black text-white border-black'
                        : 'bg-paper text-ink/60 border-rule hover:border-ink/30'
                    }`}
                  >
                    {srv}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['delivery.note']}</label>
          <input
            type="text"
            placeholder={u['delivery.notePh']}
            value={deliveryData.specialInstructions}
            onChange={(e) =>
              setDeliveryData({ ...deliveryData, specialInstructions: e.target.value })
            }
            className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  // ==================== WHATSAPP FORM ====================
  if (type === 'whatsapp') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['whatsapp.number']}</label>
          <input
            type="tel"
            placeholder={u['whatsapp.numberPh']}
            value={whatsappData.phoneNumber}
            onChange={(e) =>
              setWhatsappData({
                ...whatsappData,
                phoneNumber: e.target.value.replace(/[^0-9]/g, ''),
              })
            }
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1 text-xs text-ink/60">{u['whatsapp.hint']}</p>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['whatsapp.message']}</label>
          <textarea
            rows={3}
            placeholder={u['whatsapp.messagePh']}
            value={whatsappData.message}
            onChange={(e) =>
              setWhatsappData({ ...whatsappData, message: e.target.value })
            }
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  // ==================== SMS FORM ====================
  if (type === 'sms') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['sms.number']}</label>
          <input
            type="tel"
            placeholder={u['vcard.mobilePh']}
            value={smsData.phoneNumber}
            onChange={(e) => setSmsData({ ...smsData, phoneNumber: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1 text-xs text-ink/60">{u['sms.hint']}</p>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['sms.message']}</label>
          <textarea
            rows={3}
            placeholder={u['sms.messagePh']}
            value={smsData.message}
            onChange={(e) => setSmsData({ ...smsData, message: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1 text-xs text-ink/60">
            Der Gast tippt nach dem Scannen nur noch auf Senden – ideal für Bestell-SMS am Tisch oder auf Flyern.
          </p>
        </div>
      </div>
    );
  }

  // ==================== STANDORT FORM ====================
  if (type === 'standort') {
    const lat = parseFloat(standortData.latitude.replace(',', '.'));
    const lng = parseFloat(standortData.longitude.replace(',', '.'));
    const coordsValid =
      Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
    const mapsHref = coordsValid
      ? `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`
      : null;

    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['standort.label']}</label>
          <input
            type="text"
            placeholder={u['standort.labelPh']}
            value={standortData.label}
            onChange={(e) => setStandortData({ ...standortData, label: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['standort.lat']}</label>
            <input
              type="text"
              inputMode="decimal"
              placeholder={u['standort.latPh']}
              value={standortData.latitude}
              onChange={(e) =>
                setStandortData({ ...standortData, latitude: e.target.value.replace(/[^0-9.,-]/g, '') })
              }
              className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['standort.lon']}</label>
            <input
              type="text"
              inputMode="decimal"
              placeholder={u['standort.lonPh']}
              value={standortData.longitude}
              onChange={(e) =>
                setStandortData({ ...standortData, longitude: e.target.value.replace(/[^0-9.,-]/g, '') })
              }
              className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>

        {standortData.latitude && standortData.longitude && !coordsValid && (
          <p className="text-xs text-[#B31D00] font-semibold" role="alert">{u['standort.hint']}</p>
        )}

        <div className="flex items-start gap-2.5 rounded-none bg-paper-2 border border-rule p-3.5">
          <MapPin className="w-4 h-4 text-accent mt-0.5 shrink-0" />
          <p className="text-xs text-ink/60 leading-relaxed">
            Der Code öffnet nach dem Scannen die Koordinaten direkt in Google Maps (iOS &
            Android) – der ideale Wegweiser für Hauspartys, Hofeinfahrten, Ferienwohnungen
            oder Veranstaltungsorte. Koordinaten z. B. aus Google Maps per Rechtsklick auf die
            Karte ablesen.
          </p>
        </div>

        {mapsHref && (
          <p className="text-[11px] text-ink/60 font-mono break-all">
            Ziel: {mapsHref}
          </p>
        )}
      </div>
    );
  }

  // ==================== TEXT FORM ====================
  if (type === 'text') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['text.label']}</label>
          <textarea
            rows={4}
            placeholder={u['text.ph']}
            value={textData.text}
            onChange={(e) => setTextData({ text: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <div className="flex justify-between items-center mt-1 text-xs text-ink/60">
            <span>{u['text.hint']}</span>
            <span>{textData.text.length} Zeichen</span>
          </div>
        </div>

        {/* Quick German Home Storage Chips */}
        <div>
          <span className="text-[11px] font-semibold text-ink/60 block mb-1.5">{u['text.templatesHead']}</span>
          <div className="flex flex-wrap gap-1.5">
            {[
              {
                label: 'Umzugskarton Winterkleidung',
                text: 'Karton #12: Winterjacken, Schals, Skiausrüstung, Thermowäsche.',
              },
              {
                label: 'Kellerbox Werkzeug',
                text: 'Box A-3: Akkuschrauber, Dübel, Schrauben, Bohrmaschine.',
              },
              {
                label: 'Ferienwohnung Willkommen',
                text: 'Herzlich Willkommen in unserer Wohnung! Ruhezeiten: 22:00 - 07:00 Uhr. Müllentsorgung im Innenhof.',
              },
            ].map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setTextData({ text: p.text })}
                className="text-xs px-2.5 py-1 rounded-none bg-zinc-100 hover:bg-paper-2 text-ink font-medium transition cursor-pointer"
              >
                + {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ==================== EMAIL FORM ====================
  if (type === 'email') {
    const isInvalidEmail =
      emailData.email.trim().length > 0 &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailData.email.trim());

    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['email.to']}</label>
          <input
            type="email"
            placeholder={u['email.toPh']}
            value={emailData.email}
            onChange={(e) => setEmailData({ ...emailData, email: e.target.value })}
            className={`w-full px-4 py-2.5 rounded-none border text-base sm:text-sm focus:outline-none transition ${
              isInvalidEmail
                ? 'border-rose-400 ring-2 ring-rose-500/20 bg-rose-50/20'
                : 'border-rule focus:ring-2 focus:ring-black'
            }`}
          />
          {isInvalidEmail && (
            <p className="mt-1 text-xs text-rose-600 font-medium">
              ⚠️ Bitte geben Sie eine gültige E-Mail-Adresse ein (z. B. name@beispiel.de).
            </p>
          )}
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['email.subject']}</label>
          <input
            type="text"
            placeholder={u['email.subjectPh']}
            value={emailData.subject}
            onChange={(e) => setEmailData({ ...emailData, subject: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['email.body']}</label>
          <textarea
            rows={3}
            placeholder={u['email.bodyPh']}
            value={emailData.body}
            onChange={(e) => setEmailData({ ...emailData, body: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  // ==================== PHONE FORM ====================
  if (type === 'phone') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['phone.number']}</label>
          <input
            type="tel"
            placeholder={u['phone.numberPh']}
            value={phoneData.phoneNumber}
            onChange={(e) => setPhoneData({ phoneNumber: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
          <p className="mt-1.5 text-xs text-ink/60">{u['phone.hint']}</p>
        </div>
      </div>
    );
  }

  // ==================== EVENT FORM ====================
  if (type === 'event') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['event.title']}</label>
          <input
            type="text"
            placeholder={u['event.titlePh']}
            value={eventData.title}
            onChange={(e) => setEventData({ ...eventData, title: e.target.value })}
            className="w-full px-4 py-3 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['event.start']}</label>
            <input
              type="date"
              value={eventData.startDate}
              onChange={(e) => setEventData({ ...eventData, startDate: e.target.value })}
              className="w-full px-3.5 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1">{u['event.time']}</label>
            <input
              type="time"
              value={eventData.startTime}
              onChange={(e) => setEventData({ ...eventData, startTime: e.target.value })}
              className="w-full px-3.5 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-ink/60 mb-1.5">{u['event.location']}</label>
          <input
            type="text"
            placeholder={u['event.locationPh']}
            value={eventData.location}
            onChange={(e) => setEventData({ ...eventData, location: e.target.value })}
            className="w-full px-4 py-2 rounded-none border border-rule text-sm focus:ring-2 focus:ring-black focus:outline-none"
          />
        </div>
      </div>
    );
  }

  // ==================== SCHEMA-DRIVEN TYPES ====================
  /* mecard, the four social networks and the three payment formats all render
     from the field list in qrTypeSchema.ts. One branch instead of eight. */
  if (isAdvancedType(type)) {
    return <AdvancedTypeForm type={type} values={advanced} onChange={setAdvanced} />;
  }

  return null;
};
