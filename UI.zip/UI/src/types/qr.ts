/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type QRType =
  | 'url'
  | 'wifi'
  | 'sepa'
  | 'vcard'
  | 'delivery'
  | 'text'
  | 'email'
  | 'whatsapp'
  | 'sms'
  | 'standort'
  | 'phone'
  | 'event'
  /* Second wave, driven by a field schema rather than a hand-written form. */
  | 'mecard'
  | 'facebook'
  | 'twitter'
  | 'youtube'
  | 'instagram'
  | 'bitcoin'
  | 'paypal'
  | 'pix';

export type DotStyle = 'squares' | 'dots' | 'rounded' | 'classy';
export type CornerStyle = 'square' | 'rounded' | 'extra-rounded' | 'leaf';
export type FrameType = 'none' | 'bottom-bar' | 'top-bar' | 'speech-bubble' | 'badge-card';

export interface QRCustomization {
  foregroundColor: string;
  backgroundColor: string;
  useGradient: boolean;
  gradientColor: string;
  gradientType: 'linear' | 'radial';
  gradientAngle: number;
  dotStyle: DotStyle;
  cornerStyle: CornerStyle;
  eyeBorderColor: string;
  eyeCenterColor: string;
  errorCorrectionLevel: 'L' | 'M' | 'Q' | 'H';
  logoType: string;
  customLogoUrl?: string;
  logoSize: number; // 0.15 to 0.30
  frameType: FrameType;
  frameText: string;
  frameColor: string;
  frameTextColor: string;
  size: number; // Export size in px
  /** Uploaded design image behind the QR modules (data URL, JPEG). */
  backgroundImageUrl?: string;
  /** 0.15–0.6 — how strongly the background image shows through. */
  backgroundImageOpacity?: number;
  /** Average lightness of the uploaded background image (0–1), measured on upload. */
  bgImageLuminance?: number;
  /** Uploaded image rendered as the decorative border/card AROUND the quiet zone. */
  borderImageUrl?: string;
}

export interface URLData {
  url: string;
}

export interface WifiData {
  ssid: string;
  password: string;
  encryption: 'WPA' | 'WEP' | 'nopass';
  hidden: boolean;
  routerPreset?: 'fritzbox' | 'speedport' | 'vodafone' | 'custom';
}

export interface SepaData {
  name: string;
  iban: string;
  bic: string;
  amount: string;
  purpose: string;
  reference: string;
}

export interface VCardData {
  firstName: string;
  lastName: string;
  organization: string;
  title: string;
  phone: string;
  mobile: string;
  email: string;
  street: string;
  zip: string;
  city: string;
  country: string;
  website: string;
  note: string;
}

export interface DeliveryData {
  recipientName: string;
  deliveryLocation: string; // e.g. "Hinter der blauen Papiertonne im Carport"
  parcelServices: string[]; // DHL, Hermes, Amazon, DPD, GLS
  phone: string;
  specialInstructions: string;
}

export interface TextData {
  text: string;
}

export interface EmailData {
  email: string;
  subject: string;
  body: string;
}

export interface WhatsappData {
  phoneNumber: string;
  message: string;
}

export interface PhoneData {
  phoneNumber: string;
}

export interface SmsData {
  phoneNumber: string;
  message: string;
}

export interface StandortData {
  /** Grad, z. B. 52.520008 */
  latitude: string;
  /** Grad, z. B. 13.404954 */
  longitude: string;
  /** Beschriftung des Ziels (Ort, Treffpunkt, Ladenlokal …) */
  label: string;
}

export interface EventData {
  title: string;
  location: string;
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
  description: string;
}

export interface GermanCitySEO {
  slug: string;
  name: string;
  state: string;
  tagline: string;
  metaDescription: string;
  badge: string;
  stats: {
    homeOfficeRatio: string;
    fiberInternet: string;
    avgHouseholds: string;
  };
  popularUseCases: {
    title: string;
    desc: string;
    qrType: QRType;
    defaultData: Record<string, any>;
    customization?: Partial<QRCustomization>;
  }[];
  localTips: string[];
  faqs: {
    question: string;
    answer: string;
  }[];
}
